// FR24 LADD Unblocker 1.4.1 - the page-world part (see src/page.js)
(function () {
  'use strict';
  // ------------------------------------------------------------------------------------------------------------
  // PART 1 — PAGE-WORLD INTERCEPTOR (injected as a <script>; must be self-contained, no closures over the outside)
  // ------------------------------------------------------------------------------------------------------------
  function pageInterceptor() {
    'use strict';
    var NS = '__tweeksLaddBridge';
    var BRIDGE_V = "1.4.1";
    if (window[NS]) { try { window[NS].hello(); } catch (e) { /* ignore */ } return; }
    // the switches of the LADD Unblock window (the userscript's; kept in localStorage, so known here at document start,
    // and updated by an 'opts' message when one is changed): everything off - nothing of this part is installed but the
    // reading of FR24's own answers for the monitor (1.3: reportOnly, below)
    var opts = (function () { try { var o = JSON.parse(localStorage.getItem('tweeks.fr24.ladd.opts1') || 'null'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } })();
    var optOn = function (k) { return opts[k] !== false; };

    var resolved = new Map();     // fr24 flight id -> identity record (incl. photos)
    // The callsign shown: the one the transponder sends; when none is known yet, the registration the way a transponder
    // sends it - ICAO callsigns have no hyphen (I-ADVD flying on its registration is "IADVD", never "I-ADVD")
    var csOf = function (rec) { if (!rec) return ''; var c = String(rec.cs || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); return c || String(rec.reg || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); };
    var routes = new Map();       // fr24 flight id -> route / schedule / progress
    var telem = new Map();        // fr24 flight id -> live ADS-B telemetry { vr, sq, agps, ias, tas, mach, oat, wd, ws, mcp, at }
    var lastPos = new Map();      // fr24 flight id -> last position of a callsign-less flight seen in any feed
    var pbPos = new Map();        // the same, in FR24's playback (the moment being played)
    // FR24's own flights with no destination ("N/A") whose predicted one is good: on the airport boards like the rest
    var naRecs = new Map(), naRoutes = new Map();
    var recOf = function (id) { return resolved.get(id) || naRecs.get(id); }, routeOf = function (id) { return routes.get(id) || naRoutes.get(id); };
    var curNa = null;             // (while a LiveFeed answer is read: its N/A flights)
    // Flights FR24 names itself - its own registration in its feed - that had been taken for blocked ones (no callsign: the
    // transponder sends none, an easyJet on the stand after landing - G-EZWZ at Liverpool, 15 Oct): never drawn as ours
    var fr24Named = new Set(), curNamed = null;
    var hist = new Map();         // registration -> { data: [flight list entries], at } for the "Recent <reg> flights" dropdown
    var histWait = new Map();     // registration -> [resolve callbacks] waiting for the userscript to supply history
    var veils = {};               // (1.3.6) the page held hidden until it is built as it should be: veilOn
    var photoCache = new Map();   // HEX -> { photos, at, err, final } - the pictures shown (from the userscript)
    var psCache = new Map();      // HEX -> { photos, at, err } - Planespotters answers (the fallback source)
    var photoJobs = new Map();    // hex -> promise
    // (FR24's own requests, as they go - method, address, how it was asked - the last sixty, in memory only: what the page
    // asks for "Recent <reg> flights" and the like, readable in the console as __tweeksLaddBridge.stats.reqLog)
    var reqLog = [];
    function noteReq(how, method, url) {
      try { url = String(url || ''); if (!/flightradar24\.com|fr24\./i.test(url) || /\.(png|jpe?g|svg|webp|woff2?|css|js|mjs|map|ico)(\?|$)/i.test(url) || /\/tiles?\//i.test(url)) return;
        // (FR24's session token blanked out: the log is pasted into bug reports)
        reqLog.push((new Date().toISOString().slice(11, 19)) + ' ' + how + ' ' + (method || 'GET') + ' ' + url.replace(/^https?:\/\//, '').replace(/([?&]token=)[^&#]*/gi, '$1…').slice(0, 200)); if (reqLog.length > 60) reqLog.shift(); } catch (e) { /* ignore */ }
    }
    // FR24's list of an aircraft's flights ("Recent <reg> flights"): asked of api.flightradar24.com/common/v1 before, of
    // www.flightradar24.com/common/v2 then (with the session's token) - any FR24 host, any version, by registration.
    // (1.3.7) FR24's build of mid-November asks www.flightradar24.com/api/v2/flights - the same question (query, fetchBy,
    // filterBy, limit, page, timestamp, token) from the same caller: its blocked and military aircraft's lists, filled
    // here from the log, were empty again
    var REGLIST_RE = /(?:^|flightradar24\.com)\/(?:common\/v\d+\/flight\/list\.json|api\/v\d+\/flights)\?/i;
    // (its answer's list: { result: { response: { data, item, page, aircraftInfo } } } - and, should the new version
    // answer without the wrapping, the same object at the top or under `response`)
    function listRespOf(j) {
      if (!j || typeof j !== 'object') return null;
      if (j.result && j.result.response && typeof j.result.response === 'object') return j.result.response;
      if (j.response && typeof j.response === 'object' && ('data' in j.response || 'aircraftInfo' in j.response)) return j.response;
      if ('data' in j && ('aircraftInfo' in j || 'item' in j || 'page' in j)) return j;
      return null;
    }
    // (1.3.7) an answer with something in it, in no shape known - not an error's ({ message }, { error }, { errors }): FR24's
    // own, left as it is
    function listUnknown(j) { if (Array.isArray(j)) return j.length > 0; return !!j && typeof j === 'object' && Object.keys(j).length > 0 && !('error' in j) && !('errors' in j) && !('message' in j && Object.keys(j).length <= 3); }
    // (what an answer is made of - its keys, three deep, no values: readable in stats.lastList when it is in no shape known)
    function shapeOf(v, d) {
      if (Array.isArray(v)) return v.length ? [shapeOf(v[0], d)] : [];
      if (!v || typeof v !== 'object') return v === null ? null : typeof v;
      if (d >= 3) return '{…}';
      var o = {}; Object.keys(v).slice(0, 25).forEach(function (k) { o[k] = shapeOf(v[k], d + 1); }); return o;
    }
    var stats = { reqLog: reqLog, liveFeed: 0, follow: 0, patched: 0, errors: 0, lastError: '', maskPatched: 0, maskDisabled: false, scans: 0, searchHits: 0, boardHits: 0, details: 0, lists: 0, flightDetails: 0, boardRefreshes: 0, unlocked: 0 };
    var feedHeaders = null;       // request headers of FR24's own LiveFeed requests (device id, platform, ...)
    var enc = new TextEncoder();
    var fr24ImgSent = {};   // flight id -> FR24's own photos already handed to the userscript
    var dec = new TextDecoder();
    var oFetch = window.fetch;

    function post(type, payload) {
      var msg = Object.assign({ __tweeksLadd: type }, payload || {});
      try { window.postMessage(msg, location.origin); } catch (e) { /* ignore */ }
    }

    // ---- protobuf wire helpers -------------------------------------------------------------------------------
    function readVarint(b, p) { var r = 0, mul = 1, x; do { x = b[p++]; r += (x & 0x7f) * mul; mul *= 128; } while (x & 0x80); return [r, p]; }
    function varintBytes(n) { var o = []; n = Math.max(0, Math.floor(n)); do { var x = n % 128; n = Math.floor(n / 128); if (n) x |= 0x80; o.push(x); } while (n); return o; }
    // int32 fields encode negative numbers as 10-byte two's complement varints
    function varintInt32(n) {
      n = Math.round(n); if (n >= 0) return varintBytes(n);
      var v = (BigInt(1) << BigInt(64)) + BigInt(n), o = [];
      while (v >= BigInt(128)) { o.push(Number(v & BigInt(127)) | 0x80); v >>= BigInt(7); }
      o.push(Number(v)); return o;
    }
    function parse(b) {
      var out = [], p = 0;
      while (p < b.length) {
        var kv = readVarint(b, p), key = kv[0], q = kv[1];
        var fn = Math.floor(key / 8), wt = key & 7, end, val;
        if (wt === 0) { var v = readVarint(b, q); val = v[0]; end = v[1]; }
        else if (wt === 1) { end = q + 8; val = b.subarray(q, end); }
        else if (wt === 5) { end = q + 4; val = b.subarray(q, end); }
        else if (wt === 2) { var l = readVarint(b, q); end = l[1] + l[0]; val = b.subarray(l[1], end); }
        else throw new Error('wire type ' + wt);
        if (end > b.length) throw new Error('truncated');
        out.push({ fn: fn, wt: wt, val: val, raw: b.subarray(p, end) });
        p = end;
      }
      return out;
    }
    function concat(parts) { var n = 0, i; for (i = 0; i < parts.length; i++) n += parts[i].length; var o = new Uint8Array(n), p = 0; for (i = 0; i < parts.length; i++) { o.set(parts[i], p); p += parts[i].length; } return o; }
    function fLen(fn, bytes) { return concat([Uint8Array.from(varintBytes(fn * 8 + 2)), Uint8Array.from(varintBytes(bytes.length)), bytes]); }
    function fStr(fn, s) { return fLen(fn, enc.encode(String(s))); }
    function fVar(fn, n) { return Uint8Array.from(varintBytes(fn * 8).concat(varintBytes(n))); }
    function fInt(fn, n) { return Uint8Array.from(varintBytes(fn * 8).concat(varintInt32(n))); }
    // FR24 prints a squawk as the hex digits of its integer, so code 0570 travels as 0x0570 (not octal 0570 = 376)
    function squawkWire(sq) { return parseInt(Number(sq).toString(8), 16); }
    function fF32(fn, v) { var b = new Uint8Array(5); b[0] = fn * 8 + 5; new DataView(b.buffer).setFloat32(1, v, true); return b; }
    function f32(v) { return new DataView(v.buffer, v.byteOffset, 4).getFloat32(0, true); }
    function find(fs, fn) { for (var i = 0; i < fs.length; i++) if (fs[i].fn === fn) return fs[i]; return null; }
    function strOf(fs, fn) { var f = find(fs, fn); return f && f.wt === 2 && f.val.length ? dec.decode(f.val) : ''; }
    function numOf(fs, fn) { var f = find(fs, fn); return f && f.wt === 0 ? f.val : 0; }
    function fltOf(fs, fn) { var f = find(fs, fn); return f && f.wt === 5 ? f32(f.val) : NaN; }
    function has(fs, fn) { var f = find(fs, fn); if (!f) return false; if (f.wt === 2) return f.val.length > 0; if (f.wt === 0) return f.val !== 0; return true; }
    function frameHeader(flag, len) { return Uint8Array.of(flag, (len >>> 24) & 255, (len >>> 16) & 255, (len >>> 8) & 255, len & 255); }
    var fin = function (v) { return typeof v === 'number' && isFinite(v); };

    // ---- base64 (grpc-web-text: frames are individually padded; must decode in 4-char groups) ---------------
    var B64C = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var B64M = new Int16Array(256); for (var bi = 0; bi < 256; bi++) B64M[bi] = -1; for (bi = 0; bi < 64; bi++) B64M[B64C.charCodeAt(bi)] = bi; B64M[61] = 64;
    function b64DecodeInto(text, out) {
      for (var i = 0; i + 4 <= text.length; i += 4) {
        var a = B64M[text.charCodeAt(i)], b = B64M[text.charCodeAt(i + 1)], c = B64M[text.charCodeAt(i + 2)], d = B64M[text.charCodeAt(i + 3)];
        if (a < 0 || b < 0 || c < 0 || d < 0 || a === 64 || b === 64) throw new Error('bad base64');
        out.push((a << 2) | (b >> 4));
        if (c !== 64) { out.push(((b & 15) << 4) | (c >> 2)); if (d !== 64) out.push(((c & 3) << 6) | d); }
      }
    }
    function b64Encode(bytes) {
      var s = '', n = bytes.length;
      for (var i = 0; i < n; i += 3) {
        var a = bytes[i], b = i + 1 < n ? bytes[i + 1] : 0, c = i + 2 < n ? bytes[i + 2] : 0;
        s += B64C[a >> 2] + B64C[((a & 3) << 4) | (b >> 4)] + (i + 1 < n ? B64C[((b & 15) << 2) | (c >> 6)] : '=') + (i + 2 < n ? B64C[c & 63] : '=');
      }
      return s;
    }

    // (1.3) LADD Unblock switched off in its window: FR24 exactly as it is - nothing patched, nothing added, nothing asked
    // of the monitor. Only what FR24's own feed and boards show this page is read on its way past, to go to the monitor as
    // every browser's does (the flights on the map with no callsign, FR24's rows of a board): reportOnly
    if (!optOn('on')) { reportOnly(); return; }
    function reportOnly() {
      var LF = /fr24\.feed\.api\.v1\.Feed\/LiveFeed(?:$|\?)/, BOARD = /\/api\/v\d+\/airports\/(\d+)\/(departures|arrivals)(?:[?#]|$)/;
      var hdr = null;
      var hdrOf = function (h) { var o = {}; for (var k in h) if (Object.prototype.hasOwnProperty.call(h, k) && /^(fr24-[a-z0-9-]+|x-grpc-web|x-user-agent|content-type)$/i.test(k)) o[k] = String(h[k]); return o; };
      // (one LiveFeed answer: its flights with neither callsign nor registration - what the whole part reports of it)
      function feedMsg(body, at) {
        var fs = parse(body), out = [], serverTime = 0, total = 0;
        for (var i = 0; i < fs.length; i++) {
          var f = fs[i];
          if (f.wt === 2 && (f.fn === 1 || f.fn === 3)) {
            total++;
            var ff = parse(f.val), idF = find(ff, 1); if (!idF || idF.wt !== 0) continue;
            var exF = find(ff, 13), ex = exF && exF.wt === 2 ? parse(exF.val) : [];
            if (strOf(ff, 11) || strOf(ex, 2)) continue;
            out.push({ id: idF.val, lat: fltOf(ff, 2), lon: fltOf(ff, 3), trk: numOf(ff, 4), alt: numOf(ff, 5), spd: numOf(ff, 6), icon: numOf(ff, 7),
              ts: numOf(ff, 9), gnd: !!numOf(ff, 10), src: numOf(ff, 12), type: strOf(ex, 4), reg: '', sel: f.fn === 3 });
          } else if (f.fn === 4 && f.wt === 0) serverTime = f.val;
        }
        post('feed', { flights: out, na: [], named: [], serverTime: serverTime, total: total, at: at, bg: false, observe: true });
      }
      function frames(b, at) {
        var p = 0;
        while (p + 5 <= b.length) {
          var len = ((b[p + 1] << 24) | (b[p + 2] << 16) | (b[p + 3] << 8) | b[p + 4]) >>> 0, e = p + 5 + len;
          if (e > b.length) break;
          if (b[p] === 0) feedMsg(b.subarray(p + 5, e), at);
          p = e;
        }
      }
      function readFeed(x) {
        if (x.status !== 200) return;
        var at = Date.now(), rt = x.responseType;
        if (rt === 'arraybuffer') { if (x.response instanceof ArrayBuffer) frames(new Uint8Array(x.response), at); return; }
        if (rt && rt !== 'text') return;
        var t = String(x.responseText || ''), out = []; b64DecodeInto(t.slice(0, t.length - t.length % 4), out); frames(Uint8Array.from(out), at);
      }
      // (FR24's XMLHttpRequest and fetch wrapped, never changed: each request sent as FR24 made it, each answer FR24's own)
      var XP = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
      if (XP) {
        var oOpen0 = XP.open, oSet0 = XP.setRequestHeader, oSend0 = XP.send;
        XP.open = function (method, url) { try { this.__tlObs = LF.test(String(url)) ? {} : null; } catch (e) { /* ignore */ } return oOpen0.apply(this, arguments); };
        XP.setRequestHeader = function (k, v) { try { if (this.__tlObs) this.__tlObs[k] = v; } catch (e) { /* ignore */ } return oSet0.apply(this, arguments); };
        XP.send = function () {
          var x = this;
          try {
            if (x.__tlObs) {
              if (!hdr && x.__tlObs['fr24-device-id']) { hdr = hdrOf(x.__tlObs); post('feedReady', { hdr: hdr }); }
              x.addEventListener('load', function () { try { readFeed(x); } catch (e) { /* not one to read */ } });
            }
          } catch (e) { /* ignore */ }
          return oSend0.apply(this, arguments);
        };
      }
      if (typeof oFetch === 'function') {
        window.fetch = function (input) {
          var p = oFetch.apply(this, arguments);
          try {
            var url = typeof input === 'string' ? input : String((input && (input.url || input.href)) || ''), m = url.match(BOARD), pg = (url.match(/[?&]page=(-?\d+)/) || [])[1];
            if (m && (!pg || pg === '1' || pg === '-1')) {
              p.then(function (res) {
                if (!res || !res.ok) return;
                res.clone().json().then(function (j) {
                  var rows = j && Array.isArray(j.data) ? j.data.filter(function (e) { return e && e.flight && e.flight.id; }) : [];
                  if (rows.length) post('boardRows', { apId: Number(m[1]), kind: m[2], rows: rows });
                }, function () { /* not JSON */ });
              }, function () { /* FR24's to handle */ });
            }
          } catch (e) { /* ignore */ }
          return p;
        };
      }
      window[NS] = { observe: true, hello: function () { post('ready', { feedReady: !!hdr, hdr: hdr || {}, v: BRIDGE_V, observe: true }); } };
      window.addEventListener('message', function (ev) { if (ev.source === window && ev.data && ev.data.__tweeksLadd === 'hello') window[NS].hello(); });
      window[NS].hello();
    }

    // ---- LiveFeed request: make sure the field mask asks for type + reg ---------------------------------------
    // the map's view (the bounds FR24 asks its feed for): the userscript polls the aggregators for exactly this area
    var lastView = '', viewBox = null;
    function noteView(fs) {
      var bf = find(fs, 1); if (!bf || bf.wt !== 2) return;
      var q = parse(bf.val), v = { n: fltOf(q, 1), s: fltOf(q, 2), w: fltOf(q, 3), e: fltOf(q, 4) };
      if (!fin(v.n) || !fin(v.s) || !fin(v.w) || !fin(v.e)) return;
      var key = [v.n, v.s, v.w, v.e].map(function (x) { return x.toFixed(2); }).join(',');
      viewBox = v;      // (1.3.2: where the map is, whatever FR24's address says - oaView)
      if (key !== lastView) { lastView = key; post('view', v); }
    }
    // (1.2.1) A blocked flight's panel and search card ask FR24 with a "restriction mode" (field 2) a Basic account may not
    // use: FR24 then refuses outright ("Restriction mode not allowed!") and the search card shows N/A everywhere. Asked
    // without it, FR24 answers for a blocked flight as for any other (its type, its own model name, its position and track)
    // - checked against its server: the same request with field 2 refused, without it answered.
    function stripRestriction(body) {
      var b = body instanceof ArrayBuffer ? new Uint8Array(body) : (ArrayBuffer.isView(body) ? new Uint8Array(body.buffer, body.byteOffset, body.byteLength) : null);
      if (!b || b.length < 5 || b[0] !== 0) return body;
      var len = ((b[1] << 24) | (b[2] << 16) | (b[3] << 8) | b[4]) >>> 0;
      if (5 + len > b.length) return body;
      var fs = parse(b.subarray(5, 5 + len)), keep = [], cut = false;
      for (var i = 0; i < fs.length; i++) { if (fs[i].fn === 2 && fs[i].wt === 0 && fs[i].val) { cut = true; continue; } keep.push(fs[i].raw); }
      if (!cut) return body;
      stats.restrictionCut = (stats.restrictionCut || 0) + 1;
      var nb = concat(keep), out = concat([frameHeader(0, nb.length), nb, b.subarray(5 + len)]);
      return body instanceof ArrayBuffer ? out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength) : out;
    }
    function patchLiveFeedRequest(body) {
      var b = body instanceof ArrayBuffer ? new Uint8Array(body) : (ArrayBuffer.isView(body) ? new Uint8Array(body.buffer, body.byteOffset, body.byteLength) : null);
      if (!b || b.length < 5 || b[0] !== 0) return body;
      var len = ((b[1] << 24) | (b[2] << 16) | (b[3] << 8) | b[4]) >>> 0;
      if (5 + len > b.length) return body;
      var fs = parse(b.subarray(5, 5 + len)), paths = [], parts = [], i, hadMask = false;
      try { noteView(fs); } catch (e) { /* ignore */ }
      // (1.2.0) the aircraft categories unticked in FR24's filters window: left out of the categories its feed asks for
      // (FR24 asks for all of them for a Basic account; its server answers with only those asked for, for any account)
      var off = mx.on ? mxCategoriesOff() : null, catChanged = false;
      for (i = 0; i < fs.length; i++) {
        if (fs[i].fn === 10 && fs[i].wt === 2) { hadMask = true; var m = parse(fs[i].val); for (var j = 0; j < m.length; j++) if (m[j].fn === 1 && m[j].wt === 2) paths.push(dec.decode(m[j].val)); }
        else if (off && fs[i].fn === 2 && fs[i].wt === 2) {
          var sf = parse(fs[i].val), sp = [], cats = [];
          for (var k = 0; k < sf.length; k++) { if (sf[k].fn === 2 && sf[k].wt === 2) { for (var q = 0; q < sf[k].val.length;) { var rv = readVarint(sf[k].val, q); cats.push(rv[0]); q = rv[1]; } } else if (sf[k].fn === 2 && sf[k].wt === 0) cats.push(sf[k].val); else sp.push(sf[k].raw); }
          var keep = cats.filter(function (c) { return off.indexOf(c) < 0; });
          if (keep.length !== cats.length) { catChanged = true; stats.catPatched = (stats.catPatched || 0) + 1; sp.push(fLen(2, Uint8Array.from([].concat.apply([], keep.map(function (c) { return varintBytes(c); }))))); parts.push(fLen(2, concat(sp))); }
          else parts.push(fs[i].raw);
        }
        else parts.push(fs[i].raw);
      }
      var want = stats.maskDisabled ? [] : ['type', 'reg'], changed = false;
      for (i = 0; i < want.length; i++) if (paths.indexOf(want[i]) < 0) { paths.push(want[i]); changed = true; }
      if (!changed && !catChanged) return body;
      if (paths.length || hadMask) { var maskParts = []; for (i = 0; i < paths.length; i++) maskParts.push(fStr(1, paths[i])); parts.push(fLen(10, concat(maskParts))); }
      var nb = concat(parts), out = concat([frameHeader(0, nb.length), nb, b.subarray(5 + len)]);
      if (changed) stats.maskPatched++;
      return out;
    }

    // ---- public ADS-B telemetry of every ordinary aircraft in view (from the userscript's view poll) --------------------
    // keyed 'C'+callsign and 'R'+registration; a match must also be where FR24 draws the flight
    var pubTel = new Map(), pubTelPruned = 0;
    // hex (upper case) -> { o: owner / operator name, a: age in years, m: serial number, c: FR24 country id }: what the
    // userscript holds of ordinary aircraft, for their first frame (06 pubIds)
    var pubIds = new Map();
    var PT_NUM = ['vr', 'agps', 'ias', 'tas', 'mach', 'oat', 'wd', 'ws'];
    function acceptPubTel(rows) {
      var t = Date.now();
      for (var i = 0; i < (rows || []).length; i++) {
        var r = rows[i]; if (!r) continue;
        var e = { hex: r[2], lat: r[3], lon: r[4], at: r[5], vr: r[6], sqs: r[7] || '', sq: r[7] ? parseInt(r[7], 8) : 0, agps: r[8], ias: r[9], tas: r[10], mach: r[11], oat: r[12], wd: r[13], ws: r[14], air: r[15] || '', airId: r[16] || '', gnd: !!r[17], pub: true };
        for (var k = 0; k < PT_NUM.length; k++) if (e[PT_NUM[k]] == null) e[PT_NUM[k]] = NaN;
        if (r[2]) { var ph = pubTel.get('H' + String(r[2]).toLowerCase()); if (!ph || ph.at <= e.at) pubTel.set('H' + String(r[2]).toLowerCase(), e); }
        if (e.sq > 0 && !e.gnd) noteSq([r[2] ? 'H' + String(r[2]).toLowerCase() : '', r[0] ? 'C' + r[0] : '', r[1] ? 'R' + r[1] : ''], e.sq, e.at);
        if (r[0]) { var pc = pubTel.get('C' + r[0]); if (!pc || pc.at <= e.at) pubTel.set('C' + r[0], e); }
        if (r[1]) { var pr = pubTel.get('R' + r[1]); if (!pr || pr.at <= e.at) pubTel.set('R' + r[1], e); }
      }
      if (t - pubTelPruned > 60000) {
        pubTelPruned = t;
        pubTel.forEach(function (v, key) { if (t - v.at > 180000) pubTel.delete(key); });
        telem.forEach(function (v, key) { if (v.pub && t - v.at > 180000) telem.delete(key); });
      }
    }
    // The public figures at the very moment FR24's own data is for (the time its record or frame carries): between the two
    // public reports either side of it, what changes steadily - climb, heights, speeds - in proportion, the squawk, wind and
    // airspace from the nearer; FR24 ahead of everything heard, the latest. So they move with FR24's own figures, frame by frame.
    var telemHist = new Map(), TEL_NUM = ['vr', 'agps', 'ias', 'tas', 'mach', 'oat', 'ws'];
    function noteTelem(id, t) { if (!t || !(t.at > 0)) return; if (t.sq > 0 && !t.gnd) noteSq(['F' + id], t.sq, t.at); var h = telemHist.get(id) || []; if (!h.length || t.at > h[h.length - 1].at) { h.push(t); if (h.length > 40) h.shift(); } telemHist.set(id, h); if (telemHist.size > 300) telemHist.delete(telemHist.keys().next().value); }
    function telAt(id, tsS) {
      var last = telem.get(id), h = telemHist.get(id); if (!h || h.length < 2 || !(tsS > 0)) return last || null;
      var tms = tsS * 1000, i = 0; while (i < h.length && h[i].at < tms) i++;
      if (i >= h.length) return last || h[h.length - 1];
      if (i === 0) return h[0];
      var a = h[i - 1], b = h[i], f = (tms - a.at) / (b.at - a.at), near = f < 0.5 ? a : b; if (b.at - a.at > 60000) return near;
      var o = Object.assign({}, near); for (var k = 0; k < TEL_NUM.length; k++) { var x = a[TEL_NUM[k]], y = b[TEL_NUM[k]]; if (fin(x) && fin(y)) o[TEL_NUM[k]] = x + (y - x) * f; }
      o.at = b.at; return o;
    }
    function pubTelFor(cs, reg, lat, lon, hex) {
      cs = String(cs || '').toUpperCase(); reg = String(reg || '').toUpperCase(); hex = String(hex || '').toLowerCase();
      var e = (hex && pubTel.get('H' + hex)) || (cs && pubTel.get('C' + cs)) || (reg && pubTel.get('R' + reg));
      if (!e || Date.now() - e.at > (e.gnd ? 900000 : 90000)) return null;
      if (fin(lat) && fin(lon) && (lat || lon) && (Math.abs(lat - e.lat) > 0.6 || Math.abs(lon - e.lon) > 0.9)) return null;
      return e;
    }

    // ---- what FR24 padlocks, worked out where no public receiver has it ---------------------------------------------
    // The vertical speed from FR24's own altitudes as its feed brings them (two reports 20 s to 3 minutes apart; on the
    // ground, level), and the airspace from the FIR / UIR boundaries the userscript holds (asked for the flights in view
    // that have no public report, answered within a frame). Never a figure made up: what is not known stays empty.
    var altHist = new Map(), pbAltHist = new Map(), pbAltTs = 0;
    function altNote(m, id, ts, alt, gnd) {
      if (!(ts > 0) || !fin(alt)) return;
      var h = m.get(id); if (!h) { h = []; m.set(id, h); if (m.size > 8000) m.delete(m.keys().next().value); }
      // (in time order: the panel's trail - older points - comes in the same frame as its newest position, after it)
      var i = h.length; while (i > 0 && h[i - 1][0] > ts) i--;
      if (i > 0 && h[i - 1][0] === ts) return;
      h.splice(i, 0, [ts, alt, gnd ? 1 : 0]); if (h.length > 10) h.shift();
    }
    // (1.2.4) FR24's satellite and sparse positions - over an ocean, out of public coverage - come minutes apart: level the
    // whole time (within 100 ft) over up to half an hour is level flight, 0 fpm; a climb or descent seen over ten minutes at
    // most, its average rate. Wider apart and changing: not known
    function derivedVs(m, id) {
      var h = m.get(id); if (!h || !h.length) return NaN;
      var b = h[h.length - 1]; if (b[2]) return 0;
      for (var i = h.length - 2; i >= 0; i--) {
        var a = h[i], dt = b[0] - a[0]; if (dt < 20) continue;
        if (a[2]) return NaN;
        var d = b[1] - a[1];
        if (dt <= 180) return Math.round(d / (dt / 60) / 10) * 10;
        if (Math.abs(d) <= 100 && dt <= 1800) return 0;
        return dt <= 600 ? Math.round(d / (dt / 60) / 10) * 10 : NaN;
      }
      return NaN;
    }
    // (1.2.4) The squawk last heard of an aircraft in the air - a code ATC gives a flight and it keeps the whole way, but
    // for an emergency (FR24 shows those itself): FR24's padlock filled with it where no receiver hears the aircraft now.
    // Only one heard since this flight took off (the panel's trail says when), never a code of an earlier flight
    var lastSq = new Map(), sqAsked = new Map();
    function noteSq(keys, sq, at) {
      if (!(sq > 0) || !(at > 0)) return;
      for (var i = 0; i < keys.length; i++) { var k = keys[i]; if (!k) continue; var o = lastSq.get(k); if (!o || o.at <= at) lastSq.set(k, { sq: sq, at: at }); }
      if (lastSq.size > 20000) lastSq.delete(lastSq.keys().next().value);
    }
    function sqSince(keys, fromMs) {
      for (var i = 0; i < keys.length; i++) { var o = keys[i] && lastSq.get(keys[i]); if (o && o.at >= fromMs && Date.now() - o.at < 16 * 3600e3) return o.sq; }
      return 0;
    }
    function wantSq(hex) {
      if (!/^[0-9a-f]{6}$/.test(hex || '') || Date.now() - (sqAsked.get(hex) || 0) < 120000) return;
      sqAsked.set(hex, Date.now()); if (sqAsked.size > 4000) sqAsked.delete(sqAsked.keys().next().value);
      post('wantSq', { hex: hex });
    }
    // (1.2.7) The flight open in the panel, heard by no receiver now - an ocean, ADS-C by satellite: the code it was last
    // heard with since it took off (the panel's trail says when; with none, the last two hours), in FR24's own record of
    // it - the panel's squawk is read from there. Asked of the userscript once if not here (the monitor, else the
    // aircraft's public ADS-B record of the day)
    function lastSqFor(id, hex, cs, reg, gnd) {
      if (gnd || !followSt || followSt.id !== id) return 0;
      var from = followSt.t0 > 0 ? followSt.t0 * 1000 - 600000 : Date.now() - 2 * 3600e3;
      var sq = sqSince(['F' + id, /^[0-9a-f]{6}$/.test(hex || '') ? 'H' + hex : '', cs ? 'C' + String(cs).toUpperCase() : '', reg ? 'R' + reg : ''], from);
      if (!(sq > 0)) wantSq(hex);
      return sq > 0 ? sq : 0;
    }
    function onLastSq(d) { if (d && /^[0-9a-f]{6}$/.test(d.hex || '') && /^[0-7]{4}$/.test(String(d.sq || ''))) noteSq(['H' + d.hex], parseInt(d.sq, 8), Number(d.at) || 0); }
    // (FR24's playback: the altitudes of the moments played, apart from the live ones - started afresh on a jump)
    function altHistFor(pbTs) { if (!pbTs) return altHist; if (Math.abs(pbTs - pbAltTs) > 300) pbAltHist.clear(); pbAltTs = pbTs; return pbAltHist; }
    var airCache = new Map(), airAsked = new Map(), airWant = [];
    function airFor(id, lat, lon, alt) {
      var a = airCache.get(id); if (!a || !fin(lat) || !fin(lon)) return null;
      var fl = (fin(alt) ? Math.max(0, alt) : 0) / 100;
      if (Date.now() - a.at > 600000 || Math.abs(a.lat - lat) > 0.25 || Math.abs(a.lon - lon) > 0.4 || fl < a.lo || (fl >= a.hi && a.hi < 999)) return null;
      return a;
    }
    function wantAir(id, lat, lon, alt) {
      if (!fin(lat) || !fin(lon) || (lat === 0 && lon === 0) || Date.now() - (airAsked.get(id) || 0) < 30000) return;
      airAsked.set(id, Date.now()); if (airAsked.size > 8000) airAsked.delete(airAsked.keys().next().value);
      airWant.push([id, Math.round(lat * 1000) / 1000, Math.round(lon * 1000) / 1000, fin(alt) ? Math.round(alt) : 0]); if (airWant.length > 4000) airWant.splice(0, airWant.length - 4000);
    }
    function acceptAir(rows) {
      for (var i = 0; i < (rows || []).length; i++) { var r = rows[i]; if (!r || r[0] == null || !r[4]) continue; airCache.set(Number(r[0]), { lat: r[1], lon: r[2], name: r[4], code: r[5] || '', lo: fin(r[6]) ? r[6] : 0, hi: fin(r[7]) ? r[7] : 999, at: Date.now() }); }
      if (airCache.size > 8000) { var cut = Date.now() - 600000; airCache.forEach(function (v, k) { if (v.at < cut) airCache.delete(k); }); }
    }
    function flushAir() { if (airWant.length) post('airAsk', { rows: airWant.splice(0, 800) }); }
    // A flight FR24 shows a free account with padlocks (vertical speed, GPS altitude, airspeeds, Mach, wind, temperature,
    // squawk, airspace - its flags 17, 13, 16 and 18 in this record; the panel takes its padlocks from here): every flag
    // cleared, whatever is known put in - the public report of it (the view polled by this browser and the monitor in
    // turn), else the vertical speed from FR24's own altitudes and the airspace from the boundaries. Only a vertical
    // speed nothing yet tells keeps FR24's own way, for a flight's first seconds on screen (never a "0 fpm" made up).
    // (1.2.3) FR24's Flag label draws each aircraft's country of registration (extra info 8), which FR24's feed leaves out
    // for a Basic account: only the blocked aircraft named here - mostly N-registered, given theirs - had a flag. Worked out
    // here for every aircraft from its registration's prefix, else its transponder address's block (the userscript's
    // tables, as FR24's country ids)
    var ctyT = null;
    function onCtyTable(d) { if (d && Array.isArray(d.terr) && Array.isArray(d.nat) && Array.isArray(d.hex)) ctyT = { terr: d.terr, nat: d.nat, hex: d.hex, us: d.us | 0 }; }
    function ctyOf(reg, hx) {
      if (!ctyT) return 0;
      var r = String(reg || '').toUpperCase(), i, x;
      if (r) {
        for (i = 0; i < ctyT.terr.length; i++) { x = ctyT.terr[i]; if (r.indexOf(x[0]) === 0 && r.length > x[0].length + 1) return x[1]; }
        if (/^N[1-9]/.test(r) && ctyT.us) return ctyT.us;
        for (i = 0; i < ctyT.nat.length; i++) { x = ctyT.nat[i]; if (r.indexOf(x[0]) === 0 && r.length > x[0].length + 1 && (x[0].indexOf('-') >= 0 || r.indexOf('-') < 0)) return x[1]; }
      }
      if (hx > 0) { var lo = 0, hi = ctyT.hex.length - 1; while (lo <= hi) { var m = (lo + hi) >> 1, b = ctyT.hex[m]; if (hx < b[0]) hi = m - 1; else if (hx > b[1]) lo = m + 1; else return b[2]; } }
      return 0;
    }
    function unlockFeed(fb, fs, ex, extraF, id, cs, reg, pbTs) {
      if (!extraF || extraF.wt !== 2) return fb;
      var fts = numOf(fs, 9), lat = fltOf(fs, 2), lon = fltOf(fs, 3), gnd = !!numOf(fs, 10), alt = numOf(fs, 5);
      var hx = numOf(ex, 14), hexS = hx > 0 ? ('000000' + hx.toString(16)).slice(-6) : '';
      var tl0 = pbTs ? pbTelAt(id, fts || pbTs) : telAt(id, fts);
      if (!pbTs && (!tl0 || Date.now() - tl0.at > 90000) && (cs || reg || hexS)) { var pt0 = pubTelFor(cs, reg, lat, lon, hexS); if (pt0) { tl0 = pt0; telem.set(id, pt0); noteTelem(id, pt0); } }
      if (tl0 && Date.now() - tl0.at >= 90000) tl0 = null;
      var ah = altHistFor(pbTs); altNote(ah, id, fts, gnd ? 0 : alt, gnd);
      var vr = tl0 && fin(tl0.vr) ? tl0.vr : derivedVs(ah, id);
      var air = tl0 && tl0.air ? tl0.air : '', airId = air ? tl0.airId || '' : '';
      if (!air) { var ac0 = airFor(id, lat, lon, gnd ? 0 : alt); if (ac0) { air = ac0.name; airId = ac0.code; } else wantAir(id, lat, lon, gnd ? 0 : alt); }
      var sq = tl0 && tl0.sq > 0 && !has(ex, 5) ? tl0.sq : 0, ems = tl0 ? emsBytes(tl0) : null;
      if (!sq && !has(ex, 5) && !pbTs) sq = lastSqFor(id, hexS, cs, reg, gnd);
      var vsFlag = !fin(vr) && !has(ex, 6), exU = [], k0;
      for (k0 = 0; k0 < ex.length; k0++) { var fu = ex[k0].fn; if (fu === 13 || fu === 16 || fu === 18 || (fu === 17 && !vsFlag) || (fin(vr) && fu === 6) || (ems && fu === 12) || (sq && fu === 5) || (air && (fu === 11 || fu === 19))) continue; exU.push(ex[k0].raw); }
      if (fin(vr)) exU.push(fInt(6, Math.round(vr)));
      if (sq) exU.push(fVar(5, squawkWire(sq)));
      if (ems) exU.push(fLen(12, ems));
      if (air) { exU.push(fStr(11, air)); if (airId) exU.push(fStr(19, airId)); }   // FIR name + its ICAO code (the badge)
      if (!has(ex, 8)) { var cty = ctyOf(reg, hx); if (cty) { exU.push(fVar(8, cty)); stats.flags = (stats.flags || 0) + 1; } }
      var keepU = []; for (k0 = 0; k0 < fs.length; k0++) if (fs[k0].fn !== 13) keepU.push(fs[k0].raw);
      keepU.push(fLen(13, concat(exU)));
      stats.unlocked++;
      return concat(keepU);
    }

    // ---- (1.4.0) The icon FR24 draws an aircraft with: its own number for it, in every flight of its feed - learnt here by
    // type (the one most of a type are drawn with: an airline's own livery icon is not its type's) and by aircraft, and
    // kept in this page's storage. FR24's player of a flight of this script's is told it (mxPbFlightMsg): FR24 gives no
    // icon of a flight it does not know, and its player drew the aircraft as a Boeing 737 whatever it was
    var ICONS_KEY = 'tweeks.fr24.ladd.icons1', iconsT = {}, iconsH = new Map(), iconsDirty = false;
    try { var ic0 = JSON.parse(localStorage.getItem(ICONS_KEY) || 'null'); if (ic0 && ic0.t && typeof ic0.t === 'object') iconsT = ic0.t; if (ic0 && Array.isArray(ic0.h)) ic0.h.forEach(function (x) { if (Array.isArray(x) && /^[0-9a-f]{6}$/.test(x[0]) && x[1] > 0) iconsH.set(x[0], x[1]); }); } catch (e) { /* none kept */ }
    function iconNote(type, hexNum, icon, id) {
      if (!(icon > 0) || icon > 1000) return;
      if (type && /^[A-Z0-9]{2,4}$/.test(type)) {
        var c = iconsT[type] || (iconsT[type] = {}), k = String(icon);
        if ((c[k] || 0) < 50) { c[k] = (c[k] || 0) + 1; iconsDirty = true; }
      }
      var rr = !(hexNum > 0) && id ? resolved.get(id) : null, hx = hexNum > 0 ? ('000000' + hexNum.toString(16)).slice(-6) : rr && /^[0-9a-f]{6}$/i.test(rr.hex || '') ? String(rr.hex).toLowerCase() : '';
      if (hx && iconsH.get(hx) !== icon) { iconsH.delete(hx); iconsH.set(hx, icon); if (iconsH.size > 4000) iconsH.delete(iconsH.keys().next().value); iconsDirty = true; }
    }
    function iconFor(hex, type) {
      var h = String(hex || '').toLowerCase(), v = /^[0-9a-f]{6}$/.test(h) ? iconsH.get(h) : 0; if (v > 0) return v;
      var c = iconsT[String(type || '').toUpperCase()], best = 0, n = 0; if (!c) return 0;
      Object.keys(c).forEach(function (k) { if (c[k] > n) { n = c[k]; best = Number(k); } });
      return best > 0 ? best : 0;
    }
    window.setInterval(function () { if (!iconsDirty) return; iconsDirty = false; try { localStorage.setItem(ICONS_KEY, JSON.stringify({ v: 1, t: iconsT, h: Array.from(iconsH) })); } catch (e) { /* full or refused */ } }, 30000);

    // ---- LiveFeed response (Flight message, _common.proto) ----------------------------------------------------
    function patchFlight(fb, report, selected, at, readOnly, pbTs) {
      var fs = parse(fb), idF = find(fs, 1);
      if (!idF || idF.wt !== 0) return fb;
      var id = idF.val, cs = strOf(fs, 11);
      var extraF = find(fs, 13), ex = extraF && extraF.wt === 2 ? parse(extraF.val) : [];
      var type = strOf(ex, 4), reg = strOf(ex, 2);
      if (!pbTs) iconNote(type, numOf(ex, 14), numOf(fs, 7), id);
      // (FR24's own registration for it: not blocked - one taken for blocked (no callsign) let go, here and by the userscript)
      if (reg && (!cs || resolved.has(id))) { if (!fr24Named.has(id)) { fr24Named.add(id); if (fr24Named.size > 20000) fr24Named.delete(fr24Named.values().next().value); } if (resolved.has(id)) { resolved.delete(id); routes.delete(id); } if (curNamed && curNamed.length < 500) curNamed.push(id); }
      if (!cs && !reg) {
        var rep = { id: id, lat: fltOf(fs, 2), lon: fltOf(fs, 3), trk: numOf(fs, 4), alt: numOf(fs, 5), spd: numOf(fs, 6), icon: numOf(fs, 7),
          ts: numOf(fs, 9), gnd: !!numOf(fs, 10), src: numOf(fs, 12), type: type, reg: reg, sel: !!selected };
        if (report) report.push(rep);
        (pbTs ? pbPos : lastPos).set(id, { lat: rep.lat, lon: rep.lon, alt: rep.alt, gnd: rep.gnd, at: at });
      } else if (curNa && !resolved.has(id)) {
        // a flight FR24 identifies but has no destination for: reported for the boards' predictions
        var rtF = find(ex, 3), rt = rtF && rtF.wt === 2 ? parse(rtF.val) : [];
        if (!strOf(rt, 2)) {
          var na = { id: id, lat: fltOf(fs, 2), lon: fltOf(fs, 3), trk: numOf(fs, 4), alt: numOf(fs, 5), spd: numOf(fs, 6), ts: numOf(fs, 9), gnd: !!numOf(fs, 10), cs: cs, reg: reg, type: type, hex: numOf(ex, 14), from: strOf(rt, 1) };
          if (fin(na.lat) && fin(na.lon) && (na.lat || na.lon)) { curNa.push(na); lastPos.set(id, { lat: na.lat, lon: na.lon, alt: na.alt, gnd: na.gnd, at: at }); }
        }
      }
      if (readOnly) return fb;        // (a background scan's answer: read for its reports, never drawn)
      // An ordinary flight - or a blocked one not named yet: FR24's padlocks off, what is known put in (unlockFeed)
      if (cs || !resolved.get(id)) return unlockFeed(fb, fs, ex, extraF, id, cs, reg, pbTs);
      var rec = resolved.get(id); if (!rec) return fb;
      var label = csOf(rec); if (!label) return unlockFeed(fb, fs, ex, extraF, id, cs, reg, pbTs);
      var route = pbTs ? pbRoutes.get(id) : routes.get(id);
      var keep = [];
      for (var i = 0; i < fs.length; i++) if (fs[i].fn !== 11 && fs[i].fn !== 13) keep.push(fs[i].raw);
      keep.push(fStr(11, label));
      var exKeep = [];
      // (FR24's padlocks off here too, as for any flight: unlockFeed)
      var fts1 = numOf(fs, 9), lat1 = fltOf(fs, 2), lon1 = fltOf(fs, 3), gnd1 = !!numOf(fs, 10), alt1 = numOf(fs, 5);
      var tlL = pbTs ? pbTelAt(id, fts1 || pbTs) : telAt(id, fts1); if (tlL && Date.now() - tlL.at > 90000) tlL = null;
      var ahL = altHistFor(pbTs); altNote(ahL, id, fts1, gnd1 ? 0 : alt1, gnd1);
      var vrL = tlL && fin(tlL.vr) ? tlL.vr : derivedVs(ahL, id), vsFlagL = !fin(vrL) && !has(ex, 6), emsL = tlL ? emsBytes(tlL) : null;
      var airL = tlL && tlL.air || '', airIdL = airL ? tlL.airId || '' : '';
      if (!airL) { var acL = airFor(id, lat1, lon1, gnd1 ? 0 : alt1); if (acL) { airL = acL.name; airIdL = acL.code; } else wantAir(id, lat1, lon1, gnd1 ? 0 : alt1); }
      var sqL = (tlL && tlL.sq > 0 ? tlL.sq : rec.squawk) || 0; if (has(ex, 5)) sqL = 0;
      // (1.2.7: heard by nobody now - the code it was last heard with since it took off)
      if (!(sqL > 0) && !has(ex, 5) && !pbTs) sqL = lastSqFor(id, rec.hex || '', label, rec.reg || '', gnd1);
      for (i = 0; i < ex.length; i++) { var f = ex[i]; if ((f.fn === 2 && !f.val.length) || (f.fn === 14 && !f.val)) continue; if (f.fn === 13 || f.fn === 16 || f.fn === 18 || (f.fn === 17 && !vsFlagL) || (fin(vrL) && f.fn === 6) || (emsL && f.fn === 12)) continue; if (airL && (f.fn === 11 || f.fn === 19)) continue; exKeep.push(f.raw); }
      if (fin(vrL)) exKeep.push(fInt(6, Math.round(vrL)));
      if (emsL) exKeep.push(fLen(12, emsL));
      if (airL) { exKeep.push(fStr(11, airL)); if (airIdL) exKeep.push(fStr(19, airIdL)); }
      if (rec.reg && !has(ex, 2)) exKeep.push(fStr(2, rec.reg));
      if (rec.type && !has(ex, 4)) exKeep.push(fStr(4, rec.type));
      if (rec.hexNum && !has(ex, 14)) exKeep.push(fVar(14, rec.hexNum));
      if (rec.operatorId && !has(ex, 15)) exKeep.push(fVar(15, rec.operatorId));
      if (rec.operatorId && !has(ex, 10)) exKeep.push(fVar(10, rec.operatorId));
      if (rec.countryId && !has(ex, 8)) exKeep.push(fVar(8, rec.countryId));
      if ((rec.ageText || rec.age > 0) && !has(ex, 7)) exKeep.push(fStr(7, rec.ageText || (rec.age + (rec.age === 1 ? ' year' : ' years'))));
      if (sqL > 0) exKeep.push(fVar(5, squawkWire(sqL)));            // (no 16: squawkAvailability set is FR24's padlock)
      if (route && !has(ex, 3) && (route.originIata || route.destIata)) {
        var rp = []; if (route.originIata) rp.push(fStr(1, route.originIata)); if (route.destIata) rp.push(fStr(2, route.destIata));
        exKeep.push(fLen(3, concat(rp)));
      }
      if (exKeep.length) keep.push(fLen(13, concat(exKeep)));
      stats.patched++;
      return concat(keep);
    }
    var lastFeedTotal = 0;
    function patchLiveFeed(body, bg, pbTs) {
      var fs = parse(body), report = [], parts = [], changed = false, serverTime = 0, total = 0, at = Date.now();
      curNa = bg || pbTs ? null : []; curNamed = pbTs ? null : [];
      for (var i = 0; i < fs.length; i++) {
        var f = fs[i];
        if (f.wt === 2 && (f.fn === 1 || f.fn === 3)) {
          total++;
          if (pbTs && f.fn === 3) pbSelOf(f.val, pbTs);
          var nb = patchFlight(f.val, report, f.fn === 3, at, !!bg, pbTs);
          if (nb !== f.val) { changed = true; parts.push(fLen(f.fn, nb)); } else parts.push(f.raw);
        } else { if (f.fn === 4 && f.wt === 0) serverTime = f.val; parts.push(f.raw); }
      }
      // (FR24's playback: the moment's unnamed flights, for the userscript to name as they were then - never as live ones)
      if (pbTs) { post('pbFeed', { ts: pbTs, flights: report, at: at }); curNa = null; curNamed = null; flushAir(); return changed ? concat(parts) : body; }
      if (!bg) stats.liveFeed++;
      lastFeedTotal = total; flushAir();
      post('feed', { flights: report, na: curNa || [], named: curNamed || [], serverTime: serverTime, total: total, at: at, bg: !!bg });
      curNa = null; curNamed = null;
      return changed ? concat(parts) : body;
    }
    function patchFrames(buf, patchBody) {
      var b = new Uint8Array(buf), out = [], p = 0;
      while (p + 5 <= b.length) {
        var flag = b[p], len = ((b[p + 1] << 24) | (b[p + 2] << 16) | (b[p + 3] << 8) | b[p + 4]) >>> 0, s = p + 5, e = s + len;
        if (e > b.length) break;
        if (flag === 0) { var nb = patchBody(b.subarray(s, e)); out.push(frameHeader(0, nb.length), nb); } else out.push(b.subarray(p, e));
        p = e;
      }
      if (p < b.length) out.push(b.subarray(p));
      return concat(out).buffer;
    }

    // ---- FollowFlight (FollowFlightResponse: 1 AircraftInfo, 3 ScheduleInfo, 4 FlightProgress, 5 ExtendedFlightInfo, 6 trail)
    // Field numbers were read from FR24's generated protobuf code:
    //   AircraftInfo        1 icao 2 reg 3 countryOfReg 4 type 5 icon 6 fullDescription 7 msn 8 service 9 birthDate 10 age
    //                       11 images 12 isTestFlight 13 msnAvailable 14 ageAvailable 15 registeredOwners 16 countryAvailable
    //   ExtendedFlightInfo  1 id 2 lat 3 lon 4 track 5 alt 6 speed 7 status 8 tsMs 9 onGround 10 callsign 11 source
    //                       12 emsAvailability 13 emsInfo 14 squawkAvailability 15 squawk 16 vspeedAvailability 17 vspeed
    //                       18 airspaceAvailability 19 airspace 20 airspaceId 21 serverTimeMs
    //   EmsInfo             1 qnh 2 amcp 3 afms 4 oat 5 ias 6 tas 7 mach(x1000) 8 agps 9 agpsdiff 10 apflags 11 windDir 12 windSpd
    // FR24 draws a padlock (subscription upsell) wherever an "availability" flag is set. For values this script supplies
    // itself from public ADS-B, the flag is cleared, so the panel shows them as ordinary text.
    function emsBytes(t) {
      var e = [];
      if (fin(t.oat)) e.push(fInt(4, Math.round(t.oat)));
      if (fin(t.ias) && t.ias > 0) e.push(fInt(5, Math.round(t.ias)));
      if (fin(t.tas) && t.tas > 0) e.push(fInt(6, Math.round(t.tas)));
      if (fin(t.mach) && t.mach > 0) e.push(fInt(7, Math.round(t.mach * 1000)));
      if (fin(t.agps)) e.push(fInt(8, Math.round(t.agps)));
      if (fin(t.wd)) e.push(fInt(11, Math.round(t.wd)));
      if (fin(t.ws)) e.push(fInt(12, Math.round(t.ws)));
      return e.length ? concat(e) : null;
    }
    // The two messages that describe one flight in full share their parts, under different field numbers:
    //   FollowFlightResponse   1 AircraftInfo, 3 ScheduleInfo, 4 FlightProgress, 5 ExtendedFlightInfo, 6 trail (the panel)
    //   FlightDetailsResponse  1 AircraftInfo, 2 ScheduleInfo, 3 FlightProgress, 4 ExtendedFlightInfo    (the search card)
    var FOLLOW = { ai: 1, sched: 3, prog: 4, efi: 5, trail: 6, follow: true };
    var DETAILS = { ai: 1, sched: 2, prog: 3, efi: 4, trail: 0, follow: false };
    // FR24's map playback: a flight's panel as it was at a moment (PlaybackFlightResponse: 1 AircraftInfo, 2 ScheduleInfo,
    // 3 ExtendedFlightInfo, 4 trail points, 5 FlightProgress) - its route and figures are those of that moment
    var PLAYBACK = { ai: 1, sched: 2, efi: 3, trail: 4, prog: 5, follow: false, pb: true };
    var pbRoutes = new Map(), pbSent = {}, pbTrace = null;   // (the userscript's: each flight as flown; the open flight's track)
    // The figures FR24 padlocks, at the moment being played, from the open flight's ADS-B track: what changes steadily -
    // heights, speeds, climb - in proportion between two reports at most two minutes apart, the squawk and the wind from
    // the nearer. Rows: [t, alt, GPS alt, vertical rate, IAS, TAS, squawk, wind dir, wind speed, sent by the aircraft 1/0,
    // FIR name, FIR code, Mach, outside air temperature]
    function pbTelAt(id, ts) {
      var tr = pbTrace; if (!tr || tr.id !== id || !ts || !tr.pts.length) return null;
      var P = tr.pts, lo = 0, hi = P.length - 1; while (lo < hi) { var m = (lo + hi) >> 1; if (P[m][0] < ts) lo = m + 1; else hi = m; }
      var b = P[lo], a = P[lo - 1] || b; if (Math.abs(b[0] - ts) > 120 && Math.abs(a[0] - ts) > 120) return null;
      var f = b[0] > a[0] && ts > a[0] && ts < b[0] && b[0] - a[0] <= 120 ? (ts - a[0]) / (b[0] - a[0]) : (Math.abs(a[0] - ts) <= Math.abs(b[0] - ts) ? 0 : 1), near = f < 0.5 ? a : b;
      var mix = function (k) { var x = a[k], y = b[k]; return fin(x) && fin(y) ? x + (y - x) * f : fin(near[k]) ? near[k] : NaN; };
      var own = near[9] !== 0, n = function (v) { return fin(v) ? v : NaN; };
      return { vr: own ? mix(3) : NaN, agps: own ? mix(2) : NaN, ias: own ? mix(4) : NaN, tas: own ? mix(5) : NaN, mach: own ? mix(12) : NaN, oat: own ? mix(13) : NaN, wd: n(near[7]), ws: n(near[8]), sq: near[6] ? parseInt(near[6], 8) || 0 : 0, air: near[10] || '', airId: near[11] || '', at: Date.now() };
    }
    // FR24's playback - the map's, an aircraft's, a log's - moves its own figures (altitude, speed, track) along the open
    // flight's trail with its clock; the ones supplied here follow the same clock, set in the panel's own state each time the
    // clock moves - not only when FR24 asks for the panel again
    var pbTickTs = 0;
    function pbPanelTick() {
      if (!pbTrace) return; var pb = pinStore('playback'); if (!pb || !pb.active) return;
      var ac = pinStore('aircraft'), fi = ac && ac.selected && ac.selected.flightInfo, sid = pb.selectedFlightId; if (!fi) return;
      if (fi.flightId !== pbTrace.id && Number(sid) !== pbTrace.id && parseInt(String(sid), 16) !== pbTrace.id) return;
      var ts = pb.timestamp > 1e12 ? Math.round(pb.timestamp / 1000) : Math.round(pb.timestamp || 0); if (!ts || ts === pbTickTs) return; pbTickTs = ts;
      var t = pbTelAt(pbTrace.id, ts); if (!t) return;
      if (fin(t.vr)) fi.vspeed = Math.round(t.vr);
      if (t.sq > 0) fi.squawk = squawkWire(t.sq);
      if (t.air) { fi.airspace = t.air; if (t.airId) fi.airspaceId = t.airId; }
      var e = Object.assign({}, fi.emsInfo || {}), ch = false, set = function (k, v) { if (fin(v)) { e[k] = Math.round(v); ch = true; } };
      set('agps', t.agps); set('ias', t.ias > 0 ? t.ias : NaN); set('tas', t.tas > 0 ? t.tas : NaN); set('windDir', t.wd); set('windSpd', t.ws); set('oat', t.oat);
      // (Mach as the panel's state holds it: the wire's thousandths, as decoded - or, should a value already there be the
      // number itself, that)
      if (t.mach > 0) { e.mach = fin(e.mach) && e.mach > 0 && e.mach < 5 ? Math.round(t.mach * 1000) / 1000 : Math.round(t.mach * 1000); ch = true; }
      if (ch) fi.emsInfo = e;
    }
    setInterval(pbPanelTick, 250);
    // (the flight selected in FR24's playback, as its feed names it: its aircraft to the userscript at once, so the track for
    // its figures is in before FR24 asks for its panel)
    var pbSelSent = {};
    function pbSelOf(fb, ts) { try { var fs = parse(fb), id = numOf(fs, 1), exF = find(fs, 13), ex = exF && exF.wt === 2 ? parse(exF.val) : [], hx = numOf(ex, 14); if (!id || pbSelSent[id]) return; pbSelSent[id] = true; post('pbHex', { id: id, ts: ts, hex: hx > 0 ? ('000000' + hx.toString(16)).slice(-6) : '', reg: strOf(ex, 2), type: strOf(ex, 4), o: 0, d: 1, sel: true }); } catch (e) { /* ignore */ } }
    // (FR24's first panel answer of a flight opened in playback waits a moment - 1.5 s at most - for its track, so its
    // padlocked figures are there from the first draw)
    // (and for its route as flown - or word that there is none - so a flight FR24 has no destination for gets it in
    // FR24's own boxes from the first draw)
    var pbWaiters = [], pbRouteDone = new Set();
    function pbReady(id) { return !!pbTrace && pbTrace.id === id && (pbRoutes.has(id) || pbRouteDone.has(id)); }
    function whenPbReady(id, ms) { if (pbReady(id)) return Promise.resolve(); return new Promise(function (res) { var w = { id: id, res: res }; pbWaiters.push(w); oSetTimeout(function () { var i = pbWaiters.indexOf(w); if (i >= 0) { pbWaiters.splice(i, 1); res(); } }, ms); }); }
    function pbRelease() { pbWaiters = pbWaiters.filter(function (w) { if (pbReady(w.id)) { w.res(); return false; } return true; }); }
    function tsOf(body) { var b = bodyBytes(body); if (!b || b.length < 5) return 0; try { return numOf(parse(b.subarray(5)), 2); } catch (e) { return 0; } }
    // (FR24's own playback request asks for nothing of the flights but where they are: the aircraft type is asked for too
    // - one field: two or more it refuses - to tell a blocked aircraft's matches apart)
    function patchPlaybackRequest(body) {
      var b = bodyBytes(body); if (!b || b.length < 5 || b[0] !== 0) return body;
      var len = ((b[1] << 24) | (b[2] << 16) | (b[3] << 8) | b[4]) >>> 0; if (5 + len > b.length) return body;
      var fs = parse(b.subarray(5, 5 + len)), parts = [], changed = false;
      for (var i = 0; i < fs.length; i++) {
        var f = fs[i];
        if (f.fn === 1 && f.wt === 2) { var inner = parse(f.val), m = find(inner, 10); if (!m || (m.wt === 2 && !m.val.length)) { var keep = inner.filter(function (x) { return x.fn !== 10; }).map(function (x) { return x.raw; }); keep.push(fLen(10, fStr(1, 'type'))); parts.push(fLen(1, concat(keep))); changed = true; continue; } }
        parts.push(f.raw);
      }
      if (!changed) return body;
      var nb = concat(parts); return concat([frameHeader(0, nb.length), nb, b.subarray(5 + len)]);
    }
    // PlaybackResponse: 1 the LiveFeedResponse of that moment
    function patchPlayback(body, ts) {
      var fs = parse(body), parts = [], changed = false;
      for (var i = 0; i < fs.length; i++) { var f = fs[i]; if (f.fn === 1 && f.wt === 2) { var nb = patchLiveFeed(f.val, false, ts); if (nb !== f.val) { parts.push(fLen(1, nb)); changed = true; continue; } } parts.push(f.raw); }
      return changed ? concat(parts) : body;
    }
    var aiSent = {};   // flight id -> identity of a non-blocked aircraft already reported
    var modelSent = {};   // hex -> FR24's model name already reported
    var curFollowId = 0;   // the flight open in the panel (its stream)
    var followSt = null;   // that stream's state: { xhr, id, lastRest (FR24's latest schedule/progress/position), out ... }
    var schedSent = {};   // flight id -> FR24's own departure / arrival airport of an ordinary flight, as last reported
    // airport-data.com pictures (FR24's fallback when it has no JetPhotos one): never shown - JetPhotos / Planespotters
    // instead when there are any, otherwise no picture at all
    var AD_RE = /airport-data/i;
    // (nor FR24's stock picture of the type - a G550 that is not N50JE - credited to Flightradar24 itself, with no JetPhotos
    // page: taken for FR24's own photo of a blocked airframe, it kept the JetPhotos ones out of the panel and was kept as its
    // pictures. FR24's real pictures are JetPhotos', credited to their photographer)
    var STOCK_RE = /^\W*flightradar\s*24\W*$/i, JP_RE = /jetphotos/i;
    function adImg(im) { for (var k = 1; k <= 5; k++) if (AD_RE.test(strOf(im, k))) return true; return STOCK_RE.test(strOf(im, 2)) && ![1, 3, 4, 5].some(function (k) { return JP_RE.test(strOf(im, k)); }); }
    function adJson(o) {
      if (!o || typeof o !== 'object') return false;
      var jp = false, stock = false;
      for (var k in o) { if (typeof o[k] !== 'string') continue; if (AD_RE.test(o[k])) return true; if (JP_RE.test(o[k])) jp = true; if (/^(copyright|credit|photographer)$/i.test(k) && STOCK_RE.test(o[k])) stock = true; }
      return stock && !jp;
    }
    var aiKeep = {};   // flight id -> { val: FR24's aircraft block of the first frame, sig: the pictures it was sent with, ... }
    var photoSig = function (l) { return (l || []).slice(0, 3).map(function (p) { return p.large || p.medium || p.thumb || ''; }).join('|'); };
    function aiWanted(fid) {
      var k = aiKeep[fid]; if (!k || k.real) return false;
      var want = k.pubHex ? ourPhotosFor(k.pubHex) : (function () { var r = resolved.get(fid); if (!r) return []; var l = goodPhotos(shownPhotos(r)); return l.length ? l : goodPhotos((psCache.get(String(r.hex || '').toUpperCase()) || {}).photos); })();
      return want.length > 0 && photoSig(want) !== k.sig;
    }
    var fileKey = function (u) { return String(u || '').split('/').pop().replace(/\?.*$/, '').replace(/\.[a-z]+$/i, '').replace(/_(?:t|tb|\d{3,4})$/i, ''); };
    var shotKeyP = function (p) { return fileKey(p && (p.large || p.medium || p.thumb)); };
    var imgKeyA = function (im) { return fileKey(strOf(im, 5) || strOf(im, 4) || strOf(im, 3) || strOf(im, 1)); };
    var realImg = function (im) { return !adImg(im) && (has(im, 3) || has(im, 4) || has(im, 5)); };
    // JetPhotos' "cb" sizes have the photographer's credit bar burnt into the bottom of the picture: the same size without
    // "cb" is the clean photo (FR24 strips it on its own medium / large path, not on the thumbnail it takes verbatim)
    var noBar = function (u) { return typeof u === 'string' ? u.replace(/(\/\/cdn\.jetphotos\.com\/\d+)cb\//i, '$1/') : u; };
    function goodPhotos(l) { return (l || []).filter(function (p) { return p && !adJson(p); }).map(function (p) { return p.large === noBar(p.large) && p.medium === noBar(p.medium) && p.thumb === noBar(p.thumb) ? p : Object.assign({}, p, { large: noBar(p.large), medium: noBar(p.medium), thumb: noBar(p.thumb) }); }); }
    function ourPhotosFor(hexU) { var c = photoCache.get(hexU); var l = goodPhotos(c && c.photos); if (!l.length) l = goodPhotos((psCache.get(hexU) || {}).photos); return l; }
    // One slide of FR24's slideshow, in the shape of FR24's own JetPhotos pictures: url (1, the link), copyright (2), and
    // the picture as its thumbnail (3), medium (4) and large (5) - the one clean large picture in all three, so whichever
    // size FR24 draws a slide (or its dots) from, it is that one, as for any aircraft FR24 has pictures of. (Ours were
    // given as a thumbnail alone - a shape FR24's own pictures never have. FR24's medium / large path runs
    // .replace("cb", "") - right for JetPhotos' credit-bar sizes, and it would corrupt any other address with "cb" in it:
    // one such is given as its thumbnail only, as before.)
    function slide(link, credit, img) { return fLen(11, concat([fStr(1, link || img), fStr(2, credit || ''), fStr(3, img)].concat(img.indexOf('cb') < 0 ? [fStr(4, img), fStr(5, img)] : []))); }
    function photoParts(photos) {
      var out = [];
      for (var j = 0; j < photos.length && out.length < 3; j++) { var ph = photos[j], img = ph.large || ph.medium || ph.thumb; if (img) out.push(slide(ph.link, ph.credit, img)); }
      return out;
    }
    function patchFollow(body, st) { return patchFlightMsg(body, st, FOLLOW); }
    var pushT = 0;
    function pushFollowSoon() { if (!pushT) pushT = oSetTimeout(function () { pushT = 0; pushFollow(); }, 40); }
    function pushFollow() {
      var s = followSt; if (!s || !s.xhr || s.broken || !s.lastRest || !s.id || s.xhr.readyState !== 3) return false;
      var k = aiKeep[s.id], body = k && k.val ? concat([fLen(FOLLOW.ai, k.val), s.lastRest]) : s.lastRest, nb;
      s.synth = true;
      try { nb = patchFlightMsg(body, s, FOLLOW); } catch (e) { stats.errors++; stats.lastError = String(e); return false; } finally { s.synth = false; }
      s.out += b64Encode(concat([frameHeader(0, nb.length), nb]));
      stats.pushed = (stats.pushed || 0) + 1;
      try { s.xhr.dispatchEvent(new Event('readystatechange')); } catch (e) { /* ignore */ }
      return true;
    }
    function photosChanged() { var s = followSt; if (s && s.id && aiWanted(s.id)) pushFollowSoon(); }
    function patchFlightMsg(body, st, F) {
      var fs = parse(body);
      if (F.follow && !st.synth && has(fs, F.efi)) { var rest = []; for (var ri = 0; ri < fs.length; ri++) if (fs[ri].fn === F.sched || fs[ri].fn === F.prog || fs[ri].fn === F.efi) rest.push(fs[ri].raw); st.lastRest = concat(rest); }
      // (pictures that arrived after the first frame: the aircraft block goes again, with all of them)
      if (F.follow && st.id && !has(fs, F.ai) && aiWanted(st.id)) return patchFlightMsg(concat([fLen(F.ai, aiKeep[st.id].val), body]), st, F);
      var fiF = find(fs, F.efi);
      var fid = st.id, fi0 = null;
      if (fiF && fiF.wt === 2) {
        fi0 = parse(fiF.val); var idv = numOf(fi0, 1); if (idv) fid = idv;
        // (its altitudes as the panel's stream brings them - every second or two: its vertical speed where no receiver has it)
        if (fid && !st.synth) altNote(F.pb ? altHistFor(st.ts) : altHist, fid, Math.round(numOf(fi0, 8) / 1000), numOf(fi0, 9) ? 0 : numOf(fi0, 5), !!numOf(fi0, 9));
        if (F.follow && !st.synth) post('pos', { id: fid, lat: fltOf(fi0, 2), lon: fltOf(fi0, 3), trk: numOf(fi0, 4), alt: numOf(fi0, 5), spd: numOf(fi0, 6), gnd: !!numOf(fi0, 9), tsMs: numOf(fi0, 8), serverMs: numOf(fi0, 21), at: Date.now() });
      }
      if (F.follow && fid !== st.id && fid && !st.synth) { st.id = fid; curFollowId = fid; post('follow', { id: fid }); }
      if (F.follow && fid) curFollowId = fid;
      // FR24's own trail of this flight: where it began, how high it has been, and the path so far.
      var pts = [], maxAlt = 0;
      // (1.2.9: FR24's playback's too - where a blocked flight it plays took off, which public ADS-B may never have heard)
      for (var ti = 0; F.trail && ti < fs.length; ti++) {
        if (fs[ti].fn !== F.trail || fs[ti].wt !== 2) continue;
        try {
          var tp = parse(fs[ti].val), talt = numOf(tp, 4);
          if (talt > 2147483647) talt = 0;
          if (talt > maxAlt) maxAlt = talt;
          pts.push({ t: numOf(tp, 1), lat: fltOf(tp, 2), lon: fltOf(tp, 3), alt: talt, gs: numOf(tp, 5), trk: numOf(tp, 6) });
        } catch (e) { /* ignore */ }
      }
      if (pts.length && fid) {
        pts.sort(function (a, b) { return a.t - b.t; });
        if (F.follow && pts[0].t > 0) st.t0 = pts[0].t;
        // (the trail's last minutes: a vertical speed from the first frame of the panel)
        if (!F.pb) for (var tq = Math.max(0, pts.length - 12); tq < pts.length; tq++) altNote(altHist, fid, pts[tq].t, pts[tq].alt, !(pts[tq].alt > 0));
        // every 15 s for the take-off (first 30 min) and the last hour, every 90 s in between - so a long flight's
        // departure (where it took off from) is never cut off, whatever its length
        var thin = [], t0 = pts[0].t, tN = pts[pts.length - 1].t;
        for (var k = 0; k < pts.length; k++) { var step = pts[k].t - t0 < 1800 || tN - pts[k].t < 3600 ? 15 : 90; if (!thin.length || pts[k].t - thin[thin.length - 1].t >= step || k === pts.length - 1) thin.push(pts[k]); }
        if (thin.length > 1000) { var head = thin.slice(0, 150), tail = thin.slice(-600), mid = thin.slice(150, -600), every = Math.ceil(mid.length / 250); thin = head.concat(mid.filter(function (_, i) { return i % every === 0; }), tail); }
        post('trail', { id: fid, first: pts[0], n: pts.length, maxAlt: maxAlt, pts: thin, at: Date.now(), pb: !!F.pb });
      }
      // (1.2.4: the aircraft's address and registration, for the squawk it was last heard with)
      if (F.follow) { var aiS = find(fs, F.ai); if (aiS && aiS.wt === 2) { var aiSf = parse(aiS.val), hxS = numOf(aiSf, 1); if (hxS > 0) st.hex = ('000000' + hxS.toString(16)).slice(-6); var rgS = strOf(aiSf, 2); if (rgS) st.reg = rgS.toUpperCase(); } }
      var rec = fid ? resolved.get(fid) : null;
      var route = fid ? (F.pb ? pbRoutes.get(fid) : routes.get(fid)) : null;
      var efiTs = fi0 ? Math.round(numOf(fi0, 8) / 1000) : 0, tl = fid ? (F.pb ? pbTelAt(fid, efiTs || st.ts) : telAt(fid, efiTs)) : null; if (tl && Date.now() - tl.at > 90000) tl = null;
      // (the flight opened in FR24's playback: the userscript is told which aircraft it is, and whether FR24 has its route)
      if (F.pb && fid && !pbSent[fid]) { var aiB = find(fs, F.ai), scB = find(fs, F.sched); if (aiB && aiB.wt === 2) { var a1 = parse(aiB.val), sc1 = scB && scB.wt === 2 ? parse(scB.val) : [], hx1 = numOf(a1, 1); pbSent[fid] = true; post('pbHex', { id: fid, ts: st.ts, hex: hx1 > 0 ? ('000000' + hx1.toString(16)).slice(-6) : '', reg: strOf(a1, 2), type: strOf(a1, 4), o: numOf(sc1, 4), d: numOf(sc1, 5) }); } }
      // an ordinary flight not yet matched in the feed (opened from a link): its view-poll telemetry, by callsign
      if (!F.pb && !tl && !rec && fi0 && fid) { var ptf = pubTelFor(strOf(fi0, 10), '', fltOf(fi0, 2), fltOf(fi0, 3)); if (ptf) { tl = ptf; telem.set(fid, ptf); noteTelem(fid, ptf); } }
      // What FR24 itself knows of an ordinary flight's route (its own departure / arrival airport ids, before anything is
      // added): a flight it shows without a destination gets the userscript's reasoned one, a flight it has a route for
      // is left alone. Read from the full frames (those carrying the aircraft block), whatever the later updates omit.
      if (F.follow && fid && !rec && !st.synth && (has(fs, F.ai) || has(fs, F.sched))) {
        // (with its times and flight number: a schedule with times but no airports is a flight FR24 has not matched yet -
        // a crew already on the next callsign at the gate - not the flight that has just landed)
        var scF = find(fs, F.sched), so = 0, sd = 0, sstd = 0, ssta = 0, satd = 0, sata = 0, snum = '', prevS = String(schedSent[fid] || '0:0').split(':');
        if (scF && scF.wt === 2) { var sc0 = parse(scF.val); so = numOf(sc0, 4); sd = numOf(sc0, 5); sstd = numOf(sc0, 7); ssta = numOf(sc0, 8); satd = numOf(sc0, 9); sata = numOf(sc0, 10); snum = strOf(sc0, 1) || ''; }
        if (!has(fs, F.ai)) { so = so || Number(prevS[0]) || 0; sd = sd || Number(prevS[1]) || 0; sstd = sstd || Number(prevS[2]) || 0; satd = satd || Number(prevS[3]) || 0; }
        var skey = so + ':' + sd + ':' + sstd + ':' + satd;
        if (schedSent[fid] !== skey) { schedSent[fid] = skey; post('sched', { id: fid, o: so, d: sd, std: sstd, sta: ssta, atd: satd, ata: sata, num: snum }); }
      }
      // Any aircraft opened in the panel - blocked or not - is reported with its identity, so the userscript can fetch
      // public ADS-B telemetry and registry data for the fields FR24 keeps behind a padlock.
      if (F.follow && fid && !rec && !aiSent[fid]) {
        var aiF = find(fs, F.ai);
        if (aiF && aiF.wt === 2) {
          var a0 = parse(aiF.val), hx0 = numOf(a0, 1);
          if (hx0 > 0) {
            aiSent[fid] = true;
            var adOnly = a0.some(function (x) { return x.fn === 11 && adImg(parse(x.val)); });
            var realN = a0.filter(function (x) { return x.fn === 11 && realImg(parse(x.val)); }).length;
            // (1.2.1: its serial number and date of manufacture as FR24's record holds them, 7 and 9 - and its age, 10 -
            // whatever FR24's panel then padlocks)
            var bf = find(a0, 9);
            post('aircraftInfo', { id: fid, hex: ('000000' + hx0.toString(16)).slice(-6), reg: strOf(a0, 2), type: strOf(a0, 4), cs: fi0 ? strOf(fi0, 10) : '', adPhotos: adOnly,
              msn: strOf(a0, 7), birth: bf ? (bf.wt === 2 ? strOf(a0, 9) : numOf(a0, 9)) : '', age: find(a0, 10) ? (find(a0, 10).wt === 2 ? strOf(a0, 10) : numOf(a0, 10)) : '' });
            if (adOnly || realN < 3) photosFor({ hex: ('000000' + hx0.toString(16)).slice(-6), reg: strOf(a0, 2) }, true);
          }
        }
      }
      // (1.2.1) FR24's own name for the model (6, "Raytheon Hawker 750") - given for a blocked aircraft too: kept for it, so
      // its board cards and search say the same as its panel (not a database's "HAWKER BEECHCRAFT Hawker 750/850")
      var aiM = F.follow ? find(fs, F.ai) : null;
      if (aiM && aiM.wt === 2) {
        var aiMf = parse(aiM.val), md6 = strOf(aiMf, 6), hx6 = numOf(aiMf, 1), hex6 = hx6 > 0 ? ('000000' + hx6.toString(16)).slice(-6) : (rec && rec.hex) || '';
        if (md6 && /^[0-9a-f]{6}$/.test(hex6) && modelSent[hex6] !== md6 && (!rec || !rec.fr24Model || rec.fr24Model !== md6)) { modelSent[hex6] = md6; post('fr24Model', { hex: hex6, model: md6 }); }
      }
      var aiX = find(fs, F.ai), aiXf = !rec && aiX && aiX.wt === 2 ? parse(aiX.val) : null;
      var adAI = !!aiXf && (aiXf.some(function (x) { return x.fn === 11 && adImg(parse(x.val)); }) || (F.follow && aiXf.filter(function (x) { return x.fn === 11 && realImg(parse(x.val)); }).length < 3));
      // (an ordinary aircraft whose registered name, serial number, age or country the userscript already holds: in FR24's
      // own aircraft block from the first frame - no "Private owner" or padlock drawn first and replaced a moment later)
      var pubI = aiXf ? pubIds.get(('000000' + numOf(aiXf, 1).toString(16)).slice(-6).toUpperCase()) : null;
      if (pubI) { var o15x = strOf(aiXf, 15); if (!((pubI.c && !has(aiXf, 3)) || (pubI.m && !has(aiXf, 7)) || (pubI.a > 0 && !has(aiXf, 10)) || (pubI.o && (!o15x || /^private owner$/i.test(o15x))))) pubI = null; }
      if (!rec && !route && !tl && !adAI && !pubI && !fi0) return body;
      var label = rec ? csOf(rec) : '', changed = false, parts = [], i, j;
      var hasSchedule = has(fs, F.sched), hasProgress = has(fs, F.prog), hasAircraft = has(fs, F.ai);
      var schedAdds = function (si) {
        // ScheduleInfo: 1 flight_number, 2 operated_by_id, 3 painted_as_id, 4 origin_id, 5 destination_id, 7 std, 8 sta, 9 atd, 10 ata
        var add = [];
        if (label && !has(si, 1)) add.push(fStr(1, label));
        if (rec && rec.operatorId) { if (!has(si, 2)) add.push(fVar(2, rec.operatorId)); if (!has(si, 3)) add.push(fVar(3, rec.operatorId)); }
        if (route) {
          if (route.originId && !has(si, 4)) add.push(fVar(4, route.originId));
          if (route.destId && !has(si, 5)) add.push(fVar(5, route.destId));
          if (route.std > 0 && !has(si, 7)) add.push(fVar(7, route.std));
          if (route.sta > 0 && !has(si, 8)) add.push(fVar(8, route.sta));
          if (route.atd > 0 && !has(si, 9)) add.push(fVar(9, route.atd));
          if (route.ata > 0 && !has(si, 10)) add.push(fVar(10, route.ata));
        }
        return add;
      };
      var progAdds = function (pg) {
        var pr0 = route && route.progress; if (!pr0) return [];
        var pmap = [[1, pr0.traversed], [2, pr0.remaining], [3, pr0.elapsed], [4, pr0.remainingTime], [5, pr0.eta], [6, pr0.greatCircle], [8, pr0.stage], [10, pr0.pct]], add = [];
        for (var k = 0; k < pmap.length; k++) if (pmap[k][1] > 0 && !has(pg, pmap[k][0])) add.push(fVar(pmap[k][0], pmap[k][1]));
        return add;
      };
      for (i = 0; i < fs.length; i++) {
        var f = fs[i];
        if (f.wt !== 2) { parts.push(f.raw); continue; }
        if (f.fn === F.sched) {
          var si = parse(f.val), sadd = schedAdds(si);
          if (sadd.length) { parts.push(fLen(F.sched, concat([f.val].concat(sadd)))); changed = true; } else parts.push(f.raw);
          continue;
        }
        if (f.fn === F.prog) {
          var pg = parse(f.val), padd = progAdds(pg);
          if (padd.length) { parts.push(fLen(F.prog, concat([f.val].concat(padd)))); changed = true; } else parts.push(f.raw);
          continue;
        }
        if (f.fn === F.efi) {
          // (FR24's padlocks here too - 12 the figures', 14 the squawk's, 16 the vertical speed's, 18 the airspace's: never;
          // the vertical speed's kept only while nothing tells it, as in the feed's record)
          var fi = parse(f.val), keep = [];
          var sq = tl && tl.sq > 0 ? tl.sq : (rec ? rec.squawk : 0);
          // (1.2.4) none heard now: the code it was last heard with since it took off - asked of the monitor once if not here
          if (!(sq > 0) && !has(fi, 15) && F.follow && !numOf(fi, 9)) {
            var csS = strOf(fi, 10), sqKeys = ['F' + fid, st.hex ? 'H' + st.hex : (rec && rec.hex ? 'H' + rec.hex : ''), csS ? 'C' + csS.toUpperCase() : '', st.reg ? 'R' + st.reg : ''];
            sq = sqSince(sqKeys, st.t0 > 0 ? st.t0 * 1000 - 600000 : Date.now() - 2 * 3600e3);
            if (!(sq > 0)) wantSq(st.hex || (rec && rec.hex) || '');
          }
          var addCs = label && !has(fi, 10), addSq = sq > 0 && !has(fi, 15);
          var vrF = tl && fin(tl.vr) ? tl.vr : derivedVs(F.pb ? altHistFor(st.ts) : altHist, fid);
          var addVs = fin(vrF) && !has(fi, 17);
          var ems = tl && !has(fi, 13) ? emsBytes(tl) : null;
          var gndF = !!numOf(fi, 9), airC = !(tl && tl.air) && !has(fi, 19) ? airFor(fid, fltOf(fi, 2), fltOf(fi, 3), gndF ? 0 : numOf(fi, 5)) : null;
          if (!(tl && tl.air) && !airC && !has(fi, 19) && !F.pb) wantAir(fid, fltOf(fi, 2), fltOf(fi, 3), gndF ? 0 : numOf(fi, 5));
          var addAir = has(fi, 19) ? '' : tl && tl.air ? tl.air : airC ? airC.name : '', addAirId = !addAir ? '' : tl && tl.air ? tl.airId || '' : airC ? airC.code || '' : '';
          var vsLock = !addVs && !has(fi, 17);
          var locks = has(fi, 12) || has(fi, 14) || has(fi, 18) || (has(fi, 16) && !vsLock);
          if (!addCs && !addSq && !addVs && !ems && !addAir && !locks) { parts.push(f.raw); continue; }
          for (j = 0; j < fi.length; j++) {
            var y = fi[j];
            if (addCs && y.fn === 10) continue;
            if (y.fn === 12 || y.fn === 14 || y.fn === 18 || (y.fn === 16 && !vsLock)) continue;
            if (addSq && y.fn === 15) continue;
            if (ems && y.fn === 13) continue;
            if (addAir && (y.fn === 19 || y.fn === 20)) continue;
            keep.push(y.raw);
          }
          if (addCs) keep.push(fStr(10, label));
          if (addSq) keep.push(fVar(15, squawkWire(sq)));                       // (no 14: squawkAvailability set is FR24's padlock)
          if (addVs) keep.push(fInt(17, Math.round(vrF)));         // no 16: vspeedAvailability=false -> rendered as text
          if (ems) keep.push(fLen(13, ems));                        // no 12: emsAvailability empty -> rendered as text
          if (addAir) { keep.push(fStr(19, addAir)); if (addAirId) keep.push(fStr(20, addAirId)); }   // no 18: airspace as text, code in its badge
          parts.push(fLen(F.efi, concat(keep))); changed = true; continue;
        }
        if (f.fn === F.ai && !rec && (adAI || pubI)) {
          // an ordinary aircraft: its airport-data pictures out, and its slideshow filled to three with JetPhotos /
          // Planespotters ones FR24 does not show (asked for when it was opened; the frame after they come goes again);
          // and what the userscript already knows of it - its registered owner / operator over "Private owner", the
          // serial number, age and country FR24 padlocks (no padlock flag left on what is given)
          var aiP = parse(f.val), kP = [], hexP = ('000000' + numOf(aiP, 1).toString(16)).slice(-6).toUpperCase(), seenK = {}, realP = 0;
          var o15p = strOf(aiP, 15), gC = !!pubI && pubI.c > 0 && !has(aiP, 3), gM = !!pubI && !!pubI.m && !has(aiP, 7), gA = !!pubI && pubI.a > 0 && !has(aiP, 10), gO = !!pubI && !!pubI.o && (!o15p || /^private owner$/i.test(o15p));
          for (j = 0; j < aiP.length; j++) {
            var xP = aiP[j];
            if (xP.fn === 11) { var imP = parse(xP.val); if (adAI && adImg(imP)) continue; if (realImg(imP)) { realP++; seenK[imgKeyA(imP)] = true; } }
            if ((gC && (xP.fn === 3 || xP.fn === 16)) || (gM && (xP.fn === 7 || xP.fn === 13)) || (gA && (xP.fn === 10 || xP.fn === 14)) || (gO && xP.fn === 15)) continue;
            kP.push(xP.raw);
          }
          if (gC) kP.push(fVar(3, pubI.c)); if (gM) kP.push(fStr(7, pubI.m)); if (gA) kP.push(fVar(10, pubI.a)); if (gO) kP.push(fStr(15, pubI.o));
          if (gC || gM || gA || gO) stats.pubIds = (stats.pubIds || 0) + 1;
          if (adAI) {
            var ourP = ourPhotosFor(hexP), extraP = ourP.filter(function (p) { return !seenK[shotKeyP(p)]; }).slice(0, Math.max(0, 3 - realP));
            kP = kP.concat(photoParts(extraP));
            // (a blocked aircraft's block has no Mode S address: its pictures are its record's, once the userscript names
            // it - looked for under "000000" they were never sent, and only the userscript's stand-in showed them)
            if (F.follow && realP < 3) aiKeep[fid] = numOf(aiP, 1) > 0 ? { val: f.val, sig: photoSig(ourP), pubHex: hexP } : { val: f.val, sig: '' };
          }
          parts.push(fLen(F.ai, concat(kP))); changed = true; continue;
        }
        if (f.fn === F.ai && rec) {
          // AircraftInfo. FR24 sends a "sideview" image even for blocked aircraft; only a real photo counts.
          var ai = parse(f.val), k2 = [], sideviews = [], hasRealPhoto = false, touched = false;
          var giveCountry = rec.countryId && !has(ai, 3), giveMsn = rec.msn && !has(ai, 7), giveAge = rec.age > 0 && !has(ai, 10);
          for (j = 0; j < ai.length; j++) {
            var x = ai[j];
            if ((x.fn === 1 && !x.val) || (x.fn === 2 && !x.val.length) || (x.fn === 3 && !x.val) || (x.fn === 7 && !x.val.length) || (x.fn === 13 && !x.val) || (x.fn === 14 && !x.val) || (x.fn === 16 && !x.val) || (x.fn === 10 && !x.val) || (x.fn === 15 && !x.val.length)) continue;
            if ((giveCountry && x.fn === 16) || (giveMsn && x.fn === 13) || (giveAge && x.fn === 14)) continue;   // our value: no padlock
            if (x.fn === 11) {
              var im = parse(x.val); if (adImg(im)) continue;
              if (!(has(im, 3) || has(im, 4) || has(im, 5))) { sideviews.push(x.raw); continue; }
              // FR24's own picture of a blocked airframe: given the way ours are (link, credit, the clean large picture in
              // every size), so FR24 draws it like every other slide - its 640cb large size has JetPhotos' credit bar burnt
              // into the bottom
              hasRealPhoto = true;
              var bigO = noBar(strOf(im, 5) || strOf(im, 4) || strOf(im, 3));
              k2.push(slide(strOf(im, 1), strOf(im, 2), bigO)); touched = true;
              continue;
            }
            k2.push(x.raw);
          }
          if (rec.hexNum && !has(ai, 1)) { k2.push(fVar(1, rec.hexNum)); touched = true; }
          if (rec.reg && !has(ai, 2)) { k2.push(fStr(2, rec.reg)); touched = true; }
          if (giveCountry) { k2.push(fVar(3, rec.countryId)); touched = true; }
          if (rec.desc && !has(ai, 6)) { k2.push(fStr(6, rec.desc)); touched = true; }
          if (giveMsn) { k2.push(fStr(7, rec.msn)); touched = true; }
          if (giveAge) { k2.push(fVar(10, rec.age)); touched = true; }
          // (the name shown for it: its operator, else its registered owner - a trust company holding the registration is neither)
          if ((rec.operatorName || rec.owner) && !has(ai, 15)) { k2.push(fStr(15, rec.operatorName || rec.owner)); touched = true; }
          var photos = goodPhotos(shownPhotos(rec)); if (!photos.length) photos = goodPhotos((psCache.get(String(rec.hex || '').toUpperCase()) || {}).photos);
          var realR = ai.filter(function (x) { return x.fn === 11 && realImg(parse(x.val)); }), keysR = {}; realR.forEach(function (x) { keysR[imgKeyA(parse(x.val))] = true; });
          if (F.follow && fid) aiKeep[fid] = { val: f.val, sig: photoSig(photos), real: realR.length >= 3 };
          if (hasRealPhoto && realR.length < 3) { var extraR = photos.filter(function (p) { return !keysR[shotKeyP(p)]; }).slice(0, 3 - realR.length); if (extraR.length) { k2 = k2.concat(photoParts(extraR)); touched = true; } }
          if (photos.length && !hasRealPhoto) { k2 = k2.concat(photoParts(photos)); touched = true; }
          for (j = 0; j < sideviews.length; j++) k2.push(sideviews[j]);
          // FR24 sometimes has its own pictures of a blocked airframe: kept by the userscript for the log page and boards
          if (hasRealPhoto && rec.hex && !fr24ImgSent[fid]) {
            fr24ImgSent[fid] = true;
            var own = [];
            for (j = 0; j < ai.length; j++) {
              if (ai[j].fn !== 11) continue;
              var im2 = parse(ai[j].val), big = strOf(im2, 5) || strOf(im2, 4) || strOf(im2, 3);
              if (adImg(im2)) continue;
              if (big) own.push({ link: strOf(im2, 1) || big, credit: strOf(im2, 2), large: big, medium: strOf(im2, 4) || big, thumb: strOf(im2, 3) || big, source: 'Flightradar24' });
            }
            if (own.length) post('photos', { hex: rec.hex, reg: rec.reg, photos: own.slice(0, 3), err: '' });
          }
          if (touched || giveCountry || giveMsn || giveAge) { parts.push(fLen(F.ai, concat(k2))); changed = true; } else parts.push(f.raw);
          continue;
        }
        parts.push(f.raw);
      }
      if (hasAircraft || (F.follow && route)) {
        if (!hasSchedule) { var sp = schedAdds([]); if (sp.length) { parts.push(fLen(F.sched, concat(sp))); changed = true; } }
        if (!hasProgress) { var pp = progAdds([]); if (pp.length) { parts.push(fLen(F.prog, concat(pp))); changed = true; } }
      }
      if (changed) stats.patched++;
      return changed ? concat(parts) : body;
    }

    // ---- request parsing -----------------------------------------------------------------------------------
    function bodyBytes(body) {
      try {
        if (!body) return null;
        if (typeof body === 'string') { var o = []; b64DecodeInto(body.slice(0, body.length - body.length % 4), o); return Uint8Array.from(o); }
        if (body instanceof ArrayBuffer) return new Uint8Array(body);
        if (ArrayBuffer.isView(body)) return new Uint8Array(body.buffer, body.byteOffset, body.byteLength);
      } catch (e) { /* ignore */ }
      return null;
    }
    function followIdFromBody(body) {
      var b = bodyBytes(body); if (!b || b.length < 5) return 0;
      try { var fs = parse(b.subarray(5)); var f = find(fs, 1); if (f && f.wt === 5) return new DataView(f.val.buffer, f.val.byteOffset, 4).getUint32(0, true); } catch (e) { /* ignore */ }
      return 0;
    }

    // (a request's flight id - field 1, fixed32 or varint)
    function reqIdOf(body) {
      var b = bodyBytes(body); if (!b || b.length < 5) return 0;
      try { var f = find(parse(b.subarray(5)), 1); if (f && f.wt === 5) return new DataView(f.val.buffer, f.val.byteOffset, 4).getUint32(0, true); if (f && f.wt === 0) return f.val; } catch (e) { /* ignore */ }
      return 0;
    }

    // ---- (1.2.4) FR24's player on a page of ours (mxPbShow): the GPS altitude, true and indicated airspeed and squawk of
    // each moment, which FR24's player asks its server for by the flight's live id (PlaybackFlight) - a page of ours has a
    // stand-in id of its own, 0xF0000000 and up (FR24's ids are far below), and FR24's asks by it are answered here, from
    // the flight's track as kept: nothing sent. Its live stream and stored trail of that id: "not found", as FR24's server
    // says of a flight it has no more (its page plays the track it was given)
    var MX_PB_STAND = 0xF0000000, mxPbStand = new Map(), mxPbStandN = 0;
    function mxPbStandIn(d) {
      var sq4 = /^[0-7]{4}$/, R = [];
      (d.pts || []).forEach(function (p) {
        if (!p || !fin(p.t)) return;
        var r = { t: p.t, ag: fin(p.ag) ? p.ag : null, ias: fin(p.ias) && p.ias > 0 ? p.ias : null, tas: fin(p.tas) && p.tas > 0 ? p.tas : null, sq: sq4.test(p.sq || '') ? p.sq : '' };
        if (r.ag != null || r.ias != null || r.tas != null || r.sq) R.push(r);
      });
      // (1.4.0: and its aircraft - address, registration, type, model - for the icon FR24's player draws it with: a stand-in
      // for every flight with an aircraft known, figures or none)
      var ai = { hex: /^[0-9a-f]{6}$/i.test(d.hex || '') ? String(d.hex).toLowerCase() : '', reg: d.reg || '', type: d.type || '', model: d.model || '' };
      if (!R.length && !ai.hex && !ai.type) return null;
      R.sort(function (a, b) { return a.t - b.t; });
      var key = String(d.id), sid = 0;
      mxPbStand.forEach(function (v, k) { if (v.key === key) sid = k; });
      if (!sid) { sid = MX_PB_STAND + (++mxPbStandN % 0x0ffffff); if (mxPbStand.size >= 20) mxPbStand.delete(mxPbStand.keys().next().value); }
      mxPbStand.set(sid, { key: key, R: R, ai: ai });
      return sid;
    }
    // (each figure at a moment: in proportion between the reports either side of it two minutes apart at most, else the
    // nearer within a minute; the squawk the last set within ten minutes, else the next within a minute)
    function mxPbReadAt(R, t) {
      var lo = 0, hi = R.length; while (lo < hi) { var m = (lo + hi) >> 1; if (R[m].t <= t) lo = m + 1; else hi = m; }
      var out = {};
      ['ag', 'ias', 'tas', 'sq'].forEach(function (k) {
        var a = null, b = null, i;
        for (i = lo - 1; i >= 0 && i >= lo - 400; i--) if (k === 'sq' ? R[i].sq : R[i][k] != null) { a = R[i]; break; }
        for (i = lo; i < R.length && i < lo + 400; i++) if (k === 'sq' ? R[i].sq : R[i][k] != null) { b = R[i]; break; }
        if (k === 'sq') { out.sq = a && t - a.t <= 600 ? a.sq : b && b.t - t <= 60 ? b.sq : ''; return; }
        if (a && b && b.t - a.t <= 120) out[k] = b.t === a.t ? a[k] : a[k] + (b[k] - a[k]) * (t - a.t) / (b.t - a.t);
        else { var n = a && (!b || t - a.t <= b.t - t) ? a : b; out[k] = n && Math.abs(n.t - t) <= 60 ? n[k] : null; }
      });
      return out;
    }
    // (FR24's PlaybackFlightResponse of that moment: 1 AircraftInfo - 1 address, 2 registration, 4 type, 5 icon, 6 its
    // full name (1.4.0) - and 3 ExtendedFlightInfo - 13 EmsInfo, 15 squawk)
    function mxPbFlightMsg(sid, ts) {
      var s = mxPbStand.get(sid), parts = [], out = [];
      if (s && s.ai) {
        var a = s.ai, ab = [], ic = iconFor(a.hex, a.type);
        if (a.hex) ab.push(fVar(1, parseInt(a.hex, 16)));
        if (a.reg) ab.push(fStr(2, a.reg));
        if (a.type) ab.push(fStr(4, a.type));
        if (ic > 0) ab.push(fVar(5, ic));
        if (a.model) ab.push(fStr(6, a.model));
        if (ab.length) out.push(fLen(1, concat(ab)));
      }
      if (s && ts > 0 && s.R.length) {
        var r = mxPbReadAt(s.R, ts), ems = emsBytes({ agps: r.ag, ias: r.ias, tas: r.tas });
        if (ems) parts.push(fLen(13, ems));
        if (r.sq) parts.push(fVar(15, parseInt(r.sq, 16)));
      }
      if (parts.length) out.push(fLen(3, concat(parts)));
      return out.length ? concat(out) : new Uint8Array(0);
    }
    // (a gRPC-web answer given to FR24's XHR as from its server: its state, status, headers and body, and its events)
    function grpcAnswer(xhr, msg, code, text) {
      var bin = xhr.responseType === 'arraybuffer', hd = xhr.__tlHeaders || {}, ct = '';
      Object.keys(hd).forEach(function (k) { if (/^content-type$/i.test(k)) ct = String(hd[k]); });
      if (!/grpc-web/.test(ct)) ct = bin ? 'application/grpc-web+proto' : 'application/grpc-web-text';
      var tr = enc.encode('grpc-status:' + code + '\r\ngrpc-message:' + (text || '') + '\r\n'), frames = [];
      if (msg) frames.push(concat([frameHeader(0, msg.length), msg]));
      frames.push(concat([frameHeader(0x80, tr.length), tr]));
      var b64 = /-text/.test(ct), body = b64 ? frames.map(b64Encode).join('') : concat(frames).buffer;
      var hdrs = { 'content-type': ct }; if (code) { hdrs['grpc-status'] = String(code); hdrs['grpc-message'] = text || ''; }
      var rs = 1, gone = false, def = function (k, g) { Object.defineProperty(xhr, k, { configurable: true, get: g }); };
      def('readyState', function () { return rs; });
      def('status', function () { return rs >= 2 ? 200 : 0; });
      def('statusText', function () { return rs >= 2 ? 'OK' : ''; });
      def('responseURL', function () { return rs >= 2 ? String(xhr.__tlUrl || '') : ''; });
      def('responseText', function () { return rs >= 3 && typeof body === 'string' ? body : ''; });
      def('response', function () { return typeof body === 'string' ? (rs >= 3 ? body : '') : (rs === 4 ? body : null); });
      xhr.getResponseHeader = function (k) { var v = rs >= 2 ? hdrs[String(k).toLowerCase()] : null; return v == null ? null : v; };
      xhr.getAllResponseHeaders = function () { return rs >= 2 ? Object.keys(hdrs).map(function (k) { return k + ': ' + hdrs[k]; }).join('\r\n') + '\r\n' : ''; };
      xhr.abort = function () { gone = true; rs = 0; };
      var fire = function (n) { try { xhr.dispatchEvent(n === 'progress' || n === 'load' || n === 'loadend' ? new ProgressEvent(n) : new Event(n)); } catch (e) { /* ignore */ } };
      var step = function (s) { if (gone) return; rs = s; fire('readystatechange'); if (s === 3) fire('progress'); if (s === 4) { fire('load'); fire('loadend'); } if (s < 4) oSetTimeout(function () { step(s + 1); }, 0); };
      oSetTimeout(function () { step(2); }, 0);
    }
    function mxPbStandReq(xhr, url, body) {
      var m = url.match(/fr24\.feed\.api\.v1\.Feed\/(PlaybackFlight|FollowFlight|HistoricTrail|FlightDetails)(?:$|\?)/); if (!m) return false;
      var sid = reqIdOf(body); if (!(sid >= MX_PB_STAND)) return false;
      if (m[1] === 'PlaybackFlight') { grpcAnswer(xhr, mxPbFlightMsg(sid, tsOf(body)), 0, ''); mx.pbReads = (mx.pbReads || 0) + 1; }
      else grpcAnswer(xhr, null, 5, 'flight not found');
      return true;
    }

    // ---- XHR shims -----------------------------------------------------------------------------------------
    var P = XMLHttpRequest.prototype, oOpen = P.open, oSend = P.send, oSetHeader = P.setRequestHeader;
    var respDesc = Object.getOwnPropertyDescriptor(P, 'response'), textDesc = Object.getOwnPropertyDescriptor(P, 'responseText');
    function installBinary(xhr, patchBody) {
      var cache = { done: false, src: null, out: null };
      Object.defineProperty(xhr, 'response', { configurable: true, get: function () {
        var raw; try { raw = respDesc.get.call(this); } catch (e) { return undefined; }
        if (this.readyState !== 4 || !(raw instanceof ArrayBuffer)) return raw;
        if (!cache.done || cache.src !== raw) {
          cache.done = true; cache.src = raw;
          try { cache.out = patchFrames(raw, patchBody); } catch (e) { stats.errors++; stats.lastError = String(e); cache.out = raw; }
        }
        return cache.out;
      } });
    }
    function installText(xhr, patchBody, st) {
      st.xhr = xhr; st.inPos = 0; st.buf = []; st.out = ''; st.frames = 0; st.broken = false;
      function getter() {
        var raw; try { raw = textDesc.get.call(this); } catch (e) { return ''; }
        if (typeof raw !== 'string') return raw;
        if (st.broken) return st.out ? st.out : raw;
        var usable = raw.length - raw.length % 4;
        if (usable > st.inPos) { try { b64DecodeInto(raw.slice(st.inPos, usable), st.buf); st.inPos = usable; } catch (e) { stats.errors++; stats.lastError = String(e); st.broken = true; return st.out ? st.out : raw; } }
        while (st.buf.length >= 5) {
          var len = ((st.buf[1] << 24) | (st.buf[2] << 16) | (st.buf[3] << 8) | st.buf[4]) >>> 0;
          if (st.buf.length < 5 + len) break;
          var frame = Uint8Array.from(st.buf.splice(0, 5 + len)), bytes = frame;
          if (frame[0] === 0) { try { var nb = patchBody(frame.subarray(5), st); if (nb !== frame.subarray(5) && nb.length) bytes = concat([frameHeader(0, nb.length), nb]); } catch (e) { stats.errors++; stats.lastError = String(e); } }
          st.frames++;
          st.out += b64Encode(bytes);
        }
        return st.out;
      }
      Object.defineProperty(xhr, 'responseText', { configurable: true, get: getter });
      Object.defineProperty(xhr, 'response', { configurable: true, get: function () {
        if (this.responseType && this.responseType !== 'text') { try { return respDesc.get.call(this); } catch (e) { return null; } }
        return getter.call(this);
      } });
    }
    var STATS_PAGE_RE = /\/data\/airports\/[^/?#]+(?:\/statistics)?\/?(?:[?#]|$)/i;
    // (an answer of JSON, as text or as read: fn(object) -> the object to give instead, or null for the answer as it came)
    function installJsonXhr(xhr, fn) {
      var cache = { src: null, out: null };
      var patched = function (raw) {
        if (cache.src === raw && cache.out != null) return cache.out;
        var out = raw;
        try { var j = typeof raw === 'string' ? (raw ? JSON.parse(raw) : null) : raw, r = j ? fn(j) : null; if (r) out = typeof raw === 'string' ? JSON.stringify(r) : r; } catch (e) { out = raw; }
        cache.src = raw; cache.out = out; return out;
      };
      Object.defineProperty(xhr, 'responseText', { configurable: true, get: function () { var raw; try { raw = textDesc.get.call(this); } catch (e) { return ''; } return this.readyState === 4 ? patched(raw) : raw; } });
      Object.defineProperty(xhr, 'response', { configurable: true, get: function () {
        var raw; try { raw = respDesc.get.call(this); } catch (e) { return null; }
        if (this.readyState !== 4 || !(typeof raw === 'string' || (raw && typeof raw === 'object' && !(raw instanceof ArrayBuffer) && !(raw instanceof Blob)))) return raw;
        return patched(raw);
      } });
    }
    function installListXhr(xhr, reg, url) {
      var cache = { src: null, out: null };
      var patched = function (raw) {
        if (cache.src === raw && cache.out != null) return cache.out;
        var out = raw;
        try {
          var j = typeof raw === 'string' ? (raw ? JSON.parse(raw) : null) : raw, resp = listRespOf(j), h = hist.get(reg);
          stats.lastList = { reg: reg, at: Date.now(), via: 'xhr', url: listUrlOf(url), status: xhr.status, fr24: resp ? (Array.isArray(resp.data) ? resp.data.length : 0) : -1, ours: h && h.data ? h.data.length : 0, shape: resp ? null : shapeOf(j, 0) };
          // (1.3.7: an answer of FR24's in a shape not known here left as it is - listUnknown)
          if (!resp && xhr.status >= 200 && xhr.status < 300 && listUnknown(j)) stats.lastList.left = true;
          else if (!(resp && Array.isArray(resp.data) && resp.data.length > 1) && h && h.data && h.data.length > 1) {
            var o = resp ? j : listShell(reg, url); fillList(resp || o.result.response, h, url);
            out = typeof raw === 'string' ? JSON.stringify(o) : o;
          }
        } catch (e) { out = raw; }
        cache.src = raw; cache.out = out; return out;
      };
      Object.defineProperty(xhr, 'responseText', { configurable: true, get: function () { var raw; try { raw = textDesc.get.call(this); } catch (e) { return ''; } return this.readyState === 4 ? patched(raw) : raw; } });
      Object.defineProperty(xhr, 'response', { configurable: true, get: function () {
        var raw; try { raw = respDesc.get.call(this); } catch (e) { return null; }
        if (this.readyState !== 4 || !(typeof raw === 'string' || (raw && typeof raw === 'object' && !(raw instanceof ArrayBuffer) && !(raw instanceof Blob)))) return raw;
        return patched(raw);
      } });
    }
    P.open = function (method, url) { try { this.__tlUrl = String(url); this.__tlMethod = String(method || 'GET'); this.__tlHeaders = {}; noteReq('xhr', method, url); } catch (e) { /* ignore */ } return oOpen.apply(this, arguments); };
    P.setRequestHeader = function (k, v) { try { if (this.__tlHeaders) this.__tlHeaders[k] = v; } catch (e) { /* ignore */ } return oSetHeader.apply(this, arguments); };
    P.send = function (body) {
      // (1.3: LADD Unblock switched off in its window while FR24 is open: FR24's own requests and answers left as they are
      // from that moment - nothing patched, nothing asked for - until the reload that takes this part away)
      if (!optOn('on') && !this.__tlOwn) return oSend.apply(this, arguments);
      var url = this.__tlUrl || '', sendBody = body;
      try {
        if (!this.__tlOwn && mxPbStandReq(this, url, body)) return;
        if (/fr24\.feed\.api\.v1\.Feed\/LiveFeed(?:$|\?)/.test(url)) {
          if (!this.__tlOwn) {
            if (this.__tlHeaders && this.__tlHeaders['fr24-device-id'] && !feedHeaders) { feedHeaders = Object.assign({}, this.__tlHeaders); post('feedReady', { hdr: feedHdrPublic() }); }
            if (this.responseType === 'arraybuffer') {
              installBinary(this, function (b) { return patchLiveFeed(b, false); });
              try { sendBody = patchLiveFeedRequest(body); } catch (e) { sendBody = body; }
              if (sendBody !== body) {
                var x = this;
                x.addEventListener('load', function () { try { var gs = x.getResponseHeader('grpc-status'); if (gs && gs !== '0') { stats.maskDisabled = true; stats.lastError = 'field mask refused: ' + (x.getResponseHeader('grpc-message') || gs); } } catch (e) { /* ignore */ } });
              }
            } else installText(this, function (b) { return patchLiveFeed(b, false); }, {});
          }
        } else if (!this.__tlOwn && /fr24\.feed\.api\.v1\.Feed\/Playback(?:$|\?)/.test(url)) {
          // FR24's map playback: its feed of a moment (the same flights as the live feed, wrapped)
          var pts0 = tsOf(body) || Math.floor(Date.now() / 1000);
          if (!stats.pbMaskOff) {
            try { sendBody = patchPlaybackRequest(body); } catch (e) { sendBody = body; }
            if (sendBody !== body) { var xp = this; xp.addEventListener('load', function () { try { var gs1 = xp.getResponseHeader('grpc-status'); if (gs1 && gs1 !== '0') { stats.pbMaskOff = true; stats.lastError = 'playback field mask refused'; } } catch (e) { /* ignore */ } }); }
          }
          if (this.responseType === 'arraybuffer') installBinary(this, function (b) { return patchPlayback(b, pts0); });
          else installText(this, function (b) { return patchPlayback(b, pts0); }, {});
        } else if (!this.__tlOwn && /fr24\.feed\.api\.v1\.Feed\/PlaybackFlight(?:$|\?)/.test(url)) {
          // ... and the panel of the flight opened in it, at that moment
          var pst = { id: followIdFromBody(body), ts: tsOf(body), pb: true };
          if (pst.id) post('pbFollow', { id: pst.id, ts: pst.ts });
          if (this.responseType === 'arraybuffer') installBinary(this, function (b) { return patchFlightMsg(b, pst, PLAYBACK); });
          else installText(this, function (b) { return patchFlightMsg(b, pst, PLAYBACK); }, pst);
          // (a blocked aircraft named here: its pictures asked for now, at the front of the queue, and the answer held for
          // them too - 2.5 s at most - so the slideshow opens with them)
          var ppr = pst.id ? resolved.get(pst.id) : null, pphWait = !!(ppr && ppr.hex && !hasPhotos(ppr) && !((photoCache.get(String(ppr.hex).toUpperCase()) || {}).final));
          if (ppr && ppr.hex && !((photoCache.get(String(ppr.hex).toUpperCase()) || {}).final)) photosFor(ppr, true);
          if (pst.id && (!pbReady(pst.id) || pphWait)) { var xpb = this, bpb = sendBody; Promise.all([whenPbReady(pst.id, 1500), pphWait ? photosWithin(ppr, 2500) : null]).then(function () { try { oSend.call(xpb, bpb); } catch (e) { /* aborted meanwhile */ } }); return; }
        } else if (!this.__tlOwn && this.__tlHeaders && (this.__tlHeaders['X-Inertia'] || this.__tlHeaders['x-inertia']) && acPageReq(url)) {
          // (1.3.5: a page of one of the families or types FR24 does not list - its page of its list, or its pictures: the
          // page of FR24's it is made from asked for instead, sent once the monitor's page of it is here, and given to FR24
          // as theirs - acPageOf)
          var aq = acPageReq(url), xa = this, ba = sendBody;
          oOpen.call(xa, xa.__tlMethod || 'GET', aq.refUrl, true);
          Object.keys(xa.__tlHeaders || {}).forEach(function (k) { try { oSetHeader.call(xa, k, xa.__tlHeaders[k]); } catch (e) { /* ignore */ } });
          installJsonXhr(xa, function (j) { return j && j.component && j.props ? acPageOf(j, aq, acGot.get(aq.key) || null) : null; });
          acAskPage(aq).then(function () { try { oSend.call(xa, ba); } catch (e) { /* aborted meanwhile */ } });
          return;
        } else if (!this.__tlOwn && this.__tlHeaders && (this.__tlHeaders['X-Inertia'] || this.__tlHeaders['x-inertia']) && oaPageReq(url)) {
          // (1.3.1: a data page of an OurAirports airport - FR24 has none: its nearest airport's same page asked for instead,
          // and given to FR24 as this airport's - oaPageOf)
          var oq = oaPageReq(url), xo = this;
          oOpen.call(xo, xo.__tlMethod || 'GET', oq.refUrl, true);
          Object.keys(xo.__tlHeaders || {}).forEach(function (k) { try { oSetHeader.call(xo, k, xo.__tlHeaders[k]); } catch (e) { /* ignore */ } });
          installJsonXhr(xo, function (j) { var o = j && j.component && j.props ? oaPageOf(j, oq) : null; if (o) statsUnlock(o); return o; });
          stats.oaPages = (stats.oaPages || 0) + 1;
        } else if (!this.__tlOwn && STATS_PAGE_RE.test(url) && this.__tlHeaders && (this.__tlHeaders['X-Inertia'] || this.__tlHeaders['x-inertia'])) {
          // (1.3.1: a move to an airport's statistics page within FR24 - its router's answer, unlocked as the first load is)
          installJsonXhr(this, function (j) { return j && typeof j === 'object' && statsUnlock(j) ? j : null; });
        } else if (!this.__tlOwn && REGLIST_RE.test(url) && /[?&]fetchBy=reg\b/.test(url)) {
          // (the registration list asked for with XHR: the log asked for as it goes - FR24's own list never waits for it -
          // and put in FR24's answer when that has no flights)
          var lq = (url.match(/[?&]query=([^&]*)/) || [])[1], lreg = lq ? decodeURIComponent(lq).toUpperCase() : '';
          if (lreg) { stats.listAsked = (stats.listAsked || 0) + 1; needHistory(lreg); installListXhr(this, lreg, url); }
        } else if (!this.__tlOwn && /fr24\.feed\.api\.v1\.Feed\/TopFlights(?:$|\?)/.test(url)) {
          stats.topSeen = (stats.topSeen || 0) + 1;
          if (this.responseType === 'arraybuffer') installBinary(this, patchTopFlights);
          else installText(this, function (b) { return patchTopFlights(b); }, {});
        } else if (!this.__tlOwn && /fr24\.feed\.api\.v1\.Feed\/(?:FollowFlight|FlightDetails)(?:$|\?)/.test(url)) {
          // FollowFlight feeds the aircraft panel; FlightDetails the expanded card of a live search result
          var isFollow = /FollowFlight/.test(url), FM = isFollow ? FOLLOW : DETAILS, st = { id: followIdFromBody(body) };
          try { sendBody = stripRestriction(body); } catch (e) { sendBody = body; }
          if (isFollow) { stats.follow++; curFollowId = st.id; post('follow', { id: st.id }); } else stats.flightDetails++;
          if (this.responseType === 'arraybuffer') installBinary(this, function (b) { return patchFlightMsg(b, st, FM); });
          else { installText(this, function (b, s) { return patchFlightMsg(b, s, FM); }, st); if (isFollow) followSt = st; }
          var pr = resolved.get(st.id);
          if (pr && pr.hex && !((photoCache.get(String(pr.hex).toUpperCase()) || {}).final)) {
            // The search card is drawn once, from this one answer: it is asked for when the pictures are in (JetPhotos,
            // else Planespotters; at most 2.8 s later), so the card opens complete. (The panel is not held up - its
            // pictures are filled in as they arrive.)
            if (!isFollow && !hasPhotos(pr)) {
              var xhr = this, sb = sendBody;
              photosWithin(pr, 2800).then(function () { try { oSend.call(xhr, sb); } catch (e) { /* aborted meanwhile */ } });
              return;
            }
            photosFor(pr, true);
          }
        }
      } catch (e) { stats.errors++; stats.lastError = String(e); }
      return oSend.call(this, sendBody);
    };

    // (the headers of FR24's feed requests the monitor may use for its own scans of FR24: its device id, platform and
    // grpc-web markers - never an authorization, cookie or anything else)
    function feedHdrPublic() { var o = {}; if (!feedHeaders) return o; for (var k in feedHeaders) if (Object.prototype.hasOwnProperty.call(feedHeaders, k) && /^(fr24-[a-z0-9-]+|x-grpc-web|x-user-agent|content-type)$/i.test(k)) o[k] = String(feedHeaders[k]); return o; }
    // ---- background LiveFeed queries (world scan), same headers as FR24's own requests -------------------------
    function liveFeedQuery(q) {
      return new Promise(function (resolve, reject) {
        if (!feedHeaders) return reject(new Error('no feed headers yet'));
        var bounds = concat([fF32(1, q.n), fF32(2, q.s), fF32(3, q.w), fF32(4, q.e)]);
        var settings = concat([fLen(1, Uint8Array.from([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])), fLen(2, Uint8Array.from(q.services || [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11])), fVar(3, q.traffic || 3)]);
        var body = concat([fLen(1, bounds), fLen(2, settings), fVar(6, 1), fVar(7, q.limit || 1500), fVar(8, q.maxage || 14400), fVar(9, 0), fLen(10, concat([fStr(1, 'type'), fStr(1, 'reg')]))]);
        var frame = concat([frameHeader(0, body.length), body]);
        var x = new XMLHttpRequest(); x.__tlOwn = true;
        x.open('POST', 'https://data-feed.flightradar24.com/fr24.feed.api.v1.Feed/LiveFeed');
        for (var k in feedHeaders) if (Object.prototype.hasOwnProperty.call(feedHeaders, k)) { try { x.setRequestHeader(k, feedHeaders[k]); } catch (e) { /* ignore */ } }
        x.responseType = 'arraybuffer'; x.timeout = 15000;
        x.onload = function () {
          try {
            if (x.status !== 200) return reject(new Error('HTTP ' + x.status));
            var gs = x.getResponseHeader('grpc-status'); if (gs && gs !== '0') return reject(new Error('grpc ' + gs + ' ' + (x.getResponseHeader('grpc-message') || '')));
            var b = new Uint8Array(x.response), p = 0, n = 0, total = 0;
            while (p + 5 <= b.length) {
              var flag = b[p], len = ((b[p + 1] << 24) | (b[p + 2] << 16) | (b[p + 3] << 8) | b[p + 4]) >>> 0;
              if (p + 5 + len > b.length) break;
              if (flag === 0) { patchLiveFeed(b.subarray(p + 5, p + 5 + len), true); n++; total += lastFeedTotal; }
              p += 5 + len;
            }
            stats.scans++;
            resolve({ frames: n, total: total });
          } catch (e) { reject(e); }
        };
        x.onerror = function () { reject(new Error('network error')); };
        x.ontimeout = function () { reject(new Error('timeout')); };
        x.send(frame.buffer);
      });
    }
    // ---- background FollowFlight: the trail of a flight nobody opened (its first frame only) --------------------
    // FR24 gives no playback of a blocked flight, but its follow stream gives the whole trail since take-off (a G500 at
    // FL450 mid-Atlantic, 9 Oct: 532 fixes back to the runway at Baltimore). Asked for by the userscript for an unnamed
    // flight out of public coverage; read up to the first frame, then closed - one every 20 s at most.
    var bgFollowAt = 0;
    // ---- FR24's Most tracked flights: its widget's list (Feed/TopFlights; the JSON /flights/most-tracked elsewhere) --------
    // A flight FR24 lists with no destination - "N/A": Air Force One out of Andrews - is given the one worked out here, as on
    // its panel and the boards. One not worked out yet is asked for (the userscript fetches its track in the background):
    // FR24 asks for the list again every little while, and it is in the list then.
    //   TopFlightsResponse 1 FollowedFlight (repeated): 1 flight_id 2 live_clicks 3 total_clicks 4 flight_number 5 callsign
    //   6 squawk 7 from_iata 8 from_city 9 to_iata 10 to_city 11 type 12 full_description
    var naAsked = new Map();
    // (1.2.10: a flight in it that this page has not identified - off the map's view - its name and route asked of the
    // monitor by FR24's id: in for FR24's next read of the list)
    var topNames = new Map(), topAsked = new Map();
    function askTop(ids) {
      var now = Date.now(), want = ids.filter(function (id) { var t = topAsked.get(id); return !t || now - t > 60000; }).slice(0, 12);
      if (!want.length) return;
      want.forEach(function (id) { topAsked.set(id, now); }); if (topAsked.size > 300) topAsked.delete(topAsked.keys().next().value);
      post('topNeed', { ids: want });
    }
    function onTopGot(d) {
      Object.keys((d && d.names) || {}).forEach(function (k) { var v = String(d.names[k] || '').replace(/[^A-Za-z0-9-]/g, '').toUpperCase(); if (v) topNames.set(Number(k), v.replace(/-/g, '')); });
      Object.keys((d && d.routes) || {}).forEach(function (k) { var r = d.routes[k]; if (r && !routes.has(Number(k))) routes.set(Number(k), r); });
      while (topNames.size > 300) topNames.delete(topNames.keys().next().value);
    }
    var isCode = function (c) { return /^[A-Z0-9]{3,4}$/.test(String(c || '')); };
    function destFor(id) { var r = id ? routeNow(id) : null; return r && isCode(r.destIata) ? r : null; }
    function askNaRoutes(list) {
      // (one not worked out yet asked for again after a minute; one already given, to keep it current, every two)
      var now = Date.now(), ask = list.filter(function (x) { var t = naAsked.get(x.id); return !t || now - t > (x.has ? 120000 : 60000); }).slice(0, 6);
      if (!ask.length) return;
      ask.forEach(function (x) { naAsked.set(x.id, now); }); if (naAsked.size > 300) naAsked.delete(naAsked.keys().next().value);
      post('needNaRoutes', { list: ask });
    }
    // (1.2.10) Every flight worked out or identified here shows in it as on its panel: a blocked one FR24 lists with nothing
    // but its type - "N/A, GLF4, N/A - N/A" for N291VK, Bengaluru to Riyadh, the fifth most tracked - gets its name (the
    // panel's: its callsign, else registration), where it took off and where it is going. 1.2.9 and before left any entry
    // with no flight number or callsign as FR24 sent it, which is every blocked flight's. FR24's own values never replaced.
    function patchTopFlights(body) {
      var fs = parse(body), parts = [], changed = false, ask = [], need = [];
      for (var i = 0; i < fs.length; i++) {
        var f = fs[i], it = null;
        if (f.fn === 1 && f.wt === 2) { try { it = parse(f.val); } catch (e) { it = null; } }
        var id = it ? numOf(it, 1) : 0, num = it ? strOf(it, 4) : '', cs = it ? strOf(it, 5) : '', from = it ? strOf(it, 7) : '', to = it ? strOf(it, 9) : '';
        // (only what reads as FR24's entry: an id, its airports as codes where it has them)
        if (!id || (from && !isCode(from)) || (to && !isCode(to))) { parts.push(f.raw); continue; }
        var r = routeNow(id), label = !num && !cs ? (csOf(recOf(id)) || topNames.get(id) || '') : '';
        var addFrom = !from && !!r && isCode(r.originIata), addTo = !to && !!r && isCode(r.destIata);
        if (!to) ask.push({ id: id, cs: cs || num || label, from: from || (addFrom ? r.originIata : ''), type: strOf(it, 11), has: addTo });
        if ((!num && !cs && !label) || (!r && (!to || !from))) need.push(id);
        if (!label && !addFrom && !addTo) { parts.push(f.raw); continue; }
        var keep = it.filter(function (x) { return !(label && x.fn === 5) && !(addFrom && (x.fn === 7 || x.fn === 8)) && !(addTo && (x.fn === 9 || x.fn === 10)); }).map(function (x) { return x.raw; });
        if (label) keep.push(fStr(5, label));
        if (addFrom) { keep.push(fStr(7, r.originIata)); if (r.originCity) keep.push(fStr(8, r.originCity)); }
        if (addTo) { keep.push(fStr(9, r.destIata)); if (r.destCity) keep.push(fStr(10, r.destCity)); }
        parts.push(fLen(1, concat(keep))); changed = true;
      }
      if (ask.length) askNaRoutes(ask);
      if (need.length) askTop(need);
      if (changed) stats.topFlights = (stats.topFlights || 0) + 1;
      return changed ? concat(parts) : body;
    }
    // (the same list as JSON - whatever it nests the flights in: each one with a flight id and an empty destination)
    function fillFlightList(j) {
      var n = 0, ask = [];
      (function walk(o, depth) {
        if (!o || typeof o !== 'object' || depth > 6) return;
        if (Array.isArray(o)) { o.forEach(function (x) { walk(x, depth + 1); }); return; }
        var idv = o.flight_id != null ? o.flight_id : o.flightId, id = typeof idv === 'number' ? idv : /^[0-9a-f]{6,8}$/i.test(String(idv || '')) ? parseInt(idv, 16) : 0;
        var tk = ['to_iata', 'toIata', 'destination_iata', 'destinationIata'].filter(function (k) { return k in o; })[0];
        if (id && tk && !isCode(o[tk])) {
          var r = destFor(id), ck = ['to_city', 'toCity', 'destination_city', 'destinationCity'].filter(function (k) { return k in o; })[0];
          if (r) { o[tk] = r.destIata; if (ck && r.destCity) o[ck] = r.destCity; n++; }
          // (1.2.10: a blocked flight's name and origin too, where FR24's are empty)
          var rn = routeNow(id), fk = ['from_iata', 'fromIata', 'origin_iata', 'originIata'].filter(function (k) { return k in o; })[0], fck = ['from_city', 'fromCity', 'origin_city', 'originCity'].filter(function (k) { return k in o; })[0];
          if (fk && !isCode(o[fk]) && rn && isCode(rn.originIata)) { o[fk] = rn.originIata; if (fck && rn.originCity) o[fck] = rn.originCity; n++; }
          var nk = ['callsign', 'flight', 'flight_number', 'flightNumber'].filter(function (k) { return k in o; }), lb = csOf(recOf(id));
          if (lb && nk.length && nk.every(function (k) { return !o[k]; })) { o[nk[0]] = lb; n++; }
          ask.push({ id: id, cs: String(o.callsign || o.flight || o.flight_number || o.flightNumber || ''), from: String(o.from_iata || o.fromIata || ''), type: String(o.model || o.type || ''), has: !!r });
          return;
        }
        for (var k in o) if (o[k] && typeof o[k] === 'object') walk(o[k], depth + 1);
      })(j, 0);
      if (ask.length) askNaRoutes(ask);
      return n;
    }

    function bgFollowTrail(id) {
      if (!feedHeaders || !id || Date.now() - bgFollowAt < 20000) return;
      bgFollowAt = Date.now();
      var b = new Uint8Array([0x0d, id & 255, (id >>> 8) & 255, (id >>> 16) & 255, (id >>> 24) & 255]), x = new XMLHttpRequest(), done = false;
      x.__tlOwn = true;
      x.open('POST', 'https://data-feed.flightradar24.com/fr24.feed.api.v1.Feed/FollowFlight');
      for (var k in feedHeaders) if (Object.prototype.hasOwnProperty.call(feedHeaders, k)) { try { x.setRequestHeader(k, feedHeaders[k]); } catch (e) { /* ignore */ } }
      x.overrideMimeType('text/plain; charset=x-user-defined');
      var bytes = function () { var s = x.responseText || '', u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i) & 255; return u; };
      var finish = function () {
        if (done) return; done = true;
        try {
          var u = bytes(); try { x.abort(); } catch (e) { /* closed */ }
          if (u.length < 5 || u[0] !== 0) return;
          var len = ((u[1] << 24) | (u[2] << 16) | (u[3] << 8) | u[4]) >>> 0; if (u.length < 5 + len) return;
          var fs = parse(u.subarray(5, 5 + len)), pts = [], maxAlt = 0;
          for (var i = 0; i < fs.length; i++) {
            if (fs[i].fn !== 6 || fs[i].wt !== 2) continue;
            var tp = parse(fs[i].val), talt = numOf(tp, 4); if (talt > 2147483647) talt = 0; if (talt > maxAlt) maxAlt = talt;
            pts.push({ t: numOf(tp, 1), lat: fltOf(tp, 2), lon: fltOf(tp, 3), alt: talt, gs: numOf(tp, 5), trk: numOf(tp, 6) });
          }
          if (pts.length) { pts.sort(function (p, q) { return p.t - q.t; }); post('trail', { id: id, first: pts[0], n: pts.length, maxAlt: maxAlt, pts: pts, at: Date.now(), bg: true }); }
        } catch (e) { stats.errors++; stats.lastError = String(e); }
      };
      x.onprogress = function () { var s = x.responseText || ''; if (s.length >= 5) { var len = (((s.charCodeAt(1) & 255) << 24) | ((s.charCodeAt(2) & 255) << 16) | ((s.charCodeAt(3) & 255) << 8) | (s.charCodeAt(4) & 255)) >>> 0; if (s.length >= 5 + len) finish(); } };
      x.onload = finish; x.onerror = function () { done = true; };
      setTimeout(finish, 12000);
      x.send(concat([frameHeader(0, b.length), b]).buffer);
    }
    // FR24 answers at most 1500 flights per request (more is refused: "Flights limit exceeded"), and a busy region -
    // Europe in the morning, the US by day - holds more than that: the answer is then silently cut short. A full answer
    // therefore splits its box in four and each quarter is asked for (twice at most), so no aircraft is left out when
    // it is busy and nothing extra is asked when it is quiet.
    var scanQueue = Promise.resolve();
    function quarters(r) {
      var mLat = (r.n + r.s) / 2, mLon = (r.w + r.e) / 2;
      return [{ n: r.n, s: mLat, w: r.w, e: mLon }, { n: r.n, s: mLat, w: mLon, e: r.e }, { n: mLat, s: r.s, w: r.w, e: mLon }, { n: mLat, s: r.s, w: mLon, e: r.e }];
    }
    function runScan(regions, opts) {
      opts = opts || {};
      var results = [], limit = opts.limit || 1500, work = regions.map(function (r) { return { r: r, depth: 0 }; });
      function next() {
        var it = work.shift();
        if (!it) { post('scanDone', { results: results }); return null; }
        return liveFeedQuery(Object.assign({}, opts, it.r)).then(function (res) {
          results.push({ ok: true, n: res.frames, total: res.total, depth: it.depth });
          if (res.total >= limit - 10 && it.depth < 2) quarters(it.r).forEach(function (q) { work.push({ r: q, depth: it.depth + 1 }); });
        }, function (e) {
          var msg = String(e.message || e); results.push({ ok: false, err: msg }); stats.lastError = 'scan: ' + msg;
          if (/429|grpc (8|14)\b/.test(msg)) work.length = 0;   // FR24 is pushing back: the rest waits for the next scan
        }).then(function () { return new Promise(function (res) { oSetTimeout(res, opts.gapMs || 400); }); }).then(next);
      }
      scanQueue = scanQueue.then(next, next);
    }

    // ---- photos: Planespotters answers requests that carry the embedding site's Origin, i.e. requests made from here
    // Registrations get reused (N677AA was an American Airlines 737 before it was a Cessna 172): a photo found by
    // registration only is kept when its page does not name a different manufacturer than this aircraft's.
    var MAKERS = ['airbus', 'boeing', 'embraer', 'bombardier', 'canadair', 'cessna', 'textron', 'gulfstream', 'dassault', 'pilatus', 'beech', 'raytheon', 'hawker', 'learjet', 'piper', 'cirrus', 'diamond', 'mooney', 'bell', 'robinson', 'sikorsky', 'eurocopter', 'agusta', 'leonardo', 'honda', 'daher', 'socata', 'lockheed', 'mcdonnell', 'douglas', 'atr', 'fokker', 'saab', 'mitsubishi', 'grumman', 'eclipse', 'tecnam', 'antonov'];
    var SAME = { cessna: ['textron'], textron: ['cessna', 'beech', 'hawker'], beech: ['raytheon', 'hawker', 'textron'], raytheon: ['beech', 'hawker'], hawker: ['raytheon', 'beech', 'textron'], bombardier: ['canadair', 'learjet'], canadair: ['bombardier'], learjet: ['bombardier'], eurocopter: ['airbus'], airbus: ['eurocopter'], agusta: ['leonardo'], leonardo: ['agusta'], mcdonnell: ['douglas', 'boeing'], douglas: ['mcdonnell', 'boeing'], daher: ['socata'], socata: ['daher'] };
    function makerOf(rec) {
      if (!rec) return '';
      var d = String(rec.desc || '').toLowerCase();
      for (var i = 0; i < MAKERS.length; i++) if (d.indexOf(MAKERS[i]) === 0 || d.indexOf(' ' + MAKERS[i]) >= 0) return MAKERS[i];
      var t = String(rec.type || '').toUpperCase();
      return /^C[1-9]\d{1,2}|^C25|^C5|^C6|^C7/.test(t) ? 'cessna' : /^GLF|^GA\d/.test(t) ? 'gulfstream' : /^GL|^CL|^CRJ/.test(t) ? 'bombardier' : /^E\d|^E5|^E1/.test(t) ? 'embraer'
        : /^B7\d|^B3/.test(t) ? 'boeing' : /^A3\d|^A2\d/.test(t) ? 'airbus' : /^PC/.test(t) ? 'pilatus' : /^FA|^F2TH|^F900/.test(t) ? 'dassault' : /^LJ/.test(t) ? 'learjet' : /^B0[5-7]|^B4\d/.test(t) ? 'bell' : /^P28|^PA/.test(t) ? 'piper' : /^SR2/.test(t) ? 'cirrus' : '';
    }
    function photoFits(p, maker) {
      if (!maker) return true;
      var slug = String(p.link || '').toLowerCase().split('/photo/')[1] || ''; if (!slug) return true;
      var ok = [maker].concat(SAME[maker] || []), named = false;
      for (var i = 0; i < MAKERS.length; i++) if (new RegExp('(^|[-/])' + MAKERS[i] + '([-/?]|$)').test(slug)) { if (ok.indexOf(MAKERS[i]) >= 0) return true; named = true; }
      return !named;
    }
    function psPhotos(j) {
      var out = [];
      (j && Array.isArray(j.photos) ? j.photos : []).forEach(function (p) {
        var large = (p.thumbnail_large && p.thumbnail_large.src) || (p.thumbnail && p.thumbnail.src) || '';
        if (!/^https:\/\//.test(large) || out.length >= 3) return;
        out.push({ link: p.link || large, credit: p.photographer || '', thumb: (p.thumbnail && p.thumbnail.src) || large, medium: large, large: large, source: 'Planespotters', date: '' });
      });
      return out;
    }
    // Planespotters rate-limits (403/429) when asked for many airframes at once: requests go out one at a time, spaced,
    // and pause for a while after a refusal instead of hammering it. What the user is looking at right now (the
    // selected aircraft, an expanded search or board card) goes to the front; board-row warming waits its turn.
    var psLast = 0, psBlockedUntil = 0, psQ = [], psBusy = false, psFails = 0;
    var psPri = new Set();   // aircraft being looked at: every step of their lookup (hex, then registration) goes first
    function psGet(u, hex, pri) {
      return new Promise(function (resolve) {
        var job = { u: u, hex: hex, resolve: resolve };
        if (pri || psPri.has(hex)) psQ.unshift(job); else psQ.push(job);
        psPump();
      });
    }
    function psBump(hex) {
      psPri.add(hex);
      for (var i = 1; i < psQ.length; i++) if (psQ[i].hex === hex) { psQ.unshift(psQ.splice(i, 1)[0]); return; }
    }
    function psPump() {
      if (psBusy || !psQ.length) return;
      psBusy = true;
      oSetTimeout(function () {
        var job = psQ.shift(); psBusy = false;
        if (!job) return;
        if (Date.now() < psBlockedUntil) { job.resolve({ ok: false, status: 429 }); psPump(); return; }
        psLast = Date.now();
        // A refusal - or a failure the browser reports as a CORS error: Planespotters' rate limit and its outages (Cloudflare
        // 5xx) come without CORS headers - pauses the queue, longer each time it happens again, instead of hammering it.
        var pause = function () { psFails = Math.min(psFails + 1, 5); psBlockedUntil = Date.now() + 30000 * Math.pow(2, psFails - 1); };
        oFetch.call(window, job.u, { credentials: 'omit', referrerPolicy: 'strict-origin-when-cross-origin' })
          .then(function (r) { if (r.status === 403 || r.status === 429 || r.status >= 500) pause(); else psFails = 0; job.resolve(r); }, function (e) { pause(); job.resolve({ ok: false, status: 0, statusText: String(e && e.message || e) }); });
        psPump();
      }, Math.max(0, psLast + 1200 - Date.now()));
    }
    // Planespotters, asked from here for the userscript (its only use: the fallback when JetPhotos has no picture).
    // Its answers are kept apart from the pictures shown - those come from the userscript, JetPhotos first.
    function fetchPhotos(hex, reg, pri) {
      hex = String(hex || '').toUpperCase();
      var c = psCache.get(hex);
      if (c && (c.photos.length || Date.now() - c.at < (/HTTP (0|4(03|29)|5\d\d)/.test(c.err) ? 90000 : 600000))) return Promise.resolve(c.photos);
      if (photoJobs.has(hex)) { if (pri) psBump(hex); return photoJobs.get(hex); }
      if (pri) psPri.add(hex);
      var urls = [hex ? 'https://api.planespotters.net/pub/photos/hex/' + hex : '', reg ? 'https://api.planespotters.net/pub/photos/reg/' + encodeURIComponent(reg) : ''].filter(Boolean);
      var err = '';
      var job = urls.reduce(function (acc, u) {
        return acc.then(function (got) {
          if (got.length) return got;
          var byReg = u.indexOf('/photos/reg/') > 0;
          return psGet(u, hex, pri).then(function (r) {
            if (!r.ok) { err = 'HTTP ' + r.status; return []; }
            return r.json().then(function (j) {
              var ph = psPhotos(j); if (!byReg) return ph;
              var own = null; resolved.forEach(function (x) { if (!own && String(x.hex || '').toUpperCase() === hex) own = x; });
              var maker = makerOf(own), kept = ph.filter(function (p) { return photoFits(p, maker); });
              if (kept.length < ph.length) err = 'registration photos show another aircraft type';
              return kept;
            });
          }, function (e) { err = String(e.message || e); return []; });
        });
      }, Promise.resolve([])).then(function (photos) {
        psCache.set(hex, { photos: photos, at: Date.now(), err: photos.length ? '' : (err || 'none') }); psPri.delete(hex);
        photoJobs.delete(hex);
        post('photos', { hex: hex.toLowerCase(), reg: reg || '', photos: photos, err: photos.length ? '' : (err || 'none') });
        photosChanged();
        return photos;
      });
      photoJobs.set(hex, job);
      return job;
    }
    // Pictures to show: asked of the userscript (JetPhotos first, then Planespotters); answered by 'photosDone'.
    var photoWait = new Map(), photoAsked = new Map();   // HEX -> [resolve]; HEX -> time asked
    function shownPhotos(rec) {
      if (!rec) return [];
      var c = photoCache.get(String(rec.hex || '').toUpperCase());
      if (c && c.photos && c.photos.length) return c.photos;
      return rec.photos || [];
    }
    function photosFor(rec, pri) {
      if (!rec || !rec.hex) return Promise.resolve([]);
      var hex = String(rec.hex).toUpperCase(), have = shownPhotos(rec), c = photoCache.get(hex);
      if (have.length && c && c.final) return Promise.resolve(have);
      return new Promise(function (resolve) {
        var l = photoWait.get(hex) || []; l.push(resolve); photoWait.set(hex, l);
        // a background ask is repeated as a front-of-queue one when the aircraft is now being looked at
        var asked = photoAsked.get(hex);
        if (!asked || (pri && !asked.pri) || Date.now() - asked.at > 20000) { photoAsked.set(hex, { at: Date.now(), pri: !!pri }); post('needPhotos', { hex: hex.toLowerCase(), reg: rec.reg || '', pri: !!pri }); }
      });
    }
    // a card drawn once (search card, board card): waits for the pictures a short while, then shows what there is
    function photosWithin(rec, ms) {
      return withTimeout(photosFor(rec, true), ms, null).then(function (ph) {
        if (ph && ph.length) return ph;
        var have = shownPhotos(rec); if (have.length) return have;
        return ((psCache.get(String(rec.hex || '').toUpperCase()) || {}).photos) || [];
      });
    }
    // The pictures are fetched into the browser's cache the moment they are known - the first for every identified
    // aircraft, all three for the one being looked at - so the slideshow shows them the instant the panel opens.
    var preloaded = new Set();
    function preloadPhotos(photos, all) {
      for (var i = 0; i < (photos || []).length && i < (all ? 3 : 1); i++) {
        var ph = photos[i], u = ph && (ph.large || ph.medium || ph.thumb); if (!u || preloaded.has(u)) continue;
        if (preloaded.size > 1500) preloaded.clear();
        preloaded.add(u); try { var im = new Image(); im.decoding = 'async'; im.src = u; } catch (e) { /* ignore */ }
      }
    }
    var followedHex = function () { var r = followSt && followSt.id ? resolved.get(followSt.id) : null; return r && r.hex ? String(r.hex).toUpperCase() : ''; };
    function acceptPhotosDone(d) {
      var hex = String(d.hex || '').toUpperCase(); if (!hex) return;
      var photos = Array.isArray(d.photos) ? d.photos : [];
      if (photos.length) { photoCache.set(hex, { photos: photos, at: Date.now(), err: '', final: !d.early }); preloadPhotos(photos, hex === followedHex() || !!d.pri); }
      else if (!d.early) { var c = photoCache.get(hex); if (c) c.final = true; else photoCache.set(hex, { photos: [], at: Date.now(), err: 'none', final: true }); }
      if (!d.early) photoAsked.delete(hex);
      if (d.early && !photos.length) return;
      var w = photoWait.get(hex) || []; photoWait.delete(hex);
      w.forEach(function (fn) { try { fn(photos); } catch (e) { /* ignore */ } });
      photosChanged();
    }
    var hasPhotos = function (rec) { return shownPhotos(rec).length > 0; };
    // warm: ask now, so the card has its pictures when opened (nothing waits on the answer)
    function warmPhotos(rec, pri) { if (rec && rec.hex && !((photoCache.get(String(rec.hex).toUpperCase()) || {}).final)) photosFor(rec, pri); }
    var boardImage = function (ph) { var img = noBar(ph.large || ph.medium || ph.thumb); return { copyright: ph.credit || ph.source || '', link: ph.link || img, thumbnail: noBar(ph.thumb) || img, url: img }; };
    function withTimeout(p, ms, dflt) { return Promise.race([p, new Promise(function (res) { setTimeout(function () { res(dflt); }, ms); })]); }

    // ---- fetch shim: search box, airport boards (list + detail card), "Recent <reg> flights" ---------------------------
    function urlOf(input) { try { return typeof input === 'string' ? input : (input && input.url) || ''; } catch (e) { return ''; } }
    function jsonResponse(res, obj) {
      var headers = new Headers(res ? res.headers : { 'content-type': 'application/json' }); headers.delete('content-length'); headers.delete('content-encoding');
      if (!headers.get('content-type')) headers.set('content-type', 'application/json');
      return new Response(JSON.stringify(obj), { status: res && res.ok ? res.status : 200, statusText: res && res.ok ? res.statusText : 'OK', headers: headers });
    }
    // Live search results: one row per aircraft - the flight it is flying now. FR24 gives every leg its own flight id,
    // and the ids of earlier legs stay known (for boards and logs), so an aircraft that flew AGS-TEB and then TEB-MXP
    // must not be listed twice: only the id seen most recently counts, and only if it was seen in the last half hour.
    // (in FR24's playback: the flights of the moment being played - where its feed last placed them, a couple of minutes)
    function liveEntries(q) {
      var out = [], now = Date.now(), qq = q.replace(/[-\s]/g, ''), best = {}, pb = pbOn();
      resolved.forEach(function (rec, id) {
        var pos = (pb ? pbPos : lastPos).get(id);
        if (!pos || !pos.at || now - pos.at > (pb ? 120000 : 30 * 60000)) return;
        var keys = [rec.cs, rec.reg, rec.hex].filter(Boolean).map(function (s) { return String(s).toUpperCase(); });
        if (!keys.some(function (k) { return k.indexOf(q) === 0 || k.replace(/[-\s]/g, '').indexOf(qq) === 0; })) return;
        var ak = String(rec.hex || rec.reg || id).toUpperCase(), cur = best[ak];
        if (!cur || pos.at > cur.pos.at || (pos.at === cur.pos.at && id > cur.id)) best[ak] = { id: id, rec: rec, pos: pos };
      });
      Object.keys(best).forEach(function (ak) {
        var id = best[ak].id;
        out.push(liveRow(id, best[ak].rec, (pb ? pbRoutes.get(id) : routes.get(id)) || {}, best[ak].pos, 'begins'));
      });
      return out.slice(0, 20);
    }
    var routeText = function (from, fromCity, to, toCity) { return from || to ? ((fromCity || from || '?') + (from ? ' (' + from + ')' : '') + ' ⟶ ' + (toCity || to || '?') + (to ? ' (' + to + ')' : '')) : ''; };
    function liveRow(id, rec, route, pos, match) {
      var from = route.originIata || '', to = route.destIata || '', label = csOf(rec);
      return { id: id.toString(16), label: label + (rec.reg && csOf(rec) !== String(rec.reg).replace(/[^A-Za-z0-9]/g, '').toUpperCase() ? ' / ' + rec.reg : '') + ' / ' + (rec.type || '') + ' (' + (rec.reg || rec.hex) + ')',
        detail: { lat: pos.lat, lon: pos.lon, schd_from: from, schd_to: to, ac_type: rec.type || '', route: routeText(from, route.originCity, to, route.destCity), logo: logoOf(rec.operatorId), reg: rec.reg || '', callsign: label, flight: label, operator: rec.operatorIcao || '', operator_id: rec.operatorId || 0 },
        type: 'live', match: match };
    }
    // (a route searched for - "LPL-EIS": the flights the userscript has worked out between the two, each { id, rec, route,
    // pos } - those named here and those FR24 shows without a destination alike - as live flights, as FR24 lists its own)
    function routeRows(list) {
      var out = [], now = Date.now();
      (list || []).forEach(function (x) {
        if (!x || x.id == null || !x.route || !x.pos || !fin(x.pos.lat) || now - (x.pos.at || 0) > 30 * 60000) return;
        var id = Number(x.id), rec = resolved.get(id) || x.rec; if (!rec) return;
        out.push(liveRow(id, rec, routeOf(id) || x.route, lastPos.get(id) || x.pos, 'begins'));
      });
      return out.slice(0, 20);
    }
    // (FR24's own row of a flight it has no destination for: the one worked out here, as on its panel)
    function liveDestFix(r) {
      if (!r || r.type !== 'live' || !r.id || !r.detail || r.detail.schd_to) return false;
      var route = routeNow(parseInt(r.id, 16)); if (!route || !/^[A-Z0-9]{3,4}$/.test(route.destIata || '')) return false;
      var d = r.detail, from = d.schd_from || route.originIata || '';
      d.schd_to = route.destIata; if (!d.schd_from && from) d.schd_from = from;
      d.route = routeText(from, route.originCity, route.destIata, route.destCity);
      return true;
    }
    // (the userscript's search answer - the blocked aircraft and callsigns it keeps logs of - asked for as FR24 asks its own;
    // a moment at most, then without it)
    var searchWait = new Map(), searchSeq = 0;
    // (1.2.1: routes for flights the page has none of - asked of the userscript, which asks the monitor; 1.5 s at most)
    var routeAskWait = new Map();
    function askRoutes(ids) {
      if (!ids || !ids.length) return Promise.resolve();
      var rid = 'r' + (++searchSeq);
      return new Promise(function (res) { routeAskWait.set(rid, res); oSetTimeout(function () { if (routeAskWait.has(rid)) { routeAskWait.delete(rid); res(); } }, 1500); post('routesAsk', { rid: rid, ids: ids }); });
    }
    function onRoutesGot(d) {
      Object.keys(d && d.routes || {}).forEach(function (k) { var r = d.routes[k]; if (r && !routes.has(Number(k))) routes.set(Number(k), r); });
      var f = d && typeof d.rid === 'string' ? routeAskWait.get(d.rid) : null; if (typeof f === 'function') { routeAskWait.delete(d.rid); f(); }
    }
    function askSearch(q) { var rid = 's' + (++searchSeq); return new Promise(function (res) { searchWait.set(rid, res); oSetTimeout(function () { if (searchWait.has(rid)) { searchWait.delete(rid); res({ rows: [], live: [] }); } }, 700); post('needSearch', { q: q, rid: rid }); }); }
    function onSearchAdd(d) {
      // (each a blocked aircraft or a callsign of one: its Playback is FR24's map playback of its flight)
      (Array.isArray(d.rows) ? d.rows : []).forEach(function (r) { if (r && r.id && (r.type === 'aircraft' || r.type === 'schedule')) pbBlkNote(r.type === 'aircraft' ? 'A' : 'C', r.id, r.type === 'aircraft' && r.detail ? r.detail.hex : ''); });
      var f = d && typeof d.rid === 'string' ? searchWait.get(d.rid) : null; if (typeof f === 'function') { searchWait.delete(d.rid); f({ rows: Array.isArray(d.rows) ? d.rows : [], live: Array.isArray(d.live) ? d.live : [] }); }
    }
    // (a logo FR24 has none of - BAE Systems' - on any row of its search: airline, aircraft, flight)
    function logoFix(r) { var id = r && r.detail && r.detail.operator_id; if (!id || !LOGO_ADD[id] || r.detail.logo === LOGO_ADD[id].source) return false; r.detail.logo = LOGO_ADD[id].source; return true; }
    function recByReg(reg) { reg = String(reg || '').toUpperCase(); var hit = null; resolved.forEach(function (rec) { if (!hit && rec.reg && rec.reg.toUpperCase() === reg) hit = rec; }); return hit; }
    function enrichAircraftRow(r) {
      if (!r || r.type !== 'aircraft' || !r.id) return false;
      var hit = recByReg(r.id); if (!hit) return false;
      var d = r.detail = r.detail || {}, changed = false;
      if (!d.equip && hit.type) { d.equip = hit.type; changed = true; }
      if (!d.hex && hit.hex) { d.hex = hit.hex.toUpperCase(); changed = true; }
      if (!d.operator_id && hit.operatorId) { d.operator_id = hit.operatorId; d.logo = logoOf(hit.operatorId); changed = true; }
      if (!d.owner && (hit.operatorIcao || hit.operatorName)) { d.owner = hit.operatorIcao || hit.operatorName; changed = true; }
      return changed;
    }
    // FR24's aircraft category ids, as its own code lists them (8 Oct): 0 passenger, 1 cargo, 2 military and government,
    // 3 business jet, 4 general aviation, 5 helicopter, 6 lighter than air, 7 glider, 8 drone, 9 ground vehicle. (The
    // helicopters were 8 here - M-SKTO's H160 a "Drone" - and military 9, "ground vehicles".) By type, else by the
    // transponder's emitter category. (The userscript's own reading of the type, where it gave one: an airliner is a
    // passenger aircraft - HZ-AR27's 787-10 was a "Business jet")
    function categoryOf(rec) {
      if (typeof rec.fcat === 'number') return rec.fcat;
      var c = String(rec.cat || ''), t = String(rec.type || '').toUpperCase();
      // (1.2.1: a jet whose type starts "H" and a digit is no helicopter - SP-CEO's H25B, a Hawker 750; and a type known
      // as an aeroplane is not one for its transponder saying "rotorcraft")
      var jetH = /^(H25[A-C]|HA4T|HDJT)$/.test(t);
      if (!jetH && ((c === 'A7' && !/^(C\d|B7|A3|E\d|GL|FA|LJ|CL|PC|BE|P28|SR2|DA\d)/.test(t)) || /^(H\d+$|H\d{2}[A-Z]?$|EC\d|AS[3-6]|A1[0-6]9|AW\d|S\d{2}|B0[5-7]|B4\d\d|R[246][246]|NH90|EH10|MD[59]|BK17|EXPL)/.test(t))) return 5;
      if (rec.mil) return 2;
      if (c === 'B1' || /^(GLID|ASK|ASW|ASG|ASH|DG\d|LS\d|DISC|DUO|JANU|NIMB|VENT|ARCP)/.test(t)) return 7;
      if (c === 'B2' || /^BALL/.test(t)) return 6;
      if (c === 'B6') return 8;
      if (c === 'A1' || /^(C1[5-9]\d|C2[01]\d|SR2|P28|PA\d|DA[24]|BE3|M20|AA5|DR40|TB[12])/.test(t)) return 4;
      return 3;
    }
    function boardRowFor(id, rec, route, kind, apId) {
      var label = csOf(rec);
      var dep = kind === 'departures';
      var sched = dep ? (route.std || route.atd) : (route.sta || route.eta);
      var est = dep ? (route.atd || route.etd || route.std) : (route.landed ? route.ata : (route.eta || route.sta));
      // green like any scheduled arrival when filed / on approach / landed / likely (72%+); FR24's yellow "ambiguous"
      // style for the less certain reasoned ones
      var sure = route.destConf === 'filed' || route.destConf === 'confirmed' || route.destConf === 'landed' || route.destConf === 'likely';
      var st = dep ? (route.atd ? { name: 'departed', color: 'green', isAmbiguous: false, live: !route.landed } : { name: 'estimated', color: 'green', isAmbiguous: false, live: false })
        : route.landed ? { name: 'landed', color: 'green', isAmbiguous: false, live: false }
        : { name: 'estimated', color: sure ? 'green' : 'yellow', isAmbiguous: !sure, live: true };
      return { aircraftType: rec.type || '', airline: rec.operatorName || rec.owner || (rec.mil ? 'Military' : 'Private owner'), airlineId: rec.operatorId || null, airportId: (dep ? route.destId : route.originId) || null, divertedToId: null,
        estimatedTime: est || sched || null, flight: { callsign: label, id: id.toString(16), number: null }, id: 9000000000 + id, runway: null, scheduledTime: sched || est || null, status: st, __tlAdded: true };
    }
    function boardDetailFor(id, rec, route, kind, apId, photos) {
      var label = csOf(rec), dep = kind === 'departures';
      var row = boardRowFor(id, rec, route, kind, apId);
      return { data: { aircraft: { category: categoryOf(rec), name: rec.desc || rec.type || null, registration: rec.reg || null, type: rec.type || null }, airline: rec.operatorName || rec.owner || (rec.mil ? 'Military' : 'Private owner'), airlineId: rec.operatorId || null,
        destinationId: route.destId || (dep ? null : apId), divertedToId: null, flight: { callsign: label, id: id.toString(16), number: null }, id: 9000000000 + id,
        images: (photos || []).slice(0, 3).map(boardImage), locationInfo: { belt: null, gate: null, terminal: null }, originId: route.originId || (dep ? apId : null),
        runways: { arrival: { name: null, upsell: false }, departure: { name: null, upsell: false } },
        // scheduled times only from a filed plan (route.std/sta); nothing is invented for a private flight
        schedule: { ata: route.ata || null, atd: route.atd || null, eta: route.landed ? (route.ata || null) : (route.eta || route.sta || null), etd: route.etd || route.atd || route.std || null, sta: route.sta || null, std: route.std || null },
        // FR24's info box (status.isAmbiguous) on every card whose destination is the userscript's rather than filed: it
        // becomes the yellow "predicted destination" note, or the green "confirmed destination" one (on final approach)
        status: Object.assign({}, row.status, { isAmbiguous: !!route.destId && !route.landed && route.destConf !== 'filed' && route.destConf !== 'landed' }) }, __tlAdded: true };
    }
    // ---- airport boards: identified traffic appears the moment its route is reasoned -----------------------------
    // FR24 re-reads an open board every 5 minutes (a setTimeout it arms right after each board response). That timer
    // is recognised, and fired early - rate-limited - whenever a newly reasoned flight joins or leaves the board on
    // screen or lands there, so the row shows up within seconds instead of minutes. It is FR24's own reload, nothing more.
    var curBoard = null, boardServedAt = 0, boardTimers = [], lastBoardRefresh = 0, boardRefreshPending = 0;
    function boardMatch(route, apId, kind) {
      if (!route) return false;
      return kind === 'on-grounds' ? route.groundAirportId === apId : kind === 'departures' ? route.originId === apId : route.destId === apId;
    }
    function kmBetween(a1, o1, a2, o2) { var r = Math.PI / 180, x = (o2 - o1) * r * Math.cos((a1 + a2) / 2 * r), y = (a2 - a1) * r; return Math.sqrt(x * x + y * y) * 6371; }
    // A flight gone quiet for three minutes, last heard low beside where it was going, is down there: its board row is a
    // landed one at once, as FR24's own turns - not an "estimated" one burned on for half an hour after (HLL01 into
    // Liverpool, listed both landed and still estimated 40 minutes after)
    function routeNow(id) {
      var route = routeOf(id); if (!route || route.landed || route.destLat == null) return route;
      var lp = lastPos.get(id); if (!lp || Date.now() - lp.at < 180000 || lp.alt == null || lp.alt - (route.destAlt || 0) > 2500) return route;
      var km = kmBetween(lp.lat, lp.lon, route.destLat, route.destLon); if (km > 12) return route;
      return Object.assign({}, route, { landed: true, ata: Math.round(lp.at / 1000 + Math.max(60, km / 4 * 60)), destConf: 'landed' });
    }
    // Whether (and how) an identified flight belongs on a board: '' not listed, 'E' en route / expected, 'L' landed.
    // One rule for both listing it and deciding that the open board needs a reload.
    function boardSig(id, apId, kind) {
      var rec = recOf(id), route = routeNow(id);
      if (!rec || !route || !(csOf(rec)) || !boardMatch(route, apId, kind)) return '';
      // (never flew: a transponder on to taxi - and back where it began only after a take-off that was seen)
      if (kind !== 'on-grounds' && ((route.landed && route.originId && route.originId === route.destId && !(route.atd > 0 && (route.ata || 0) - route.atd >= 600)) || (!route.landed && route.groundAirportId))) return '';
      // (the other end of the row counts too: a departure that becomes known re-reads an arrivals board)
      var other = kind === 'arrivals' ? ':' + (route.originId || 0) : kind === 'departures' ? ':' + (route.destId || 0) : '';
      var nowS = Date.now() / 1000, lp = lastPos.get(id);
      if (kind !== 'on-grounds') {
        if (!route.landed && (!lp || Date.now() - lp.at > 30 * 60000)) return '';               // not seen for half an hour
        if (route.landed && nowS - (route.ata || 0) > 3 * 3600) return '';                       // landed hours ago
        if (kind === 'arrivals' && !route.landed && route.eta && route.eta < nowS - 45 * 60) return '';   // overdue
      }
      return (route.landed ? 'L' : 'E') + other;
    }
    function noteBoard(apId, kind) {
      // sig: what each identified flight looked like when the board was last served; native: flights FR24 lists itself
      if (!curBoard || curBoard.apId !== apId || curBoard.kind !== kind) curBoard = { apId: apId, kind: kind, sig: {}, native: {} };
      return curBoard;
    }
    var oSetTimeout = window.setTimeout, oClearTimeout = window.clearTimeout;
    window.setTimeout = function (fn, ms) {
      var h = oSetTimeout.apply(this, arguments);
      // (only FR24's 5-minute board reloads: it arms other long timers about then - the open panel's 10-minute
      // autorefresh, a clock tick - and firing one of those in their place left a newly listed flight off the board)
      try {
        if (typeof fn === 'function' && ms >= 240000 && ms <= 360000 && Date.now() - boardServedAt < 5000) {
          var src = ''; try { src = Function.prototype.toString.call(fn).slice(0, 400); } catch (e) { /* ignore */ }
          if (!/Autorefresh|updateInfoPanel|\.tick\(/.test(src)) { boardTimers = boardTimers.filter(function (b) { return b.fn !== fn; }); boardTimers.push({ fn: fn, h: h, args: [].slice.call(arguments, 2) }); if (boardTimers.length > 6) boardTimers.shift(); }
        }
      } catch (e) { /* ignore */ }
      return h;
    };
    window.clearTimeout = function (h) { if (boardTimers.length) boardTimers = boardTimers.filter(function (b) { return b.h !== h; }); return oClearTimeout.apply(this, arguments); };
    function boardAffected(ids) {
      if (!curBoard || !boardTimers.length) return false;
      for (var i = 0; i < ids.length; i++) {
        var id = Number(ids[i]); if (curBoard.native[id]) continue;
        if (boardSig(id, curBoard.apId, curBoard.kind) !== (curBoard.sig[id] || '')) return true;   // joins, leaves or lands
      }
      return false;
    }
    function refreshBoardSoon() {
      if (boardRefreshPending || !boardTimers.length) return;
      // (within a second; at most one re-read every 5 s - a destination still settling re-reads again once it has)
      var wait = Math.max(800, lastBoardRefresh + 5000 - Date.now());
      boardRefreshPending = oSetTimeout(function () {
        boardRefreshPending = 0;
        var ts = boardTimers; if (!ts.length || !document.querySelector('li[id^="airport_schedule_"], [data-testid^="airport-panel__tab-"]')) return;
        boardTimers = []; lastBoardRefresh = Date.now();
        ts.forEach(function (t) { try { oClearTimeout(t.h); t.fn.apply(window, t.args); stats.boardRefreshes++; } catch (e) { stats.errors++; stats.lastError = String(e); } });
      }, wait);
    }
    // ---- the board archive (userscript 06-boards): three days back and three ahead, in one list ------------------
    // FR24 serves a free account its page 1 (now onwards) and page -1 (earlier today), a page at a time. Its page 1 is
    // answered with both, and with every flight the userscript keeps for the airport, in FR24's row format - its own day
    // headings and cards - cut into FR24's own pages (1.1.5, below): the present first, the rest when its "Load earlier /
    // later flights" asks, answered here.
    var boardArch = new Map(), archWait = new Map(), archById = new Map(), archRefreshAt = 0, archRefreshT = 0, archRefreshSince = 0;
    // (1.1.5) A board's whole list - FR24's rows, the kept fortnight, the flights followed here - is FR24's own pages:
    // FR24 drawing a thousand rows at once held the page for seconds (two minutes, with the script's watchers), however
    // little the script did. Page 1 is the present (40 rows before it, 160 after); the pages before and after it 100 rows
    // each, as FR24's own, their edges times set once when the board opens - a page's rows the same however often FR24
    // asks for it again, none twice, none lost - answered here at once when FR24's "Load earlier / later flights" asks.
    var boardKept = new Map(), PAGE_FIRST = 200, PAGE_ROWS = 100, PAGE_BEFORE = 40;
    var rowT = function (e) { return (e && (e.scheduledTime || e.estimatedTime || e.landedTime)) || 0; };
    function keepBoard(apId, kind, list, fresh) {
      var k = apId + '/' + kind, kb = boardKept.get(k), now = Date.now();
      // (the edges set when FR24 opens the board - its first ask names no page - and not again while it holds other pages
      // of it: every five minutes, and on coming back to the tab, it asks again for every page it has, all at once, and
      // each must keep its rows. With page 1 alone drawn, set afresh after ten minutes, to keep up with the present)
      if (!kb || fresh || (!kb.paged && now - kb.anchoredAt > 10 * 60000)) {
        var from = now / 1000 - 900, start = 0; while (start < list.length && rowT(list[start]) < from) start++;
        // (nothing before page 1: it reaches back to the start, whatever comes in earlier later on)
        var i0 = Math.max(0, start - PAGE_BEFORE), cuts = { 1: i0 > 0 && list.length ? rowT(list[Math.min(i0, list.length - 1)]) : -Infinity };
        for (var n = 2, i = i0 + PAGE_FIRST; i < list.length; n++, i += PAGE_ROWS) cuts[n] = Math.max(rowT(list[i]), cuts[n - 1]);
        for (var q = 1, b = i0 - PAGE_ROWS; i0 > 0; q++, b -= PAGE_ROWS) { cuts[-q] = b > 0 ? Math.min(rowT(list[b]), q === 1 ? cuts[1] : cuts[-q + 1]) : -Infinity; if (b <= 0) break; }
        kb = { anchoredAt: now, cuts: cuts, paged: false };
      }
      kb.list = list; kb.at = now;
      // (the last four boards asked for kept: FR24 shows one at a time, and asks for page 1 afresh whenever one is opened)
      boardKept.delete(k); boardKept.set(k, kb);
      if (boardKept.size > 4) boardKept.delete(boardKept.keys().next().value);
      return kb;
    }
    // (page p's rows: from the time it begins to the time the next begins - the last forward page to the end, the first
    // page back from the start)
    function pageOf(kb, p) {
      // (a page there is none of: empty, leading nowhere - never "earlier" again and again)
      var c = kb.cuts; if (c[p] == null) return { data: [], meta: { currentPage: p, previousPage: null, nextPage: null, hasMorePreviousData: false, hasMoreNextData: false } };
      var lo = c[p], hi = p >= 1 ? (c[p + 1] != null ? c[p + 1] : Infinity) : (p === -1 ? c[1] : c[p + 1]);
      var list = kb.list || [], data = list.filter(function (e) { var t = rowT(e); return t >= lo && t < hi; });
      var before = lo > -Infinity && list.some(function (e) { return rowT(e) < lo; }), after = hi < Infinity && list.some(function (e) { return rowT(e) >= hi; });
      return { data: data, meta: { currentPage: p, previousPage: before ? (p === 1 ? -1 : p - 1) : null, nextPage: after ? (p === -1 ? 1 : p + 1) : null, hasMorePreviousData: before, hasMoreNextData: after } };
    }
    function keptPage(apId, kind, url) {
      var pm = url.match(/[?&]page=(-?\d+)/), p = pm ? Number(pm[1]) : 1; if (p === 1 || p === 0) return null;
      // (however long ago page 1 was: the pages FR24 asks for again, coming back to the tab after an hour, are the pages it has)
      var kb = boardKept.get(apId + '/' + kind); if (!kb || !kb.list) return null;
      var pg = pageOf(kb, p); kb.paged = true; stats.boardPages = (stats.boardPages || 0) + 1;
      return { data: pg.data, meta: Object.assign({ date: kb.date || null }, pg.meta) };
    }

    function hashStr(s) { var h = 2166136261; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h; }
    function needBoardArch(apId) {
      var a = boardArch.get(apId);
      if (a && Date.now() - a.at < 60000) return Promise.resolve(a);
      post('needBoard', { apId: apId });
      // (the first time: waited for, two seconds at most - read from disk, with the monitor's flights of the airport - so the
      // board is drawn whole: its blocked aircraft's rows were "N/A" where they went or came from, and the list jumped, as
      // the rest came in a re-read later. A copy kept from before: used at once, the new one re-reads the board)
      return withTimeout(new Promise(function (res) { var l = archWait.get(apId) || []; l.push(res); archWait.set(apId, l); }), a ? 0 : 2000, a || null);
    }
    function acceptBoardArch(d) {
      var apId = Number(d.apId); if (!apId) return;
      var a = { arr: Array.isArray(d.arr) ? d.arr : [], dep: Array.isArray(d.dep) ? d.dep : [], at: Date.now() }, had = boardArch.get(apId);
      boardArch.set(apId, a);
      var w = archWait.get(apId) || []; archWait.delete(apId); w.forEach(function (fn) { try { fn(a); } catch (e) { /* ignore */ } });
      // (rows added while the board is open: FR24's own re-read shows them)
      // (and the first lot, when FR24's board was served before it came; while an airport fills up, a re-read at most
      // every 15 s - each one redraws the whole list)
      // (1.1.2: rows that keep coming - FR24's schedule read, flight-number lookups - redrawn once they have settled, three
      // seconds with nothing new, and not more than every 30 s: each redraw of a week's list was the board building
      // itself again a piece at a time)
      if (curBoard && curBoard.apId === apId && (!had || had.arr.length !== a.arr.length || had.dep.length !== a.dep.length)) {
        if (!had) { archRefreshAt = Date.now(); refreshBoardSoon(); }
        else {
          if (archRefreshT && Date.now() - archRefreshSince < 30000) { oClearTimeout(archRefreshT); archRefreshT = 0; }
          if (!archRefreshT) { if (!archRefreshSince || Date.now() - archRefreshSince >= 30000) archRefreshSince = Date.now(); archRefreshT = oSetTimeout(function () { archRefreshT = 0; archRefreshSince = 0; archRefreshAt = Date.now(); refreshBoardSoon(); }, Math.max(3000, archRefreshAt + 30000 - Date.now())); }
        }
      }
    }
    function archRow(r, kind, apId) {
      // (FR24's own row of the flight, kept as FR24 served it or converted field for field: exactly what its board shows)
      if (r.nat && r.nat.id && r.nat.scheduledTime) { archById.set(r.nat.id, { r: r, kind: kind, apId: apId, fid: r.nat.flight && r.nat.flight.id || ('c' + (hashStr(r.k) % 0x0fffffff).toString(16)), own: !(r.nat.flight && r.nat.flight.id) }); if (archById.size > 8000) archById.delete(archById.keys().next().value); return Object.assign({}, r.nat, { __tlAdded: true, __tlArch: true }); }
      // (FR24's own row id where it gave one - its board or its flight-number list: its card is FR24's then)
      var h = hashStr(r.k), id = (r.src === 'fr24' || r.src === 'sched') && r.id ? r.id : 20000000000 + (h % 1000000000);
      var fid = r.fid || ('c' + (h % 0x0fffffff).toString(16));
      // (own: the flight id made up here for a row of this script's own, not FR24's id of the flight - 1.2.4 playback)
      archById.set(id, { r: r, kind: kind, apId: apId, fid: fid, own: !r.fid }); if (archById.size > 8000) archById.delete(archById.keys().next().value);
      return { id: id, flight: { id: fid, number: r.num || null, callsign: r.cs || null }, status: { name: r.st || (kind === 'arrivals' ? 'landed' : 'departed'), color: r.col || 'green', isAmbiguous: false, live: false },
        scheduledTime: r.sch || r.t, estimatedTime: r.est || r.t, airportId: r.ap || null, divertedToId: null, airlineId: r.alId || null, airline: r.al || null, aircraftType: r.ty || null, runway: null, __tlAdded: true, __tlArch: true };
    }
    // Kept rows into FR24's board answer (the whole of it is one page now). Returns rows added.
    function addArch(j, apId, kind) {
      if (kind === 'on-grounds') return 0;
      var a = boardArch.get(apId), rows = a ? (kind === 'arrivals' ? a.arr : a.dep) : null; if (!rows || !rows.length) return 0;
      var nowS = Date.now() / 1000;
      var nat = j.data.filter(function (e) { return e && !e.__tlArch; });
      // (none twice: FR24's own row of the flight - by its flight id, its flight number within 30 minutes, or its callsign
      // within 45)
      // (indexed by callsign and number: an airport's six days are thousands of rows)
      var fids = {}, cst = {}, nmt = {}, add = function (o, k, t, e) { (o[k] || (o[k] = [])).push({ t: t, e: e }); }, near = function (o, k, t, w) { return k ? (o[k] || []).find(function (x) { return Math.abs(x.t - t) < w; }) || null : null; };
      nat.forEach(function (e) { if (e.flight && e.flight.id) fids[String(e.flight.id)] = e; if (e.flight && e.flight.callsign) add(cst, String(e.flight.callsign).toUpperCase(), e.estimatedTime || e.scheduledTime || 0, e); if (e.flight && e.flight.number) add(nmt, String(e.flight.number).toUpperCase(), e.scheduledTime || 0, e); });
      // (the same callsign to the same airport with its time moved - a flight not flown yet planned again: FR24's own row of
      // CWL52 to Glasgow at 15:30 (estimated 15:40), the schedule's at 16:15 (16:25), exactly 45 minutes apart - within two
      // hours by any of their times; two flights already flown within 45 minutes)
      var went = function (x) { return /^(departed|landed)$/.test(x || ''); };
      var nearCs = function (k, r) {
        if (!k) return null;
        var rt = [r.est, r.sch, r.t].filter(Boolean), ra = went(r.st), rap = (r.nat && r.nat.airportId) || r.ap || 0;
        return (cst[k] || []).find(function (x) {
          var e = x.e;
          if (ra && went(e.status && e.status.name)) return Math.abs(x.t - (r.est || r.t)) < 2700;
          if (e.airportId && rap && e.airportId === rap) return [e.estimatedTime, e.scheduledTime].filter(Boolean).some(function (a) { return rt.some(function (b) { return Math.abs(a - b) < 7200; }); });
          return Math.abs(x.t - (r.est || r.t)) < 2700;
        }) || null;
      };
      var pick = rows.filter(function (r) {
        var t = r.sch || r.t; if (!(t >= nowS - 7 * 86400 && t <= nowS + 7 * 86400)) return false;
        var hit = (r.fid && fids[r.fid]) || near(nmt, String(r.num || '').toUpperCase(), r.sch || r.t, 1800) || nearCs(String(r.cs || '').toUpperCase(), r);
        if (!hit) return true;
        // (FR24's own row of it stands - what it leaves out, "N/A" where the flight went or came from, the aircraft of
        // its card, from the kept one: G-PTRK)
        nativeFill(hit.e || hit, r, kind);
        return false;
      });
      pick.forEach(function (r) { j.data.push(archRow(r, kind, apId)); });
      return pick.length;
    }
    // What a native row of FR24's leaves empty - the other airport, the type, the aircraft of its card - from a flight
    // this script knows: a kept row of it, or an N/A flight it follows. Its card is filled from natInfo.
    var natInfo = new Map();
    function nativeFill(e, r, kind, route) {
      if (!e || !r) return;
      if (!e.airportId && r.ap) { e.airportId = r.ap; if (route && !route.landed && kind === 'departures' && ['filed', 'confirmed', 'landed'].indexOf(route.destConf) < 0) e.status = Object.assign({}, e.status, { isAmbiguous: true }); }
      if (!e.aircraftType && r.ty) e.aircraftType = r.ty;
      // (no airline on FR24's own row - G-RVRN's, Ravenair's: the operator the userscript names, and so its logo)
      if (!e.airlineId && r.alId) { e.airlineId = r.alId; if (!e.airline || /private owner/i.test(e.airline)) e.airline = r.al || e.airline; }
      var cur = natInfo.get(e.id) || {};
      natInfo.set(e.id, { blk: !!(cur.blk || r.blk), reg: cur.reg || r.reg || '', hex: cur.hex || r.hex || '', ty: cur.ty || r.ty || '', dsc: cur.dsc || r.dsc || '', al: cur.al || r.al || '', alId: cur.alId || r.alId || 0, fc: cur.fc != null ? cur.fc : r.fc, ap: cur.ap || r.ap || 0, kind: kind });
      if (natInfo.size > 3000) natInfo.delete(natInfo.keys().next().value);
    }
    // A registration from a callsign that is one - GPTRK, DEABC, FGXYZ, N123AB - checked against FR24's own register
    // lookup (its aircraft list): its model, Mode S address and operator. One lookup per registration.
    var regInfoCache = new Map();
    function regInfo(reg) {
      reg = String(reg || '').toUpperCase(); if (!reg) return Promise.resolve(null);
      if (regInfoCache.has(reg)) return regInfoCache.get(reg);
      var p = oFetch.call(window, 'https://api.flightradar24.com/common/v1/flight/list.json?query=' + encodeURIComponent(reg) + '&fetchBy=reg&page=1&limit=1', { credentials: 'omit' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
        var resp = j && j.result && j.result.response, ai = resp && resp.aircraftInfo; if (!ai || String(ai.registration || '').toUpperCase() !== reg) return null;
        return { reg: reg, hex: String(ai.hex || '').toLowerCase(), ty: (ai.model && ai.model.code) || '', dsc: (ai.model && ai.model.text) || '', al: (ai.airline && ai.airline.name) || (ai.owner && ai.owner.name) || '', blocked: resp.data === null };
      }).catch(function () { return null; });
      regInfoCache.set(reg, p); if (regInfoCache.size > 300) regInfoCache.delete(regInfoCache.keys().next().value);
      return p;
    }
    function regsOfCallsign(cs) {
      cs = String(cs || '').toUpperCase(); if (!/^[A-Z0-9]{4,7}$/.test(cs) || /^[A-Z]{3}\d/.test(cs) && !/^N/.test(cs)) return [];
      if (/^N\d[0-9A-Z]{0,4}$/.test(cs)) return [cs];
      var out = [];
      for (var n = 1; n <= 2; n++) { var p = cs.slice(0, n), rest = cs.slice(n); if (rest.length >= 3 && /^[A-Z0-9]+$/.test(p)) out.push(p + '-' + rest); }
      return out;
    }
    function infoOfCallsign(cs) {
      var c = regsOfCallsign(cs);
      return c.reduce(function (pr, reg) { return pr.then(function (hit) { return hit || regInfo(reg); }); }, Promise.resolve(null));
    }
    // (the registered owner / operator the userscript keeps of an aircraft - asked for, and waited on a moment, when it has
    // none yet: M-SKTO "Private owner" on FR24's own card)
    function ownerOf(hex, reg, ms) {
      var H = String(hex || '').toUpperCase(), have = function () { var p = pubIds.get(H); return p && p.o ? p.o : ''; };
      if (!/^[0-9A-F]{6}$/.test(H) || have()) return Promise.resolve(have());
      post('needPub', { hex: H.toLowerCase(), reg: reg || '' });
      return new Promise(function (res) { var t0 = Date.now(); (function look() { var o = have(); if (o || Date.now() - t0 > ms) return res(o); oSetTimeout(look, 100); })(); });
    }
    // the card of FR24's own row: its aircraft, airline, other airport and pictures where FR24 has none
    function fillNativeCard(d, rowId, kind) {
      var info = natInfo.get(rowId) || null, ac = d.aircraft = d.aircraft || {};
      var need = !ac.registration || !ac.type, priv = !d.airline || /private owner/i.test(d.airline);
      var known = String(ac.hex || ac.icao24 || ac.modeS || '').toLowerCase();
      var got = info && (info.reg || info.hex) ? Promise.resolve(info) : need ? infoOfCallsign(d.flight && d.flight.callsign) : priv && !/^[0-9a-f]{6}$/.test(known) && ac.registration ? regInfo(ac.registration) : Promise.resolve(known ? { hex: known } : null);
      // (what was kept of the flight without its aircraft - the type and operator its schedule gave: CWL52's card, Cranwell
      // FTU, E50P - stands with what the lookup adds)
      if (info && !(info.reg || info.hex) && (info.ty || info.al)) got = got.then(function (x) { var o = Object.assign({}, info); Object.keys(x || {}).forEach(function (k) { if (x[k]) o[k] = x[k]; }); return o; });
      return got.then(function (x) {
        if (x) {
          if (!ac.registration && x.reg) ac.registration = x.reg;
          // (FR24's category goes with the type it had - "Business jet" on an H125 with none)
          if (!ac.type && x.ty) { ac.type = x.ty; ac.category = categoryOf({ type: x.ty, fcat: x.fc }); }
          if (!ac.name && (x.dsc || x.ty)) ac.name = x.dsc || x.ty;
          if (x.ap) { if (kind === 'departures' && !d.destinationId) d.destinationId = x.ap; if (kind === 'arrivals' && !d.originId) d.originId = x.ap; }
        }
        var hex = (x && x.hex) || known, rg = ac.registration || '';
        if (Array.isArray(d.images)) d.images = d.images.filter(function (im) { return !adJson(im); });
        var needPh = !(Array.isArray(d.images) && d.images.length) && /^[0-9a-f]{6}$/.test(hex);
        // (the registered owner - waited on only where a register is read: the UK's, the Isle of Man's, Switzerland's,
        // the FAA's - and the pictures, both at once)
        return Promise.all([priv && hex ? ownerOf(hex, rg, /^(G-|M-|HB-|N\d)/i.test(rg) ? 2500 : 0) : '', needPh ? photosWithin({ hex: hex, reg: rg }, 2800) : null]).then(function (r) {
          if (r[0]) d.airline = r[0]; else if (x && x.al && priv) d.airline = x.al;
          if (r[1]) d.images = goodPhotos(r[1]).slice(0, 3).map(boardImage);
          return d;
        });
      });
    }
    // The list opens at the present, as FR24's own does (it starts three days back now): the first row from a quarter of
    // an hour ago is brought to the top, once per board opened. After that the row at the top of the view is held where it
    // is through every re-read: FR24 draws the whole list again each time, and rows coming in above it - days of kept
    // flights, as they are read - moved the view back "two days behind" without a touch. Held for six seconds after each
    // answer, until the list is moved by the user (wheel, touch, a key, a click).
    var ROW_TID = 'airport-panel__schedules__flight__', boardHold = null, boardTimes = {};
    function boardRows(root) { return (root || document).querySelectorAll('[data-testid^="' + ROW_TID + '"]'); }
    function rowById(id) { return document.querySelector('[data-testid="' + ROW_TID + id + '"]'); }
    // (the row at the top of the view now - the first one not scrolled past - and how far below the list's top it is)
    function topRowOf(main) {
      var mt = main.getBoundingClientRect().top, rows = boardRows(main);
      for (var i = 0; i < rows.length; i++) { var r = rows[i].getBoundingClientRect(); if (r.bottom > mt + 1) return { id: rows[i].getAttribute('data-testid').slice(ROW_TID.length), off: r.top - mt }; }
      return null;
    }
    function stopBoardHold() { if (boardHold) boardHold.stop = true; }
    // (1.1.5: the six seconds counted from when the row is first there to be placed - waited for up to half a minute.
    // They were counted from FR24's answer: a board drawn later than that - all of them while the page was held for
    // minutes - was never placed, and opened at its very top, a week back)
    function holdBoardRow(id, off, t) {
      var h = boardHold = { id: String(id), off: off, t: t || 0, until: Date.now() + 30000, placed: false, stop: false }, mo = null, main = null, frameDue = false;
      // (the row wanted - or, while it is not drawn, the drawn row nearest its time: FR24 draws a long list a piece at a
      // time, and a row gone from a new list has another under another id. Found in one pass over the drawn rows - it was
      // a search of the page for every row kept, each frame: a fortnight of a big airport froze the page for half a
      // minute - and the wanted row kept, not swapped for the stand-in, so the present is where the board ends up)
      var find = function () {
        var el = rowById(h.id); if (el || !h.t) return el;
        var rows = boardRows(), best = null, bd = 3600;
        for (var i = 0; i < rows.length; i++) { var k = rows[i].getAttribute('data-testid').slice(ROW_TID.length), tk = boardTimes[k]; if (tk) { var d = Math.abs(tk - h.t); if (d < bd) { bd = d; best = rows[i]; } } }
        return best;
      };
      var apply = function () {
        frameDue = false;
        if (boardHold !== h || h.stop || Date.now() > h.until) { if (mo) mo.disconnect(); return false; }
        var el = find();
        var m = el && el.closest('main'); if (!el || !m) return true;
        if (m !== main) {
          if (mo) mo.disconnect(); main = m;
          if (typeof MutationObserver === 'function') { mo = new MutationObserver(function () { if (frameDue) return; frameDue = true; if (window.requestAnimationFrame) window.requestAnimationFrame(apply); else oSetTimeout(apply, 16); }); mo.observe(m, { childList: true, subtree: true }); }
          if (!m.__tlHoldL) { m.__tlHoldL = true; ['wheel', 'touchstart', 'keydown', 'mousedown'].forEach(function (ev) { m.addEventListener(ev, stopBoardHold, { passive: true }); }); }
        }
        var d = el.getBoundingClientRect().top - m.getBoundingClientRect().top - h.off;
        if (Math.abs(d) > 1) m.scrollTop += d;
        if (!h.placed) { h.placed = true; h.until = Date.now() + 6000; }
        return true;
      };
      (function poll() { if (apply() && Date.now() < h.until) oSetTimeout(poll, 100); })();
    }
    // (an answer of the board: the present brought up when the board is opened - FR24's first ask of it, which names no
    // page: FR24 has just put its list back to the top - else the row at the top held there)
    function placeBoard(first, key, data, opened) {
      var times = {}; (data || []).forEach(function (e) { if (e && e.id) times[e.id] = e.scheduledTime || e.landedTime || 0; });
      var anyRow = boardRows()[0], main = anyRow && anyRow.closest('main'), wrap = main && (anyRow.closest('[data-testid="list-wrapper"]') || main);
      var top = !opened && wrap && wrap.__tlKey === key ? topRowOf(main) : null;
      if (top) holdBoardRow(top.id, top.off, boardTimes[top.id] || times[top.id] || 0);
      else if (first) {
        holdBoardRow(first.id, 36, first.scheduledTime || 0);
        // (the board marked opened once its rows are drawn)
        var tries = 0; (function mark() { var el = rowById(first.id), m = el && el.closest('main'); if (m) (el.closest('[data-testid="list-wrapper"]') || m).__tlKey = key; else if (++tries < 200) oSetTimeout(mark, 150); })();
      }
      boardTimes = times;
    }
    // the card of a kept row: from what was kept (FR24 has no card for it - or no longer gives a free account one)
    function archDetail(ar, apId, kind) {
      var r = ar.r, dep = kind === 'departures', rec = { hex: r.hex || '', reg: r.reg || '', type: r.ty || '', cat: '', mil: false, fcat: r.fc };
      var own = r.src === 'fr24' || r.src === 'sched';
      return (r.hex ? photosWithin(rec, 2800) : Promise.resolve([])).then(function (ph) {
        return jsonResponse(null, { data: { aircraft: { category: categoryOf(rec), name: r.dsc || r.ty || null, registration: r.reg || null, type: r.ty || null }, airline: r.al || null, airlineId: r.alId || null,
          destinationId: dep ? (r.ap || null) : apId, divertedToId: null, flight: { callsign: r.cs || null, id: ar.fid, number: r.num || null }, id: r.src === 'fr24' && r.id ? r.id : 20000000000 + (hashStr(r.k) % 1000000000),
          images: goodPhotos(ph).slice(0, 3).map(boardImage), locationInfo: { belt: null, gate: null, terminal: null }, originId: dep ? apId : (r.ap || null),
          runways: { arrival: { name: null, upsell: false }, departure: { name: null, upsell: false } },
          // (a scheduled time only where FR24's own schedule had one: nothing is invented for a private flight)
          // (1.2.7: and the other end's actual time, as kept - an arrival's take-off, a departure's landing: M-PORT's card
          // said "Actual departure N/A" with its take-off from Helsinki known)
          schedule: { ata: !dep && r.st === 'landed' ? (r.est || r.t) : dep && Number(r.t2) > 0 ? Number(r.t2) : null, atd: dep && r.st === 'departed' ? (r.est || r.t) : !dep && Number(r.t2) > 0 ? Number(r.t2) : null, eta: !dep && r.st === 'estimated' ? (r.est || null) : null, etd: null, sta: !dep && own ? (r.sch || null) : null, std: dep && own ? (r.sch || null) : null },
          status: { name: r.st || (dep ? 'departed' : 'landed'), color: r.col || 'green', isAmbiguous: false, live: false } }, __tlAdded: true });
      });
    }
    // ---- FR24's own airline and airport lists (its IndexedDB keeps them, read again hourly): what they lack, added -----
    // BAE Systems' three airlines have no logo (the public-domain text logo from Wikimedia Commons is drawn for them);
    // the landing places the userscript has learned - private sites, strips - are no airports of FR24's. Added to every
    // full list FR24 receives, so its boards, cards and panel draw them as their own ("Ormskirk PVT", not "N/A"). When
    // what is added has changed since FR24 last kept its list, its next read of the list (it reads it again hourly) asks
    // for the whole of it. (Until 1.0.1 FR24's copy was dropped - its IndexedDB database deleted - at the page's start:
    // with another FR24 tab open the deletion waits for that tab, and FR24 here, opening the database behind it, never
    // had its airports - every flight "N/A -> N/A", blocked flights without time zones or progress bar, until a reload.
    // Nothing of FR24's own is deleted now.)
    var BAE_LOGO = { source: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/BAE_Systems_logo.svg/250px-BAE_Systems_logo.svg.png', dimensions: { width: 250, height: 39 } };
    var LOGO_ADD = { 583: BAE_LOGO, 3046: BAE_LOGO, 582: BAE_LOGO };
    var LISTS_V = '1';
    function logoOf(id) { return !id ? '' : LOGO_ADD[id] ? LOGO_ADD[id].source : 'https://cdn.flightradar24.com/assets/airlines/logotypes/' + id + '.png'; }
    function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
    function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* full or blocked */ } }
    // (a place is its part before the first comma - "Rotherham, South Yorkshire" is Rotherham: the same cut as the userscript's
    // ENGINE.placeShort, which test/unit_places.cjs checks them against. The landing places kept from before, cut here; the
    // userscript's own list, which keeps both names where two places would read the same, replaces them at once)
    // (1.3.4) an airfield's name as FR24 would show it - the place, not the kind of field: "RAF Woodvale" is Woodvale - the
    // route engine's ENGINE.fieldShortName, which test/unit_134.cjs checks this against
    function fieldShortName(n) {
      var s = String(n || '').replace(/\s*\((disused|closed|private|abandoned)\)\s*$/i, '').trim();
      var t = s.replace(/^(RAF|RNAS|RAAF|RCAF|RNZAF|RNLAF|AAC|MOD|NAS|NAF|ANGB|Royal Air Force|Army Air Corps|Naval Air Station|Air Force Base)\s+/i, '');
      for (var k = 0, was = ''; k < 4 && was !== t; k++) {
        was = t;
        t = t.replace(/\s*\([^()]*\b(field|airport|airfield|air ?base|heliport)\)\s*$/i, '').replace(/\s+\(?(UL|ULM|microlight|private|disused)\)?$/i, '')
          .replace(/\s+(MCAS|MCAF|AFB|ARB|AAF|ANGB|NAS|NAF|JRB|NAWS|army air ?field|army heliport|air national guard base|air reserve base|naval air station|marine corps air station)$/i, '')
          .replace(/\s+(airfield|aerodrome|airport|air ?strip|air ?field|air ?base|air station|flying field|landing (strip|ground|field)|glider ?field|gliding (site|club)|aero ?club|farm ?strip|private strip|strip|airpark|air park|heliport|heli ?pad|helistop|helicopter landing (site|pad|area)|hls)$/i, '').trim();
      }
      return t.length >= 3 ? t : s;
    }
    function placeShort(n) {
      var s = String(n == null ? '' : n).replace(/\s+/g, ' ').trim(), i = s.indexOf(',');
      return i < 0 ? s : s.slice(0, i).trim() || s.replace(/^[,\s]+|[,\s]+$/g, '').replace(/,\s*/g, ', ');
    }
    var siteRows = (function () { try { var l = JSON.parse(lsGet('tl.sites') || '[]'); return Array.isArray(l) ? l.map(function (r) { return r && typeof r === 'object' ? Object.assign({}, r, { name: placeShort(r.name), city: placeShort(r.city) }) : r; }) : []; } catch (e) { return []; } })();
    function listSig(kind) { return kind === 'airlines' ? LISTS_V : LISTS_V + ':' + hashStr(JSON.stringify(siteRows)) + ':' + (lsGet('tl.oa.sig') || ''); }
    // ---- (1.3) Every OurAirports airport FR24 does not list (closed ones aside): airfields, strips, heliports, seaplane
    // and balloon bases - the monitor's list (oaap.cjs), by the userscript, each with the route engine's own id for it.
    // In FR24's airport list (its panel, boards, routes and search look airports up there), with its code (IATA, else
    // ICAO, else OurAirports' own) and name, the country and time zone of the nearest FR24 airport; on the map those in
    // view once it is zoomed in (all of them at once would be some 63,000 pins); their boards and FR24's airport answer
    // for them made here
    var oaRows = null, oaById = null, oaByCode = new Map(), oaWait = [];
    // (FR24's own rows by id, as its list came - the OurAirports airports take their country and zone from them; made
    // here, before any of their pages is made as it loads - oaFast)
    var fr24Refs = new Map();
    // FR24's airport answer (common/v1/airport.json) for one of them - its details in FR24's form, no runways or weather of
    // FR24's (the monitor's weather goes in where FR24's panel says "N/A"), its schedules empty (its boards are filled
    // apart)
    function oaAirportJson(url) {
      var c = decodeURIComponent((url.match(/[?&]code=([^&#]+)/) || [])[1] || '').toLowerCase(), r = c && oaByCode.get(c); if (!r) return null;
      // (never for a code FR24 itself has: its own answer stands)
      var mine = true; fr24Refs.forEach(function (a) { if (mine && ((a.iata && String(a.iata).toLowerCase() === c) || (a.icao && String(a.icao).toLowerCase() === c))) mine = false; }); if (!mine) return null;
      var row = oaFr24Row(r, refOf(r[5])), now = Math.floor(Date.now() / 1000), tz = row.timezone || UTC_TZ;
      var sched = function () { return { item: { current: 0, total: 0, limit: 100 }, page: { current: 1, total: 1 }, timestamp: now, data: [] }; };
      var pd = { details: { name: row.name, code: { iata: row.iata, icao: row.icao || null }, delayIndex: null, stats: null,
        position: { latitude: row.lat, longitude: row.lon, altitude: row.alt, country: { name: row.country || null, code: null, id: row.countryId || null }, region: { city: row.city || null } },
        timezone: { name: tz.name, offset: tz.offset, offsetHours: tz.offsetHours, abbr: tz.abbr, abbrName: tz.abbrName, isDst: !!tz.isDst }, url: null, website: null, visible: true, airportImages: null },
        runways: [], weather: {} };
      if (/plugin\[\]=schedule/.test(decodeURIComponent(url))) pd.schedule = { arrivals: sched(), departures: sched(), ground: sched() };
      return { result: { request: { code: c }, response: { airport: { pluginData: pd } } }, _api: { version: '1.0' } };
    }
    // ---- (1.3.8) FR24's airport API, whatever version it is at: FR24's mid-November build moved an airport's own answer from
    // /api/v1/airports/<id> to /api/v2/airports/<id> (its pictures and weather stayed at v1) - and every OurAirports pin was
    // "airportsApi.airport request is not ok" again, its window shut: these answers were made for v1 only. Now: any
    // version, any part, by id or by its code. Each answer of FR24's own for one of its airports is read for its shape
    // (its keys and their kinds, never its values) and kept: an OurAirports airport's answer is made in that shape - what
    // is known of it put in, everything else FR24 has added empty of its kind - so a field FR24 adds tomorrow is there. A
    // part never seen is answered empty, and counted (oaApiNew: the health check names it); any request FR24 makes about one
    // of them that its server answers "not found" is counted too (oaMiss)
    var OA_API_RE = /\/api\/v\d+\/airports\/([A-Za-z0-9-]+)((?:\/[A-Za-z][A-Za-z-]*)*)\/?(?:[?#]|$)/, AP_SHAPE_KEY = 'tl.apShape1';
    var apShapes = (function () { try { var o = JSON.parse(lsGet(AP_SHAPE_KEY) || '{}'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } })();
    // (a value's shape: its keys, each value of its kind with nothing in it - lists empty; nothing of the value itself)
    function apShapeOf(v, d) {
      if (Array.isArray(v)) return [];
      if (v === null || v === undefined) return null;
      if (typeof v === 'object') { if (d > 6) return {}; var o = {}, ks = Object.keys(v).slice(0, 80); for (var i = 0; i < ks.length; i++) o[ks[i]] = apShapeOf(v[ks[i]], d + 1); return o; }
      return typeof v === 'number' ? 0 : typeof v === 'boolean' ? false : typeof v === 'string' ? '' : null;
    }
    function apShapeNote(part, j) {
      if (!j || typeof j !== 'object') return;
      var sh = apShapeOf(j, 0), sig = JSON.stringify(sh); if (sig.length > 20000) return;
      if (JSON.stringify(apShapes[part || '']) === sig) return;
      apShapes[part || ''] = sh; lsSet(AP_SHAPE_KEY, JSON.stringify(apShapes)); stats.apShapes = Object.keys(apShapes).length;
    }
    // (ours over a shape: ours where we have it, the shape's empty values for the rest)
    function overShape(shape, ours) {
      if (!shape || typeof shape !== 'object' || Array.isArray(shape) || !ours || typeof ours !== 'object' || Array.isArray(ours)) return ours;
      var o = JSON.parse(JSON.stringify(shape)); Object.keys(ours).forEach(function (k) { o[k] = overShape(o[k], ours[k]); }); return o;
    }
    function fr24HasCode(c) { var x = String(c || '').toLowerCase(), has = false; fr24Refs.forEach(function (a) { if (!has && ((a.iata && String(a.iata).toLowerCase() === x) || (a.icao && String(a.icao).toLowerCase() === x))) has = true; }); return has; }
    // (the OurAirports airport an airport-API address is about - by id, or by a code FR24 does not have - and the part
    // asked for: null when it is none of theirs. Boards are answered apart)
    function oaApiTarget(url) {
      var m = String(url).match(OA_API_RE); if (!m) return null;
      var seg = m[1], part = (m[2] || '').toLowerCase(); if (/^\/(?:departures|arrivals|on-grounds)\b/.test(part)) return null;
      var id = /^\d+$/.test(seg) ? Number(seg) : 0;
      if (!id && oaByCode.size && !/^(search|disruptions|list|nearby)$/i.test(seg)) { var r = oaByCode.get(seg.toLowerCase()); if (r && !fr24HasCode(seg)) id = r[0]; }
      return id >= 1e7 && oaById && oaById.has(id) ? { id: id, part: part } : null;
    }
    // (1.3.11) Any other part - FR24's /top-travelers, mid-November - answered in the shape of FR24's own answer for it,
    // empty: an OurAirports airport has none of it. 1.3.9 counted each of these as "new to this script" even where that
    // shape was known, and the health line said so on every panel. Now only a part answered blind is counted: one whose
    // shape is not known is first asked of FR24 itself - once, for the FR24 airport the OurAirports one's pages are made
    // from (its row's [5]), by the same version and address - and that answer's shape kept; only if FR24 has no answer
    // for it either is it answered { data: {} } and counted. viaRef(refId): FR24's own request for it, as FR24 made this one
    var apShapeAsk = {};
    function oaApiPart(r, part, viaRef) {
      var sh = apShapes[part];
      if (sh) { stats.oaApiShaped = (stats.oaApiShaped || 0) + 1; return Promise.resolve(JSON.parse(JSON.stringify(sh))); }
      var blind = function () { stats.oaApiNew = (stats.oaApiNew || 0) + 1; stats.oaApiNewPart = part; return { data: {} }; };
      var refId = r[5];
      if (typeof viaRef !== 'function' || !Number.isInteger(refId) || !(refId > 0 && refId < 9000000)) return Promise.resolve(blind());
      if (!apShapeAsk[part]) {
        var ask = apShapeAsk[part] = Promise.resolve().then(function () { return viaRef(refId); }).then(function (res) {
          if (!res || !res.ok) return null;
          return res.json().then(function (j) { if (!j || typeof j !== 'object') return null; apShapeNote(part, j); return apShapeOf(j, 0); }, function () { return null; });
        }, function () { return null; });
        // (asked once at a time: those asked meanwhile wait for the same answer; a failed ask may be made again later)
        ask.then(function (s) { if (!s && apShapeAsk[part] === ask) delete apShapeAsk[part]; });
      }
      return apShapeAsk[part].then(function (s) {
        if (!s) return blind();
        stats.oaApiShaped = (stats.oaApiShaped || 0) + 1; return JSON.parse(JSON.stringify(s));
      });
    }
    // (an airport-API address with another airport in it: the same version, part and query - for FR24's own airport refId)
    function apRefUrl(url, refId) {
      var s = String(url), m = s.match(OA_API_RE); if (!m) return null;
      var i = m.index + m[0].indexOf('/airports/') + '/airports/'.length;
      return s.slice(0, i) + refId + s.slice(i + m[1].length);
    }
    function oaApi(id, part, viaRef) {
      var r = oaById.get(id); if (!r) return null;
      stats.oaApi = (stats.oaApi || 0) + 1;
      if (part === '/images') return Promise.resolve({ data: [] });
      if (part === '/disruptions') return Promise.resolve({ data: {} });
      // (1.3.12: 8 s at most - 6 s left a phone's panel header without it while the monitor was busy)
      if (part === '/weather') return apWxWait(id, 8000).then(function (w) { return { data: w ? oaWeather(w) : {} }; });
      if (part) return oaApiPart(r, part, viaRef);
      // (1.3.12: the airport opened - its weather asked for now, on its way before FR24 asks for it a moment later)
      apWxWant(id);
      var a = oaStoreRow(r), sun = sunTimes(a.latitude, a.longitude, Date.now());
      if (oaRefs.has(r[5])) oaOneKeep(r, oaRefs.get(r[5]), refOf(r[5]));
      oaStoreKeep(pinStore('airports'), a);
      // (1.3.2: its ICAO code where it has one - or its GPS code: three or four letters and figures; its time zone as
      // words, today's sunrise and sunset there, worked out - 1.3.1 left all four "N/A")
      var ours = { data: { info: { id: a.id, name: a.name, iata: a.iata, icao: oaIcaoOf(r), latitude: a.latitude, longitude: a.longitude, elevation: a.altitude, timezone: a.timezoneName, countryId: a.countryId || null, faaLidCode: null, state: null, timezoneDisplay: tzText(a.timezoneName, a.timezoneCode, a.timezoneOffsetHours), sunrise: sun.rise, sunset: sun.set, satelliteImage: null, videoStream: null },
        images: [], weather: null, stats: { summary: { airportsServed: 0, countriesServed: 0, takeoffCount: 0, landingCount: 0, totalFlights: 0 }, flights: [], busiestRoutes: [] }, runways: [] } };
      // (1.3.8: in the shape of FR24's own latest answer, where one has been seen)
      return Promise.resolve(apShapes[''] ? overShape(apShapes[''], ours) : ours);
    }
    // (what kind of code an OurAirports airport is known by: its ICAO or GPS code - "EGOW", "48ID" - or only OurAirports'
    // own - "GB-0002")
    // (1.3.4) one of them by its codes, as FR24's window and pins show an airport's: its ICAO code - else its GPS or
    // OurAirports' own - and " / " its IATA code only where it has a real one: "EGOW", "GB-0735", "EGWS / WSX"; never
    // the same code twice, never "/ null"
    function oaRealIata(r) { var c = String((r && r[1]) || '').toUpperCase(); return /^[A-Z]{3}$/.test(c) && c !== String(r[2] || '').toUpperCase() ? c : ''; }
    function oaCodeLine(r) { var ia = oaRealIata(r), main = String(r[2] || r[1] || '').toUpperCase(); return main + (ia ? ' / ' + ia : ''); }
    // (FR24's pins write an airport's label [iata, icao].join(" / "): for theirs, the code line instead - only for an
    // array of exactly their two codes, joined with exactly that; every other join as it is)
    var oaPinLabels = new Map(), oJoin = Array.prototype.join;
    function oaPinKey(a, b) { return String(a) + '\u0001' + String(b); }
    try {
      Object.defineProperty(Array.prototype, 'join', { configurable: true, writable: true, value: function join(sep) {
        if (sep === ' / ' && this.length === 2 && oaPinLabels.size && typeof this[0] === 'string') { var l = oaPinLabels.get(oaPinKey(this[0], this[1])); if (l !== undefined) return l; }
        return oJoin.apply(this, arguments);
      } });
    } catch (e) { /* the pins as FR24 writes them */ }
    function oaIcaoOf(r) { var id = String((r && r[2]) || '').toUpperCase(); return /^[A-Z0-9]{3,4}$/.test(id) ? id : null; }
    // (a time zone as words: "Europe/London (UTC+00:00)" - its offset as it is today, by the browser's own tables)
    function tzText(name, abbr, offH) {
      if (!name) return null;
      var off = '';
      try {
        var parts = new Intl.DateTimeFormat('en-GB', { timeZone: name, timeZoneName: 'longOffset' }).formatToParts(new Date());
        for (var i = 0; i < parts.length; i++) if (parts[i].type === 'timeZoneName') off = String(parts[i].value).replace(/^GMT/, 'UTC');
        if (off === 'UTC') off = 'UTC+00:00';
      } catch (e) { off = offH != null && offH !== '' ? 'UTC' + (/^[+-]/.test(String(offH)) ? '' : '+') + offH : ''; }
      return String(name).replace(/_/g, ' ') + (off ? ' (' + off + ')' : abbr ? ' (' + abbr + ')' : '');
    }
    // (sunrise and sunset at a place on the day it is there now, in seconds since 1970 - the sunrise equation: the sun's
    // upper edge on the horizon, refraction counted; null where the sun does not rise or set that day)
    function sunTimes(lat, lon, ms) {
      var out = { rise: null, set: null };
      if (!fin(lat) || !fin(lon)) return out;
      var rad = Math.PI / 180, J = ms / 86400000 + 2440587.5, n = Math.round(J - 2451545.0009 + lon / 360), Js = 2451545.0009 - lon / 360 + n;
      var M = (357.5291 + 0.98560028 * (Js - 2451545)) % 360, C = 1.9148 * Math.sin(M * rad) + 0.02 * Math.sin(2 * M * rad) + 0.0003 * Math.sin(3 * M * rad);
      var L = (M + C + 180 + 102.9372) % 360, Jt = Js + 0.0053 * Math.sin(M * rad) - 0.0069 * Math.sin(2 * L * rad);
      var sinD = Math.sin(L * rad) * Math.sin(23.4397 * rad), cosD = Math.cos(Math.asin(sinD));
      var cosW = (Math.sin(-0.833 * rad) - Math.sin(lat * rad) * sinD) / (Math.cos(lat * rad) * cosD);
      if (!(cosW >= -1 && cosW <= 1)) return out;
      var w = Math.acos(cosW) / rad / 360, toS = function (j) { return Math.round((j - 2440587.5) * 86400); };
      out.rise = toS(Jt - w); out.set = toS(Jt + w);
      return out;
    }
    // (the monitor's weather of an airport in FR24's form: what its airport API gives for its window)
    function oaWeather(w) {
      return { timestamp: w.t, condition: w.cond, temperature: fin(w.tempC) ? w.tempC : null, wind: { direction: fin(w.wdir) ? w.wdir : 0, speed: fin(w.wkts) ? w.wkts : null }, pressure: fin(w.hpa) ? w.hpa : null,
        dewPoint: fin(w.dewC) ? w.dewC : null, humidity: fin(w.rh) ? w.rh : null, metar: w.metar || null };
    }
    // (1.3.1) one of them alone - an airport data page's own, the whole list not sent there - and the FR24 airport its
    // pages are made from
    function acceptOaOne(d, quiet, noKeep) {
      var r = d && d.row; if (!Array.isArray(r) || !(r[0] >= 1e7) || typeof d.ref !== 'string' || !/^[a-z0-9]{3,4}$/i.test(d.ref)) return;
      if (!oaById) oaById = new Map();
      oaById.set(r[0], r); oaByCode.set(String(r[1]).toLowerCase(), r); if (Number.isInteger(r[5])) oaRefs.set(r[5], d.ref.toLowerCase());
      if (d.near && typeof d.near === 'object' && d.near.id === r[5] && !fr24Refs.has(r[5])) fr24Refs.set(r[5], d.near);
      if (!noKeep) oaOneKeep(r, d.ref.toLowerCase(), d.near || refOf(r[5]));
      if (!quiet) oaLostGo();
    }
    // (1.3.4) One of them as this browser last had it - its row, the FR24 airport its pages are made from, its nearest FR24
    // airport (country, time zone) - kept for each one looked at, its window opened, its page linked to: its page is then
    // made from the page FR24's server sends the moment that loads, before FR24's app starts - no second load, no wait
    // for the userscript (1.3.3: the airport's page loaded, then the userscript's list was read, then the page asked for
    // again - and shown the while). The last 60 kept.
    var OA_ONE = 'tl.oa.one.';
    function oaOneKeep(r, ref, near) {
      if (!Array.isArray(r) || !ref) return;
      var code = String(r[1]).toLowerCase();
      try {
        var idx = JSON.parse(lsGet('tl.oa.ones') || '[]'); if (!Array.isArray(idx)) idx = [];
        idx = idx.filter(function (c) { return c !== code; }); idx.push(code);
        while (idx.length > 60) { var old = idx.shift(); try { localStorage.removeItem(OA_ONE + old); } catch (e) { /* none */ } }
        // (of the FR24 airport its page is made from, only what the page takes from it: its country and time zone)
        var nearKept = near && near.id === r[5] ? { id: near.id, iata: near.iata || '', icao: near.icao || '', name: near.name || '', city: near.city || '', country: near.country || '', countryId: near.countryId || 0, size: near.size || 0, timezone: near.timezone || null } : null;
        lsSet(OA_ONE + code, JSON.stringify({ row: r, ref: ref, near: nearKept, at: Date.now() }));
        lsSet('tl.oa.ones', JSON.stringify(idx));
      } catch (e) { /* full: as before */ }
    }
    function oaOneGet(code) {
      try { var o = JSON.parse(lsGet(OA_ONE + String(code || '').toLowerCase()) || 'null'); return o && Array.isArray(o.row) && o.row[0] >= 1e7 && typeof o.ref === 'string' && /^[a-z0-9]{3,4}$/.test(o.ref) && Date.now() - o.at < 30 * 864e5 ? o : null; } catch (e) { return null; }
    }
    function acceptOa(d) {
      if (!d || !Array.isArray(d.rows)) return;
      if (d.refs && typeof d.refs === 'object') Object.keys(d.refs).forEach(function (k) { var v = d.refs[k], id = Number(k); if (Number.isInteger(id) && id > 0 && typeof v === 'string' && /^[a-z0-9]{3,4}$/i.test(v)) oaRefs.set(id, v.toLowerCase()); });
      oaRows = d.rows; oaById = new Map(); oaByCode = new Map(); d.rows.forEach(function (r) { if (Array.isArray(r) && r[0] >= 1e7) { oaById.set(r[0], r); oaByCode.set(String(r[1]).toLowerCase(), r); } });
      if (d.sig) lsSet('tl.oa.sig', String(d.sig));
      oaFillTables();
      var w = oaWait; oaWait = []; w.forEach(function (f) { try { f(); } catch (e) { /* ignore */ } });
      oaMapSoon();
    }
    // ---- (1.3.1) The data pages of an OurAirports airport (/data/airports/egow, /statistics, /arrivals, /routes ...). FR24
    // has none: its server says "not found", and its app, moved to one, shows an error. Made from FR24's own: the same
    // page of the nearest FR24 airport is asked for in its place, and given to FR24's app as this airport's - its airport
    // this one (its name, code, place; the country and time zone of the airport it was made from), every figure of that
    // other airport taken out (its lists empty, its numbers and words none); then filled as FR24's own pages are -
    // the flights kept for it, its weather, its movements, its runway usage. Every link and tab on it stays on it.
    var oaRefs = new Map(); // FR24 airport id -> its code in FR24's addresses (from the userscript)
    // (the OurAirports code this page is for, as its address said when it loaded - FR24's app may rewrite the address
    // before the userscript asks: its own page's code, or the one marked on its nearest airport's page)
    var oaFast = null;     // (1.3.4: this page made into one of theirs as it loads - its code and sub-page)
    var oaWant = (function () { var m = location.pathname.match(/^\/data\/airports\/([^\/?#]+)/i); if (!m) return ''; var t = new URLSearchParams(location.search).get('tl-oa'); try { return String(t || decodeURIComponent(m[1])).toLowerCase(); } catch (e) { return ''; } })();
    function oaPageReq(url) {
      if (!oaByCode.size) return null;
      var u; try { u = new URL(url, location.href); } catch (e) { return null; }
      if (!/flightradar24\.com$/.test(u.hostname)) return null;
      var m = u.pathname.match(/^\/data\/airports\/([^\/?#]+)(\/[^?#]*)?$/i); if (!m) return null;
      var code = decodeURIComponent(m[1]).toLowerCase(), r = oaByCode.get(code); if (!r || !(r[0] >= 1e7)) return null;
      var ref = oaRefs.get(r[5]); if (!ref) return null;
      var sub = (m[2] || '').replace(/\/+$/, ''), q = new URLSearchParams(u.search); q.delete('tl-oa');
      var qs = q.toString();
      return { row: r, code: code, sub: sub, query: qs ? '?' + qs : '', refUrl: '/data/airports/' + encodeURIComponent(ref) + sub + (qs ? '?' + qs : '') };
    }
    // (a value of the other airport's taken out, its shape kept: a list empty, a number or a word none)
    function oaEmpty(v, d) {
      if (Array.isArray(v)) return [];
      if (v === null || typeof v !== 'object') return typeof v === 'boolean' ? v : null;
      if (d > 8) return null;
      var o = {}; Object.keys(v).forEach(function (k) { o[k] = oaEmpty(v[k], d + 1); }); return o;
    }
    var OA_PAGE_KEEP = ['errors', 'name', 'host', 'locale', 'dispatcher', 'features', 'content', 'meta', 'dateModified', 'locked', 'auth', 'flash', 'ziggy', 'translations'];
    var OA_AP_KEEP = /^(country|countryName|countryId|countryCode|countryIso|countryIso2|countryIso3|countryFlag|countrySlug|timezone|timezoneName|timezoneAbbr|timezoneOffset|timezoneOffsetHours|tz|region|regionName|continent|continentName)$/;
    function oaPageOf(pg, oq) {
      var r = oq.row, a = oaStoreRow(r), p = pg.props || {}, out = {}, code = oq.code;
      Object.keys(p).forEach(function (k) { out[k] = OA_PAGE_KEEP.indexOf(k) >= 0 ? p[k] : k === 'weather' ? null : oaEmpty(p[k], 0); });
      if (p.airport && typeof p.airport === 'object') {
        var ap0 = p.airport, ap = {};
        Object.keys(ap0).forEach(function (k) { ap[k] = OA_AP_KEEP.test(k) ? ap0[k] : oaEmpty(ap0[k], 1); });
        ap.id = r[0]; ap.name = a.name; if ('city' in ap0) ap.city = a.city || null; ap.iata = r[1]; ap.icao = a.icao && a.icao !== r[1] ? a.icao : null;   // (one code, shown once)
        if ('elevationFt' in ap0) ap.elevationFt = r[8] || 0; if ('elevation' in ap0) ap.elevation = r[8] || 0; if ('altitude' in ap0) ap.altitude = r[8] || 0;
        ['latitude', 'lat'].forEach(function (k) { if (k in ap0) ap[k] = r[6]; }); ['longitude', 'lon', 'lng'].forEach(function (k) { if (k in ap0) ap[k] = r[7]; });
        { var nr = refOf(r[5]); if (nr && nr.timezone && nr.timezone.name && 'timezone' in ap0 && typeof ap0.timezone === 'string') ap.timezone = nr.timezone.name; }
        if ('slug' in ap0) ap.slug = code; if ('code' in ap0) ap.code = r[1]; if ('url' in ap0) ap.url = '/data/airports/' + code;
        out.airport = ap;
      }
      if (p.route && typeof p.route === 'object') out.route = Object.assign({}, p.route, { params: Object.assign({}, p.route.params || {}, { airport: code }) });
      if ('canonicalUrl' in p) out.canonicalUrl = 'https://www.flightradar24.com/data/airports/' + code + oq.sub;
      if ('image' in p) out.image = null;
      var page = {}; Object.keys(pg).forEach(function (k) { page[k] = pg[k]; });
      page.props = out; page.url = '/data/airports/' + code + oq.sub + oq.query;
      // (props FR24 would fetch after - of the other airport: not asked for)
      if (page.deferredProps) page.deferredProps = {};
      return page;
    }
    // (an address of one typed or followed from outside: FR24's server's "not found" page. Its nearest airport's page
    // loaded, marked, and moved from at once to this one - by FR24's own router, as above; nothing of that page shown)
    (function () {
      var m = location.pathname.match(/^\/data\/airports\/([^\/?#]+)(\/[^?#]*)?$/i); if (!m) return;
      var want = new URLSearchParams(location.search).get('tl-oa');
      if (want) {
        lsSet('tl.oa.goto', '');
        // (kept here from before: made from this page as it loads - oaFast, in the page's data, below)
        var one = oaOneGet(want);
        if (one && one.ref === decodeURIComponent(m[1]).toLowerCase()) { acceptOaOne({ row: one.row, ref: one.ref, near: one.near }, true); oaFast = { code: String(want).toLowerCase(), sub: m[2] || '' }; veilOn('oa', 6000, appMounted); return; }
        try { var hide = document.createElement('style'); hide.id = 'tl-oa-hide'; hide.textContent = '#app{visibility:hidden!important}'; (document.head || document.documentElement).appendChild(hide); } catch (e) { /* none */ }
        var shown = function () { var h = document.getElementById('tl-oa-hide'); if (h) h.remove(); };
        oSetTimeout(shown, 15000);
        (function go(n) {
          var gp = mxGp(), router = gp && gp.$inertia;
          if (!router || !oaPageReq('/data/airports/' + want + (m[2] || ''))) { if (n < 600) oSetTimeout(function () { go(n + 1); }, 50); else shown(); return; }
          var q = new URLSearchParams(location.search); q.delete('tl-oa'); var qs = q.toString();
          document.addEventListener('inertia:navigate', function () { oSetTimeout(shown, 30); }, { once: true });
          try { router.visit('/data/airports/' + encodeURIComponent(want) + (m[2] || '') + (qs ? '?' + qs : ''), { replace: true, preserveScroll: false, preserveState: false }); } catch (e) { shown(); }
        })(0);
        return;
      }
      // (FR24's own page of it: nothing to do)
      var own = function () { var el = document.getElementById('app'), raw = el && el.getAttribute('data-page'); if (!raw) return false; try { return /^Data\/Airport/.test(JSON.parse(raw).component || ''); } catch (e) { return false; } };
      var tries = 0, check = function () {
        if (own()) return;
        var oq = oaPageReq(location.href);
        if (!oq) { if (++tries < 60) oSetTimeout(check, 250); return; }
        var k = 'tl.oa.go.' + oq.code; if (Date.now() - (Number(lsGet(k)) || 0) < 15000) return; lsSet(k, String(Date.now()));   // (never round and round)
        var gp = mxGp(), router = gp && gp.$inertia;
        if (router) { try { router.visit(location.pathname + location.search, { replace: true }); return; } catch (e) { /* by its nearest airport's page */ } }
        var q = new URLSearchParams(location.search); q.set('tl-oa', oq.code);
        location.replace('/data/airports/' + encodeURIComponent(oaRefs.get(oq.row[5])) + oq.sub + '?' + q.toString());
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { oSetTimeout(check, 300); }, { once: true }); else oSetTimeout(check, 300);
    })();
    // (1.3.2) FR24's server does not say "not found" for an airport page it has none of: it sends the browser on to its
    // airport search (/data/airports) - "More" in an OurAirports airport's window opened that, in a new tab, and nothing
    // there says which airport was asked for. So:
    //  - a link to one of their pages that opens a tab of its own (FR24's "More") is pointed, as it is pressed, at the
    //    page they are made from (its nearest FR24 airport's, marked with this airport's code): no detour at all
    //  - any other link to one pressed: its code noted for a minute, for a tab that ends up on the search page by FR24's
    //    server's doing (the browser says when a page was reached by being sent on) - taken from there to the airport
    //  - one of their pages loaded again, or come back to: this tab remembers which airport each of its pages was
    // An address typed or pasted into a new tab is the one case left: FR24's server has sent it on before any of this
    // runs, and nothing in the browser says where from.
    var OA_GOTO = 'tl.oa.goto', OA_TAB = 'tl.oa.tab';
    function oaRefHref(oq) { var q = new URLSearchParams(oq.query); q.set('tl-oa', oq.code); return oq.refUrl.replace(/\?.*$/, '') + '?' + q.toString(); }
    function oaLinkPressed(ev) {
      try {
        var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null; if (!a) return;
        var oq = oaPageReq(a.href); if (!oq) return;
        lsSet(OA_GOTO, JSON.stringify({ code: oq.code, sub: oq.sub, q: oq.query, at: Date.now() }));
        oaOneKeep(oq.row, oaRefs.get(oq.row[5]), refOf(oq.row[5]));
        // (1.3.4: every such link - FR24's airport lists' are plain links, and its server would send them to its search)
        a.setAttribute('href', oaRefHref(oq));
      } catch (e) { stats.errors++; stats.lastError = String(e); }
    }
    ['pointerdown', 'mousedown', 'touchstart', 'auxclick', 'contextmenu', 'keydown'].forEach(function (k) { document.addEventListener(k, function (ev) { if (k === 'keydown' && ev.key !== 'Enter') return; oaLinkPressed(ev); }, true); });
    function navKey() { try { return (window.navigation && window.navigation.currentEntry && window.navigation.currentEntry.key) || ''; } catch (e) { return ''; } }
    function oaTabGet() { try { var j = JSON.parse(sessionStorage.getItem(OA_TAB) || 'null'); return j && typeof j === 'object' ? j : null; } catch (e) { return null; } }
    // (the airport of the page this tab shows now: kept with the tab, by the page's place in its history)
    setInterval(function () {
      if (!/^\/data\/airports\/[^\/]/i.test(location.pathname) || !oaByCode.size) return;
      var oq = oaPageReq(location.href); if (!oq) return;
      try {
        var t = oaTabGet() || { keys: {} }, k = navKey(), e = { code: oq.code, sub: oq.sub, q: oq.query };
        if (t.last && t.last.code === e.code && t.last.sub === e.sub && (!k || (t.keys[k] && t.keys[k].code === e.code && t.keys[k].sub === e.sub))) return;
        t.last = e; if (k) { t.keys[k] = e; var ks = Object.keys(t.keys); if (ks.length > 60) delete t.keys[ks[0]]; }
        sessionStorage.setItem(OA_TAB, JSON.stringify(t));
      } catch (e2) { /* no storage */ }
    }, 1000);
    // (on FR24's airport search, sent there by its server: which airport's page was meant - null when none is known)
    var oaLost = (function () {
      if (!/^\/data\/airports\/?$/i.test(location.pathname)) return null;
      var nav = null; try { nav = performance.getEntriesByType('navigation')[0] || null; } catch (e) { nav = null; }
      if (!nav || !(nav.redirectCount > 0)) return null;
      var codeOk = function (e) { return !!e && typeof e.code === 'string' && /^[a-z0-9-]{2,12}$/i.test(e.code) && (!e.sub || /^\/[a-z-]{1,20}$/i.test(e.sub)); };
      if (nav.type === 'reload' || nav.type === 'back_forward') {
        var t = oaTabGet(), k = navKey(), e1 = t && ((k && t.keys && t.keys[k]) || (nav.type === 'reload' ? t.last : null));
        return codeOk(e1) ? e1 : null;
      }
      var g = null; try { g = JSON.parse(lsGet(OA_GOTO) || 'null'); } catch (e) { g = null; }
      if (!codeOk(g) || !(Date.now() - g.at < 60000)) return null;
      lsSet(OA_GOTO, '');
      return g;
    })();
    if (oaLost) {
      oaWant = String(oaLost.code).toLowerCase();    // (the userscript says whether it is one of these, and which FR24 airport it is made from: acceptOaOne)
      try { var lostHide = document.createElement('style'); lostHide.id = 'tl-oa-hide'; lostHide.textContent = '#app{visibility:hidden!important}'; (document.head || document.documentElement).appendChild(lostHide); } catch (e) { /* none */ }
      oSetTimeout(function () { var h = document.getElementById('tl-oa-hide'); if (h) h.remove(); oaLost = null; }, 3500);
    }
    // (1.3.4: the extension saw FR24's server send this tab here from one of their pages' addresses - typed or pasted)
    function acceptOaFrom(d) {
      if (!/^\/data\/airports\/?$/i.test(location.pathname) || !d || typeof d.path !== 'string') return;
      var m = d.path.match(/^\/data\/airports\/([^\/?#]+)(\/[a-z-]{1,20})?\/?(\?[^#]*)?$/i); if (!m) return;
      var code = ''; try { code = decodeURIComponent(m[1]).toLowerCase(); } catch (e) { return; }
      if (!/^[a-z0-9-]{2,12}$/.test(code)) return;
      oaLost = { code: code, sub: m[2] || '', q: m[3] || '' }; oaWant = code;
      try { if (!document.getElementById('tl-oa-hide')) { var h = document.createElement('style'); h.id = 'tl-oa-hide'; h.textContent = '#app{visibility:hidden!important}'; (document.head || document.documentElement).appendChild(h); } } catch (e) { /* none */ }
      oSetTimeout(function () { var x = document.getElementById('tl-oa-hide'); if (x) x.remove(); oaLost = null; }, 8000);
      var one = oaOneGet(code); if (one) acceptOaOne({ row: one.row, ref: one.ref, near: one.near });
    }
    var oaNav = function (u) { location.replace(u); };
    function oaLostGo() {
      if (!oaLost) return;
      var oq = oaPageReq('/data/airports/' + encodeURIComponent(oaLost.code) + (oaLost.sub || '') + (oaLost.q || '')); if (!oq) return;
      oaLost = null;
      try { oaNav(oaRefHref(oq)); } catch (e) { stats.errors++; stats.lastError = String(e); }
    }
    var OA_SIZE = { L: 3000, M: 400, S: 12, H: 3, W: 3, B: 1 };
    // ---- (1.3.4) FR24's searches: its search box on every page (/v1/search/web/find) and its airport pages' own
    // (/api/v1/airports/search) find the OurAirports airports as they find FR24's - by code (EGOW, GB-0002) or by name -
    // in FR24's own form, opened as FR24's are. On the map the list is here; elsewhere the userscript is asked (it has it),
    // half a second at most, and FR24's own answer never waits longer
    // ==OA-MATCH==
    function oaMatchRows(rows, q, n, size) {
      q = String(q || '').trim().toLowerCase(); if (q.length < 2 || !rows) return [];
      var hits = [], word = { test: function (nm) { for (var k = nm.indexOf(q); k >= 0; k = nm.indexOf(q, k + 1)) { if (k === 0 || ' (/-'.indexOf(nm.charAt(k - 1)) >= 0) return true; } return false; } };
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i]; if (!Array.isArray(r)) continue;
        var c1 = String(r[1]).toLowerCase(), c2 = String(r[2]).toLowerCase(), nm = String(r[3] || '').toLowerCase(), s = -1;
        if (c1 === q || c2 === q) s = 0; else if (c1.indexOf(q) === 0 || c2.indexOf(q) === 0) s = 1; else if (nm.indexOf(q) === 0) s = 2; else if (q.length >= 3 && word.test(nm)) s = 3; else if (q.length >= 3 && (nm.indexOf(q) >= 0 || String(r[4] || '').toLowerCase().indexOf(q) >= 0)) s = 4;
        if (s >= 0) hits.push([s, size(r), r]);
      }
      hits.sort(function (a, b) { return a[0] - b[0] || b[1] - a[1] || String(a[2][3]).localeCompare(String(b[2][3])); });
      return hits.slice(0, n || 10).map(function (h) { return h[2]; });
    }
    // ==/OA-MATCH==
    var oaFindWait = new Map(), oaFindSeq = 0;
    function oaSearch(q, ms) {
      q = String(q || '').trim(); if (q.length < 2) return Promise.resolve([]);
      if (oaRows) return Promise.resolve(oaMatchRows(oaRows, q, 10, function (r) { return OA_SIZE[r[9]] || 0; }));
      return new Promise(function (res) {
        var key = 'f' + (++oaFindSeq), t = oSetTimeout(function () { oaFindWait.delete(key); res([]); }, ms || 500);
        oaFindWait.set(key, function (rows) { oClearTimeout(t); oaFindWait.delete(key); res(rows); });
        post('oaFind', { key: key, q: q });
      });
    }
    function acceptOaFound(d) {
      if (!d || !Array.isArray(d.list)) return;
      d.list.forEach(function (o) { acceptOaOne(o, true, true); });
      var f = typeof d.key === 'string' && /^f\d{1,9}$/.test(d.key) ? oaFindWait.get(d.key) : null; if (typeof f === 'function') f(d.list.filter(function (o) { return o && Array.isArray(o.row); }).map(function (o) { return o.row; }));
    }
    var oaLabel = function (r) { var ic = oaIcaoOf(r); return String(r[3]) + ' (' + r[1] + (ic && ic !== String(r[1]).toUpperCase() ? ' / ' + ic : '') + ')'; };
    // (FR24's search box's answer: { results: [{ id: its code, label: "Name (CODE / ICAO)", detail: { lat, lon, size },
    // type: 'airport', match, name }], stats: { total, count } } - theirs among its airports: an exact code first)
    function searchMerge(j, rows, q) {
      if (!j || !Array.isArray(j.results) || !rows.length) return null;
      var have = new Set(); j.results.forEach(function (x) { if (x && x.type === 'airport') have.add(String(x.id).toUpperCase()); });
      var ql = q.trim().toLowerCase(), first = [], rest = [];
      rows.forEach(function (r) {
        if (have.has(String(r[1]).toUpperCase()) || oaDupe(r)) return;
        var c1 = String(r[1]).toLowerCase(), c2 = String(r[2]).toLowerCase(), exact = c1 === ql || c2 === ql;
        var o = { id: String(r[1]), label: oaLabel(r), detail: { lat: r[6], lon: r[7], size: OA_SIZE[r[9]] || 1 }, type: 'airport', match: exact ? (c2 === ql && c2.length === 4 ? 'icao' : 'iata') : c1.indexOf(ql) === 0 || c2.indexOf(ql) === 0 ? 'begins' : 'contains', name: String(r[3]) };
        (exact ? first : rest).push(o);
      });
      var add = first.length + rest.length; if (!add) return null;
      var ap = j.results.filter(function (x) { return x && x.type === 'airport'; }), other = j.results.filter(function (x) { return !(x && x.type === 'airport'); });
      j.results = first.concat(ap, rest, other);
      ['total', 'count'].forEach(function (k) { var s = j.stats && j.stats[k]; if (s && typeof s === 'object') { s.airport = (s.airport || 0) + add; if ('all' in s) s.all = (s.all || 0) + add; } });
      return j;
    }
    // (an airport page's search: { data: [{ id, iata, icao, name, countryId, ... }] } - the code is what its links go by)
    function apSearchMerge(j, rows) {
      if (!j || !Array.isArray(j.data) || !rows.length) return null;
      var have = new Set(); j.data.forEach(function (x) { if (x) have.add(x.id); });
      var add = rows.filter(function (r) { return !have.has(r[0]); }).map(function (r) {
        var a = oaFr24Row(r, refOf(r[5]));
        return { id: r[0], iata: String(r[1]), icao: oaIcaoOf(r), name: String(r[3]), city: a.city || null, countryId: a.countryId || null, countryName: a.country || null, latitude: r[6], longitude: r[7] };
      });
      if (!add.length) return null;
      j.data = j.data.concat(add); return j;
    }
    // ---- (1.3.4) FR24's airport lists (/data/airports): each country's count with theirs; a country's list of airports -
    // or of its states, each one's count - and a state's list, with theirs, in FR24's form: { id, name, iata (the code its
    // links go by), icao, total }. Asked of the userscript once a page; a country's counts kept here, so the page has
    // them at once next time. Their links go straight to their pages (oaLinkPressed).
    var dirAsked = new Map(), dirGot = new Map(), DIR_KEEP = 'tl.oa.dirs';
    var US_STATES = { alabama: 'AL', alaska: 'AK', arizona: 'AZ', arkansas: 'AR', california: 'CA', colorado: 'CO', connecticut: 'CT', delaware: 'DE', 'district of columbia': 'DC', florida: 'FL', georgia: 'GA', hawaii: 'HI', idaho: 'ID', illinois: 'IL', indiana: 'IN', iowa: 'IA', kansas: 'KS', kentucky: 'KY', louisiana: 'LA', maine: 'ME', maryland: 'MD', massachusetts: 'MA', michigan: 'MI', minnesota: 'MN', mississippi: 'MS', missouri: 'MO', montana: 'MT', nebraska: 'NE', nevada: 'NV', 'new hampshire': 'NH', 'new jersey': 'NJ', 'new mexico': 'NM', 'new york': 'NY', 'north carolina': 'NC', 'north dakota': 'ND', ohio: 'OH', oklahoma: 'OK', oregon: 'OR', pennsylvania: 'PA', 'rhode island': 'RI', 'south carolina': 'SC', 'south dakota': 'SD', tennessee: 'TN', texas: 'TX', utah: 'UT', vermont: 'VT', virginia: 'VA', washington: 'WA', 'west virginia': 'WV', wisconsin: 'WI', wyoming: 'WY' };
    function dirAsk(key, msg) {
      if (dirGot.has(key) || (dirAsked.has(key) && Date.now() - dirAsked.get(key) < 20000)) return dirGot.get(key) || null;
      dirAsked.set(key, Date.now()); msg.key = key; post('oaDir', msg); return null;
    }
    function acceptOaDir(d) {
      if (!d || typeof d.key !== 'string' || !dirAsked.has(d.key)) return;
      // (their rows, for their links - known here, not kept: one is kept when its link is pressed. 1.3.4 kept every one
      // of a country's - some 1,500 writes for the United Kingdom's - which is what held its list back seconds)
      if (Array.isArray(d.rows)) { var refs = d.refs && typeof d.refs === 'object' ? d.refs : {}, nears = d.nears && typeof d.nears === 'object' ? d.nears : {}; d.rows.forEach(function (r) { var k = Array.isArray(r) && Number.isInteger(r[5]) ? String(r[5]) : ''; if (k && Object.prototype.hasOwnProperty.call(refs, k)) acceptOaOne({ row: r, ref: refs[k], near: Object.prototype.hasOwnProperty.call(nears, k) ? nears[k] : null }, true, true); }); }
      dirGot.set(d.key, d);
      if (d.counts && typeof d.counts === 'object') lsSet('tl.oa.counts', JSON.stringify({ at: Date.now(), counts: d.counts }));
      if (Array.isArray(d.airports) || (d.states && typeof d.states === 'object')) dirKeep(d.key, d);
      dirTick();
    }
    // (1.3.6) a country's list or a state's as last answered - the last 8 - so a page of it is built with them as it
    // loads; and the countries' counts
    function dirKept(key) {
      try { var o = JSON.parse(lsGet(DIR_KEEP) || '{}'), e = o && Object.prototype.hasOwnProperty.call(o, key) ? o[key] : null; return e && Date.now() - e.at < 14 * 864e5 && (Array.isArray(e.airports) || (e.states && typeof e.states === 'object')) ? e : null; } catch (e2) { return null; }
    }
    function dirKeep(key, d) {
      try {
        var o = JSON.parse(lsGet(DIR_KEEP) || '{}'); if (!o || typeof o !== 'object' || Array.isArray(o)) o = {};
        o[key] = { at: Date.now(), airports: Array.isArray(d.airports) ? d.airports : null, states: d.states && typeof d.states === 'object' ? d.states : null };
        var ks = Object.keys(o).sort(function (x, y) { return o[x].at - o[y].at; }), s;
        while (ks.length > 8) delete o[ks.shift()];
        while ((s = JSON.stringify(o)).length > 1500000 && ks.length > 1) delete o[ks.shift()];
        lsSet(DIR_KEEP, s);
      } catch (e) { /* full: as before */ }
    }
    function countsKept() { try { var o = JSON.parse(lsGet('tl.oa.counts') || 'null'); return o && o.counts && typeof o.counts === 'object' ? o : null; } catch (e) { return null; } }
    // (FR24's items with theirs added: a count raised carries what was added - tlN - and one of theirs is marked tl, so
    // what was added is always taken back out first: the same list given again, kept in the page as it loaded, or newer)
    function dirCounted(list, add, idOf) {
      var same = true;
      var out = list.map(function (x) {
        if (!x) return x;
        var n0 = +x.tlN || 0, k = idOf(x), n = Object.prototype.hasOwnProperty.call(add, k) ? +add[k] || 0 : 0; if (n0 === n) return x;
        same = false; var b = Object.assign({}, x, { total: (x.total || 0) - n0 + n }); if (n) b.tlN = n; else delete b.tlN; return b;
      });
      return same ? null : out;
    }
    function dirMerge(list, add) {
      var base = list.filter(function (x) { return x && !x.tl; }), have = new Set(); base.forEach(function (x) { have.add(x.id); });
      return base.concat(add.filter(function (x) { return x && !have.has(x.id); }).map(function (x) { return Object.assign({}, x, { tl: 1 }); }));
    }
    function dirTlIds(list) { var s = ''; list.forEach(function (x) { if (x && x.tl) s += x.id + ','; }); return s; }
    // (the page's list - FR24's airport lists - and what to ask for it)
    function dirKeyOf(pg) {
      var p = pg && pg.props; if (!p) return null;
      if (pg.component === 'Data/Airports' && Array.isArray(p.airportsByCountry)) return { key: 'counts', msg: { kind: 'counts' } };
      if ((pg.component === 'Data/AirportsByCountry' || pg.component === 'Data/AirportsByState') && p.country) {
        var st = pg.component === 'Data/AirportsByState' ? p.state : null, cs = String(p.country.slug || p.country.name || ''), sc = '';
        if (st) { try { var sm = JSON.parse(lsGet('tl.oa.states.' + cs) || '{}') || {}, ss = String(st.slug || ''); sc = Object.prototype.hasOwnProperty.call(sm, ss) ? String(sm[ss]) : ''; } catch (e) { sc = ''; } if (!sc) sc = US_STATES[String(st.name || '').toLowerCase()] || ''; if (!sc) return null; }
        return { key: st ? 'state:' + cs + ':' + sc : 'country:' + cs, states: !st && Array.isArray(p.states), cs: cs, msg: { kind: st ? 'state' : 'country', id: p.country.id || 0, name: p.country.name || '', code: sc, hasStates: !st && Array.isArray(p.states) } };
      }
      return null;
    }
    // (theirs into the page's props: true when anything changed)
    function dirApply(pg, k, d) {
      var p = pg.props;
      if (k.key === 'counts') { if (!d || !d.counts || typeof d.counts !== 'object') return false; var o = dirCounted(p.airportsByCountry, d.counts, function (x) { return x.id; }); if (o) p.airportsByCountry = o; return !!o; }
      if (k.states) { if (!d || !d.states || typeof d.states !== 'object') return false; var so = dirCounted(p.states, d.states, function (s) { return String(s.code || '').toUpperCase(); }); if (so) p.states = so; return !!so; }
      if (!d || !Array.isArray(d.airports) || !d.airports.length) return false;
      var cur = Array.isArray(p.airports) ? p.airports : [], mo = dirMerge(cur, d.airports);
      if (dirTlIds(mo) === dirTlIds(cur)) return false;
      p.airports = mo; return true;
    }
    function dirTick() {
      if (!optOn('on') || !/^\/data\/airports(\/|$)/i.test(location.pathname)) return;
      var gp = mxGp(), pg = gp && gp.$page, p = pg && pg.props; if (!p) return;
      try {
        var k = dirKeyOf(pg); if (!k) return;
        // (a country of states: which code each state's address has, for its own page)
        if (k.states) { var map = Object.create(null); p.states.forEach(function (s) { var m = String(s.url || '').match(/\/([^\/?#]+)\/?$/); if (m && s.code && /^[a-z0-9-]{1,40}$/i.test(m[1])) map[m[1]] = String(s.code).toUpperCase(); }); var ms = JSON.stringify(map); if (lsGet('tl.oa.states.' + k.cs) !== ms) lsSet('tl.oa.states.' + k.cs, ms); }
        var d = dirAsk(k.key, k.msg) || (k.key === 'counts' ? countsKept() : dirKept(k.key));
        if (d && dirApply(pg, k, d)) stats.oaDir = (stats.oaDir || 0) + 1;
        emptyTags();
      } catch (e) { stats.errors++; stats.lastError = String(e); }
    }
    setInterval(dirTick, 400);
    // (1.3.6) an airport code tag FR24 draws with no code in it - the ICAO code of one of theirs that has none, beside its
    // OurAirports code - not drawn (FR24's tag: its tooltip's span, the tag, the code's span)
    var EMPTY_TAG = 'span.inline-flex.w-fit:has(> span.uppercase > span:empty)';
    if (/^\/data\//i.test(location.pathname)) { try { var etag = document.createElement('style'); etag.id = 'tl-empty-tag'; etag.textContent = '#app ' + EMPTY_TAG + '{display:none!important}'; (document.head || document.documentElement).appendChild(etag); } catch (e) { /* none */ } }
    function emptyTags() {
      try { if (document.querySelector(':has(*)') !== undefined) { /* :has understood: the style does it */ } } catch (e) {
        // (a browser without :has: the same by hand)
        document.querySelectorAll('#app span.inline-flex.w-fit').forEach(function (w) { var t = w.firstElementChild; if (t && t.classList.contains('uppercase') && !w.textContent.trim() && w.style.display !== 'none') w.style.display = 'none'; });
      }
    }
    // (1.3.6) FR24's page held hidden - #app - until it is built as it should be: until() true, or maxMs at most. For the
    // pages made from another (an OurAirports airport's from an FR24 airport's, a family of aircraft's from FR24's own):
    // what FR24's server drew of the other before FR24's app starts is never seen
    function appMounted() { var el = document.getElementById('app'); return !!(el && el.__vue_app__); }
    function veilOn(id, maxMs, until) {
      if (Object.prototype.hasOwnProperty.call(veils, id)) return;
      var st; try { st = document.createElement('style'); st.id = 'tl-veil-' + id; st.textContent = '#app{visibility:hidden!important}'; (document.head || document.documentElement).appendChild(st); } catch (e) { return; }
      veils[id] = st;
      oSetTimeout(function () { veilOff(id); }, maxMs);
      (function poll() { if (veils[id] !== st) return; var ok = false; try { ok = !until || until(); } catch (e) { ok = true; } if (ok) veilOff(id); else oSetTimeout(poll, 40); })();
    }
    function veilOff(id) { var st = Object.prototype.hasOwnProperty.call(veils, id) ? veils[id] : null; if (!st) return; delete veils[id]; try { st.remove(); } catch (e) { /* gone */ } }
    // (1.3.6) FR24's list page as its server sent it, with theirs from the last time put in before FR24's app reads it -
    // so the page is built with them; one not looked at before shown once they are in (5 s at most)
    function dirFastPage(pg) {
      if (!pg || !pg.props || !/^Data\/Airports(ByCountry|ByState)?$/.test(pg.component)) return false;
      var k = dirKeyOf(pg); if (!k) return false;
      var d = k.key === 'counts' ? countsKept() : dirKept(k.key), ch = dirApply(pg, k, d);
      veilOn('dir', ch ? 4000 : 5000, function () { return appMounted() && (ch || dirGot.has(k.key)); });
      return ch;
    }
    // ---- (1.3.5) FR24's aircraft directory (/data/aircraft): the families and types of aircraft FR24 does not list -
    // Bombardier Global, Gulfstream and the rest the monitor's aircraft database knows - among its own, in its own form:
    // families [{ code, name, slug, count, types: [{ code, name, slug, count }] }]. FR24's own search on the page searches
    // that list, so it finds them too. Their pages - a family's and a type's, each with its production list - are made from
    // a family's and a type's page FR24 really has (learned from its list), its server never asked for theirs: in FR24's
    // own moves between pages (Inertia's XHR - its pages of the list, its pictures) and on a first load alike.
    var AC_ADD = 'tl.ac.add', AC_REF = 'tl.ac.ref', AC_PG = 'tl.ac.pg', acAdd = null, acAddSaved = false, acAsked = new Map(), acWait = new Map(), acGot = new Map();
    function acAddGet() {
      if (acAdd) return acAdd;
      try { var o = JSON.parse(lsGet(AC_ADD) || 'null'); if (o && Array.isArray(o.fams)) acAdd = o; } catch (e) { acAdd = null; }
      return acAdd;
    }
    function acRefGet() {
      try { var r = JSON.parse(lsGet(AC_REF) || 'null'); return r && /^[a-z0-9-]{1,60}$/.test(r.fam) && /^[a-z0-9-]{1,40}$/.test(r.type) && /^[a-z0-9-]{1,60}$/.test(r.typeFam) ? r : null; } catch (e) { return null; }
    }
    // (FR24's families with theirs: a type FR24 lists itself left to FR24; a family FR24 has under the same code given the
    // types it lacks, the rest added after its own - most aircraft first. What was added is marked - a family of theirs tl,
    // a type of theirs tl, a family of FR24's given types tlAdd - so FR24's own list is always had back first (acStrip):
    // the page built with them as it loaded, then the monitor's newer list)
    // (1.3.7) The maker each family is listed under. FR24's directory of mid-November groups its families by maker
    // (family.manufacturer) and makes each group's id from it - one without one stopped the page being drawn again: the
    // families added were in its data and never on the page. A product line of a maker's (the monitor's "Bombardier
    // Global", "Cessna Citation", "Hawker and Beechjet") under that maker; any other family is named after its maker
    // already; FR24's own way of writing a maker it has ("Bombardier", "Embraer") so they are in one group with its own
    var AC_LINES = /^(GLOBAL|CHALLENGER|LEARJET|FALCON|CITATION|PHENOM|LEGACY|HAWKER|KINGAIR|BONANZA|TBM|HONDAJET)$/;
    function acMakers(fams) { var m = new Map(); (fams || []).forEach(function (f) { var s = f && typeof f.manufacturer === 'string' ? f.manufacturer.trim() : ''; if (s) m.set(s.toLowerCase(), s); }); return m; }
    function acMaker(f, makers) {
      var name = String(f.name || f.code || '').trim(), mk = AC_LINES.test(String(f.code || '').toUpperCase()) ? name.split(' ')[0] : name;
      return (makers && makers.get(mk.toLowerCase())) || mk || String(f.code || '?');
    }
    function acStrip(fams) {
      return fams.filter(function (f) { return f && !f.tl; }).map(function (f) {
        if (!f.tlAdd) return f;
        var o = Object.assign({}, f, { count: (f.count || 0) - f.tlAdd, types: (f.types || []).filter(function (t) { return t && !t.tl; }) }); delete o.tlAdd; return o;
      });
    }
    function acMerge(fams, ours) {
      var fr24 = acStrip(fams), have = new Set(), byCode = new Map(), slugs = new Set(), add = [], makers = acMakers(fr24);
      fr24.forEach(function (f) { byCode.set(String(f.code).toUpperCase(), f); slugs.add(String(f.slug).toLowerCase()); (f.types || []).forEach(function (t) { if (t && t.code) have.add(String(t.code).toUpperCase()); }); });
      var out = fr24.slice(), extra = [];
      ours.forEach(function (f) {
        if (!f || !Array.isArray(f.types) || typeof f.code !== 'string' || typeof f.slug !== 'string') return;
        var types = f.types.filter(function (t) { return t && typeof t.code === 'string' && /^[A-Z0-9]{2,4}$/.test(t.code) && !have.has(t.code) && t.count > 0; }).map(function (t) { return { code: t.code, name: String(t.name || t.code), slug: String(t.slug || t.code.toLowerCase()), count: +t.count || 0, tl: 1 }; });
        if (!types.length) return;
        var n = types.reduce(function (s, t) { return s + t.count; }, 0), mine = byCode.get(f.code.toUpperCase());
        if (mine) {
          var i = out.indexOf(mine), m2 = Object.assign({}, mine, { count: (mine.count || 0) + n, types: (mine.types || []).concat(types), tlAdd: n }); out[i] = m2; byCode.set(f.code.toUpperCase(), m2);
          add.push({ code: mine.code, name: mine.name, slug: String(mine.slug), fr24: true, count: n, types: types });
        } else {
          var slug = slugs.has(f.slug) ? 'tl-' + f.slug : f.slug;
          extra.push({ code: f.code, name: String(f.name || f.code), slug: slug, count: n, types: types, photo: null, manufacturer: acMaker(f, makers), tl: 1 });
        }
      });
      // (theirs after FR24's own, most aircraft first - the additions kept in the same order, so the page built with them
      // as it loads is the one the monitor's list makes)
      extra.sort(function (a, b) { return b.count - a.count; });
      extra.forEach(function (f) { add.push({ code: f.code, name: f.name, slug: f.slug, count: f.count, types: f.types, manufacturer: f.manufacturer }); });
      return { families: out.concat(extra), add: add };
    }
    // (the same from the additions kept from the last time - the page built with them as it loads, before the monitor
    // is asked: its families with those added, FR24's own as the page has them)
    function acMergeAdd(fams, add) {
      var out = acStrip(fams), byCode = new Map(), extra = [], makers = acMakers(out);
      out.forEach(function (f, i) { byCode.set(String(f.code).toUpperCase(), i); });
      add.forEach(function (a) {
        if (!a || !Array.isArray(a.types) || !a.types.length) return;
        var types = a.types.map(function (t) { return Object.assign({}, t, { tl: 1 }); }), n = types.reduce(function (s, t) { return s + (+t.count || 0); }, 0);
        if (a.fr24) { var i = byCode.has(String(a.code).toUpperCase()) ? byCode.get(String(a.code).toUpperCase()) : -1; if (i < 0) return; var f = out[i]; out[i] = Object.assign({}, f, { count: (f.count || 0) + n, types: (f.types || []).concat(types), tlAdd: n }); }
        else if (!byCode.has(String(a.code).toUpperCase())) extra.push({ code: a.code, name: a.name, slug: a.slug, count: n, types: types, photo: null, manufacturer: acMaker(a, makers), tl: 1 });
      });
      return out.concat(extra);
    }
    // (the monitor's newer list is to be put in when the page's is not its: the page's added families and types told
    // apart by their codes, in order)
    function acSig(fams) { var s = ''; (fams || []).forEach(function (f) { if (!f) return; if (f.tl) s += f.code + ':'; else if (f.tlAdd) s += f.code + '+'; if (f.tl || f.tlAdd) (f.types || []).forEach(function (t) { if (t && t.tl) s += t.code + ','; }); s += ';'; }); return s; }
    // (an address of one of theirs - its own, /data/aircraft/bombardier-global/glex, or a page of FR24's carrying it as
    // ?tl-ac=: what it is, and the page of FR24's it is made from)
    function acPageReq(url) {
      var u; try { u = new URL(url, location.href); } catch (e) { return null; }
      if (u.origin !== location.origin || !/^\/data\/aircraft\//i.test(u.pathname)) return null;
      var add = acAddGet(), ref = acRefGet(); if (!add || !ref) return null;
      var want = u.searchParams.get('tl-ac'), path = want && /^\/data\/aircraft\/[a-z0-9-\/]{1,110}$/i.test(want) ? want : u.pathname;
      var m = path.match(/^\/data\/aircraft\/([a-z0-9-]{1,60})(?:\/([a-z0-9-]{1,40}))?\/?$/i); if (!m) return null;
      var fs = m[1].toLowerCase(), ts = m[2] ? m[2].toLowerCase() : '', f = null;
      for (var i = 0; i < add.fams.length; i++) if (add.fams[i].slug === fs) { f = add.fams[i]; break; }
      if (!f) return null;
      var pg = Math.max(1, Math.min(5000, Math.floor(+u.searchParams.get('page')) || 1)), t = null;
      if (ts) { for (var k = 0; k < f.types.length; k++) if (f.types[k].slug === ts) { t = f.types[k]; break; } if (!t) return null; }
      else if (f.fr24) return null;   // (FR24's own family: its page is FR24's, its list of types given theirs - acTick)
      var own = '/data/aircraft/' + f.slug + (t ? '/' + t.slug : '');
      return { kind: t ? 'type' : 'family', fam: f, type: t, page: pg, path: own, key: (t ? 't.' + t.code : 'f.' + f.code) + '.' + pg,
        // (1.3.7: on FR24's server's own pages a family's is made from its type page too - the one whose markup is known)
        refUrl: '/data/aircraft/' + (t || ref.legacy ? ref.typeFam + '/' + ref.type : ref.fam) + '?tl-ac=' + encodeURIComponent(own) + (pg > 1 ? '&page=' + pg : '') };
    }
    // (the monitor's page of it: asked once, kept - the last 30 - so the way back, or a second look, is at once)
    function acPgKept(key) { try { var o = JSON.parse(lsGet(AC_PG) || '{}'); var e = o && Object.prototype.hasOwnProperty.call(o, key) ? o[key] : null; return e && Date.now() - e.at < 7 * 864e5 && Array.isArray(e.d.rows) ? e.d : null; } catch (e2) { return null; } }
    function acPgKeep(key, d) {
      try { var o = JSON.parse(lsGet(AC_PG) || '{}'); if (!o || typeof o !== 'object' || Array.isArray(o)) o = {}; o[key] = { at: Date.now(), d: d }; var ks = Object.keys(o); ks.sort(function (a, b) { return o[a].at - o[b].at; }); while (ks.length > 30) delete o[ks.shift()]; lsSet(AC_PG, JSON.stringify(o)); } catch (e) { /* full */ }
    }
    function acAskPage(q) {
      if (acGot.has(q.key)) return Promise.resolve(acGot.get(q.key));
      var kept = acPgKept(q.key); if (kept) { acGot.set(q.key, kept); return Promise.resolve(kept); }
      if (acWait.has(q.key)) return acWait.get(q.key).p;
      var w = {}; w.p = new Promise(function (res) { w.res = res; }); acWait.set(q.key, w);
      post('acPage', { key: q.key, kind: q.kind, code: q.kind === 'type' ? q.type.code : q.fam.code, page: q.page });
      setTimeout(function () { if (acWait.get(q.key) === w) { acWait.delete(q.key); w.res(null); } }, 8000);
      return w.p;
    }
    function acceptAcPage(d) {
      if (!d || typeof d.key !== 'string') return;
      var w = acWait.get(d.key), pg = d.page && Array.isArray(d.page.rows) ? d.page : null;
      if (pg) { acGot.set(d.key, pg); acPgKeep(d.key, pg); }
      if (w) { acWait.delete(d.key); w.res(pg); }
    }
    function acceptAcDir(d) {
      if (!d || typeof d.key !== 'string' || !acAsked.has(d.key)) return;
      if (Array.isArray(d.families)) { acAsked.set(d.key, { at: Date.now(), families: d.families }); acTick(); }
    }
    // (FR24's production list's rows - { msn, registration, airline, owner, type, age } - and Laravel's pages of them)
    function acPaginator(q, d) {
      var nowY = new Date().getUTCFullYear(), names = {};
      (q.fam.types || []).forEach(function (t) { names[t.code] = t.name; });
      var rows = d && Array.isArray(d.rows) ? d.rows : [], cur = d ? d.page : 1, last = d ? d.lastPage : 1, per = d ? d.perPage : 50, total = d ? d.total : 0;
      var data = rows.map(function (r) {
        var tc = String(r[5] || (q.type && q.type.code) || ''), y = +r[2] || 0;
        return { msn: r[1] ? String(r[1]) : null, registration: String(r[0] || ''), airline: null, owner: r[3] ? String(r[3]) : null, type: Object.prototype.hasOwnProperty.call(names, tc) ? names[tc] : tc, typeCode: tc, age: y > 1900 ? Math.max(0, nowY - y) : null, testFlight: false };
      });
      var base = location.origin + q.path, url = function (n) { return base + '?page=' + n; }, links = [{ url: cur > 1 ? url(cur - 1) : null, label: '&laquo; Previous', active: false }];
      for (var n = 1; n <= last; n++) {
        if (n === 1 || n === last || Math.abs(n - cur) <= 3) links.push({ url: url(n), label: String(n), active: n === cur });
        else if (links[links.length - 1].label !== '...') links.push({ url: null, label: '...', active: false });
      }
      links.push({ url: cur < last ? url(cur + 1) : null, label: 'Next &raquo;', active: false });
      return { data: data, current_page: cur, last_page: last, per_page: per, total: total, from: data.length ? (cur - 1) * per + 1 : null, to: data.length ? (cur - 1) * per + data.length : null,
        path: base, first_page_url: url(1), last_page_url: url(last), next_page_url: cur < last ? url(cur + 1) : null, prev_page_url: cur > 1 ? url(cur - 1) : null, links: links };
    }
    // (the photos FR24's list shows beside each - those this page has found for the registrations on it: { reg: { src, copyright } })
    function acPhotos(rows) {
      var o = {};
      rows.forEach(function (r) {
        try { var res = r[4] && photoCache.get(String(r[4]).toUpperCase()), ph = res && Array.isArray(res.photos) ? res.photos[0] : null, u = ph && (ph.medium || ph.thumb || ph.large); if (u) o[String(r[0])] = { src: String(u), copyright: String(ph.copyright || ph.photographer || ph.by || '') }; } catch (e) { /* none */ }
      });
      return o;
    }
    // (FR24's page of the family or type it is made from - its layout, its texts - made theirs)
    function acPageOf(j, q, d) {
      var o = Object.assign({}, j), p = Object.assign({}, j.props || {}), stat = q.type || q.fam;
      o.component = q.kind === 'type' ? 'Data/AircraftType' : 'Data/AircraftFamily';
      o.url = q.path + (q.page > 1 ? '?page=' + q.page : '');
      p.family = Object.assign({}, p.family && typeof p.family === 'object' ? p.family : {}, { code: q.fam.code, name: q.fam.name, slug: q.fam.slug });
      p.statistics = { total: d ? d.total : (stat.count || 0), averageAge: d ? d.averageAge : null };
      p.aircraft = acPaginator(q, d);
      p.photos = acPhotos(d && Array.isArray(d.rows) ? d.rows : []);
      p.locked = false;
      p.canonicalUrl = location.origin + q.path;
      if (q.kind === 'type') { p.type = { code: q.type.code, name: q.type.name, model: q.type.name, slug: q.type.slug }; delete p.types; }
      else { p.types = q.fam.types.map(function (t) { return { code: t.code, name: t.name, slug: t.slug, count: t.count, photo: null }; }); delete p.type; }
      o.props = p;
      Object.defineProperty(o, '__tlAc', { value: q.key, enumerable: false });
      stats.acPages = (stats.acPages || 0) + 1;
      return o;
    }
    // (the page FR24's server sent for the page theirs is made from, made theirs as it loads - the monitor's page of it
    // when kept, else filled when it comes (acTick) - and its address theirs)
    function acFastPage(pg) {
      if (!pg || !pg.component || !/^Data\/Aircraft/.test(pg.component)) return pg;
      var q = acPageReq(location.href); if (!q) return pg;
      var o = acPageOf(pg, q, acPgKept(q.key));
      try { history.replaceState(history.state, '', o.url); } catch (e) { /* the address as it is */ }
      veilOn('ac', 6000, appMounted);
      return o;
    }
    // (1.3.6) FR24's directory as its server sent it, with the families and types added the last time put in before
    // FR24's app reads it - the page built with them; the first time, shown once they are in (5 s at most)
    function acDirFastPage(pg) {
      if (!pg || pg.component !== 'Data/Aircraft' || !pg.props || !Array.isArray(pg.props.families)) return false;
      var kept = acAddGet(), ch = false;
      if (kept && kept.fams.length) { pg.props.families = acMergeAdd(pg.props.families, kept.fams); ch = true; }
      veilOn('acdir', ch ? 4000 : 5000, function () { if (!appMounted()) return false; if (ch) return true; var gp = mxGp(), p = gp && gp.$page && gp.$page.props; return !!(p && Array.isArray(p.families) && p.families.some(function (f) { return f && (f.tl || f.tlAdd); })); });
      return ch;
    }
    function acTick() {
      if (!optOn('on') || !/^\/data\/aircraft(\/|$)/i.test(location.pathname)) return;
      var gp = mxGp(), pg = gp && gp.$page, p = pg && pg.props; if (!p) { try { acLegTick(); } catch (e) { stats.errors++; stats.lastError = String(e); } return; }
      try {
        if (pg.component === 'Data/Aircraft' && Array.isArray(p.families)) {
          var base = acStrip(p.families);
          // (a family and a type of FR24's own, to make theirs from: the one with the most aircraft)
          var rf = null; base.forEach(function (f) { if (f && f.slug && Array.isArray(f.types) && f.types.length && f.types[0].slug && (!rf || (f.count || 0) > (rf.count || 0))) rf = f; });
          if (rf) { var ref = { fam: String(rf.slug).toLowerCase(), typeFam: String(rf.slug).toLowerCase(), type: String(rf.types[0].slug).toLowerCase() }; var was = acRefGet(); if (!was || was.fam !== ref.fam || was.type !== ref.type) lsSet(AC_REF, JSON.stringify(ref)); }
          var a = acAsked.get('idx');
          if (!a) { acAsked.set('idx', { at: Date.now() }); post('acDir', { key: 'idx' }); a = acAsked.get('idx'); }
          if (!a.families) {
            if (Date.now() - a.at > 30000) acAsked.delete('idx');
            // (meanwhile the additions kept from the last time, should the page not have them - FR24's own move to it)
            var kept = acAddGet(); if (kept && !p.families.some(function (f) { return f && (f.tl || f.tlAdd); })) { p.families = acMergeAdd(p.families, kept.fams); stats.acDir = (stats.acDir || 0) + 1; }
            return;
          }
          var m = acMerge(p.families, a.families);
          if (acSig(m.families) === acSig(p.families)) { if (!acAddSaved) { acAddSaved = true; acAdd = { at: Date.now(), fams: m.add }; lsSet(AC_ADD, JSON.stringify(acAdd)); } return; }
          p.families = m.families; acAdd = { at: Date.now(), fams: m.add }; acAddSaved = true; lsSet(AC_ADD, JSON.stringify(acAdd)); stats.acDir = (stats.acDir || 0) + 1;
        } else if (pg.component === 'Data/AircraftFamily' && p.family && Array.isArray(p.types) && !p.types.some(function (t) { return t && t.tl; })) {
          // (a family of FR24's own: the types it lacks among its own)
          var add = acAddGet(), f = add && add.fams.filter(function (x) { return x.fr24 && x.slug === String(p.family.slug || '').toLowerCase(); })[0];
          if (f) { p.types = p.types.concat(f.types.map(function (t) { return { code: t.code, name: t.name, slug: t.slug, count: t.count, photo: null, tl: 1 }; })); stats.acDir = (stats.acDir || 0) + 1; }
        }
        // (one of theirs whose production list was not here when it loaded: filled now)
        var q = (pg.component === 'Data/AircraftFamily' || pg.component === 'Data/AircraftType') && p.aircraft && !p.aircraft.data.length ? acPageReq(location.href) : null;
        if (q && p.family && p.family.slug === q.fam.slug && !p.aircraft.__tlAsk) {
          p.aircraft.__tlAsk = 1;
          acAskPage(q).then(function (d) { if (!d) return; var g2 = mxGp(), pg2 = g2 && g2.$page; if (!pg2 || !pg2.props || pg2.props.family !== p.family) return; pg2.props.statistics = { total: d.total, averageAge: d.averageAge }; pg2.props.aircraft = acPaginator(q, d); pg2.props.photos = acPhotos(d.rows); });
        }
      } catch (e) { stats.errors++; stats.lastError = String(e); }
    }
    setInterval(acTick, 400);
    // (one of theirs whose address FR24's server sent elsewhere - typed, or the page loaded again: the extension saw where
    // from - made from FR24's page as it loads)
    var acNav = function (u) { location.replace(u); };
    function acceptAcFrom(d) {
      if (!optOn('on') || !d || typeof d.path !== 'string' || !/^\/data\/aircraft\//i.test(d.path)) return;
      var q = acPageReq(d.path); if (q) acNav(q.refUrl);
    }
    // ---- (1.3.7) FR24's directory and production lists as its server makes them - not its app's pages: the ones it sends
    // some browsers (/data/aircraft: a table of families, each with its types; /data/aircraft/a32s/a319: a type's aircraft
    // all on one page). 1.3.5 and 1.3.6 changed only its app's pages - these never had a family added. The same families
    // and types added, in FR24's own rows; their pages made from one of FR24's own type pages, as its app's are
    var acTxt = function (el) { return String(el ? el.textContent : '').replace(/\s+/g, ' ').trim(); };
    function hx(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    var acLegSig = '', acLegHide = null;
    function acLegTable() { return document.querySelector('#list-aircraft table.data-table'); }
    // (its families from its rows - a family's first row its label, code and total; then a row a type)
    function acLegFams(tb) {
      var fams = [], f = null, num = function (el) { return parseInt(acTxt(el).replace(/\D/g, ''), 10) || 0; };
      [].forEach.call(tb.querySelectorAll('tr'), function (tr) {
        if (tr.getAttribute('data-tl')) return;
        var lab = tr.querySelector('label.aircraft-family'), a = tr.querySelector('a[href*="/data/aircraft/"]'), n = tr.querySelector('td.text-right'), h = a ? a.getAttribute('href') || '' : '';
        var mf = h.match(/\/data\/aircraft\/([a-z0-9-]+)\/?$/i), mt = h.match(/\/data\/aircraft\/([a-z0-9-]+)\/([a-z0-9-]+)\/?$/i);
        if (lab && mf) { f = { code: acTxt(a), name: acTxt(lab), slug: mf[1].toLowerCase(), count: num(n), types: [], tr: tr }; fams.push(f); }
        else if (f && mt) f.types.push({ code: acTxt(a).toUpperCase(), slug: mt[2].toLowerCase(), count: num(n), tr: tr });
      });
      return fams;
    }
    function acLegRows(fam, types, own) {
      var h = '';
      if (!own) h += '<tr class="border-top" data-tl="1"><td rowspan="' + (types.length + 1) + '"><label class="aircraft-family">' + hx(fam.name) + '</label></td><td> <strong><a href="/data/aircraft/' + hx(fam.slug) + '" title="Aircraft family code">' + hx(fam.code) + '</a></strong></td><td class="text-right"><strong><span title="Total number of aircraft for this family" class="cursor-help"> ' + (+fam.count || 0) + ' </span></strong></td></tr>';
      types.forEach(function (t) { h += '<tr data-tl="1"><td> <a href="/data/aircraft/' + hx(fam.slug) + '/' + hx(t.slug) + '" title="' + hx(t.name || t.code) + '"> ' + hx(t.code) + ' </a></td><td class="text-right"><span title="Total number of ' + hx(t.code) + ' aircraft" class="cursor-help"> ' + (+t.count || 0) + ' </span></td></tr>'; });
      if (!own) h += '<tr data-tl="1"><td colspan="3">&nbsp;</td></tr>';
      return h;
    }
    // (the directory: theirs put in - the monitor's list when it is in (theirs), else the additions kept from the last time)
    function acLegDir(theirs) {
      var tb = acLegTable(); if (!tb) return false;
      var own = acLegFams(tb); if (own.length < 5) return false;
      // (FR24's type page to make theirs from: the family with the most aircraft, its first type - its own markup)
      var rf = null; own.forEach(function (f) { if (f.types.length && f.slug && (!rf || f.count > rf.count)) rf = f; });
      if (rf) { var ref = { fam: rf.slug, typeFam: rf.slug, type: rf.types[0].slug, legacy: 1 }, was = acRefGet(); if (!was || was.fam !== ref.fam || was.type !== ref.type || !was.legacy) lsSet(AC_REF, JSON.stringify(ref)); }
      var add;
      if (theirs) { add = acMerge(own.map(function (f) { return { code: f.code, name: f.name, slug: f.slug, count: f.count, types: f.types.map(function (t) { return { code: t.code, slug: t.slug, count: t.count }; }) }; }), theirs).add; acAdd = { at: Date.now(), fams: add }; acAddSaved = true; lsSet(AC_ADD, JSON.stringify(acAdd)); }
      else { var k = acAddGet(); if (!k || !k.fams.length) return false; add = k.fams; }
      var sig = add.map(function (a) { return a.code + ':' + a.types.length; }).join(',');
      if (sig === acLegSig && tb.querySelector('tr[data-tl]')) return true;
      // (put in afresh: what was put in before taken out, FR24's own as it sent them)
      [].forEach.call(tb.querySelectorAll('tr[data-tl]'), function (tr) { tr.remove(); });
      own.forEach(function (f) { var td = f.tr.querySelector('td[rowspan]'), n = f.tr.querySelector('td.text-right span'); if (td && td.getAttribute('data-tl-rs')) td.setAttribute('rowspan', td.getAttribute('data-tl-rs')); if (n && n.getAttribute('data-tl-n')) n.textContent = ' ' + n.getAttribute('data-tl-n') + ' '; });
      var body = tb.tBodies[0] || tb;
      add.filter(function (a) { return a.fr24; }).forEach(function (a) {
        var f = null; own.forEach(function (x) { if (!f && x.code.toUpperCase() === String(a.code).toUpperCase()) f = x; }); if (!f || !a.types.length) return;
        (f.types.length ? f.types[f.types.length - 1].tr : f.tr).insertAdjacentHTML('afterend', acLegRows(f, a.types, true));
        var td = f.tr.querySelector('td[rowspan]'), n = f.tr.querySelector('td.text-right span');
        if (td) { if (!td.getAttribute('data-tl-rs')) td.setAttribute('data-tl-rs', td.getAttribute('rowspan') || '1'); td.setAttribute('rowspan', String((+td.getAttribute('data-tl-rs') || 1) + a.types.length)); }
        if (n) { if (!n.getAttribute('data-tl-n')) n.setAttribute('data-tl-n', String(f.count)); n.textContent = ' ' + (f.count + (+a.count || 0)) + ' '; }
      });
      // (theirs among FR24's in its order - by name, as its list is)
      add.filter(function (a) { return !a.fr24 && a.types.length; }).sort(function (x, y) { return x.name < y.name ? -1 : x.name > y.name ? 1 : 0; }).forEach(function (a) {
        var before = null; own.forEach(function (f) { if (!before && f.name > a.name) before = f; });
        if (before) before.tr.insertAdjacentHTML('beforebegin', acLegRows(a, a.types, false)); else body.insertAdjacentHTML('beforeend', acLegRows(a, a.types, false));
      });
      acLegSig = sig; stats.acDir = (stats.acDir || 0) + 1;
      return true;
    }
    // (a page of theirs, made from FR24's type page: its title, total, crumbs and table theirs - the monitor's aircraft of
    // it, 50 a page - and the address theirs)
    var acLegKey = '';
    function acLegPage() {
      var q = acPageReq(location.href); if (!q) return false;
      var tb = document.querySelector('#cnt-list-aircraft table.data-table'); if (!tb || !tb.tBodies[0]) return false;
      if (acLegKey === q.key) return true;
      acLegKey = q.key;
      try { if (location.pathname + location.search !== q.path + (q.page > 1 ? '?page=' + q.page : '')) history.replaceState(history.state, '', q.path + (q.page > 1 ? '?page=' + q.page : '')); } catch (e) { /* the address as it is */ }
      var fam = q.fam, t = q.type, title = t ? (t.name || t.code) + ' (' + t.code + ') production list' : fam.name + ' production list';
      document.title = title + ' - Flight tracker | Flightradar24';
      var h1 = document.querySelector('#cnt-subpage-title h1'), h3 = document.querySelector('#cnt-subpage-title h3');
      if (h1) h1.textContent = 'Production lists - ' + fam.name + (t ? ' - ' + t.code : '');
      var crumbs = document.querySelectorAll('.breadcrumbs__list-item-name');
      if (crumbs.length >= 2) {
        var last = crumbs[crumbs.length - 1], prev = crumbs[crumbs.length - 2], pa = prev.closest('a');
        if (t) { last.textContent = ' ' + t.code + ' '; prev.textContent = ' ' + fam.name + ' '; if (pa) { pa.setAttribute('href', '/data/aircraft/' + fam.slug); pa.setAttribute('itemid', '/data/aircraft/' + fam.slug); } }
        else { last.textContent = ' ' + fam.name + ' '; var li = prev.closest('li'), sp = li && li.nextElementSibling; if (li) li.remove(); if (sp && sp.tagName === 'SPAN') sp.remove(); }
      }
      var head = tb.tHead && tb.tHead.rows[0];
      if (head && !t && !head.querySelector('th[data-tl]')) { var ths = head.cells; if (ths.length > 2) ths[1].insertAdjacentHTML('afterend', '<th class="sortable w-80" data-tl="1">TYPE</th>'); }
      var body = tb.tBodies[0];
      body.innerHTML = '<tr data-tl="1"><td colspan="6" class="text-center">Loading the aircraft of ' + hx(t ? t.code : fam.name) + '…</td></tr>';
      acAskPage(q).then(function (d) {
        if (acLegKey !== q.key) return;
        if (!d) { body.innerHTML = '<tr data-tl="1"><td colspan="6" class="text-center">The list is not available just now - the page loaded again will ask for it again.</td></tr>'; acLegShow(); return; }
        var nowY = new Date().getUTCFullYear(), h = '';
        d.rows.forEach(function (r) {
          var reg = String(r[0] || ''), y = +r[2] || 0, age = y > 1900 ? Math.max(0, nowY - y) : null, tc = String(r[5] || (t && t.code) || '');
          var ts = null; (fam.types || []).forEach(function (x) { if (!ts && x.code === tc) ts = x.slug; });
          h += '<tr data-tl="1"><td> ' + hx(r[1] || '') + ' </td> <td><a class="regLinks" target="_self" href="/data/aircraft/' + hx(reg.toLowerCase()) + '"> ' + hx(reg) + ' </a></td>' +
            (t ? '' : '<td>' + (ts ? '<a href="/data/aircraft/' + hx(fam.slug) + '/' + hx(ts) + '"> ' + hx(tc) + ' </a>' : hx(tc)) + '</td>') +
            '<td> ' + hx(r[3] || '') + ' </td> <td>' + (y > 1900 ? y + ' (' + (age === 0 ? 'new' : age + (age === 1 ? ' year' : ' years')) + ')' : '') + '</td> <td class="text-center"><a href="https://www.jetphotos.com/registration/' + hx(encodeURIComponent(reg)) + '" target="_blank" rel="noopener"><i class="fa fa-camera"></i></a></td></tr>';
        });
        body.innerHTML = h || '<tr data-tl="1"><td colspan="6" class="text-center">None known.</td></tr>';
        if (h3) h3.textContent = 'Total number of aircraft: ' + (d.total || 0);
        // (its pages: 50 aircraft a page)
        var nav = document.getElementById('tl-ac-pages'); if (nav) nav.remove();
        if (d.lastPage > 1) {
          var link = function (n, label) { return '<a href="' + hx(q.path + (n > 1 ? '?page=' + n : '')) + '" style="margin:0 6px">' + label + '</a>'; };
          tb.insertAdjacentHTML('afterend', '<div id="tl-ac-pages" class="text-center" style="margin:12px 0">' + (d.page > 1 ? link(d.page - 1, '&laquo; Previous') : '') + '<span style="margin:0 6px">Page ' + d.page + ' of ' + d.lastPage + '</span>' + (d.page < d.lastPage ? link(d.page + 1, 'Next &raquo;') : '') + '</div>');
        }
        acLegShow();
      });
      return true;
    }
    function acLegShow() { if (acLegHide) { try { acLegHide.remove(); } catch (e) { /* gone */ } acLegHide = null; } }
    // (as the page loads: hidden until it is built - 5 s at most; the address of one of theirs FR24's server has no page
    // of: to the page it is made from)
    function acLegBoot() {
      if (!optOn('on') || !/^\/data\/aircraft(\/|$)/i.test(location.pathname)) return;
      var q = acPageReq(location.href), dir = /^\/data\/aircraft\/?$/i.test(location.pathname);
      if (!q && !(dir && acAddGet())) return;
      try { acLegHide = document.createElement('style'); acLegHide.textContent = '#list-aircraft,#cnt-list-aircraft,#cnt-subpage-title,.breadcrumbs__list-item-name{visibility:hidden!important}'; (document.head || document.documentElement).appendChild(acLegHide); } catch (e) { acLegHide = null; }
      oSetTimeout(acLegShow, 5000);
      var go = function () {
        // (the directory: built from what was kept, then shown - FR24's app's, or one with nothing to put in, at once)
        if (dir) { acLegDir(null); acLegShow(); return; }
        if (document.querySelector('#app[data-page]')) { acLegShow(); return; }   // (FR24's app's page: acFastPage)
        if (!acLegPage()) { acLegShow(); if (!document.querySelector('#cnt-list-aircraft, #list-aircraft') && !new URL(location.href).searchParams.get('tl-ac')) { try { acNav(q.refUrl); } catch (e) { /* stays */ } } }
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go, { once: true }); else go();
    }
    // (the directory, once the monitor's list is in: FR24's table with it - looked at with acTick)
    function acLegTick() {
      if (!/^\/data\/aircraft\/?$/i.test(location.pathname) || !acLegTable()) return;
      var a = acAsked.get('idx');
      if (!a) { acAsked.set('idx', { at: Date.now() }); post('acDir', { key: 'idx' }); return; }
      if (!a.families) { if (Date.now() - a.at > 30000) acAsked.delete('idx'); return; }
      if (acLegDir(a.families)) acLegShow();
    }
    try { acLegBoot(); } catch (e) { stats.errors++; stats.lastError = String(e); }
    // (a link to one of theirs - FR24's search on the page, its cards, a list's next page: to the page of FR24's it is made
    // from, so a load of it, in this tab or another, is made theirs as it loads)
    function acLinkPressed(ev) {
      if (!optOn('on')) return;
      try {
        var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null; if (!a) return;
        var q = acPageReq(a.href); if (!q) return;
        var h = new URL(a.href, location.href); if (h.searchParams.get('tl-ac')) return;
        a.setAttribute('href', q.refUrl);
      } catch (e) { stats.errors++; stats.lastError = String(e); }
    }
    ['pointerdown', 'mousedown', 'touchstart', 'auxclick', 'contextmenu', 'keydown', 'focusin'].forEach(function (k) { document.addEventListener(k, function (ev) { if (k === 'keydown' && ev.key !== 'Enter') return; acLinkPressed(ev); }, true); });
    function searchFetch(self, args, url, kind) {
      var u; try { u = new URL(url, location.href); } catch (e) { return null; }
      var q = u.searchParams.get('query') || '', type = u.searchParams.get('type') || '';
      if (q.trim().length < 2 || (kind === 'find' && type && type !== 'airport')) return null;
      // (1.4.1: an airport search proper - FR24's flights page's, its airport pages' - waits for the list a little longer
      // while the page has none of it yet: the userscript reads it as the page opens)
      return Promise.all([oFetch.apply(self, args), oaSearch(q, kind === 'airports' && !oaRows ? 3000 : 500)]).then(function (x) {
        var res = x[0], rows = x[1]; if (!rows.length || !res || !res.ok) return res;
        return res.clone().json().then(function (j) { var o = kind === 'find' ? searchMerge(j, rows, q) : apSearchMerge(j, rows); if (o) stats.oaSearch = (stats.oaSearch || 0) + 1; return o ? jsonResponse(res, o) : res; }, function () { return res; });
      });
    }
    var UTC_TZ = { abbr: 'UTC', abbrName: null, isDst: false, name: 'UTC', offset: 0, offsetHours: '0:00' };
    function oaFr24Row(r, ref) {
      ref = ref || {};
      var name = String(r[3] || r[1]), city = placeShort(fieldShortName(name)) || placeShort(r[4]) || placeShort(name);
      // (1.3.2: its identifier - ICAO, GPS or OurAirports' own - where FR24 keeps an ICAO code: the map's labels set to "ICAO"
      // showed nothing for these, the window's ICAO field "N/A")
      return { id: r[0], iata: r[1], icao: String(r[2] || r[1] || ''), name: name, city: city, country: ref.country || '', countryId: ref.countryId || 0, lat: r[6], lon: r[7], alt: r[8] || 0,
        size: OA_SIZE[r[9]] || 1, timezone: ref.timezone || UTC_TZ, videoStream: null };
    }
    // (1.3.1) one as FR24's own store and map keep an airport - FR24 turns each row of its list into this (its latitude and
    // longitude, its zone's name and offset); 1.3 put the list's rows themselves on the map, with lat / lon where FR24's
    // map reads latitude / longitude: every pin was drawn nowhere
    function oaStoreRow(r) {
      if (oaPinLabels.size < 200000) { var ic0 = String(r[2] || r[1] || ''); oaPinLabels.set(oaPinKey(String(r[1]), ic0), oaCodeLine(r)); }
      return storeForm(oaFr24Row(r, refOf(r[5])));
    }
    // (an airport of FR24's list as FR24's own store keeps it: its latitude and longitude, its zone's name and offset)
    function storeForm(a) {
      var tz = a.timezone || UTC_TZ;
      return { id: a.id, iata: a.iata, icao: a.icao, name: a.name, latitude: a.lat, longitude: a.lon, altitude: a.alt, city: a.city, country: a.country, countryId: a.countryId, size: a.size,
        timezoneName: tz.name, timezoneCode: tz.abbr, timezoneDST: !!tz.isDst, timezoneOffset: tz.offset, timezoneOffsetHours: tz.offsetHours, videoStream: null };
    }
    // (1.3.4) one of FR24's airports in its list's form: as its list came, else from FR24's own table of airports - FR24
    // reads its list from its cache most of the time, and the list never comes past here then
    function refOf(id) {
      var r = fr24Refs.get(id); if (r || !id) return r || null;
      var st = pinStore('airports'), m = st && st.airportsById, a = m && typeof m.get === 'function' ? m.get(id) : null;
      if (!a || !(a.id < 9000000) || !isFinite(a.latitude)) return null;
      r = { id: a.id, iata: a.iata, icao: a.icao, name: a.name, city: a.city, country: a.country || '', countryId: a.countryId || 0, lat: a.latitude, lon: a.longitude, alt: a.altitude || 0, size: a.size || 0,
        timezone: a.timezoneName ? { name: a.timezoneName, abbr: a.timezoneCode, abbrName: null, isDst: !!a.timezoneDST, offset: a.timezoneOffset, offsetHours: a.timezoneOffsetHours } : UTC_TZ };
      fr24Refs.set(id, r); return r;
    }
    // (1.3.4) Every one of them in FR24's own tables of airports - by id and by code - whatever its map shows: FR24 looks
    // airports up there for its playback, its boards, its panels and its window, and one missing is "-" (M-SKTO's landings
    // at Axis Business Park's helipad in playback) or a window with nothing in it. In the tables themselves, not through
    // FR24's reactive wrapper of them (63,000 changes would each wake its map); the landing places learned too. Again each
    // time FR24 makes the tables anew.
    var oaFillT = 0, oaFillAt = null;
    function rawOf(m) { return m && m.__v_raw ? m.__v_raw : m; }
    function oaFillTables() {
      if (oaFillT) return;
      var st = pinStore('airports'), byId = st && rawOf(st.airportsById), byIata = st && rawOf(st.airportsByIata);
      if (!byId || typeof byId.set !== 'function' || !(byId.size > 100)) return;
      var todo = (oaRows || []).slice(), sites = siteRows.slice(), i = 0;
      oaFillAt = byId;
      var step = function () {
        oaFillT = 0;
        if (oaFillAt !== byId) return;                     // (FR24 made its tables anew meanwhile: done again for those)
        var t = Date.now();
        while (i < todo.length && Date.now() - t < 12) {
          // (theirs always as the list has them now - FR24's cached list may hold them as an older script made them)
          var r = todo[i++]; if (!Array.isArray(r) || !(r[0] >= 1e7) || oaDupe(r)) continue;
          var o = oaStoreRow(r); byId.set(o.id, o); if (byIata && o.iata) byIata.set(o.iata, o);
        }
        if (i < todo.length) { oaFillT = setTimeout(step, 0); return; }
        sites.forEach(function (a) { if (a && a.id > 9000000 && a.id < 1e7 && isFinite(a.lat)) { var o = storeForm(a); byId.set(o.id, o); if (byIata && o.iata && o.iata !== 'PVT' && !byIata.has(o.iata)) byIata.set(o.iata, o); } });
        stats.oaTables = byId.size;
      };
      oaFillT = setTimeout(step, 0);
    }
    var isOaRow = function (a) { return !!a && a.id >= 1e7; };
    // (1.3.4) the codes of FR24's own airports as its list has them now - one of theirs with such a code is FR24's: left to
    // FR24 (London Heliport's pin, both, and a window that would not open)
    var fr24Codes = new Set();
    function noteFr24Codes(list) { (list || []).forEach(function (a) { if (a && a.id < 9000000) { if (a.iata) fr24Codes.add(String(a.iata).toUpperCase()); if (a.icao) fr24Codes.add(String(a.icao).toUpperCase()); } }); }
    function oaDupe(r) { return fr24Codes.size > 0 && (fr24Codes.has(String(r[1]).toUpperCase()) || (/^[A-Z]{4}$/.test(String(r[2])) && fr24Codes.has(String(r[2]).toUpperCase()))); }
    function patchList(kind, j) {
      if (!j || !Array.isArray(j.rows) || j.rows.length < 100) return false;
      if (kind === 'airlines') j.rows.forEach(function (r) { var l = r && LOGO_ADD[r.id]; if (l && !(r.metadata && r.metadata.images)) r.metadata = { images: { logotypes: { default: { file: { dimensions: l.dimensions, name: r.id + '.png', size: 0, source: l.source, type: 'PNG' } } } } }; });
      else {
        var have = {}; j.rows.forEach(function (r) { if (r) { have[r.id] = true; if (r.id < 9000000) fr24Refs.set(r.id, r); } });
        // (1.3.7: FR24's list now has its airports with an ICAO code alone too - an OurAirports one of the same code is
        // FR24's own, never added beside it)
        noteFr24Codes(j.rows.filter(function (r) { return r && r.id < 9000000; }));
        siteRows.forEach(function (r) { if (r && r.id && !have[r.id]) j.rows.push(r); });
        if (oaRows) oaRows.forEach(function (r) { if (Array.isArray(r) && r[0] >= 1e7 && !have[r[0]] && !oaDupe(r)) j.rows.push(oaFr24Row(r, refOf(r[5]))); });
      }
      lsSet('tl.list.' + kind, listSig(kind));
      return true;
    }
    function acceptSites(list) { if (!Array.isArray(list)) return; siteRows = list; lsSet('tl.sites', JSON.stringify(list)); oaFillTables(); }
    // Learned landing places stay in FR24's airport list (its panel and boards look airports up there by id) but never on
    // its map: the airport layer draws the 'airports' store's array - and highlights by IATA code, which every site shares
    // ("PVT"), so one selected flight's site lit them all. Taken out of that array alone, each time FR24 fills it.
    var isSiteRow = function (a) { return !!a && a.id > 9000000 && a.id < 10000000; };
    // (one of FR24's own state stores - the map's: airports, aircraft, playback)
    function pinStore(n) { try { var el = document.getElementById('app'), pin = el && el.__vue_app__ && el.__vue_app__.config.globalProperties.$pinia; return (pin && pin._s && pin._s.get(n)) || null; } catch (e) { return null; } }
    function pbOn() { var st = pinStore('playback'); return !!(st && st.active); }
    function sitesOffMap() {
      try {
        var st = pinStore('airports');
        if (!st || typeof st.$onAction !== 'function') return false;
        // (1.3: the OurAirports airports too - but for those in view, put in by oaMap)
        var strip = function () { var a = st.airports; if (Array.isArray(a) && a.some(function (x) { return isSiteRow(x) || isOaRow(x); })) { oaBase = a.filter(function (x) { return !isSiteRow(x) && !isOaRow(x); }); oaShown = ''; st.airports = oaBase; oaMapSoon(); } else if (Array.isArray(a)) oaBase = a.filter(function (x) { return !isOaRow(x); }); noteFr24Codes(oaBase); oaFillTables(); };
        st.$onAction(function (c) { if (c.name === 'setAirports') c.after(strip); }); strip();
        return true;
      } catch (e) { return false; }
    }
    var sitesOffN = 0, sitesOffT = setInterval(function () { if (sitesOffMap() || ++sitesOffN > 480) clearInterval(sitesOffT); }, 250);
    // (1.3) the OurAirports airports in view on the map, once zoomed in to 8 or more - the 400 nearest the middle, within
    // the screen's reach; looked at again as the map moves.
    // (1.3.2) Where the map is: FR24's address says it (/<lat>,<lon>/<zoom>) only while nothing is open - with an aircraft
    // or an airport open the address is theirs, and 1.3.1, finding no place in it, took every pin off the map (and with
    // them the airport FR24's own window was showing: its boards went blank). Then: the area FR24 last asked its feed
    // for (noteView), its zoom worked out from how wide that area is - by what the address and the area said together
    // while both were known, else by the window's width. Nothing known of either: what is shown stays.
    var oaBase = null, oaShown = '', oaMapT = 0, oaZoomK = null, oaZoomSeen = '';
    function oaMapSoon() { if (!oaMapT) oaMapT = setTimeout(function () { oaMapT = 0; oaMap(); }, 300); }
    function oaBoxOf() {
      var b = viewBox; if (!b || !(b.n > b.s)) return null;
      var e = b.e < b.w ? b.e + 360 : b.e, span = e - b.w; if (!(span > 0) || span > 360) return null;
      var lo = (b.w + e) / 2; if (lo > 180) lo -= 360;
      return { la: (b.n + b.s) / 2, lo: lo, span: span };
    }
    function oaView() {
      var m = location.pathname.match(/^\/(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)/), box = oaBoxOf();
      if (m) {
        // (the address and the area the same twice running: how the area's width and the zoom go together here)
        if (box) { var seen = m[0] + '|' + box.span.toFixed(3); if (seen === oaZoomSeen && Math.abs(box.la - +m[1]) < box.span && Math.abs(box.lo - +m[2]) < box.span) oaZoomK = +m[3] - Math.log(360 / box.span) / Math.LN2; oaZoomSeen = seen; }
        return { la: +m[1], lo: +m[2], z: +m[3] };
      }
      if (!box) return null;
      var k = oaZoomK != null ? oaZoomK : Math.log(Math.max(320, window.innerWidth || 1280) / 256) / Math.LN2;
      return { la: box.la, lo: box.lo, z: Math.round((k + Math.log(360 / box.span) / Math.LN2) * 10) / 10 };
    }
    // (the airport FR24's window is open on, when it is one of these: always among the pins, wherever the map is)
    function oaOpenRow() { var m = location.pathname.match(/^\/airport\/(?:\d+\/)?([^\/?#]+)/i); if (!m) return null; try { return oaByCode.get(decodeURIComponent(m[1]).toLowerCase()) || null; } catch (e) { return null; } }
    // (FR24's own tables of its airports - by id, by code: its window, its boards and its routes find the airport they
    // show there, and an airport missing from them is a window with nothing in it. FR24's list had them when it was
    // fetched with these added; a list fetched before they came, or kept from before, did not)
    function oaStoreKeep(st, o) {
      try {
        if (!st || !o) return;
        var byId = st.airportsById, byIata = st.airportsByIata;
        if (byId && typeof byId.set === 'function' && !byId.has(o.id)) byId.set(o.id, o);
        if (byIata && typeof byIata.set === 'function' && o.iata && !byIata.has(o.iata)) byIata.set(o.iata, o);
      } catch (e) { stats.errors++; stats.lastError = String(e); }
    }
    function oaMap() {
      var st = pinStore('airports'); if (!st || !oaRows || !Array.isArray(oaBase) || oaBase.length < 100) return;   // (FR24's own list not in yet)
      var v = pbOn() ? { z: 0 } : oaView(), open = oaOpenRow(), key = '', pick = [];
      if (!v) { if (!open) return; v = { z: 0 }; }
      if (v.z >= 7.95) {
        var la = v.la, lo = v.lo, km = 600 / Math.pow(2, Math.max(8, v.z) - 7), cosL = Math.cos(la * Math.PI / 180), dLa = km / 111.2, dLo = km / (111.2 * Math.max(0.05, cosL));
        key = la.toFixed(2) + ',' + lo.toFixed(2) + '/' + Math.round(v.z);
      }
      if (open) key += '+' + open[0];
      if (key === oaShown) return;
      if (v.z >= 7.95) {
        oaRows.forEach(function (r) { var a = r[6] - la, o = r[7] - lo; if (o > 180) o -= 360; if (o < -180) o += 360; if (Math.abs(a) <= dLa && Math.abs(o) <= dLo && !oaDupe(r)) pick.push([a * a + o * o * cosL * cosL, r]); });
        pick.sort(function (x, y) { return x[0] - y[0]; }); pick = pick.slice(0, 400);
      }
      if (open && !pick.some(function (x) { return x[1] === open; })) pick.push([0, open]);
      oaShown = key;
      // (FR24's own object of the airport where its store has it - the list it was given had it - else one of that shape)
      var byId = st.airportsById && typeof st.airportsById.get === 'function' ? st.airportsById : null;
      var add = pick.map(function (x) { var own = byId && byId.get(x[1][0]); return own && isFinite(own.latitude) ? own : oaStoreRow(x[1]); });
      add.forEach(function (o) { oaStoreKeep(st, o); });
      try { st.airports = add.length ? oaBase.concat(add) : oaBase; } catch (e) { stats.errors++; stats.lastError = String(e); }
    }
    setInterval(function () { if (oaRows && oaBase) oaMap(); }, 1000);
    // (1.3.7: FR24's build of mid-November asks for its airports at /api/v2/airports - the same list, { version, rows },
    // the same rows; its ICAO-only airports kept in it now)
    var LIST_RE = /\/mobile\/(?:airlines\?format=2|airports\/format\/4)\b|\/api\/v\d+\/airports(?:$|[?#])/;
    function listFetch(self, args, url) {
      var kind = /airlines/.test(url) ? 'airlines' : 'airports', a = [].slice.call(args);
      // (a list FR24 takes to be up to date, while what is added to it is not: the whole list asked for)
      if (lsGet('tl.list.' + kind) !== listSig(kind) && /[?&]version=[1-9]/.test(url)) a[0] = url.replace(/([?&]version=)\d+/, '$10');
      // (1.3: the OurAirports airports on their way from the userscript - waited for, 4 s at most, so FR24 keeps them in)
      var ready = kind === 'airports' && !oaRows && lsGet('tl.oa.sig') ? new Promise(function (res) { oaWait.push(res); setTimeout(res, 4000); }) : null;
      return Promise.resolve(ready).then(function () { return oFetch.apply(self, a); }).then(function (res) {
        if (!res.ok) return res;
        return res.clone().json().then(function (j) { return patchList(kind, j) ? jsonResponse(res, j) : res; }, function () { return res; });
      });
    }
    // ---- FR24's airport routes page: an Inertia page, its lists (busiest, longest, all routes, the map's) in the page's
    // own state. The routes the userscript counted for its blocked aircraft are added there - FR24's count of a route it
    // has too is raised by theirs; a route it has not is listed beside its own - and FR24 draws them itself.
    var routesAdd = new Map();
    function routeEntry(m, extra) { return Object.assign({ id: (m.from.iata || m.from.icao || m.from.id) + '-' + (m.to.iata || m.to.icao || m.to.id), origin: m.from, destination: m.to, flights: m.n }, extra || {}); }
    function mergeRoutes(arr, mine, key, keep) {
      var base = (arr || []).filter(function (r) { return r && !r.__tlOnly; }).map(function (r) { var o = Object.assign({}, r); if (o.__tlBase != null) { o.flights = o.__tlBase; delete o.__tlBase; } return o; });
      var own = base.length, byId = {}; base.forEach(function (r) { byId[r.id] = r; });
      mine.forEach(function (m) { var r = byId[m.id]; if (r) { r.__tlBase = r.flights; r.flights = (r.flights || 0) + m.flights; } else base.push(Object.assign({ __tlOnly: true }, m)); });
      if (key) base.sort(function (a, b) { return (b[key] || 0) - (a[key] || 0); });
      return keep ? base.slice(0, Math.max(own, Math.min(keep, base.length))) : base;
    }
    function applyRoutes(pg) {
      var p = pg.props, ap = p.airport, add = routesAdd.get(ap.id); if (!add || !add.length) return;
      var sig = hashStr(JSON.stringify(add)) + ':' + add.length;
      var mine = add.filter(function (m) { return p.direction === 'to' ? m.to.id === ap.id : m.from.id === ap.id; });
      var strip = function (o) { var c = Object.assign({}, o); delete c.size; return c; };
      var listed = mine.map(function (m) { return routeEntry({ from: strip(m.from), to: strip(m.to), n: m.n }, { distanceKm: m.km }); });
      if (!(p.busiestRoutes && p.busiestRoutes.__tl === sig)) { var bu = mergeRoutes(p.busiestRoutes, listed, 'flights', 6); bu.__tl = sig; p.busiestRoutes = bu; }
      if (!(p.longestRoutes && p.longestRoutes.__tl === sig)) { var lo = mergeRoutes(p.longestRoutes, listed, 'distanceKm', 6); lo.__tl = sig; p.longestRoutes = lo; }
      if (p.routes && p.routes.current_page === 1 && p.routes.__tl !== sig) {
        var all = mergeRoutes(p.routes.data, mine.map(function (m) { return routeEntry({ from: strip(m.from), to: strip(m.to), n: m.n }, { distanceKm: m.km, averageFlightTimeMinutes: m.min }); }), 'flights', 0);
        var added = all.filter(function (r) { return r.__tlOnly; }).length - (p.routes.data || []).filter(function (r) { return r && r.__tlOnly; }).length;
        p.routes = Object.assign({}, p.routes, { data: all, total: (p.routes.total || 0) + added, to: (p.routes.to || 0) + added, __tl: sig });
      }
      if (!(p.mapRoutes && p.mapRoutes.__tl === sig)) { var mp = mergeRoutes(p.mapRoutes, add.map(function (m) { return routeEntry(m); }), '', 0); mp.__tl = sig; p.mapRoutes = mp; }
    }
    // ---- FR24's other airport data pages: general, arrivals / departures, statistics. What the userscript knows of the
    // airport goes into the page's own state - the flights of its boards (kept, and those the map tab follows now), the
    // week's movements of blocked aircraft in its statistics, its runways where FR24 shows a locked sample table - and the
    // last answer for an airport is kept, so a page opened again has it from its first draw.
    var apData = new Map(), servedMem = {};
    function inertiaPage() { try { var el = document.getElementById('app'), va = el && el.__vue_app__, pg = va && va.config.globalProperties.$page; return pg && pg.props && pg.props.airport ? pg : null; } catch (e) { return null; } }
    function apDataOf(apId) { var d = apData.get(apId); if (!d) { try { d = JSON.parse(lsGet('tl.ap.' + apId) || 'null'); } catch (e) { d = null; } d = d || {}; apData.set(apId, d); if (d.routes && !routesAdd.has(apId)) routesAdd.set(apId, d.routes); } return d; }
    function keepApData(apId) { var d = apDataOf(apId), r = routesAdd.get(apId); lsSet('tl.ap.' + apId, JSON.stringify({ runways: d.runways || null, routes: r || null, stats: d.stats || null, closest: d.closest || null, at: Date.now() })); }
    // (the airports and countries FR24 itself counts as served: the ends of its own routes of the week, read once)
    function servedOf(pg) {
      var ap = pg.props.airport, code = String(ap.iata || ap.icao || '').toLowerCase(); if (servedMem[code]) return servedMem[code].ids ? servedMem[code] : null;
      if (ap.id >= 1e7) { servedMem[code] = { ids: {}, cs: {} }; return servedMem[code]; }   // (1.3.1: an OurAirports airport - FR24 has no routes of it to read)
      servedMem[code] = {};
      oFetch.call(window, '/data/airports/' + code + '/routes', { credentials: 'same-origin', headers: { 'X-Inertia': 'true', 'X-Inertia-Version': pg.version, 'X-Inertia-Partial-Component': 'Data/AirportRoutes', 'X-Inertia-Partial-Data': 'mapRoutes', 'X-Requested-With': 'XMLHttpRequest', Accept: 'text/html, application/xhtml+xml' } })
        .then(function (r) { return r.json(); }).then(function (j) { var ids = {}, cs = {}; ((j.props && j.props.mapRoutes) || []).forEach(function (m) { [m.origin, m.destination].forEach(function (a) { if (a && a.id !== ap.id) { ids[a.id] = 1; cs[a.countryId] = 1; } }); }); servedMem[code] = { ids: ids, cs: cs }; })
        .catch(function () { servedMem[code] = { ids: {}, cs: {} }; });
      return null;
    }
    // what the week's blocked flights add: landings, take-offs, airports and countries FR24 does not count
    function weekAdds(pg) {
      var apId = pg.props.airport.id, list = routesAdd.get(apId) || [], sv = servedOf(pg), out = { land: 0, off: 0, aps: {}, cs: {}, top: {} };
      list.forEach(function (m) {
        var other = m.from.id === apId ? m.to : m.from; if (m.to.id === apId) out.land += m.n; if (m.from.id === apId) { out.off += m.n; out.top[other.id] = (out.top[other.id] || 0) + m.n; }
        if (sv && !sv.ids[other.id]) out.aps[other.id] = other; if (sv && !sv.cs[other.countryId]) out.cs[other.countryId] = 1;
      });
      out.ready = !!sv; return out;
    }
    // ---- runways: FR24's own airport answer carries every runway - name, length, surface - for free accounts too (it only
    // shows them to subscribers): kept per airport code (a month in this browser), for the map panel's "Runway details" and
    // the airport pages' runway tables - each end's elevation from the userscript's OurAirports list where it has it
    var rwyByCode = {}, rwyAsked = {};
    function rwyKey(c) { return String(c || '').toUpperCase(); }
    function noteAirportJson(j) {
      var ap = j && j.result && j.result.response && j.result.response.airport, pd = ap && ap.pluginData, c = pd && pd.details && pd.details.code;
      if (!c || !Array.isArray(pd.runways)) return;
      var list = pd.runways.map(function (r) { return { name: String(r.name || ''), ft: r.length && r.length.ft, m: r.length && r.length.m, surf: (r.surface && r.surface.name) || '', code: (r.surface && r.surface.code) || '' }; }).filter(function (r) { return r.name; });
      [c.iata, c.icao].forEach(function (k) { if (k) { rwyByCode[rwyKey(k)] = list; lsSet('tl.rw.' + rwyKey(k), JSON.stringify({ at: Date.now(), list: list })); } });
      rwyPanel();
    }
    function rwyOf(code) { var k = rwyKey(code); if (!k) return null; if (rwyByCode[k]) return rwyByCode[k]; try { var v = JSON.parse(lsGet('tl.rw.' + k) || 'null'); if (v && Array.isArray(v.list) && Date.now() - v.at < 30 * 864e5) return (rwyByCode[k] = v.list); } catch (e) { /* none kept */ } return null; }
    function rwyWant(code) {
      var k = rwyKey(code); if (!k || rwyOf(k) || rwyAsked[k]) return; rwyAsked[k] = true;
      oFetch.call(window, 'https://api.flightradar24.com/common/v1/airport.json?code=' + encodeURIComponent(k.toLowerCase()) + '&plugin[]=details&plugin[]=runways').then(function (r) { return r.json(); }).then(function (j) { noteAirportJson(j); routesTick(); }, function () { rwyAsked[k] = false; });
    }
    // the map's airport panel: FR24's "Runway details" upsell picture gives way to the table of the airport open now - every
    // runway in full where the monitor has it (OurAirports: width, lighting, each end's heading, elevation and displaced
    // threshold) and the airport's radio frequencies, else FR24's own runway list - redrawn when another is opened (the
    // picture stays in its place, hidden, for FR24's own redraws)
    var SURF_NAME = { ASPH: 'Asphalt', BITU: 'Bitumen', CONC: 'Concrete', TARM: 'Tarmac', GRAS: 'Grass', TURF: 'Turf', GRVL: 'Gravel', DIRT: 'Dirt', SAND: 'Sand', CLAY: 'Clay', WATE: 'Water', SNOW: 'Snow', ICE: 'Ice', MATS: 'Mats', LATE: 'Laterite', CORL: 'Coral', UNPV: 'Unpaved', UNKN: 'Unknown' };
    // (the airport the page is on: FR24's address is /airport/<its id>/<code> now - /airport/2002/lpl - and was /airport/<code>:
    // the id read as the code, "2002", left the panel's runway details and usage locked, its data asked for an airport that
    // does not exist)
    // (1.3: an OurAirports airport's code too - OurAirports' own idents run to "GB-0123")
    function panelCode() {
      try { if (document.querySelector('[data-testid="airport-panel"]')) { var st = pinStore('airports'), inf = st && st.airport && st.airport.info; if (inf && inf.iata) return rwyKey(inf.iata); } } catch (e) { /* by the address */ }
      var m = location.pathname.match(/^\/airport\/(?:\d+\/)?([a-z0-9]{3,4}|[a-z0-9]{2,3}-[a-z0-9]{2,5})(?:[/?#]|$)/i); return m && !/^\d+$/.test(m[1]) ? rwyKey(m[1]) : ''; }
    function tlTable(box, head, rows, title) {
      var cell = 'px-1.5 py-1', tb = document.createElement('table'); tb.className = 'w-full';
      if (title) { var cap = document.createElement('caption'); cap.className = 'px-1.5 pt-2 pb-1 text-left text-xs font-semibold uppercase text-gray-900'; cap.textContent = title; tb.appendChild(cap); }
      var row = function (cls, tag, vals) { var tr = document.createElement('tr'); tr.className = cls; vals.forEach(function (v) { var c = document.createElement(tag); c.className = cell + (tag === 'th' ? ' text-left font-semibold' : ''); c.textContent = v == null || v === '' ? '–' : String(v); tr.appendChild(c); }); tb.appendChild(tr); };
      row('text-xs font-semibold uppercase text-gray-900', 'th', head);
      rows.forEach(function (v) { row('border-t border-gray-500 text-sm font-semibold text-gray-1300', 'td', v); });
      box.appendChild(tb);
    }
    // (1.3.4) a heliport with no runway of its own: said so - a helipad (its name says so), or a heliport no pad of which
    // is known
    function heliText(pd, code) {
      var r = code ? oaByCode.get(code.toLowerCase()) : null, kind = (pd && pd.kind) || (r ? r[9] : ''), name = (pd && pd.name) || (r ? r[3] : '');
      if (kind !== 'H' && !/\bheli(pad|port)\b/i.test(name)) return '';
      return /helipad/i.test(name) || kind !== 'H' ? 'This is a helipad: it has no runways.' : 'This is a heliport: it has no runways, and none of its pads\' details are known.';
    }
    function rwyPanel() {
      var pic = document.querySelector('[data-testid="airport-panel__promo-runway_details"]'), box = pic && (pic.closest('button') || pic);
      var old = document.querySelectorAll('.tl-rwy'); for (var i = 0; i < old.length; i++) if (!box || old[i].previousElementSibling !== box) old[i].remove();
      if (!box) return;
      var code = panelCode(), list = code ? rwyOf(code) : null, pd = code ? panelData[code] : null;
      var ours = pd && pd.runways && pd.runways.length ? pd.runways : null, freqs = pd && pd.freqs && pd.freqs.length ? pd.freqs : null, ends = pd && pd.ends && pd.ends.length ? pd.ends : null;
      var mine = box.nextElementSibling && box.nextElementSibling.classList.contains('tl-rwy') ? box.nextElementSibling : null;
      if (code) panelWant(code);
      // (1.3.2: FR24's own answer asked for only where FR24 has the airport; and with nothing known of its runways - yet,
      // or at all - that is said in the table's place: FR24's padlocked picture is never left there. 1.3.1 left it for
      // every airport the monitor knew no runway of - every OurAirports one)
      var isOa = !!(code && oaByCode.get(code.toLowerCase())), none = !ours && !(list && list.length) && !ends, pads = pd && pd.pads && pd.pads.length ? pd.pads : null;
      if (code && !isOa) rwyWant(code);
      // (asked for a quarter of a minute and nothing said: none known)
      var waited = !pd && !(panelOpen.code === code && Date.now() - panelOpen.at < 15000);
      var sig = code + ':' + (none ? (pads ? 'p' + pads.length : pd || waited ? 'none' : 'wait') : ours ? 'o' + ours.length + ':' + (freqs ? freqs.length : 0) : list && list.length ? 'f' + list.length : 'e' + ends.length);
      if (mine && mine.getAttribute('data-sig') === sig) return;
      if (!mine) { mine = document.createElement('div'); box.after(mine); }
      mine.className = 'tl-rwy w-full overflow-hidden rounded border border-gray-500 bg-gray-100'; mine.setAttribute('data-code', code); mine.setAttribute('data-sig', sig); mine.textContent = '';
      var n = function (v) { return fin(v) ? Number(v).toLocaleString('en-GB') : '–'; }, m = function (ft) { return fin(ft) ? Math.round(ft * 0.3048) : null; };
      if (none && pads) tlTable(mine, ['Helipad', 'Size (m)', 'Surface', 'Lights'], pads.map(function (p) { return [p[0] + (p[6] ? ' (closed)' : ''), fin(p[1]) || fin(p[2]) ? n(m(p[1])) + ' × ' + n(m(p[2])) : '–', SURF_NAME[p[3]] || p[4] || 'Unknown', p[5] === 1 ? 'Yes' : p[5] === 0 ? 'No' : '–']; }), 'Helipads');
      else if (none) { var np = document.createElement('div'); np.className = 'px-1.5 py-2 text-sm text-gray-900'; np.textContent = !(pd || waited) ? 'Reading this airport\'s runways…' : heliText(pd, code) || 'Runway details not available.'; mine.appendChild(np); }
      else if (ours) {
        // [ident, other end, length ft, width ft, surface code, surface, lit, closed, then each end: elevation, heading, displaced threshold, lat, lon]
        tlTable(mine, ['Runway', 'Length (m/ft)', 'Width (m)', 'Surface', 'Lights'], ours.map(function (r) { return [r[0] + (r[1] ? '/' + r[1] : '') + (r[7] ? ' (closed)' : ''), n(m(r[2])) + '/' + n(r[2]), n(m(r[3])), SURF_NAME[r[4]] || r[5] || 'Unknown', r[6] === 1 ? 'Yes' : r[6] === 0 ? 'No' : '–']; }));
        var er = []; ours.forEach(function (r) { if (r[7]) return; [[r[0], 8], [r[1], 13]].forEach(function (e) { if (!e[0]) return; var b = e[1]; er.push([e[0], fin(r[b + 1]) ? Math.round(r[b + 1]) + '°' : '', fin(r[b]) ? n(r[b]) + ' ft' : '', r[b + 2] > 0 ? n(r[b + 2]) + ' ft' : 'None']); }); });
        if (er.length) tlTable(mine, ['End', 'Heading (true)', 'Elevation', 'Displaced threshold'], er, 'Runway ends');
        if (freqs) tlTable(mine, ['Type', 'Name', 'MHz'], freqs.map(function (f) { return [f[0], f[1], fin(f[2]) ? f[2].toFixed(3) : '']; }), 'Radio frequencies');
      } else if (list && list.length) tlTable(mine, ['Runway', 'Length (m/ft)', 'Surface'], list.map(function (r) { return [r.name, n(r.m) + '/' + n(r.ft), r.surf || 'Unknown']; }));
      else tlTable(mine, ['Runway end', 'Length (m/ft)', 'Elevation', 'Surface'], ends.map(function (e) { return [e.name, n(m(e.lengthFt)) + '/' + n(e.lengthFt), fin(e.elevationFt) ? n(e.elevationFt) + ' ft' : '', SURF_NAME[e.surface] || 'Unknown']; }));
      box.style.display = 'none';
    }
    // ---- the rest of the map's airport panel ------------------------------------------------------------------------
    // FR24's locked pictures "Movements per day" and "Runway usage" give way to the real thing: the airport's take-offs and
    // landings of each of the last days (FR24's own schedule, counted as on its statistics page, the week's blocked flights
    // the userscript knows on top) and the runways the flights the monitor tracked there used (each one's take-off and
    // landing worked out from its track). Its "Latest events" and the plea to help its ground coverage are taken out.
    // Found by what FR24 names them or by what they say - FR24 redraws its panel, so it is done again each time.
    var panelData = {}, panelAskedAt = {}, panelOpen = { code: '', at: 0 }, panelSigs = {};
    var PANEL_TITLES = ['Latest events', 'Airport statistics', 'Airport movements', 'Movements per day', 'Runway usage', 'Airport & runway details', 'Runway details', 'Weather', 'Busiest routes'];
    function panelWant(code) { if (Date.now() - (panelAskedAt[code] || 0) > 120000) { panelAskedAt[code] = Date.now(); post('needAirportPanel', { code: code }); } }
    function textOf(el) { return String((el && el.textContent) || '').replace(/\s+/g, ' ').trim(); }
    // (the innermost elements saying this)
    // (1.1.4: never inside a flight's row of a board - nothing looked for is ever in one; a board of a fortnight is most of
    // the panel, and every row's every word read again each time the panel changed held the page for minutes)
    var ROW_ID = 'airport_schedule_', ROW_TESTID = 'airport-panel__schedules__flight__';
    // (a flight's row: its list item, or - should FR24 draw them otherwise - the box its test id marks)
    var isRow = function (n) { if (n.id && n.id.lastIndexOf(ROW_ID, 0) === 0) return true; var t = n.getAttribute && n.getAttribute('data-testid'); return !!t && t.lastIndexOf(ROW_TESTID, 0) === 0; };
    var skipRows = { acceptNode: function (n) { return n.nodeType === 3 ? NodeFilter.FILTER_ACCEPT : isRow(n) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_SKIP; } };
    var sizeRows = { acceptNode: function (n) { return n.nodeType === 1 && isRow(n) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; } };
    function saying(root, re) {
      if (root && root.nodeType === 1 && isRow(root)) return [];
      var out = [], w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, skipRows), t;
      while ((t = w.nextNode())) { var v = String(t.nodeValue || '').replace(/\s+/g, ' ').trim(); if (v && v.length < 160 && re.test(v)) { var e = t.parentElement; if (e && !e.closest('.tl-panel, .tl-rwy') && out.indexOf(e) < 0) out.push(e); } }
      return out;
    }
    // (the part of the panel a title heads: up from it while the part above holds no other part's title, nor FR24's tabs
    // or boards - and small, an events list or a notice, not half the panel)
    function partOf(el, panel, title, maxLen) {
      var cur = el;
      while (cur.parentElement && cur.parentElement !== panel) {
        var up = cur.parentElement, t = textOf(up), other = false;
        for (var i = 0; i < PANEL_TITLES.length; i++) if (PANEL_TITLES[i] !== title && t.indexOf(PANEL_TITLES[i]) >= 0) { other = true; break; }
        if (other || t.length > maxLen || up.querySelector('[data-testid^="airport-panel__tab"], [data-testid^="airport-panel__schedules"], [data-testid^="airport-panel__promo-"], .tl-panel, .tl-rwy')) break;
        cur = up;
      }
      return cur;
    }
    // (kept hidden when FR24 rewrites the element's style)
    function tlHide(el) { if (el && (el.style.getPropertyValue('display') !== 'none' || el.style.getPropertyPriority('display') !== 'important' || !el.hasAttribute('data-tl-hidden'))) { el.style.setProperty('display', 'none', 'important'); el.setAttribute('data-tl-hidden', '1'); } }
    // (what is left of a part once it is hidden - the box it sat in, its border and padding, nothing in it to see: the thin
    // empty bar under "Disruptions" where the events were - goes too, up to the panel, while nothing in it is seen. Seen:
    // words, or a picture, icon or field drawn with a size, outside anything hidden. An empty box FR24 keeps beside the
    // hidden part - its body, a spacer - counts for nothing: it was what left the bar standing)
    var SEEN_TAGS = { IMG: 1, PICTURE: 1, VIDEO: 1, CANVAS: 1, IFRAME: 1, svg: 1, SVG: 1, INPUT: 1, SELECT: 1, TEXTAREA: 1 };
    function sized(el) { try { var r = el.getBoundingClientRect(); return r.width > 1 && r.height > 1; } catch (e) { return false; } }
    function blankBox(box) {
      if (/^(SCRIPT|STYLE|TEMPLATE)$/.test(box.tagName)) return false;
      if (box.matches('.tl-panel, .tl-rwy') || box.querySelector('.tl-panel, .tl-rwy')) return false;
      var seen = false, cs0 = null;
      try { cs0 = getComputedStyle(box); } catch (e) { /* none */ }
      if (cs0 && cs0.backgroundImage && cs0.backgroundImage !== 'none' && sized(box)) return false;
      var w = document.createTreeWalker(box, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, { acceptNode: function (n) {
        if (n.nodeType === 3) { if (/\S/.test(n.nodeValue || '')) seen = true; return seen ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP; }
        if (n.hasAttribute('data-tl-hidden') || /^(SCRIPT|STYLE|TEMPLATE)$/.test(n.tagName)) return NodeFilter.FILTER_REJECT;
        var cs = null; try { cs = getComputedStyle(n); } catch (e) { /* none */ }
        if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) return NodeFilter.FILTER_REJECT;
        if ((SEEN_TAGS[n.tagName] || (cs && cs.backgroundImage && cs.backgroundImage !== 'none')) && sized(n)) seen = true;
        return seen ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      } });
      w.nextNode();
      return !seen;
    }
    function hideShell(el, panel) {
      for (var cur = el; cur && cur.parentElement && cur.parentElement !== panel && cur.parentElement !== document.body; cur = cur.parentElement) {
        var up = cur.parentElement;
        if (!blankBox(up)) return;
        tlHide(up);
      }
    }
    // (and any box in the panel's list of dropdowns - Disruptions, the events, statistics, details - with nothing in it to
    // see, or no words in it and no taller than a bar: the empty bar between Disruptions and Airport statistics. Hidden at
    // once, and back the moment FR24 puts something in it)
    var PART_RE = /^(disruptions|airport statistics|airport & runway details|airport and runway details)$/i, WX_RE = /^more weather & metar$/i;
    function commonBox(ts) {
      var a = ts[0];
      for (var i = 1; i < ts.length; i++) { while (a && !a.contains(ts[i])) a = a.parentElement; }
      return a;
    }
    function partsList(panel) {
      var ts = saying(panel, PART_RE); if (ts.length < 2) ts = ts.concat(saying(panel, WX_RE)); if (ts.length < 2) return null;
      var a = commonBox(ts);
      return a && a !== panel && panel.contains(a) && a.children.length > 1 ? a : a === panel ? panel : null;
    }
    function wordless(box) {
      if (box.matches('.tl-panel, .tl-rwy') || box.querySelector('.tl-panel, .tl-rwy')) return false;
      var w = document.createTreeWalker(box, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, { acceptNode: function (n) {
        if (n.nodeType === 3) return /\S/.test(n.nodeValue || '') ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
        if (n.hasAttribute('data-tl-hidden')) return NodeFilter.FILTER_REJECT;
        var cs = null; try { cs = getComputedStyle(n); } catch (e) { /* none */ }
        return cs && (cs.display === 'none' || cs.visibility === 'hidden') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_SKIP;
      } });
      return !w.nextNode();
    }
    function emptyPart(c) { return blankBox(c) || (wordless(c) && c.getBoundingClientRect().height < 32); }
    function blankParts(panel) {
      var list = partsList(panel); if (!list) return;
      for (var i = 0; i < list.children.length; i++) {
        var c = list.children[i];
        if (c.hasAttribute('data-tl-blank')) { c.style.removeProperty('display'); var back = !emptyPart(c); c.style.setProperty('display', 'none', 'important'); if (back) { c.style.removeProperty('display'); c.removeAttribute('data-tl-blank'); c.removeAttribute('data-tl-hidden'); } continue; }
        if (c.hasAttribute('data-tl-hidden') || /^(SCRIPT|STYLE|TEMPLATE)$/.test(c.tagName)) continue;
        if (emptyPart(c)) { tlHide(c); c.setAttribute('data-tl-blank', '1'); }
      }
    }
    // (once per change, after FR24 has done its part - and still before the browser paints)
    var blankDue = [];
    function blankSoon(panel) {
      if (blankDue.indexOf(panel) >= 0) return;
      blankDue.push(panel);
      if (blankDue.length === 1) Promise.resolve().then(function () { var l = blankDue; blankDue = []; l.forEach(function (p) { try { if (p.isConnected) blankParts(p); } catch (e) { stats.errors++; stats.lastError = String(e); } }); });
    }
    var EVENTS_RE = /^(latest|live) events$/i, BEG_RE = /help us improve|improve (our |the )?(ground )?coverage/i;
    // (words of a text node that something hidden here says - its title, the request, the button)
    function hideWords(t) { var v = String(t || '').replace(/\s+/g, ' ').trim(); return !!v && v.length < 160 && (EVENTS_RE.test(v) || BEG_RE.test(v) || ADS_RE.test(v) || PART_RE.test(v) || WX_RE.test(v)); }
    function hidePart(el, panel) { if (!el || el === panel) return; tlHide(el); hideShell(el, panel); }
    // (the events' own section - FR24 builds the panel of sections, the events' the one its title opens - whatever is in it)
    function firstText(el) {
      var w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT), t;
      while ((t = w.nextNode())) { var v = String(t.nodeValue || '').replace(/\s+/g, ' ').trim(); if (v) return v; }
      return '';
    }
    function eventsPart(e, panel) {
      var sec = e.closest('section');
      if (sec && sec !== panel && panel.contains(sec) && !sec.contains(panel) && EVENTS_RE.test(firstText(sec)) && !sec.querySelector('[data-testid^="airport-panel__tab"], [data-testid^="airport-panel__schedules"], [data-testid^="airport-panel__promo-"], .tl-panel, .tl-rwy')) return sec;
      return partOf(e, panel, 'Latest events', 4000);
    }
    function panelHide(panel, root) {
      root = root || panel;
      saying(root, EVENTS_RE).forEach(function (e) { hidePart(eventsPart(e, panel), panel); });
      saying(root, BEG_RE).forEach(function (e) { hidePart(partOf(e, panel, '', 600), panel); });
      saying(root, ADS_RE).forEach(function (e) { hideAd(e, panel); });
      blankSoon(panel);
    }
    // FR24's "Remove ads" button where an advert sat in a board's list (the advert itself hidden by the userscript's style),
    // and the empty slot around it: the button and every box that holds nothing else, and an advert's slot beside it, gone -
    // the list closes up as if neither were there. On the boards' own pages too.
    var ADS_RE = /^remove ads$/i, ADS_ONLY = /^((advert(isement)?|ads?|sponsored)\s*)*remove ads$/i;
    var AD_MARK = '[id^="pb-slot-fr24-"],[id^="div-gpt-ad-"],[data-pb-ad-wrapper],ins.adsbygoogle,.ad-manager-wrapper';
    function hideAd(el, stop) {
      var cur = el;
      while (cur.parentElement && cur.parentElement !== stop && cur.parentElement !== document.body && ADS_ONLY.test(textOf(cur.parentElement)) && !cur.parentElement.querySelector('.tl-panel, .tl-rwy')) cur = cur.parentElement;
      tlHide(cur);
      [cur.previousElementSibling, cur.nextElementSibling].forEach(function (x) { if (x && !textOf(x) && (x.matches(AD_MARK) || x.querySelector(AD_MARK))) tlHide(x); });
      hideShell(cur, stop || document.body);
    }
    // FR24 draws those two parts and the panel is painted before the next tick: they are taken out as they are put in -
    // a mutation observer's answer comes before the browser paints - so they are never seen, not even for a moment
    var hideMo = null;
    function hideWatch() {
      if (hideMo || typeof MutationObserver !== 'function' || !document.documentElement) return;
      var SEL_AP = '[data-testid="airport-panel"]';
      hideMo = new MutationObserver(function (recs) {
        var apSeen = null;
        for (var i = 0; i < recs.length; i++) {
          var r = recs[i], t = r.type === 'characterData' ? r.target.parentElement : r.target; if (!t || t.nodeType !== 1) continue;
          try {
            var panel = t.closest(SEL_AP);
            if (panel) apSeen = panel;
            if (panel) {
              if (r.type === 'characterData') { if (!t.closest('li[id^="airport_schedule_"]')) panelHide(panel, t); }
              // (1.1.2: not inside a flight's row of a board - none of what is hidden is ever in one, and a board of a fortnight
              // is thousands of rows, each looked through three times as FR24 drew it; its adverts sit between rows)
              // (1.1.5: a text put in is looked at only when its own words are what is hidden - the empty text nodes Vue puts
              // between a list's items had the whole board looked through for each one. Other words put in: the panel's empty
              // boxes looked at again, so that a box FR24 has filled since is shown)
              else for (var j = 0; j < r.addedNodes.length; j++) {
                var a = r.addedNodes[j];
                if (a.nodeType === 3) { var ap = a.parentElement; if (ap && /\S/.test(a.data || '') && !ap.closest('li[id^="airport_schedule_"]')) { if (hideWords(a.data)) panelHide(panel, ap); else blankSoon(panel); } continue; }
                if (a.nodeType === 1 && !a.closest('li[id^="airport_schedule_"]')) panelHide(panel, a);
              }
            } else if (r.type === 'childList') {
              // (the panel itself put in, whole; elsewhere - a board's own page - the "Remove ads" button)
              for (var k = 0; k < r.addedNodes.length; k++) {
                var n = r.addedNodes[k], ne = n.nodeType === 1 ? n : n.nodeType === 3 ? n.parentElement : null; if (!ne) continue;
                // (1.1.5: the panel put in is an element that is it or holds it - a text put in never is: an empty text node
                // Vue puts in high up the page, under a box that holds the panel, had the whole panel - and its board of a
                // fortnight - looked through three times for each one, half a minute of a frozen page)
                var p = n.nodeType === 1 ? (n.matches(SEL_AP) ? n : n.querySelector(SEL_AP)) : null; if (p) { panelHide(p); apSeen = p; }
                if (/remove ads/i.test(n.nodeType === 3 ? n.data || '' : n.textContent || '')) saying(ne, ADS_RE).forEach(function (e) { if (!e.closest(SEL_AP)) hideAd(e, null); });
              }
            } else if (ADS_RE.test(textOf(t))) hideAd(t, null);
          } catch (e) { stats.errors++; stats.lastError = String(e); }
        }
        // (1.2.11: the runway in use built into the panel as FR24 draws its weather - before the browser paints, so the
        // panel opens with it, not a moment after)
        if (apSeen) { try { rwyUseInline(apSeen); } catch (e) { stats.errors++; stats.lastError = String(e); } }
        // (1.3: the aircraft panel's vertical speed never a padlock - before the browser paints it)
        try { var acp = document.querySelector('[data-testid="aircraft-panel"]'); if (acp) vsNoLock(acp); } catch (e) { stats.errors++; stats.lastError = String(e); }
      });
      hideMo.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    }
    hideWatch();
    if (!hideMo) document.addEventListener('DOMContentLoaded', hideWatch, { once: true });
    // (1.3) The aircraft panel's vertical speed: FR24 draws its padlock wherever it is given no figure - a free account's
    // panel always, a figure being something only a value can say (protobuf has no "none"). The figure worked out here
    // (public ADS-B, else FR24's own altitudes: vrF in the panel's stream) is put in FR24's own answer; where there is none
    // - low coverage, the flight's first seconds - its padlock is never seen: "N/A" in its place, put in as FR24 draws it,
    // before the browser paints. A figure in the cell after all (FR24's, or the userscript's own) and it goes.
    var VS_TITLE = /ascending or descending/i;
    function vsNoLock(panel) {
      var labels = panel.querySelectorAll('div[title] > p:first-child');
      for (var i = 0; i < labels.length; i++) {
        var lab = labels[i]; if (!/^vertical speed$/i.test(textOf(lab))) continue;
        var cell = lab.parentElement, lock = null, mine = cell.querySelector(':scope > .tl-vsna');
        for (var c = cell.firstElementChild; c; c = c.nextElementSibling) if (c !== lab && c.tagName !== 'P' && c.querySelector('svg') && !c.querySelector('p') && !textOf(c)) { lock = c; break; }
        var filled = cell.querySelector(':scope > .tl-filled');
        if (lock && !filled) {
          if (!lock.hasAttribute('data-tl-vsna')) { lock.setAttribute('data-tl-vsna', ''); lock.style.setProperty('display', 'none', 'important'); }
          if (!mine) { mine = document.createElement('p'); mine.className = 'text-md leading-tight text-gray-1300 tl-vsna'; mine.textContent = 'N/A'; mine.title = 'No vertical speed: no receiver reports it now, and none can be worked out from the altitudes yet (LADD unblocker)'; lock.insertAdjacentElement('afterend', mine); }
        } else {
          if (mine) mine.remove();
          // (the userscript's own figure beside FR24's padlock: the padlock stays put away)
          if (lock && filled) continue;
          if (lock && lock.hasAttribute('data-tl-vsna')) { lock.removeAttribute('data-tl-vsna'); lock.style.removeProperty('display'); }
        }
        if (VS_TITLE.test(cell.getAttribute('title') || '')) break;
      }
    }
    // (FR24's locked pictures: by their name, else by the title they sit under)
    function kindNear(el, panel) {
      var img = el.matches('img') ? el : el.querySelector('img[alt]'), alt = img ? String(img.getAttribute('alt') || '') : '';
      if (/movements per day/i.test(alt)) return 'moves'; if (/runway usage/i.test(alt)) return 'usage';
      for (var cur = el, i = 0; i < 4 && cur && cur !== panel; i++, cur = cur.parentElement) { var t = textOf(cur), a = /movements per day/i.test(t), b = /runway usage/i.test(t); if (a !== b) return a ? 'moves' : 'usage'; }
      return '';
    }
    function lockedAfter(h, panel) {
      for (var cur = h, up = 0; up < 3 && cur && cur !== panel; up++, cur = cur.parentElement) {
        var sib = cur.nextElementSibling; while (sib && sib.classList.contains('tl-panel')) sib = sib.nextElementSibling;
        if (sib && (sib.matches('picture, img, button') || sib.querySelector('picture, img'))) return sib;
      }
      return null;
    }
    function promoSlots(panel) {
      var out = [], have = {}, ps = panel.querySelectorAll('[data-testid^="airport-panel__promo-"]');
      for (var i = 0; i < ps.length; i++) {
        var id = ps[i].getAttribute('data-testid') || ''; if (/runway[_-]?details/i.test(id)) continue;
        var kind = /movement/i.test(id) ? 'moves' : /usage/i.test(id) ? 'usage' : kindNear(ps[i], panel); if (!kind || have[kind]) continue;
        var box = ps[i].closest('button') || ps[i]; if (!panel.contains(box)) box = ps[i];
        out.push({ kind: kind, box: box }); have[kind] = 1;
      }
      [['moves', /^movements per day$/i], ['usage', /^runway usage$/i]].forEach(function (k) {
        if (have[k[0]]) return;
        var hs = saying(panel, k[1]); for (var j = 0; j < hs.length; j++) { var b = lockedAfter(hs[j], panel); if (b) { out.push({ kind: k[0], box: b }); have[k[0]] = 1; break; } }
      });
      return out;
    }
    // (the movements of each of the last days: from the monitor - 1.1.0 - every day its own, the same for everyone: the more
    // of every aircraft public ADS-B heard there and FR24's own rows of its board (Portimao, out of the receivers' reach);
    // without it, FR24's own counts read here and the blocked flights the userscript knows)
    function panelMoves(code, d) {
      var c = code.toLowerCase(), tz = d.tz || 'UTC', today = dayOf(Date.now() / 1000, tz), utcToday = new Date().toISOString().slice(0, 10);
      var mon = (Array.isArray(d.daily) ? d.daily : []).filter(function (x) { return Array.isArray(x) && /^\d{4}-\d\d-\d\d$/.test(String(x[0])) && (x[3] === 'all' || x[3] === 'live'); });
      if (d.monitor && mon.length) return mon.slice().sort(function (a, b) { return String(b[0]).localeCompare(String(a[0])); }).slice(0, 7).map(function (x) { return { day: x[0], today: x[0] === utcToday, off: +x[1] || 0, on: +x[2] || 0, blocked: 0, all: true, fr24: !!x[4] }; });
      var days = mvKept(c).days || {}, add = {}, inc = function (t, k) { var x = dayOf(t, tz); (add[x] = add[x] || { off: 0, on: 0 })[k]++; };
      (routesAdd.get(d.apId) || []).forEach(function (m) { if (m.from.id === d.apId) (m.offs || []).forEach(function (t) { inc(t, 'off'); }); if (m.to.id === d.apId) (m.ons || []).forEach(function (t) { inc(t, 'on'); }); });
      return Object.keys(days).sort().reverse().slice(0, 7).map(function (k) {
        var x = days[k], e = add[k] || { off: 0, on: 0 }; return { day: k, today: k === today, off: x.takeoffs + e.off, on: x.landings + e.on, blocked: e.off + e.on };
      });
    }
    var TL_OFF = '#3d7be0', TL_ON = '#f0b429';
    function bar(parts, max) {
      var b = document.createElement('div'); b.style.cssText = 'display:flex;height:10px;border-radius:2px;overflow:hidden;background:rgba(127,127,127,.15);min-width:60px';
      parts.forEach(function (p) { var s = document.createElement('div'); s.style.cssText = 'height:100%;background:' + p[1] + ';width:' + (max > 0 ? (100 * p[0] / max).toFixed(1) : 0) + '%'; b.appendChild(s); });
      return b;
    }
    function legend(box, note) {
      var l = document.createElement('div'); l.className = 'px-1.5 pb-1.5 pt-1 text-xs text-gray-900';
      [['Take-offs', TL_OFF], ['Landings', TL_ON]].forEach(function (x) { var s = document.createElement('span'); s.style.cssText = 'display:inline-flex;align-items:center;margin-right:10px'; var dot = document.createElement('span'); dot.style.cssText = 'display:inline-block;width:8px;height:8px;border-radius:2px;margin-right:4px;background:' + x[1]; s.appendChild(dot); s.appendChild(document.createTextNode(x[0])); l.appendChild(s); });
      if (note) { var nn = document.createElement('div'); nn.className = 'pt-1'; nn.textContent = note; l.appendChild(nn); }
      box.appendChild(l);
    }
    function grid(box, rows, max) {
      var tb = document.createElement('table'); tb.className = 'w-full';
      rows.forEach(function (r) {
        var tr = document.createElement('tr'); tr.className = 'border-t border-gray-500 text-sm font-semibold text-gray-1300';
        var a = document.createElement('td'); a.className = 'px-1.5 py-1 whitespace-nowrap'; a.textContent = r.label; tr.appendChild(a);
        var b = document.createElement('td'); b.className = 'px-1.5 py-1 w-full'; b.appendChild(bar([[r.off, TL_OFF], [r.on, TL_ON]], max)); tr.appendChild(b);
        var c = document.createElement('td'); c.className = 'px-1.5 py-1 whitespace-nowrap text-right'; c.textContent = r.off + ' / ' + r.on; tr.appendChild(c);
        tb.appendChild(tr);
      });
      box.appendChild(tb);
    }
    function dayLabel(d) { try { return new Date(d + 'T12:00:00Z').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' }); } catch (e) { return d; } }
    function movesBlock(box, code, d) {
      var rows = panelMoves(code, d);
      if (!rows.length) { var p = document.createElement('div'); p.className = 'px-1.5 py-2 text-sm text-gray-900'; p.textContent = 'Counting this airport\'s flights of the last days…'; box.appendChild(p); return 'none'; }
      var max = Math.max.apply(null, rows.map(function (r) { return r.off + r.on; }));
      grid(box, rows.map(function (r) { return { label: dayLabel(r.day) + (r.today ? ' (so far)' : ''), off: r.off, on: r.on }; }), max);
      var bl = rows.reduce(function (s, r) { return s + r.blocked; }, 0), all = rows.filter(function (r) { return r.all; }).length;
      legend(box, all === rows.length ? 'Take-offs / landings each day (UTC), counted by the monitor: every aircraft public ADS-B heard there - or FR24\'s own flights of the airport, with the blocked ones it does not show, where that is more.'
        : 'Take-offs / landings by the airport\'s local day - FR24\'s own schedule' + (bl ? ', with ' + bl + ' blocked flight' + (bl > 1 ? 's' : '') + ' it does not show' : '') + '.');
      return JSON.stringify(rows);
    }
    function usageBlock(box, d) {
      var p;
      if (!d.monitor) { p = document.createElement('div'); p.className = 'px-1.5 py-2 text-sm text-gray-900'; p.textContent = 'Runway use is worked out by the monitor from the flights it tracks - it is not connected.'; box.appendChild(p); return 'off'; }
      var by = {}; (d.usage || []).forEach(function (u) { by[u[0]] = { off: u[1] || 0, on: u[2] || 0 }; });
      (d.runways || []).forEach(function (r) { if (r[7]) return; [r[0], r[1]].forEach(function (e) { if (e && !by[e]) by[e] = { off: 0, on: 0 }; }); });
      (d.ends || []).forEach(function (e) { if (e && e.name && !by[e.name]) by[e.name] = { off: 0, on: 0 }; });
      var rows = Object.keys(by).map(function (k) { return { label: k, off: by[k].off, on: by[k].on }; }).sort(function (a, b) { return (b.off + b.on) - (a.off + a.on) || a.label.localeCompare(b.label, 'en', { numeric: true }); });
      if (!rows.length) { p = document.createElement('div'); p.className = 'px-1.5 py-2 text-sm text-gray-900'; p.textContent = heliText(d, panelCode()) ? 'Helicopters land on its pads: it has no runways to count.' : 'Runway usage not available: no runways are known for this airport.'; box.appendChild(p); return 'none'; }
      var max = Math.max(1, Math.max.apply(null, rows.map(function (r) { return r.off + r.on; })));
      grid(box, rows, max);
      legend(box, d.moves ? 'Take-offs / landings of the ' + d.moves + ' movement' + (d.moves > 1 ? 's' : '') + (d.allDays ? ' public ADS-B heard here in the last ' + (d.days || 7) + ' days (every aircraft on the ' + d.allDays + ' day' + (d.allDays > 1 ? 's' : '') + ' the monitor has counted; the rest, the flights it tracks)' : ' the monitor tracked here in the last ' + (d.days || 7) + ' days (blocked aircraft worldwide, all traffic in its areas - not every flight)') + '; the runway was clear from the track for ' + (d.withRunway || 0) + '.' : 'No take-offs or landings heard here in the last ' + (d.days || 7) + ' days.');
      return JSON.stringify(rows) + d.moves;
    }
    function panelBlock(slot, code, d) {
      var box = slot.box, mine = box.nextElementSibling && box.nextElementSibling.classList.contains('tl-panel') && box.nextElementSibling.getAttribute('data-kind') === slot.kind ? box.nextElementSibling : null;
      var probe = document.createElement('div'), sig = slot.kind === 'moves' ? movesBlock(probe, code, d) : usageBlock(probe, d);
      sig = code + ':' + sig;
      if (mine && mine.getAttribute('data-sig') === sig) { box.style.display = 'none'; return; }
      if (!mine) { mine = document.createElement('div'); box.after(mine); }
      mine.className = 'tl-panel w-full overflow-hidden rounded border border-gray-500 bg-gray-100'; mine.setAttribute('data-kind', slot.kind); mine.setAttribute('data-sig', sig); mine.textContent = '';
      while (probe.firstChild) mine.appendChild(probe.firstChild);
      box.style.display = 'none';
    }
    // (1.3.4) An OurAirports airport's codes in FR24's window. FR24 keeps one code per airport as its "IATA" - what its
    // pins, its window and its addresses go by - and for these it is OurAirports' code of it ("EGOW", "GB-1368"): the field
    // is named so, "OurAirports code", for every one of them; ICAO says its ICAO or GPS code, or "N/A". The header's line
    // under the name - FR24's flag and "LPL / EGGP" - says its code, and its ICAO code where that is another. Only the
    // words of FR24's own fields are changed (never its elements: it redraws them), and put back for FR24's airports.
    // (1.3.6) what the window's IATA field is for one of theirs: FR24's as it is where it has a real IATA code (WSX); "N/A"
    // where it has a real ICAO code but no IATA code - the field left FR24's, its ICAO code beside it (EGOW); its
    // OurAirports code, so named, where it has neither (GB-1368)
    function oaIataMode(r) { if (!r) return 'fr24'; if (oaRealIata(r)) return 'fr24'; return r[10] === 1 || (r[10] == null && /^[A-Z]{4}$/.test(String(r[2] || ''))) ? 'na' : 'oa'; }
    function textIn(el) { var w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null), t; while ((t = w.nextNode())) { if (t.__tlWas != null || t.data.trim()) return t; } return null; }
    function panelCodeFields(panel, code) {
      var r = code ? oaByCode.get(code.toLowerCase()) : null, mode = oaIataMode(r);
      var dts = panel.querySelectorAll('dt');
      for (var i = 0; i < dts.length; i++) {
        var lab = null, w = document.createTreeWalker(dts[i], NodeFilter.SHOW_TEXT, null), t;
        while ((t = w.nextNode())) { if (t.__tlWas != null || /^\s*IATA(?: code)?\s*$/i.test(t.data)) { lab = t; break; } }
        if (!lab) continue;
        if (mode === 'oa') { if (lab.__tlWas == null) lab.__tlWas = lab.data; if (lab.data !== 'OurAirports code') lab.data = 'OurAirports code'; }
        else if (lab.__tlWas != null) { lab.data = lab.__tlWas; lab.__tlWas = null; }
        // (its value: "N/A" for one with an ICAO code and no IATA code - FR24's table has the ICAO code there, its key)
        var dd = dts[i].nextElementSibling; if (!dd || dd.tagName !== 'DD') dd = dts[i].parentElement ? dts[i].parentElement.querySelector('dd') : null;
        var val = dd ? textIn(dd) : null;
        if (val) {
          if (mode === 'na') { if (val.__tlWas == null) val.__tlWas = val.data; if (val.data !== 'N/A') val.data = 'N/A'; }
          else val.__tlWas = null;   // (another airport's window: FR24 writes its value itself, as for the header's line)
        }
      }
      var hc = panel.querySelector('[data-testid="airport-panel__header__codes"]'), tn = hc && hc.firstChild && hc.firstChild.nodeType === 3 ? hc.firstChild : null;
      if (tn) {
        if (r) { var want = oaCodeLine(r); if (tn.__tlWas == null) tn.__tlWas = tn.data; if (tn.data !== want) tn.data = want; }
        else tn.__tlWas = null;      // (FR24's own airport: its words as FR24 writes them)
      }
    }
    function panelTick() {
      var panel = document.querySelector('[data-testid="airport-panel"]');
      if (!panel) { var left = document.querySelectorAll('.tl-panel'); for (var i = 0; i < left.length; i++) left[i].remove(); if (document.querySelector('.tl-rwy')) rwyPanel(); panelOpen.code = ''; return; }
      var code = panelCode(); if (!code) return;
      if (panelOpen.code !== code) { panelOpen.code = code; panelOpen.at = Date.now(); }
      panelWant(code); rwyPanel();
      try { panelCodeFields(panel, code); } catch (e) { stats.errors++; stats.lastError = String(e); }
      var d = panelData[code] || panelFromKept(code);
      // (1.2.7: the runway in use, under FR24's weather)
      { var pid = (d && d.apId) || Number((location.pathname.match(/^\/airport\/(\d+)\//) || [])[1]) || 0; if (pid) { try { rwyUsePanel(panel, pid); } catch (e) { stats.errors++; stats.lastError = String(e); } } }
      // (FR24's own counts of the last days: once the panel has been open a moment - a click through airports asks nothing)
      if (d && !d.monitor && Date.now() - panelOpen.at > 2500) mvCount(code.toLowerCase(), d.tz || 'UTC');
      // (the panel as it was last done, unchanged: nothing to do)
      if (panelSigs[code] === panelSig(panel, code, d)) return;
      panelHide(panel);
      if (d) promoSlots(panel).forEach(function (sl) { try { panelBlock(sl, code, d); } catch (e) { stats.errors++; stats.lastError = String(e); } });
      panelSigs[code] = panelSig(panel, code, d);
    }
    // (the panel's size and words, its boards' rows counted, not read: a row changing - its time, its status - is not the
    // panel changing)
    function panelSize(panel) {
      var w = document.createTreeWalker(panel, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, sizeRows), n = 0, len = 0, rows = panel.querySelectorAll('li[id^="' + ROW_ID + '"],[data-testid^="' + ROW_TESTID + '"]').length, t;
      while ((t = w.nextNode())) { if (t.nodeType === 3) len += (t.nodeValue || '').length; else n++; }
      return n + ':' + len + ':' + rows;
    }
    function panelSig(panel, code, d) { return [panelSize(panel), d ? d.at : 0, (lsGet('tl.mv.' + code.toLowerCase()) || '').length, ((d && routesAdd.get(d.apId)) || []).length, Math.floor(Date.now() / 60000)].join(':'); }
    function acceptAirportPanel(d) {
      var code = rwyKey(d.code); if (!code) return;
      panelData[code] = { at: Date.now(), apId: Number(d.apId) || 0, tz: String(d.tz || ''), days: Number(d.days) || 7, runways: Array.isArray(d.runways) ? d.runways : null, freqs: Array.isArray(d.freqs) ? d.freqs : null, usage: Array.isArray(d.usage) ? d.usage : null, moves: Number(d.moves) || 0, withRunway: Number(d.withRunway) || 0, monitor: !!d.monitor, ends: Array.isArray(d.ends) ? d.ends : null, daily: Array.isArray(d.daily) ? d.daily : null, allDays: Number(d.allDays) || 0, pads: Array.isArray(d.pads) ? d.pads : null, kind: String(d.kind || ''), name: String(d.name || '') };
      panelKeep(code, panelData[code]);
      panelSigs[code] = ''; panelTick();
    }
    // (1.0.2) the last 40 airports' panels kept in this browser: one opened again is filled the moment it shows, the
    // monitor's fresh answer replacing it when it comes
    function panelKept() { try { var o = JSON.parse(lsGet('tl.apc') || 'null'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
    function panelKeep(code, d) {
      if (!d || !d.monitor) return;
      var o = panelKept(); delete o[code]; o[code] = d;
      var ks = Object.keys(o); while (ks.length > 40) delete o[ks.shift()];
      lsSet('tl.apc', JSON.stringify(o));
    }
    function panelFromKept(code) { var d = panelKept()[code]; if (!d || typeof d !== 'object' || !(Date.now() - (d.at || 0) < 3 * 86400e3)) return null; d.kept = true; panelData[code] = d; return d; }
    setInterval(function () { try { panelTick(); } catch (e) { stats.errors++; stats.lastError = String(e); } }, 400);
    // an airport page's runway table: FR24's runways, each end's elevation where the userscript knows it, else the airport's
    function unlockRunways(p, apId) {
      var ap = p.airport || {}, code = ap.iata || ap.icao, fr = rwyOf(code); if (!fr) rwyWant(code);
      var ours = apDataOf(apId).runways || [], el = {}; ours.forEach(function (r) { el[r.name] = r.elevationFt; });
      var rw = fr ? fr.map(function (r) { return { name: r.name, lengthFt: r.ft, elevationFt: fin(el[r.name]) ? el[r.name] : (ap.elevationFt || 0), surface: r.code || 'UNKN' }; }) : ours.slice();
      if (!p.locked || !rw.length || (!p.locked.runways && !(p.runways && p.runways.__tl) && !(p.tlUnlocked && p.tlUnlocked.runways))) return;   // (a subscriber's own table stands)
      var sig = JSON.stringify(rw); if (p.runways && p.runways.__tl === sig) return;
      rw.__tl = sig; p.runways = rw; if (p.locked.runways) p.locked = Object.assign({}, p.locked, { runways: false });
    }
    // ---- the airport's movements by day (statistics page, "Airport movements"): FR24's own schedule - free accounts page
    // through it back to about yesterday morning - counted by each flight's actual landing and take-off time, by the
    // airport's local day: today so far, and each day the pages reach back past the start of (kept a week, so the table
    // fills as the days go by); the blocked flights the userscript knows on top. A day never seen whole is left out.
    var mvBusy = {};
    function dayOf(t, tz) { try { return new Date(t * 1000).toLocaleDateString('en-CA', { timeZone: tz || 'UTC' }); } catch (e) { return new Date(t * 1000).toISOString().slice(0, 10); } }
    function mvKept(code) { try { return JSON.parse(lsGet('tl.mv.' + code) || 'null') || { days: {}, at: 0 }; } catch (e) { return { days: {}, at: 0 }; } }
    function mvCount(code, tz) {
      if (mvBusy[code] || Date.now() - mvKept(code).at < 600000) return; mvBusy[code] = true;
      var now = Math.floor(Date.now() / 1000), today = dayOf(now, tz);
      var one = function (mode) {
        var cnt = {}, ts = {}, ids = {}, earliest = Infinity, k = mode === 'arrivals' ? 'arrival' : 'departure';
        var page = function (n) {
          return oFetch.call(window, 'https://api.flightradar24.com/common/v1/airport.json?code=' + encodeURIComponent(code) + '&plugin[]=schedule&plugin-setting[schedule][mode]=' + mode + '&plugin-setting[schedule][timestamp]=' + now + '&page=' + n + '&limit=100')
            .then(function (r) { return r.json(); }).then(function (j) {
              var ap = j && j.result && j.result.response && j.result.response.airport, b = ap && ap.pluginData && ap.pluginData.schedule && ap.pluginData.schedule[mode];
              ((b && b.data) || []).forEach(function (x) {
                var f = x && x.flight, tm = f && f.time, id = f && f.identification && (f.identification.row || f.identification.id); if (!tm) return;
                var sch = tm.scheduled && tm.scheduled[k], real = tm.real && tm.real[k]; if (sch && sch < earliest) earliest = sch;
                if (!real || (id && ids[id])) return; if (id) ids[id] = 1;
                var d = dayOf(real, tz); cnt[d] = (cnt[d] || 0) + 1; if (!ts[d]) ts[d] = real;
              });
              return b && b.page ? b.page : null;
            });
        };
        // back from now a page at a time until the day before yesterday is reached (or FR24 gives no more), then the next
        // page ahead (early arrivals)
        var back = function (n) { return page(-n).then(function (pg) { if (pg && n < pg.total && n < 10 && dayOf(earliest, tz) >= dayOf(now - 86400, tz)) return back(n + 1); }); };
        return back(1).then(function () { return page(1); }).catch(function () { /* what came */ }).then(function () { return { cnt: cnt, ts: ts, from: earliest < Infinity ? dayOf(earliest, tz) : today }; });
      };
      Promise.all([one('arrivals'), one('departures')]).then(function (r) {
        var a = r[0], dp = r[1], kept = mvKept(code), days = kept.days || {}, from = a.from > dp.from ? a.from : dp.from, old = dayOf(now - 8 * 86400, tz);
        Object.keys(a.cnt).concat(Object.keys(dp.cnt), [today]).forEach(function (d) { if (d > from || d === today) days[d] = { landings: a.cnt[d] || 0, takeoffs: dp.cnt[d] || 0, ts: a.ts[d] || dp.ts[d] || now }; });
        Object.keys(days).forEach(function (d) { if (d < old) delete days[d]; });
        lsSet('tl.mv.' + code, JSON.stringify({ days: days, at: Date.now() })); mvBusy[code] = false; routesTick();
      }, function () { mvBusy[code] = false; });
    }
    function mvRows(p) {
      var ap = p.airport, code = String(ap.iata || ap.icao || '').toLowerCase(), tz = ap.timezone; if (!code) return null;
      mvCount(code, tz);
      var days = mvKept(code).days || {}, keys = Object.keys(days).sort().reverse().slice(0, 7); if (!keys.length) return null;
      var add = {}, inc = function (t, k) { var d = dayOf(t, tz); (add[d] = add[d] || { off: 0, on: 0 })[k]++; };
      (routesAdd.get(ap.id) || []).forEach(function (m) { if (m.from.id === ap.id) (m.offs || []).forEach(function (t) { inc(t, 'off'); }); if (m.to.id === ap.id) (m.ons || []).forEach(function (t) { inc(t, 'on'); }); });
      return keys.map(function (d) { var x = days[d], e = add[d] || { off: 0, on: 0 }, to = x.takeoffs + e.off, la = x.landings + e.on; return { timestamp: x.ts, total: to + la, takeoffs: to, landings: la }; });
    }
    // (1.3.1) The statistics page's two tables unlocked in the page's own data, before FR24 draws it. FR24's table decides
    // once, as it is first drawn, whether it has an upgrade box over it: with one, it is drawn in a frame 21rem high that
    // cuts off what does not fit. 1.3 unlocked the tables only after that - the box went, the frame stayed, and the week's
    // movements showed five days of seven (and the box showed until the monitor answered). Now the page comes to FR24
    // unlocked - its first load (the page's data in #app) and every move to it within FR24 (its router's answers): the
    // tables as this browser last saw them for the airport, else empty, then the monitor's. A subscriber's own tables
    // (not locked) are left as they are.
    var STATS_LS = 'tl.apstats.';
    function statsCacheGet(apId) { try { var o = JSON.parse(lsGet(STATS_LS + apId) || 'null'); return o && Date.now() - o.at < 86400e3 ? o : null; } catch (e) { return null; } }
    function statsCachePut(apId, k, rows) {
      try {
        var o = statsCacheGet(apId) || { at: Date.now() }; o[k] = rows.map(function (r) { var c = {}; Object.keys(r).forEach(function (f) { c[f] = r[f]; }); return c; }); o.at = Date.now();
        lsSet(STATS_LS + apId, JSON.stringify(o));
      } catch (e) { /* full: next time */ }
    }
    // (which tables of which page: the statistics page's two; the airport page's runways - the same frame, the same cut)
    var UNLOCK_OF = { 'Data/AirportStatistics': ['movements', 'runways'], 'Data/Airport': ['runways'] };
    function statsUnlock(pg) {
      var keys = pg && UNLOCK_OF[pg.component], p = keys ? pg.props : null;
      if (!p || !p.locked || !p.airport || !keys.some(function (k) { return p.locked[k]; })) return false;
      var c = statsCacheGet(p.airport.id), un = {}, lk = {};
      Object.keys(p.locked).forEach(function (k) { lk[k] = p.locked[k]; });
      keys.forEach(function (k) {
        if (!p.locked[k]) return;
        un[k] = true; lk[k] = false;
        var kept = c && Array.isArray(c[k]) ? c[k] : null;
        // (the airport page's runways: those this browser has of it - FR24's own list of them, kept a month)
        if (!kept && pg.component === 'Data/Airport' && k === 'runways') {
          var ap = p.airport, fr = rwyOf(ap.iata || ap.icao), mine = (apDataOf(ap.id).runways || []);
          kept = fr ? fr.map(function (r) { return { name: r.name, lengthFt: r.ft, elevationFt: ap.elevationFt || 0, surface: r.code || 'UNKN' }; }) : mine.slice();
        }
        p[k] = kept || [];
      });
      p.locked = lk; p.tlUnlocked = un; stats.statsUnlocked = (stats.statsUnlocked || 0) + 1;
      return true;
    }
    // (1.3.4) the page FR24's server sent for the FR24 airport theirs are made from, made into theirs (oaPageOf) - its
    // address theirs at once (FR24's app takes the page's own, /data/airports/egow)
    function oaFastPage(pg) {
      if (!oaFast || !pg || !pg.component || !/^Data\/Airport/.test(pg.component)) return pg;
      var q = new URLSearchParams(location.search); q.delete('tl-oa'); var qs = q.toString();
      var oq = oaPageReq('/data/airports/' + encodeURIComponent(oaFast.code) + oaFast.sub + (qs ? '?' + qs : '')); if (!oq) return pg;
      var o = oaPageOf(pg, oq);
      try { history.replaceState(history.state, '', o.url); } catch (e) { /* the address as it is */ }
      Object.defineProperty(o, '__tlOa', { value: true, enumerable: false });
      stats.oaFast = (stats.oaFast || 0) + 1;
      return o;
    }
    // (the page as FR24's server gave it, in #app: read and put back unlocked the moment it is in the document - FR24's
    // app reads it once the page is parsed)
    (function () {
      var acHere = optOn('on') && /^\/data\/aircraft\/[^/]/i.test(location.pathname) && !!acPageReq(location.href);
      // (1.3.6: and FR24's lists - of airports, of aircraft - built with theirs as they load)
      var lists = optOn('on') && /^\/data\/(airports(\/[^/?#]+){0,2}|aircraft)\/?$/i.test(location.pathname);
      if (!oaFast && !acHere && !lists && !/^\/data\/airports\/[^/]+(?:\/statistics)?\/?$/i.test(location.pathname)) return;
      // (a frame of a locked table drawn by FR24's server before its app starts, should it send one: not shown - with the
      // tables unlocked FR24's app never draws one)
      if (!acHere && (oaFast || /^\/data\/airports\/[^/]+(?:\/statistics)?\/?$/i.test(location.pathname))) try { var css = document.createElement('style'); css.id = 'tl-stats-frame'; css.textContent = '#app [class*="max-h-84"]{visibility:hidden!important}'; (document.head || document.documentElement).appendChild(css); } catch (e) { /* none */ }
      var done = false;
      // (the page's data: #app's data-page, or - Inertia's newer form - a script[data-page="app"] of JSON)
      function fix() {
        if (done) return true;
        var el = document.getElementById('app'), sc = document.querySelector('script[data-page="app"][type="application/json"]');
        if (!el && !sc) return false;
        if (el && !el.getAttribute('data-page') && !sc && document.readyState === 'loading') return false;
        done = true;
        try {
          var raw = el && el.getAttribute('data-page');
          if (acHere) {
            // (1.3.5: one of the aircraft directory's families or types FR24 does not list - made from FR24's page as it loads)
            if (raw) { var pa = acFastPage(JSON.parse(raw)); if (pa.__tlAc) el.setAttribute('data-page', JSON.stringify(pa)); }
            else if (sc && sc.textContent) { var pa2 = acFastPage(JSON.parse(sc.textContent)); if (pa2.__tlAc) sc.textContent = JSON.stringify(pa2); }
          } else if (raw) { var pg = oaFastPage(JSON.parse(raw)), l1 = lists && (dirFastPage(pg) || acDirFastPage(pg)); if (statsUnlock(pg) || pg.__tlOa || l1) el.setAttribute('data-page', JSON.stringify(pg)); }
          else if (sc && sc.textContent) { var pg2 = oaFastPage(JSON.parse(sc.textContent)), l2 = lists && (dirFastPage(pg2) || acDirFastPage(pg2)); if (statsUnlock(pg2) || pg2.__tlOa || l2) sc.textContent = JSON.stringify(pg2); }
        } catch (e) { stats.errors++; stats.lastError = String(e); }
        return true;
      }
      if (fix()) return;
      try {
        var mo = new MutationObserver(function () { if (fix()) mo.disconnect(); });
        mo.observe(document.documentElement || document, { childList: true, subtree: true });
        document.addEventListener('DOMContentLoaded', function () { fix(); mo.disconnect(); }, { once: true });
      } catch (e) { /* no observer: FR24's page as it is */ }
    })();
    // (1.3) the statistics page's two tables from the monitor: "Runway usage" - each runway's take-offs and landings of the
    // last week, as the monitor logs every flight's runway from FR24's own tracks (rwylog.cjs: 1.2.10-1.2.12's rules), over
    // what its daily counts and the ADS-B legs give - and the movements of each day it counted, beside FR24's own
    // schedule's. FR24's props: runways [{ name, total, takeoffs, landings }], movements [{ timestamp, total, takeoffs,
    // landings }] (its padlock - locked.runways / locked.movements - off once filled; a subscriber's own tables stand)
    function statsUsage(p, apId) {
      var st = apDataOf(apId).stats, use = st && Array.isArray(st.usage) ? st.usage : null;
      if (!use || !use.length || !p.locked || (!p.locked.runways && !(p.runways && p.runways.__tl) && !(p.tlUnlocked && p.tlUnlocked.runways))) return;
      var rows = use.filter(function (u) { return u && u[0] && (u[1] > 0 || u[2] > 0); }).map(function (u) { return { name: String(u[0]), total: (u[1] || 0) + (u[2] || 0), takeoffs: u[1] || 0, landings: u[2] || 0 }; })
        .sort(function (a, b) { return b.total - a.total || a.name.localeCompare(b.name); });
      if (!rows.length) return;
      var sig = JSON.stringify(rows); if (p.runways && p.runways.__tl === sig) return;
      rows.__tl = sig; p.runways = rows; if (p.locked.runways) p.locked = Object.assign({}, p.locked, { runways: false });
      statsCachePut(p.airport.id, 'runways', rows);
    }
    // (FR24's schedule's count of a day and the monitor's, side by side: the larger of each - the monitor's days are UTC
    // days, given the airport's own date at noon)
    function statsMoves(p, apId, mine) {
      var st = apDataOf(apId).stats, daily = st && Array.isArray(st.daily) ? st.daily : [], tz = p.airport.timezone, by = {};
      (mine || []).forEach(function (m) { by[dayOf(m.timestamp, tz)] = { timestamp: m.timestamp, takeoffs: m.takeoffs, landings: m.landings }; });
      daily.forEach(function (x) {
        if (!Array.isArray(x) || !/^\d{4}-\d\d-\d\d$/.test(String(x[0]))) return;
        var o = by[x[0]], to = Number(x[1]) || 0, la = Number(x[2]) || 0;
        if (!o) by[x[0]] = { timestamp: Math.floor(Date.parse(x[0] + 'T12:00:00Z') / 1000), takeoffs: to, landings: la };
        else { o.takeoffs = Math.max(o.takeoffs, to); o.landings = Math.max(o.landings, la); }
      });
      var keys = Object.keys(by).sort().reverse().slice(0, 7);
      return keys.map(function (k) { var o = by[k]; return { timestamp: o.timestamp, total: o.takeoffs + o.landings, takeoffs: o.takeoffs, landings: o.landings }; }).filter(function (r) { return r.total > 0; });
    }
    function applyStats(pg) {
      var p = pg.props, apId = p.airport.id, w = weekAdds(pg), sig = w.ready + ':' + w.land + ':' + w.off + ':' + Object.keys(w.aps).length + ':' + Object.keys(w.cs).length;
      // (1.3: never the runway details' table here - its runways, "17/35", all "N/A": this one is the usage)
      statsUsage(p, apId);
      var mv = statsMoves(p, apId, mvRows(p)), msig = mv ? JSON.stringify(mv) : '';
      if (mv && mv.length && p.locked && (p.locked.movements || (p.movements && p.movements.__tl) || (p.tlUnlocked && p.tlUnlocked.movements)) && !(p.movements && p.movements.__tl === msig)) { mv.__tl = msig; p.movements = mv; if (p.locked.movements) p.locked = Object.assign({}, p.locked, { movements: false }); statsCachePut(p.airport.id, 'movements', mv); }
      if (!p.summary || p.summary.__tl === sig || !(w.land || w.off)) return;
      var b = p.summary.__tlBase || p.summary;
      p.summary = { airportsServed: (b.airportsServed || 0) + Object.keys(w.aps).length, countriesServed: (b.countriesServed || 0) + Object.keys(w.cs).length, totalFlights: (b.totalFlights || 0) + w.land + w.off, landingCount: (b.landingCount || 0) + w.land, takeoffCount: (b.takeoffCount || 0) + w.off, __tlBase: b, __tl: sig };
    }
    // ours into one of FR24's lists of flights: none twice (its own row of a flight - by flight id, or callsign within 45
    // minutes - gets what it lacks from ours: "N/A" where it went or came from), only within the span FR24's own list covers
    // (a page of the board, the general page's next few), in time order, as many as FR24 showed where it showed a few
    function mergeFlights(list, mine, kind, span, keepLen) {
      var base = (list || []).filter(function (x) { return x && !x.__tl; }), add = [];
      (mine || []).forEach(function (m) {
        var t = m.scheduledTime || m.estimatedTime || 0; if (span && !(t >= span[0] && t <= span[1])) return;
        var hit = base.find(function (x) { return (m.flightId && x.flightId === m.flightId) || (m.callsign && x.callsign === m.callsign && Math.abs((x.estimatedTime || x.scheduledTime || 0) - t) < 2700); });
        if (hit) { if (!hit.endpoint && m.endpoint) hit.endpoint = m.endpoint; if (!hit.aircraft || !hit.aircraft.type) hit.aircraft = m.aircraft; return; }
        add.push(m);
      });
      // (in the list's own order: boards run earliest first, the on-ground list latest landed first)
      var desc = base.length > 1 && (base[0].scheduledTime || 0) > (base[base.length - 1].scheduledTime || 0);
      var all = base.concat(add).sort(function (a, b) { return desc ? (b.scheduledTime || 0) - (a.scheduledTime || 0) : (a.scheduledTime || 0) - (b.scheduledTime || 0); });
      if (keepLen) { var cut = all.slice(0, Math.max(keepLen, 0)); return cut; }
      return all;
    }
    function spanOf(list, meta) { var ts = (list || []).filter(function (x) { return x && !x.__tl; }).map(function (x) { return x.scheduledTime || 0; }).filter(Boolean); if (ts.length) return [Math.min.apply(null, ts) - 900, Math.max.apply(null, ts) + 900]; return meta && meta.date ? [meta.date - 3600, meta.date + (meta.hoursRange || 12) * 3600] : null; }
    // (FR24 gives the airport's zone by name, "Europe/Dublin": its offset now, from the browser's own zone tables)
    var tzOffS = function (tz) { if (tz && typeof tz.offset === 'number') return tz.offset; try { var d = new Date(); d.setMilliseconds(0); return Math.round((Date.parse(d.toLocaleString('en-US', { timeZone: tz })) - Date.parse(d.toLocaleString('en-US', { timeZone: 'UTC' }))) / 1000) || 0; } catch (e) { return 0; } };
    var dayStartS = function (tz) { var off = tzOffS(tz), n = Date.now() / 1000 + off; return n - n % 86400 - off; };
    function todayCount(items, tz) { var s = dayStartS(tz); return (items || []).filter(function (m) { var t = m.scheduledTime || 0; return t >= s && t < s + 86400; }).length; }
    function applyBoardPage(pg) {
      // (the on-ground page is board "on-ground": every aircraft still there, however long ago it landed)
      var p = pg.props, og = p.board === 'on-ground', apId = p.airport.id, d = apDataOf(apId), mine = d.board && d.board[og ? 'onGround' : p.board]; if (!mine || !Array.isArray(p.flights)) return;
      var sig = hashStr(JSON.stringify(mine)) + ':' + (p.meta && p.meta.currentPage); if (p.flights.__tl === sig) return;
      var fl = mergeFlights(p.flights, mine, p.board, og ? null : spanOf(p.flights, p.meta), 0), added = fl.filter(function (x) { return x.__tl; }).length; fl.__tl = sig; p.flights = fl;
      if (og && p.statistics && typeof p.statistics.onGround === 'number') { var gb = p.statistics.__tlBase || p.statistics; p.statistics = Object.assign({}, gb, { onGround: gb.onGround + added, __tlBase: gb }); }
      else if (p.statistics && p.statistics.today) { var tb = p.statistics.__tlBase || p.statistics; p.statistics = Object.assign({}, tb, { today: Object.assign({}, tb.today, { total: (tb.today.total || 0) + todayCount(mine.filter(function (m) { return !fl.some(function (x) { return !x.__tl && ((m.flightId && x.flightId === m.flightId) || (m.callsign && x.callsign === m.callsign)); }); }), p.airport.timezone) }), __tlBase: tb }); }
      return added;
    }
    // (FR24's own list of the airport's closest - each { id, name, city, iata, icao, countryId, countryName, url,
    // distanceKm } - and the userscript's, in one: none twice, nearest first, as many as FR24 shows)
    function closestMerge(p, d) {
      if (!Array.isArray(d.closest) || !d.closest.length || !Array.isArray(p.closestAirports)) return;
      var sig = d.closest.map(function (x) { return x.id; }).join(','); if (p.closestAirports.__tl === sig) return;
      var base = p.closestAirports.__tlBase || p.closestAirports, by = new Set(), out = [];
      base.concat(d.closest).forEach(function (x) { if (x && x.id && x.id !== p.airport.id && !by.has(x.id)) { by.add(x.id); out.push(x); } });
      out.sort(function (a, b) { return (a.distanceKm || 0) - (b.distanceKm || 0); });
      out = out.slice(0, Math.max(5, base.length)); out.__tl = sig; out.__tlBase = base; p.closestAirports = out;
    }
    function applyAirport(pg) {
      var p = pg.props, apId = p.airport.id, d = apDataOf(apId);
      unlockRunways(p, apId);
      closestMerge(p, d);
      if (d.board && p.boards && p.boards.__tl !== hashStr(JSON.stringify(d.board))) {
        var nb = {}; ['departures', 'arrivals', 'onGround'].forEach(function (k) { var x = p.boards[k]; if (!x || !Array.isArray(x.flights)) { nb[k] = x; return; } nb[k] = Object.assign({}, x, { flights: mergeFlights(x.flights, d.board[k], k, k === 'onGround' ? null : spanOf(x.flights, null), x.flights.length || 5) }); });
        nb.__tl = hashStr(JSON.stringify(d.board)); p.boards = nb;
        if (p.delayStrip) { var db = p.delayStrip.__tlBase || p.delayStrip; p.delayStrip = Object.assign({}, db, { departuresToday: (db.departuresToday || 0) + todayCount(d.board.departures, p.airport.timezone), arrivalsToday: (db.arrivalsToday || 0) + todayCount(d.board.arrivals, p.airport.timezone), __tlBase: db }); }
      }
      // the week's routes: its top routes, and the destinations it counts
      var w = weekAdds(pg), tsig = w.ready + ':' + w.off;
      if (w.off && Array.isArray(p.topRoutes) && p.topRoutes.__tl !== tsig) {
        var tops = (p.topRoutes.__tlBase || p.topRoutes).map(function (x) { return Object.assign({}, x); }), byId = {}; tops.forEach(function (x) { byId[x.id] = x; });
        (routesAdd.get(apId) || []).forEach(function (m) { if (m.from.id !== apId) return; var o = m.to, x = byId[o.id]; if (x) x.flights = (x.flights || 0) + m.n; else { x = byId[o.id] = { id: o.id, name: o.name, city: o.city, iata: o.iata, icao: o.icao, countryId: o.countryId, countryName: o.countryName, url: '/data/airports/' + String(o.iata || o.icao).toLowerCase(), flights: m.n }; tops.push(x); } });
        var nt = tops.sort(function (a, b) { return (b.flights || 0) - (a.flights || 0); }).slice(0, Math.max(5, (p.topRoutes.__tlBase || p.topRoutes).length)); nt.__tl = tsig; nt.__tlBase = p.topRoutes.__tlBase || p.topRoutes; p.topRoutes = nt;
        if (w.ready && p.about && !p.about.__tl) p.about = Object.assign({}, p.about, { destinations: (p.about.destinations || 0) + Object.keys(w.aps).length, __tl: true });
      }
    }
    var dataAsked = {};
    function routesTick() {
      if (!/^\/data\/airports\/[^/]+/.test(location.pathname)) return;
      var pg = inertiaPage(); if (!pg) return;
      var c = pg.component, apId = pg.props.airport.id;
      var kinds = c === 'Data/AirportRoutes' ? ['routes'] : c === 'Data/AirportStatistics' ? ['routes', 'stats'] : c === 'Data/Airport' ? ['board', 'routes', 'runways', 'closest'] : c === 'Data/AirportBoard' ? ['board'] : [];
      if (!kinds.length) return;
      apDataOf(apId);
      var key = apId + ':' + kinds.join(','); if (!dataAsked[key] || Date.now() - dataAsked[key] > 60000) { dataAsked[key] = Date.now(); post('needAirportData', { apId: apId, kinds: kinds }); }
      try { if (c === 'Data/AirportRoutes') applyRoutes(pg); else if (c === 'Data/AirportStatistics') applyStats(pg); else if (c === 'Data/Airport') applyAirport(pg); else applyBoardPage(pg); } catch (e) { stats.errors++; stats.lastError = String(e); }
    }
    setInterval(routesTick, 300);
    // FR24's answer to its registration list, its flights the log's (the first, the flight on screen, hidden by FR24)
    // (1.3.7) FR24's new address (api/v2/flights) answers each row's airports as { id, type, code } - its build looks each
    // up by its id in its table of airports (this script's own among them), the code shown where it has none: the rows
    // given in that form there, as they were at the old one
    function listApCompact(ap) {
      if (!ap || typeof ap !== 'object') return null;
      if (typeof ap.code === 'string' || (ap.code == null && 'type' in ap)) return ap;
      var c = ap.code || {}, ia = c.iata || null, ic = c.icao || null;
      return { id: fin(ap.id) ? ap.id : null, type: ia ? 'iata' : ic ? 'icao' : null, code: ia || ic || null };
    }
    function listRowsFor(url, rows) {
      if (!/\/api\/v\d+\/flights\?/i.test(String(url || ''))) return rows;
      return rows.map(function (r) {
        if (!r || !r.airport) return r;
        var o = Object.assign({}, r); o.airport = { origin: listApCompact(r.airport.origin), destination: listApCompact(r.airport.destination), real: listApCompact(r.airport.real) };
        return o;
      });
    }
    function fillList(resp, h, url) {
      resp.data = listRowsFor(url, h.data.slice(0, 1 + Math.max(4, Number((resp.item && resp.item.limit) || 5))));
      resp.item = Object.assign({}, resp.item, { current: resp.data.length });
      resp.page = Object.assign({ current: 1 }, resp.page, { more: h.data.length > resp.data.length });
      stats.lists++;
    }
    // (the address, its token blanked out)
    function listUrlOf(url) { return String(url || '').replace(/^https?:\/\//, '').replace(/([?&]token=)[^&#]*/gi, '$1…').slice(0, 160); }
    // (FR24's answer had no list at all: one in its shape)
    function listShell(reg, url) {
      var lim = Number((String(url).match(/[?&]limit=(\d+)/) || [])[1]) || 5, now = Math.floor(Date.now() / 1000);
      return { result: { request: { callback: null, device: null, fetchBy: 'reg', filterBy: 'historic', format: 'json', limit: lim, olderThenFlightId: null, page: 1, pk: null, query: reg, timestamp: now, token: null },
        response: { item: { current: 0, total: null, limit: lim }, page: { current: 1, more: false }, timestamp: now, data: null, aircraftInfo: null, aircraftImages: [] } },
        _api: { copyright: 'Copyright (c) 2014-2026 Flightradar24 AB. All rights reserved.', legalNotice: '', version: '1.0' } };
    }
    // "Recent <reg> flights": FR24 answers `data: null` for blocked registrations; the userscript supplies the log.
    function needHistory(reg) {
      reg = String(reg || '').toUpperCase();
      // (a list handed over ahead of time is answered at once - a still-growing one too, when it has flights in it)
      var h = hist.get(reg); if (h && Date.now() - h.at < 10 * 60000 && (!h.partial || (h.data && h.data.length > 1))) return Promise.resolve(h);
      return new Promise(function (resolve) {
        var l = histWait.get(reg) || []; l.push(resolve); histWait.set(reg, l);
        post('needHist', { reg: reg });
        setTimeout(function () { var w = histWait.get(reg) || []; var i = w.indexOf(resolve); if (i >= 0) { w.splice(i, 1); resolve(hist.get(reg) || null); } }, 9000);
      });
    }

    // ---- (1.2.0) FR24's locked map options, worked natively ------------------------------------------------------------
    // FR24 decides what a plan may use from a table of plans per option in its own core module - exported, so the table
    // FR24 reads is reachable from here: the options this script supplies the data for get "basic" (and "guest") added,
    // nothing else - the account stays what it is everywhere else (a premium-only view stays FR24's to sell). The data:
    //   - aeronautical charts, ATC boundaries: FR24's own tiles (tiles.flightradar24.com answers any visitor)
    //   - oceanic tracks, current weather, AIRMETs/SIGMETs: FR24's own answer where it gives one; else built here from
    //     public sources (the FAA's NAT message; aviationweather.gov's METARs, AIRMETs/SIGMETs and international SIGMETs)
    //   - the layers FR24 buys from DTN: its weather "authorization" answered here, naming this script as the tile server,
    //     and each tile FR24 then asks for drawn from a free source - EUMETSAT's geostationary ring (cloud), NASA's IMERG
    //     (total precipitation), RainViewer's radar mosaic (intense precipitation, Australia), Iowa State's NEXRAD mosaic
    //     (North America), the Aviation Weather Center's WAFS forecasts (icing, turbulence, CB and jets), Open-Meteo
    //     (winds), Blitzortung (lightning)
    // FR24's own layers, toggles, sliders, legends and popups draw all of it.
    var mx = { on: optOn('mapx'), opts: 0, filterMax: 0, cats: false, tiles: 0, data: 0, fails: 0, lastError: '' };
    stats.mapx = mx;
    var MX_OPTS = ['map.layer.weather', 'map.layer.weather.radar', 'map.layer.weather.radar.global', 'map.layer.weather.satellite', 'map.layer.weather.naradar', 'map.layer.weather.auradar', 'map.layer.weather.wind', 'map.layer.weather.lightning', 'map.layer.weather.airmet', 'map.layer.weather.highlevel', 'map.layer.weather.icing', 'map.layer.weather.ict',
      'map.layer.atc', 'map.layer.tracks.oceanic', 'map.layer.ndb', 'map.layer.ndb.alt.low', 'map.layer.ndb.alt.high', 'map.widgets.last_clicked_flights',
      // (1.2.1: the aircraft labels - the flag, the logo's text row)
      'map.labels.flag', 'map.labels.logo_text_row',
      // (1.2.7: the squawk - FR24 padlocks it for a free account whatever the flight sends, its value or "N/A" shown instead;
      // the code filled from public ADS-B where FR24 has none, the last one heard over an ocean)
      'map.info.flight.squawk'];
    function mxFail(e) { mx.fails++; mx.lastError = String(e && e.message || e).slice(0, 160); }
    var mxNs = null, mxWrap = null;
    // (FR24's map wrapper - in its core module, usable once the map is made: its Google map, its picture layers)
    function mxWrapper() {
      if (mxWrap) return mxWrap;
      Object.keys(mxNs || {}).forEach(function (k) { if (mxWrap) return; try { var v = mxNs[k]; if (v && typeof v.getMap === 'function' && typeof v.addImageLayer === 'function' && v.getMap()) mxWrap = v; } catch (e) { /* not it, or not made yet */ } });
      return mxWrap;
    }
    // (the tables found by their shape - FR24's export names change with every build: the plans per option, keyed by the
    // options' own names; the custom filters each plan may keep, silver 10 / gold 25 / business 60)
    function mxPatchCore(ns) {
      // (the plan as FR24's page gives it: "Basic" - the table's own names are lower case; both added)
      var plans = ['basic', 'Basic', 'BASIC', 'guest', 'Guest', 'GUEST'];
      Object.keys(ns || {}).forEach(function (k) {
        // (an export that throws when looked into - FR24's map wrapper before the map is made - is none of these)
        try {
          var v = ns[k];
          if (!v || typeof v !== 'object' || Array.isArray(v)) return;
          if (Array.isArray(v['map.layer.weather.wind']) && Array.isArray(v['map.layer.atc'])) {
            MX_OPTS.forEach(function (f) { var a = v[f]; if (!Array.isArray(a) || !a.length) return; plans.forEach(function (p) { if (a.indexOf(p) < 0) a.push(p); }); mx.opts++; });
            // (1.2.1: the labels' rows - four, each with any of the values FR24 offers - as FR24's own silver plan has them)
            var rows = v['map.labels.rows'], vals = v['map.labels.aircraft'];
            if (rows && typeof rows === 'object' && !Array.isArray(rows) && rows.silver) { plans.forEach(function (p) { rows[p] = rows.silver; }); mx.opts++; }
            if (vals && typeof vals === 'object' && !Array.isArray(vals) && Array.isArray(vals.silver)) { plans.forEach(function (p) { vals[p] = vals.silver; }); mx.opts++; }
            // (1.2.4: a flight's KML and CSV - FR24's buttons beside its playback's play button and in its flight history:
            // a daily number of files per plan; the files themselves made here - mxTrackFile)
            mxPlans = v;
            var kml = v['history.flight.kml'];
            if (kml && typeof kml === 'object' && !Array.isArray(kml)) { plans.forEach(function (p) { if (!(p in kml)) kml[p] = 60; }); mx.opts++; }
          } else if (v.silver === 10 && v.gold === 25 && v.business === 60 && Object.keys(v).length <= 6) { plans.forEach(function (p) { v[p] = 60; }); mx.filterMax = 60; }
          // (1.3.1) FR24's airport lookup (its airports database: byCodeOrId, byIATA, byICAO, byId): a code finds an airport
          // only when it is three letters (IATA) or four (ICAO) - and its pins, search and links look airports up by code.
          // Most OurAirports codes are neither ("AE-0002", "00AL"): looked up by id from the list when FR24 finds none
          else if (typeof v.byCodeOrId === 'function' && typeof v.byId === 'function' && typeof v.byIATA === 'function' && typeof v.byICAO === 'function' && !v.byCodeOrId.__tl) {
            var ownLook = v.byCodeOrId, byIdF = v.byId;
            // (1.3.4) and by id - FR24's aircraft panel and its playback look a flight's airports up so (scheduleInfo's
            // originId / destinationId): M-SKTO's landings at Axis Business Park's helipad were "-" - by IATA and by ICAO
            // code too; the landing places learned likewise. FR24's own answer first, always
            var ownById = v.byId, ownIata = v.byIATA, ownIcao = v.byICAO;
            var oaOf = function (n) { n = Number(n); if (n >= 1e7 && oaById && oaById.has(n)) return oaStoreRow(oaById.get(n)); if (n > 9000000 && n < 1e7) { for (var i = 0; i < siteRows.length; i++) if (siteRows[i] && siteRows[i].id === n && isFinite(siteRows[i].lat)) return storeForm(siteRows[i]); } return null; };
            var keep = function (o) { if (o) { oaStoreKeep(pinStore('airports'), o); oaShown = '~'; oaMapSoon(); } return o; };
            var look = function (c) {
              return Promise.resolve(ownLook.apply(this, arguments)).then(function (a) {
                if (a) return a;
                // (1.3.7: by its id - FR24's build of mid-November opens a pin by its airport's id, not its code, and its
                // own lookup by code or id asks its own table by id, not this one: every OurAirports pin was "Cannot
                // load the airport data")
                if (typeof c === 'number') return keep(oaOf(c)) || a;
                if (typeof c !== 'string' || !oaByCode.size) return a;
                var r = oaByCode.get(c.toLowerCase()); if (!r) return a;
                return Promise.resolve(byIdF.call(v, r[0])).then(function (b) { return keep(b || oaStoreRow(r)); }, function () { return keep(oaStoreRow(r)); });
              });
            };
            look.__tl = true; v.byCodeOrId = look; mx.oaLookup = (mx.oaLookup || 0) + 1;
            // (FR24's own object of it where its database has one - by its id - else one of that form)
            var byCode = function (c) { var r = typeof c === 'string' && oaByCode.size ? oaByCode.get(c.toLowerCase()) : null; if (!r) return null; return Promise.resolve(ownById.call(v, r[0])).then(function (b) { return b || oaStoreRow(r); }, function () { return oaStoreRow(r); }); };
            v.byId = function (id) { return Promise.resolve(ownById.apply(this, arguments)).then(function (a) { return a || oaOf(id) || a; }, function (e) { var o = oaOf(id); if (o) return o; throw e; }); };
            v.byIATA = function (c) { return Promise.resolve(ownIata.apply(this, arguments)).then(function (a) { return a || byCode(c) || a; }); };
            v.byICAO = function (c) { return Promise.resolve(ownIcao.apply(this, arguments)).then(function (a) { return a || byCode(c) || a; }); };
            v.byId.__tl = v.byIATA.__tl = v.byICAO.__tl = true;
          }
        } catch (e) { /* not a table */ }
      });
    }
    // (FR24's core module, as its page links it: imported here - the same module, so the same tables FR24 reads)
    function mxCoreUrl() { var l = document.querySelector('link[rel="modulepreload"][href*="/__modulepreload__-"],script[src*="/__modulepreload__-"]'); return l ? (l.href || l.src || '') : ''; }
    function mxFindCore(n) {
      var u = mxCoreUrl();
      if (u) { import(u).then(function (ns) { mxNs = ns; mxPatchCore(ns); }, mxFail); return; }
      if (n < 600) oSetTimeout(function () { mxFindCore(n + 1); }, n < 200 ? 25 : 250);
    }
    // Aircraft categories: FR24's filters window lets only a premium account untick one (its live feed then asks for the
    // categories left ticked - FR24's server honours that for anyone). Premium stays as it is for everything else: only
    // the filters window's own reading of it is answered "yes".
    var MX_CHUNK = /\/build\/assets\/([A-Za-z0-9_.]+)-[A-Za-z0-9_-]{8}\.js/;
    // (1.2.1: the windows and panels whose locks are this one question: the filters' categories, the "Last clicked
    // flights" widget (its settings and the map's widget list), the Misc settings' trail tooltip and photo switch, the
    // label's text row beside a logo or flag)
    var MX_PREMIUM_ASKERS = /^(Filters|WidgetsSettings|SettingsMisc|SettingsMap|MapView|LastClickedFlights)$/;
    function mxCaller() {
      var ls = String(new Error().stack || '').split('\n');
      for (var i = 1; i < ls.length && i < 18; i++) { var m = ls[i].match(MX_CHUNK); if (!m || /__modulepreload__/.test(ls[i])) continue; return m[1]; }
      return '';
    }
    function mxPinia() { try { var el = document.getElementById('app'), app = el && el.__vue_app__, p = app && app.config && app.config.globalProperties && app.config.globalProperties.$pinia; return p && p._s ? p : null; } catch (e) { return null; } }
    function mxCats() {
      var p = mxPinia(), us = p && p._s.get('user'); if (!us) return false;
      var raw = us.__v_raw || us, d = Object.getOwnPropertyDescriptor(raw, 'isPremiumUser');
      if (!d || d.get) return true;
      var ref = d.value;
      Object.defineProperty(raw, 'isPremiumUser', { configurable: true, enumerable: true, get: function () { var real = ref && ref.__v_isRef ? ref.value : ref; return real || MX_PREMIUM_ASKERS.test(mxCaller()); } });
      // (the categories unticked, as FR24's own filters store gives them to its window and its counters: FR24's store
      // hands a Basic account none - read here from where FR24 keeps the choice, its settings)
      var fst = p._s.get('filters'), sst = p._s.get('settings');
      if (fst && sst) Object.defineProperty(fst.__v_raw || fst, 'deselectedCategories', { configurable: true, enumerable: true, get: function () { var d = sst.filters && sst.filters.deselectedCategories; return Array.isArray(d) ? d : []; } });
      mx.cats = true; return true;
    }
    // the categories left ticked, for FR24's live feed (null: all of them)
    function mxCategoriesOff() { try { var p = mxPinia(), st = p && p._s.get('settings'), f = st && st.filters; if (!f || f.disabled) return null; var d = f.deselectedCategories; return Array.isArray(d) && d.length ? d.map(Number) : null; } catch (e) { return null; } }
    if (mx.on) { mxFindCore(0); (function waitPinia(n) { if (!mxCats() && n < 240) oSetTimeout(function () { waitPinia(n + 1); }, 500); })(0); }

    // ---- (1.2.3) Settings kept as they were left. A signed-in FR24 takes its settings from its server, which keeps none of
    // the ones it locks for a Basic account (Misc's trail tooltip and photo switch, the Flag label, the weather layers...):
    // each came back at its default when FR24 was opened again. Every setting changed in FR24's own windows is kept here
    // (its section, name and value), and given back to FR24 - in the page's own data before FR24 reads it, and in its
    // settings store whenever FR24 sets them all anew from its server. Nothing is kept until it is changed: FR24's
    // defaults stand until then
    var MX_SET_KEY = 'tl.mx.settings';
    function mxSetKept() { try { var o = JSON.parse(localStorage.getItem(MX_SET_KEY) || '{}'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
    function mxSetSave(o) { try { localStorage.setItem(MX_SET_KEY, JSON.stringify(o)); } catch (e) { /* full */ } }
    var mxSetOk = function (sec, k) { return /^[A-Za-z0-9_]{1,40}$/.test(sec) && /^[A-Za-z0-9_]{1,60}$/.test(k); };
    var mxSetVal = function (v) { return v === null || typeof v === 'boolean' || typeof v === 'number' || typeof v === 'string' || Array.isArray(v) || (v && typeof v === 'object'); };
    // (into FR24's settings - the page's data or its store's: only a section and a setting it has)
    function mxSetApply(settings, kept) {
      var n = 0; if (!settings || typeof settings !== 'object') return 0;
      Object.keys(kept).forEach(function (sec) {
        var s = settings[sec], ks = kept[sec]; if (!s || typeof s !== 'object' || !ks || typeof ks !== 'object') return;
        Object.keys(ks).forEach(function (k) { if (!(k in s)) return; if (JSON.stringify(s[k]) !== JSON.stringify(ks[k])) { s[k] = JSON.parse(JSON.stringify(ks[k])); n++; } });
      });
      return n;
    }
    // (the page's own data, before FR24's app reads it: its first draw as left)
    function mxSetIntoPage() {
      var el = document.getElementById('app'); if (!el || el.__tlSet) return !!el;
      el.__tlSet = true;
      try {
        var kept = mxSetKept(); if (!Object.keys(kept).length) return true;
        var raw = el.getAttribute('data-page'); if (!raw) return true;
        var pg = JSON.parse(raw), d = pg && pg.props && pg.props.dispatcher; if (!d || !d.settings) return true;
        if (mxSetApply(d.settings, kept)) { el.setAttribute('data-page', JSON.stringify(pg)); mx.setApplied = (mx.setApplied || 0) + 1; }
      } catch (e) { mxFail(e); }
      return true;
    }
    // (a value FR24's store has, set as its own window would: a switch flipped through its own toggle - what it does on
    // being switched (a weather layer's loading) done too - anything else set)
    function mxSetIntoStore(st) {
      var kept = mxSetKept(), all = st && st.settings; if (!all) return 0;
      var n = 0;
      Object.keys(kept).forEach(function (sec) {
        var s = all[sec], ks = kept[sec]; if (!s || !ks) return;
        Object.keys(ks).forEach(function (k) {
          if (!(k in s) || JSON.stringify(s[k]) === JSON.stringify(ks[k])) return;
          try { if (typeof s[k] === 'boolean' && typeof ks[k] === 'boolean' && typeof st.toggle === 'function') st.toggle(sec, k); else st.set(sec, k, JSON.parse(JSON.stringify(ks[k]))); n++; } catch (e) { /* not FR24's to set */ }
        });
      });
      if (n) mx.setApplied = (mx.setApplied || 0) + n;
      return n;
    }
    // (what FR24's windows set - its store's own actions - kept, as it is once they have run)
    var mxSetQuiet = false;
    function mxSetNote(st, sec, keys) {
      if (mxSetQuiet || !st || !st.settings || !st.settings[sec]) return;
      var kept = mxSetKept(), s = st.settings[sec], ch = false;
      keys.forEach(function (k) { if (!mxSetOk(sec, k) || !(k in s) || !mxSetVal(s[k])) return; var v = JSON.parse(JSON.stringify(s[k])); kept[sec] = kept[sec] || {}; if (JSON.stringify(kept[sec][k]) !== JSON.stringify(v)) { kept[sec][k] = v; ch = true; } });
      if (ch) mxSetSave(kept);
    }
    function mxSetWatch() {
      var p = mxPinia(), st = p && p._s.get('settings'); if (!st || typeof st.$onAction !== 'function') return false;
      if (st.__tlSet) return true; st.__tlSet = true;
      st.$onAction(function (a) {
        var name = a.name, args = a.args || [];
        a.after(function () {
          if (name === 'set' || name === 'toggle') { if (typeof args[0] === 'string' && args[1] != null) mxSetNote(st, args[0], [String(args[1])]); }
          else if (name === 'toggleWeatherLayer') mxSetNote(st, 'weather', [String(args[0])]);
          else if (name === 'setWindWeatherLayer') mxSetNote(st, 'weather', ['windBarbs', 'windGradient']);
          // (FR24 setting them all anew - from its server: the ones kept given back)
          else if (name === 'setAllSettings' || name === 'resetWeatherLayers') oSetTimeout(function () { mxSetQuiet = true; try { mxSetIntoStore(st); } finally { mxSetQuiet = false; } }, 0);
        });
      });
      // (and once now, should FR24 have set them from elsewhere before this was here)
      mxSetQuiet = true; try { mxSetIntoStore(st); } finally { mxSetQuiet = false; }
      mx.setWatch = true; return true;
    }
    if (mx.on) {
      (function waitApp(n) { if (!mxSetIntoPage() && n < 400) oSetTimeout(function () { waitApp(n + 1); }, n < 200 ? 5 : 50); })(0);
      (function waitSet(n) { if (!mxSetWatch() && n < 240) oSetTimeout(function () { waitSet(n + 1); }, 250); })(0);
    }

    // ---- what the page part cannot reach itself: fetched by the userscript (any site; binary or text) --------------------
    var mxWait = new Map(), mxSeq = 0;
    function mxGet(url, bin, ms) {
      return new Promise(function (res, rej) {
        var rid = 'mx' + (++mxSeq), t = oSetTimeout(function () { mxWait.delete(rid); rej(new Error('timeout')); }, ms || 25000);
        mxWait.set(rid, function (d) { oClearTimeout(t); mxWait.delete(rid); if (d.status >= 200 && d.status < 300 && d.body != null) res(d.body); else rej(new Error('HTTP ' + (d.status || 0))); });
        post('mxGet', { rid: rid, url: url, bin: !!bin });
      });
    }
    function mxGotMsg(d) { var f = mxWait.get(d.rid); if (f) f(d); }
    var mxJsonCache = new Map();
    function mxJson(url, ttl) {
      var c = mxJsonCache.get(url); if (c && Date.now() - c.at < (ttl || 300000)) return c.p;
      var p = mxGet(url, false).then(function (t) { return JSON.parse(t); });
      mxJsonCache.set(url, { at: Date.now(), p: p }); p.catch(function () { mxJsonCache.delete(url); });
      return p;
    }

    // ---- (1.2.1) the monitor first: every layer's pictures and figures built there once, for every user - had at once
    // from one server instead of from a dozen slow ones (EUMETSAT takes half a minute to draw a quarter of the world). The
    // sources themselves are asked only when the monitor has nothing.
    var mxMetaC = null;
    function mxMon(p, bin) { return mxGet('mon:' + p, bin, 15000); }
    function mxMeta() {
      if (mxMetaC && Date.now() - mxMetaC.at < (mxMetaC.ok ? 60000 : 30000)) return mxMetaC.p;
      var c = { at: Date.now(), ok: false, p: null };
      c.p = mxMon('/wx/meta', false).then(function (t) { var j = JSON.parse(t); if (!j || j.v !== 1) throw new Error('no weather on the monitor'); c.ok = true; return j; });
      c.p.catch(function () { /* the sources themselves, for now */ });
      mxMetaC = c; return c.p;
    }
    var mxMonBufs = new Map();
    function mxMonBuf(p) {
      var c = mxMonBufs.get(p); if (c) return c;
      var pr = mxMon(p, true); mxMonBufs.set(p, pr); pr.catch(function () { mxMonBufs.delete(p); });
      if (mxMonBufs.size > 800) mxMonBufs.delete(mxMonBufs.keys().next().value);
      return pr;
    }
    // (part of a tile `dz` zooms up from it, scaled to a whole tile)
    function mxCrop(img, z, x, y, dz) {
      var cv = mxCanvas(256, 256), g = cv.getContext('2d'), s = img.width / Math.pow(2, dz), ax = x >> dz, ay = y >> dz;
      g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
      g.drawImage(img, (x - (ax << dz)) * s, (y - (ay << dz)) * s, s, s, 0, 0, 256, 256);
      return cv;
    }
    // (1.2.3) One picture for the whole map: the version of a layer a valid time FR24 asks for was first drawn with stays
    // that one's - FR24 asks for every tile again when its time moves on (the monitor keeps the picture before its newest
    // for that) - so a map moved after the monitor has a new picture is not new squares beside old ones
    var mxVerOf = new Map();
    function mxPinVer(prod, vt, cur) {
      if (!vt) return cur;
      var k = prod + '|' + vt, v = mxVerOf.get(k); if (v) return v;
      mxVerOf.set(k, cur); if (mxVerOf.size > 200) mxVerOf.delete(mxVerOf.keys().next().value);
      return cur;
    }
    var mxMonUrl = function (prod, ver, z, x, y) { return '/wx/t/' + prod + '/' + ver + '/' + z + '/' + x + '/' + y + '.png'; };
    // (1.2.3) the tiles round one asked for, fetched ahead behind FR24's own - the map moved a little has them at once - and
    // the whole world's at the zooms out, once a picture: a few at a time, never more than the monitor's lane can spare
    var mxAhead = { q: [], busy: 0, done: new Set() };
    function mxAheadRun() {
      while (mxAhead.busy < 4 && mxAhead.q.length) {
        var u = mxAhead.q.shift(); if (mxMonBufs.has(u)) continue;
        mxAhead.busy++;
        mxMonBuf(u).then(function () { mxAhead.busy--; mxAheadRun(); }, function () { mxAhead.busy--; mxAheadRun(); });
      }
    }
    function mxAheadOf(prod, ver, mz, ax, ay, maxZ) {
      var N = Math.pow(2, mz), add = function (u) { if (!mxMonBufs.has(u) && mxAhead.q.indexOf(u) < 0) mxAhead.q.push(u); };
      for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var yy = ay + dy; if (yy < 0 || yy >= N || (!dx && !dy)) continue; add(mxMonUrl(prod, ver, mz, ((ax + dx) % N + N) % N, yy)); }
      var wk = prod + '|' + ver;
      if (!mxAhead.done.has(wk)) { mxAhead.done.add(wk); for (var z = 0; z <= Math.min(2, maxZ); z++) { var n = Math.pow(2, z); for (var j = 0; j < n; j++) for (var i = 0; i < n; i++) add(mxMonUrl(prod, ver, z, i, j)); } }
      if (mxAhead.q.length > 120) mxAhead.q.splice(0, mxAhead.q.length - 120);
      oSetTimeout(mxAheadRun, 50);
    }
    // (the nearest coarser tile of the same picture already here - drawn in place of one the monitor did not give)
    function mxCachedAncestor(prod, ver, mz, ax, ay) {
      for (var d = 1; d <= mz; d++) { var u = mxMonUrl(prod, ver, mz - d, ax >> d, ay >> d); if (mxMonBufs.has(u)) return { p: mxMonBufs.get(u), dz: d }; }
      return null;
    }
    // a tile of a layer the monitor builds: its own bytes where it has that zoom (FR24 given them as they are), else its
    // nearest tile scaled up; { canvas } when one is wanted to draw on
    function mxMonTile(prod, z, x, y, wantCanvas, vt) {
      return mxMeta().then(function (m) {
        var p = m && m[prod]; if (!p || !p.ver) throw new Error(prod + ' not built yet');
        var ver = mxPinVer(prod, vt, p.ver), dz = Math.max(0, z - p.maxZ), mz = z - dz, ax = x >> dz, ay = y >> dz, url = mxMonUrl(prod, ver, mz, ax, ay);
        if (prod === 'cloud' || prod === 'precip') mxAheadOf(prod, ver, mz, ax, ay, p.maxZ);
        var draw = function (b, up) { return createImageBitmap(new Blob([b])).then(function (img) { return { canvas: mxCrop(img, z, x, y, up) }; }); };
        var got = mxMonBuf(url).catch(function () {
          // (once more; then the same picture's coarser tile already here, scaled up - never another source's beside it)
          return new Promise(function (res) { oSetTimeout(res, 400); }).then(function () { return mxMonBuf(url); }).catch(function (e) {
            var a = mxCachedAncestor(prod, ver, mz, ax, ay); if (!a) throw e;
            return a.p.then(function (b) { return { up: a.dz + dz, b: b }; });
          });
        });
        return got.then(function (b) {
          if (b && b.up != null) return draw(b.b, b.up);
          if (!dz && !wantCanvas) return { bytes: b };
          return draw(b, dz);
        });
      });
    }
    // (the monitor's tile, else - only when the monitor has no such layer at all, or cannot be reached - the source's own
    // drawn here)
    function mxMonOr(prod, z, x, y, direct, vt) {
      return mxMonTile(prod, z, x, y, false, vt).catch(function () {
        return mxMeta().then(function (m) { return !!(m && m[prod] && m[prod].ver); }, function () { return false; }).then(function (monHas) {
          if (monHas) return null;
          var d = direct(); return d && d.then ? d.then(function (cv) { return cv ? { canvas: cv } : null; }) : null;
        });
      });
    }
    function mxBytesOr(monPath, url, bin) { return mxMon(monPath, bin).catch(function () { return mxGet(url, bin); }); }

    // ---- tiles: drawing ---------------------------------------------------------------------------------------------
    function mxCanvas(w, h) { if (typeof OffscreenCanvas === 'function') return new OffscreenCanvas(w, h); var c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
    function mxPng(cv) {
      if (cv.convertToBlob) return cv.convertToBlob({ type: 'image/png' });
      return new Promise(function (res) { cv.toBlob(function (b) { res(b); }, 'image/png'); });
    }
    var MX_EMPTY = null;
    function mxEmpty() { if (!MX_EMPTY) MX_EMPTY = mxPng(mxCanvas(1, 1)); return MX_EMPTY.then(function (b) { return new Response(b, { status: 200, headers: { 'content-type': 'image/png' } }); }); }
    function mxResp(cv) { return mxPng(cv).then(function (b) { return new Response(b, { status: 200, headers: { 'content-type': 'image/png', 'cache-control': 'no-store' } }); }); }
    // (a source image, kept: the same tile asked for again at another layer opacity, or panned back to)
    var mxImgs = new Map();
    function mxImage(url) {
      var c = mxImgs.get(url); if (c) return c;
      // (the WAFS pictures: the monitor keeps every one of the newest run)
      var wafs = url.match(/^https:\/\/aviationweather\.gov\/data\/products\/wafs\/\d{8}\/\d{2}\/(\d{8}_\d{2}_F\d{2}_wafs_[a-z0-9_]+_m\.png)$/);
      var p = (wafs ? mxBytesOr('/wx/wafs/' + wafs[1], url, true) : mxGet(url, true)).then(function (buf) { return createImageBitmap(new Blob([buf])); });
      mxImgs.set(url, p); p.catch(function () { mxImgs.delete(url); });
      if (mxImgs.size > 500) mxImgs.delete(mxImgs.keys().next().value);
      return p;
    }
    // web mercator: a tile's corners in degrees, a point's place in the tile
    var MX_R = 6378137, MX_HALF = Math.PI * MX_R;
    function mxLon(x, z) { return x / Math.pow(2, z) * 360 - 180; }
    function mxLat(y, z) { var n = Math.PI - 2 * Math.PI * y / Math.pow(2, z); return 180 / Math.PI * Math.atan(Math.sinh(n)); }
    function mxMercY(lat) { var r = Math.max(-85.0511, Math.min(85.0511, lat)) * Math.PI / 180; return Math.log(Math.tan(Math.PI / 4 + r / 2)); }
    function mxBox(z, x, y) { var s = 2 * MX_HALF / Math.pow(2, z); return [-MX_HALF + x * s, MX_HALF - (y + 1) * s, -MX_HALF + (x + 1) * s, MX_HALF - y * s]; }
    // a source's tile at this zoom - or its nearest ancestor scaled up, past the source's deepest zoom
    function mxTileFrom(src, z, x, y, maxZ) {
      var dz = Math.max(0, z - maxZ), az = z - dz, ax = x >> dz, ay = y >> dz;
      return mxImage(src(az, ax, ay)).then(function (img) {
        var cv = mxCanvas(256, 256), g = cv.getContext('2d'), s = img.width / Math.pow(2, dz);
        g.imageSmoothingEnabled = true;
        g.drawImage(img, (x - (ax << dz)) * s, (y - (ay << dz)) * s, s, s, 0, 0, 256, 256);
        return cv;
      });
    }
    // only where a box of lon/lat intersects the tile: drawn; the rest left clear
    function mxClip(cv, z, x, y, w, s, e, n) {
      var g = cv.getContext('2d'), px = function (lon) { return (lon - mxLon(x, z)) / (mxLon(x + 1, z) - mxLon(x, z)) * 256; };
      var t0 = mxMercY(mxLat(y, z)), t1 = mxMercY(mxLat(y + 1, z)), py = function (lat) { return (t0 - mxMercY(lat)) / (t0 - t1) * 256; };
      var l = px(w), r = px(e), t = py(n), b = py(s);
      g.save(); g.globalCompositeOperation = 'destination-in'; g.fillStyle = '#000'; g.fillRect(l, t, r - l, b - t); g.restore();
      return cv;
    }
    function mxTileIn(z, x, y, w, s, e, n) { return !(mxLon(x + 1, z) < w || mxLon(x, z) > e || mxLat(y, z) < s || mxLat(y + 1, z) > n); }

    // ---- the weather tiles -------------------------------------------------------------------------------------------
    // cloud: EUMETSAT's geostationary ring at 10.8 µm (every geostationary satellite round the world, as FR24's own global
    // IR) - cold, high tops bright: drawn white, the warm ground and sea left clear
    function mxCloud(z, x, y) {
      var b = mxBox(z, x, y), slot = Math.floor(Date.now() / 900000);
      var u = 'https://view.eumetsat.int/geoserver/wms?service=WMS&version=1.3.0&request=GetMap&layers=mumi:worldcloudmap_ir108&styles=&format=image/png&crs=EPSG:3857&width=256&height=256&bbox=' + b.map(function (v) { return v.toFixed(2); }).join(',') + '&tl=' + slot;
      return mxImage(u).then(function (img) {
        var cv = mxCanvas(256, 256), g = cv.getContext('2d'); g.drawImage(img, 0, 0, 256, 256);
        var d = g.getImageData(0, 0, 256, 256), p = d.data;
        for (var i = 0; i < p.length; i += 4) { var a = (p[i] - 92) / 80; a = a <= 0 ? 0 : a >= 1 ? 1 : a; var al = p[i + 3]; p[i] = p[i + 1] = p[i + 2] = 255; p[i + 3] = Math.round(Math.pow(a, 0.85) * 235 * al / 255); }
        g.putImageData(d, 0, 0); return cv;
      });
    }
    // total precipitation: NASA's IMERG (satellites, every half hour, the whole world - oceans too)
    function mxImerg(z, x, y) {
      var slot = Math.floor(Date.now() / 1800000);
      return mxTileFrom(function (Z, X, Y) { return 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/IMERG_Precipitation_Rate_30min/default/default/GoogleMapsCompatible_Level6/' + Z + '/' + Y + '/' + X + '.png?tl=' + slot; }, z, x, y, 6);
    }
    // intense precipitation and Australia: RainViewer's mosaic of the world's weather radars, its newest frame
    function mxRvBase() {
      return mxJson('https://api.rainviewer.com/public/weather-maps.json', 300000).then(function (j) { var p = j && j.radar && j.radar.past, l = p && p[p.length - 1]; if (!l) throw new Error('no radar frame'); return String(j.host || 'https://tilecache.rainviewer.com') + l.path; });
    }
    function mxRadar(z, x, y) { return mxRvBase().then(function (base) { return mxTileFrom(function (Z, X, Y) { return base + '/256/' + Z + '/' + X + '/' + Y + '/2/1_1.png'; }, z, x, y, 7); }); }
    function mxAuRadar(z, x, y) { if (!mxTileIn(z, x, y, 108, -46, 160, -9)) return null; return mxRadar(z, x, y).then(function (cv) { return mxClip(cv, z, x, y, 108, -46, 160, -9); }); }
    // North America: Iowa State's mosaic of the NEXRAD radars (refreshed every five minutes)
    function mxNexrad(z, x, y) {
      if (!mxTileIn(z, x, y, -170, 14, -50, 72)) return null;
      var slot = Math.floor(Date.now() / 300000);
      return mxTileFrom(function (Z, X, Y) { return 'https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/nexrad-n0q-900913/' + Z + '/' + X + '/' + Y + '.png?tl=' + slot; }, z, x, y, 10);
    }
    // icing, turbulence and high-level significant weather: the Aviation Weather Center's WAFS forecasts - one picture of
    // the world per level and forecast hour (6 to 36 hours after each 00/06/12/18 UTC run), in Mercator to 75.94°
    var MX_WAFS_TOP = mxMercY(75.940536), mxWafs = null;
    function mxYmd(t) { var d = new Date(t); return d.getUTCFullYear() + ('0' + (d.getUTCMonth() + 1)).slice(-2) + ('0' + d.getUTCDate()).slice(-2); }
    function mxWafsUrl(run, fhr, param) { var hh = ('0' + new Date(run).getUTCHours()).slice(-2), ymd = mxYmd(run); return 'https://aviationweather.gov/data/products/wafs/' + ymd + '/' + hh + '/' + ymd + '_' + hh + '_F' + ('0' + fhr).slice(-2) + '_wafs_' + param + '_m.png'; }
    // (the newest run published: looked for from four hours ago back, kept half an hour)
    function mxWafsRun() {
      if (mxWafs && Date.now() - mxWafs.at < 1800000) return mxWafs.p;
      var t0 = Math.floor((Date.now() - 4 * 3600e3) / 21600e3) * 21600e3;
      // (the monitor's run - its pictures all kept there - else the newest one the Aviation Weather Center has out)
      var p = mxMeta().then(function (m) { if (!(m && m.wafs && m.wafs.run && m.wafs.files)) throw new Error('no run'); return m.wafs.run; }).catch(function () { return (function look(i) { if (i > 4) return Promise.reject(new Error('no WAFS run found')); var run = t0 - i * 21600e3; return mxImage(mxWafsUrl(run, 6, '301_edr')).then(function () { return run; }, function () { return look(i + 1); }); })(0); });
      mxWafs = { at: Date.now(), p: p }; p.catch(function () { mxWafs = null; });
      return p;
    }
    function mxNearest(levels, v) { var best = levels[0]; levels.forEach(function (l) { if (Math.abs(l[0] - v) < Math.abs(best[0] - v)) best = l; }); return best[1]; }
    var MX_ICE = [[60, 812], [100, 697], [140, 595], [180, 506], [240, 393], [300, 301]];
    var MX_TURB = [[140, 595], [180, 506], [240, 393], [270, 344], [300, 301], [340, 250], [390, 197], [450, 148]];
    function mxWafsDraw(g, img, z, x, y) {
      var W = img.width, H = img.height, lon0 = mxLon(x, z), lon1 = mxLon(x + 1, z), m0 = mxMercY(mxLat(y, z)), m1 = mxMercY(mxLat(y + 1, z));
      var sx0 = (lon0 + 180) / 360 * W, sx1 = (lon1 + 180) / 360 * W, sy0 = (MX_WAFS_TOP - m0) / (2 * MX_WAFS_TOP) * H, sy1 = (MX_WAFS_TOP - m1) / (2 * MX_WAFS_TOP) * H;
      var cy0 = Math.max(0, sy0), cy1 = Math.min(H, sy1); if (cy1 <= cy0) return;
      g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
      g.drawImage(img, sx0, cy0, sx1 - sx0, cy1 - cy0, 0, (cy0 - sy0) / (sy1 - sy0) * 256, 256, (cy1 - cy0) / (sy1 - sy0) * 256);
    }
    function mxWafsTile(z, x, y, params, vt, alphas) {
      return mxWafsRun().then(function (run) {
        var fhr = Math.max(6, Math.min(36, Math.round((vt - run) / 10800e3) * 3));
        return Promise.all(params.map(function (pm) { return mxImage(mxWafsUrl(run, fhr, pm)).catch(function () { return null; }); }));
      }).then(function (imgs) {
        var cv = mxCanvas(256, 256), g = cv.getContext('2d');
        imgs.forEach(function (img, i) {
          if (!img) return;
          // (the jets: only their cores - the fastest winds, green to yellow; the wide band round them left out)
          if (/_wind$/.test(params[i])) {
            var t = mxCanvas(256, 256), tg = t.getContext('2d'); mxWafsDraw(tg, img, z, x, y);
            var d = tg.getImageData(0, 0, 256, 256), px = d.data; for (var k = 0; k < px.length; k += 4) if (px[k + 2] > 130) px[k + 3] = 0;
            tg.putImageData(d, 0, 0); g.globalAlpha = alphas ? alphas[i] : 1; g.drawImage(t, 0, 0); return;
          }
          g.globalAlpha = alphas ? alphas[i] : 1; mxWafsDraw(g, img, z, x, y);
        });
        return cv;
      });
    }
    // winds: Open-Meteo's GFS - speed and direction on the two pressure levels round the altitude asked for, on a grid as
    // fine as the zoom wants (one barb every 50-60 pixels), kept; barbs or FR24's own colour scale drawn from it
    var MX_PL = [1000, 975, 950, 925, 900, 850, 800, 700, 600, 500, 400, 300, 250, 200, 150, 100];
    function mxPressure(ft) { return ft < 36089 ? 1013.25 * Math.pow(1 - 6.8756e-6 * ft, 5.2559) : 226.32 * Math.exp(-(ft - 36089) / 20806); }
    function mxLevels(kft) {
      var p = mxPressure(kft * 1000), a = 1000, b = 1000;
      for (var i = 0; i < MX_PL.length; i++) { if (MX_PL[i] >= p) a = MX_PL[i]; if (MX_PL[i] <= p) { b = MX_PL[i]; break; } }
      if (p >= 1000) return { a: 1000, b: 1000, w: 0 };
      return { a: a, b: b, w: a === b ? 0 : Math.log(a / p) / Math.log(a / b) };
    }
    function mxGridDeg(z) { return z <= 2 ? 20 : z === 3 ? 10 : z === 4 ? 5 : z === 5 ? 2.5 : z === 6 ? 1.25 : z === 7 ? 0.625 : 0.3125; }
    var mxWind = new Map(), mxWindAsk = new Map(), mxWindStop = 0;
    function mxWindKey(lat, lon, lv) { return lat.toFixed(4) + ',' + lon.toFixed(4) + ',' + lv.a + ',' + lv.b; }
    // (missing points asked for together, a hundred a request; a refusal (429) leaves Open-Meteo alone for ten minutes)
    function mxWindPoints(pts, lv) {
      var need = pts.filter(function (q) { var c = mxWind.get(mxWindKey(q[0], q[1], lv)); return !c || Date.now() - c.at > 3 * 3600e3; });
      var waits = [];
      for (var i = 0; i < need.length; i += 100) {
        var part = need.slice(i, i + 100), key = part.map(function (q) { return mxWindKey(q[0], q[1], lv); }).join(';');
        if (mxWindAsk.has(key)) { waits.push(mxWindAsk.get(key)); continue; }
        if (Date.now() < mxWindStop) continue;
        var vars = [lv.a, lv.b].filter(function (v, k, s) { return s.indexOf(v) === k; }).map(function (P) { return 'wind_speed_' + P + 'hPa,wind_direction_' + P + 'hPa'; }).join(',');
        var u = 'https://api.open-meteo.com/v1/gfs?latitude=' + part.map(function (q) { return q[0].toFixed(3); }).join(',') + '&longitude=' + part.map(function (q) { return q[1].toFixed(3); }).join(',') + '&hourly=' + vars + '&wind_speed_unit=kn&forecast_days=3&timeformat=unixtime';
        var pr = (function (part) {
          return mxGet(u, false).then(function (t) {
            var j = JSON.parse(t), arr = Array.isArray(j) ? j : [j];
            arr.forEach(function (r, k) { var q = part[k]; if (!q || !r || !r.hourly) return; mxWind.set(mxWindKey(q[0], q[1], lv), { at: Date.now(), h: r.hourly }); });
            if (mxWind.size > 20000) Array.from(mxWind.keys()).slice(0, 5000).forEach(function (k2) { mxWind.delete(k2); });
          }, function (e) { if (/HTTP 429/.test(String(e))) mxWindStop = Date.now() + 600000; throw e; });
        })(part);
        mxWindAsk.set(key, pr); (function (key) { pr.then(function () { mxWindAsk.delete(key); }, function () { mxWindAsk.delete(key); }); })(key);
        waits.push(pr);
      }
      return Promise.all(waits.map(function (w) { return w.catch(function () { return null; }); }));
    }
    // (speed (kt) and the direction it blows from, at a grid point and time: between the two levels)
    function mxWindAt(lat, lon, lv, vt) {
      var c = mxWind.get(mxWindKey(lat, lon, lv)); if (!c) return null;
      var h = c.h, ts = h.time || [], k = 0; for (var i = 0; i < ts.length; i++) if (Math.abs(ts[i] * 1000 - vt) < Math.abs(ts[k] * 1000 - vt)) k = i;
      var sa = (h['wind_speed_' + lv.a + 'hPa'] || [])[k], da = (h['wind_direction_' + lv.a + 'hPa'] || [])[k], sb = (h['wind_speed_' + lv.b + 'hPa'] || [])[k], db = (h['wind_direction_' + lv.b + 'hPa'] || [])[k];
      if (sa == null || da == null) return null; if (sb == null || db == null) { sb = sa; db = da; }
      var r = Math.PI / 180, ua = -sa * Math.sin(da * r), va = -sa * Math.cos(da * r), ub = -sb * Math.sin(db * r), vb = -sb * Math.cos(db * r);
      var u = ua + (ub - ua) * lv.w, v = va + (vb - va) * lv.w;
      return { s: Math.sqrt(u * u + v * v), d: (Math.atan2(-u, -v) / r + 360) % 360, u: u, v: v };
    }
    function mxWindGrid(z, x, y, lv) {
      var deg = mxGridDeg(z), w = mxLon(x, z), e = mxLon(x + 1, z), n = mxLat(y, z), s = mxLat(y + 1, z), pts = [];
      for (var la = Math.floor(s / deg) * deg - deg; la <= n + deg; la += deg) { if (la < -88 || la > 88) continue; for (var lo = Math.floor(w / deg) * deg - deg; lo <= e + deg; lo += deg) pts.push([la, ((lo + 540) % 360) - 180, lo]); }
      return { deg: deg, pts: pts, w: w, e: e, n: n, s: s };
    }
    function mxPx(z, x, y, lat, lon) { var t0 = mxMercY(mxLat(y, z)), t1 = mxMercY(mxLat(y + 1, z)); return [(lon - mxLon(x, z)) / (mxLon(x + 1, z) - mxLon(x, z)) * 256, (t0 - mxMercY(lat)) / (t0 - t1) * 256]; }
    // a wind barb: its staff toward where the wind comes from, flags 50 kt, barbs 10, half barbs 5
    function mxBarb(g, px, py, kt, from) {
      g.save(); g.translate(px, py);
      if (kt < 2.5) { g.beginPath(); g.arc(0, 0, 4, 0, 2 * Math.PI); g.stroke(); g.restore(); return; }
      g.rotate(from * Math.PI / 180);
      var L = 20, v = Math.round(kt / 5) * 5, yb = -L;
      g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -L);
      while (v >= 50) { g.moveTo(0, yb); g.lineTo(9, yb + 2); g.lineTo(0, yb + 5); yb += 6; v -= 50; }
      while (v >= 10) { g.moveTo(0, yb); g.lineTo(10, yb - 4); yb += 4; v -= 10; }
      if (v >= 5) { if (yb === -L) yb += 4; g.moveTo(0, yb); g.lineTo(5, yb - 2); }
      g.stroke(); g.restore();
    }
    // FR24's own scale for the gradient (kt -> colour), as its legend shows it
    var MX_GRAD = [[0, [255, 255, 255]], [20, [240, 254, 254]], [40, [225, 255, 255]], [60, [227, 255, 240]], [80, [239, 255, 210]], [100, [255, 255, 225]], [120, [254, 240, 179]], [140, [255, 210, 179]], [160, [253, 194, 180]], [180, [238, 180, 179]], [200, [255, 179, 254]], [220, [178, 179, 227]], [240, [229, 202, 255]]];
    function mxGradColor(kt) {
      if (kt >= 240) return MX_GRAD[MX_GRAD.length - 1][1];
      for (var i = 1; i < MX_GRAD.length; i++) if (kt < MX_GRAD[i][0]) { var a = MX_GRAD[i - 1], b = MX_GRAD[i], f = (kt - a[0]) / (b[0] - a[0]); return [0, 1, 2].map(function (c) { return Math.round(a[1][c] + (b[1][c] - a[1][c]) * f); }); }
      return MX_GRAD[0][1];
    }
    // (1.2.1) the monitor's GFS first: u and v (m/s) every degree on each pressure level, every three hours - the two
    // levels round the altitude asked for, at the forecast hour nearest the time; one small grid a level for the world
    var mxGrids = new Map();
    function mxGridGet(run, fhr, hpa) {
      var k = run + '/' + fhr + '/' + hpa, c = mxGrids.get(k); if (c) return c;
      var p = mxMon('/wx/wind/' + k, true).then(function (b) { var a = new Int8Array(b); if (a.length !== 2 * 360 * 181) throw new Error('bad wind grid'); return a; });
      mxGrids.set(k, p); p.catch(function () { mxGrids.delete(k); });
      if (mxGrids.size > 64) mxGrids.delete(mxGrids.keys().next().value);
      return p;
    }
    function mxMonWind(lv, vt) {
      return mxMeta().then(function (m) {
        var w = m && m.wind; if (!w || !w.run || !w.fhrs || !w.fhrs.length) throw new Error('no winds on the monitor');
        var h = (vt - w.run) / 3600e3, f = w.fhrs.reduce(function (b, x) { return Math.abs(x - h) < Math.abs(b - h) ? x : b; }, w.fhrs[0]);
        return Promise.all([mxGridGet(w.run, f, lv.a), lv.b === lv.a ? null : mxGridGet(w.run, f, lv.b)]);
      }).then(function (g) {
        var A = g[0], B = g[1] || g[0], N = 360 * 181, KT = 1.943844;
        return function (lat, lon) {
          var fy = Math.max(0, Math.min(180, 90 - lat)), fx = ((lon % 360) + 360) % 360, j0 = Math.min(179, Math.floor(fy)), i0 = Math.floor(fx) % 360, i1 = (i0 + 1) % 360, wy = fy - j0, wx = fx - Math.floor(fx);
          var bil = function (G, o) { return (G[o + j0 * 360 + i0] * (1 - wx) + G[o + j0 * 360 + i1] * wx) * (1 - wy) + (G[o + (j0 + 1) * 360 + i0] * (1 - wx) + G[o + (j0 + 1) * 360 + i1] * wx) * wy; };
          var u = (bil(A, 0) * (1 - lv.w) + bil(B, 0) * lv.w) * KT, v = (bil(A, N) * (1 - lv.w) + bil(B, N) * lv.w) * KT;
          return { s: Math.sqrt(u * u + v * v), d: (Math.atan2(-u, -v) * 180 / Math.PI + 360) % 360, u: u, v: v };
        };
      });
    }
    // (else Open-Meteo's points round the tile: a point of its grid as it is, anywhere else between the four round it)
    function mxOmWind(G, lv, vt) {
      return mxWindPoints(G.pts, lv).then(function () {
        var deg = G.deg, wrap = function (l) { return ((l + 540) % 360) - 180; };
        return function (lat, lon) {
          var la0 = Math.floor(lat / deg) * deg, lo0 = Math.floor(lon / deg) * deg, fy = (lat - la0) / deg, fx = (lon - lo0) / deg;
          if (fx < 1e-9 && fy < 1e-9) return mxWindAt(la0, wrap(lo0), lv, vt);
          var c00 = mxWindAt(la0, wrap(lo0), lv, vt), c10 = mxWindAt(la0, wrap(lo0 + deg), lv, vt), c01 = mxWindAt(la0 + deg, wrap(lo0), lv, vt), c11 = mxWindAt(la0 + deg, wrap(lo0 + deg), lv, vt);
          if (!c00 || !c10 || !c01 || !c11) return null;
          var u = (c00.u * (1 - fx) + c10.u * fx) * (1 - fy) + (c01.u * (1 - fx) + c11.u * fx) * fy, v = (c00.v * (1 - fx) + c10.v * fx) * (1 - fy) + (c01.v * (1 - fx) + c11.v * fx) * fy;
          return { s: Math.sqrt(u * u + v * v), d: (Math.atan2(-u, -v) * 180 / Math.PI + 360) % 360, u: u, v: v };
        };
      });
    }
    function mxWinds(z, x, y, kft, vt, barbs) {
      var lv = mxLevels(kft), G = mxWindGrid(z, x, y, lv);
      return mxMonWind(lv, vt).catch(function () { return mxOmWind(G, lv, vt); }).then(function (at) {
        var cv = mxCanvas(256, 256), g = cv.getContext('2d');
        if (barbs) {
          g.lineWidth = 1.4; g.lineCap = 'round'; g.lineJoin = 'round';
          G.pts.forEach(function (q) {
            var wv = at(q[0], q[1]); if (!wv) return;
            var p = mxPx(z, x, y, q[0], q[2]);
            if (p[0] < -24 || p[0] > 280 || p[1] < -24 || p[1] > 280) return;
            g.strokeStyle = 'rgba(255,255,255,0.85)'; g.lineWidth = 3.2; mxBarb(g, p[0], p[1], wv.s, wv.d);
            g.strokeStyle = '#1f2a37'; g.lineWidth = 1.4; mxBarb(g, p[0], p[1], wv.s, wv.d);
          });
          return cv;
        }
        // (the gradient: the wind at 64x64 points of the tile, then smoothed to it)
        var N = 64, small = mxCanvas(N, N), sg = small.getContext('2d'), img = sg.createImageData(N, N), d = img.data;
        for (var j = 0; j < N; j++) {
          var lat = mxLat(y + (j + 0.5) / N, z);
          for (var i = 0; i < N; i++) {
            var wv = at(lat, mxLon(x + (i + 0.5) / N, z)), o = (j * N + i) * 4;
            if (!wv) { d[o + 3] = 0; continue; }
            var col = mxGradColor(wv.s); d[o] = col[0]; d[o + 1] = col[1]; d[o + 2] = col[2]; d[o + 3] = 150;
          }
        }
        sg.putImageData(img, 0, 0); g.imageSmoothingEnabled = true; g.drawImage(small, 0, 0, 256, 256);
        return cv;
      });
    }
    // which tile FR24 asked for: its address names the product (with the level), the tile (TMS: y counted from the south)
    // and the forecast time
    function mxTile(url) {
      var m = url.match(/\/\/tl-wx\.invalid\/v1\/tl\/tms\/1\.0\.0\/([^/]+)\/(\d+)\/(\d+)\/(\d+)\.png(?:\?([^#]*))?/); if (!m) return null;
      var type = decodeURIComponent(m[1]).split('+')[0], z = +m[2], x = +m[3], y = Math.pow(2, z) - 1 - (+m[4]), q = m[5] || '';
      var vt0 = Date.parse(decodeURIComponent((q.match(/(?:^|&)valid_time=([^&]*)/) || [])[1] || '')) || 0, vt = vt0 || Date.now(), p = null, k;
      if (y < 0 || y >= Math.pow(2, z)) return mxEmpty();
      if (type === 'C09-0x0316-0') p = mxMonOr('cloud', z, x, y, function () { return mxCloud(z, x, y); }, vt0);
      else if (type === 'gfs-preciprate-inph-surface') p = mxMonOr('precip', z, x, y, function () { return mxImerg(z, x, y); }, vt0);
      else if (type === 'C09-0x0374-0') p = mxMonOr('radar', z, x, y, function () { return mxRadar(z, x, y); });
      else if (type === 'north-american-radar') p = mxTileIn(z, x, y, -170, 14, -50, 72) ? mxMonOr('naradar', z, x, y, function () { return mxNexrad(z, x, y); }) : null;
      else if (type === 'C50-0x030F-0') p = mxTileIn(z, x, y, 108, -46, 160, -9) ? mxMonTile('radar', z, x, y, true).then(function (r) { return mxClip(r.canvas, z, x, y, 108, -46, 160, -9); }, function () { return mxAuRadar(z, x, y); }) : null;
      else if (/^gfs-halfdeg-wind/.test(type)) p = null;
      else if ((k = type.match(/^wafs-hires-icing-fl(\d+)/))) p = mxWafsTile(z, x, y, [mxNearest(MX_ICE, +k[1]) + '_icsev'], vt);
      else if ((k = type.match(/^wafs-hires-turbulence-fl(\d+)/))) p = mxWafsTile(z, x, y, [mxNearest(MX_TURB, +k[1]) + '_edr'], vt);
      else if (type === 'sigwx-high') p = mxWafsTile(z, x, y, ['whole_cbhe', '250_wind'], vt, [1, 0.8]);
      mx.tiles++;
      var opk = type === 'sigwx-high' ? 'sigwx' : '';
      return Promise.resolve(p).then(function (r) {
        if (r && r.bytes) return new Response(r.bytes, { status: 200, headers: { 'content-type': 'image/png' } });
        var cv = r && r.canvas ? r.canvas : r;
        return cv ? mxResp(opk ? mxFade(cv, mxOp(opk)) : cv) : mxEmpty();
      }, function (e) { mxFail(e); return mxEmpty(); });
    }

    // ---- lightning: Blitzortung's live strikes (its servers stream every strike its network locates, worldwide) - kept
    // here from when the layer is first shown, half an hour of them; let go ten minutes after FR24 last asked
    var mxLx = { ws: null, strikes: [], asked: 0, n: 0, retry: 0, host: 0, timer: 0 };
    function mxLzw(b) { var dict = {}, d = b.split(''), c = d[0], f = c, g = [c], o = 256; for (var i = 1; i < d.length; i++) { var a = d[i].charCodeAt(0); a = a < 256 ? d[i] : dict[a] ? dict[a] : f + c; g.push(a); c = a.charAt(0); dict[o] = f + c; o++; f = a; } return g.join(''); }
    function mxLightningOn() {
      mxLx.asked = Date.now();
      if (!mxLx.timer) mxLx.timer = setInterval(function () { var cut = Date.now() - 1800000; while (mxLx.strikes.length && mxLx.strikes[0][0] < cut) mxLx.strikes.shift(); if (Date.now() - mxLx.asked > 600000 && mxLx.ws) { try { mxLx.ws.close(); } catch (e) { /* gone */ } mxLx.ws = null; } }, 30000);
      if (mxLx.ws || typeof WebSocket !== 'function') return;
      var hosts = ['wss://ws1.blitzortung.org/', 'wss://ws8.blitzortung.org/', 'wss://ws7.blitzortung.org/'], ws;
      try { ws = mxLx.ws = new WebSocket(hosts[mxLx.host++ % hosts.length]); } catch (e) { mxFail(e); mxLx.ws = null; return; }
      ws.onopen = function () { mxLx.retry = 0; try { ws.send('{"a":111}'); } catch (e) { /* closed */ } };
      ws.onmessage = function (m) { try { var j = JSON.parse(mxLzw(String(m.data))); if (typeof j.lat === 'number' && typeof j.lon === 'number') { mxLx.n++; mxLx.strikes.push([Math.round(Number(j.time) / 1e6) || Date.now(), j.lat, j.lon]); if (mxLx.strikes.length > 80000) mxLx.strikes.splice(0, 20000); } } catch (e) { /* not a strike */ } };
      ws.onclose = function () { if (mxLx.ws === ws) mxLx.ws = null; if (Date.now() - mxLx.asked < 600000) oSetTimeout(mxLightningOn, Math.min(30000, 2000 * (++mxLx.retry))); };
      ws.onerror = function () { try { ws.close(); } catch (e) { /* gone */ } };
    }
    // (FR24's own request - DTN's region.json, the bounds and the start time in its query: the strikes there since then)
    function mxLightning(url) {
      mxLightningOn();
      var q = function (k) { var m = url.match(new RegExp('[?&]' + k + '=([^&]*)')); return m ? decodeURIComponent(m[1]) : null; };
      var n = +q('n_lat'), s = +q('s_lat'), w = +q('w_lon'), e = +q('e_lon'), t0 = Date.parse(q('time_start') || '') || (Date.now() - 1680000);
      var wrap = w > e, data = [];
      for (var i = mxLx.strikes.length - 1; i >= 0; i--) {
        var k = mxLx.strikes[i]; if (k[0] < t0) break;
        if (isFinite(n) && (k[1] > n || k[1] < s)) continue;
        if (isFinite(w) && (wrap ? (k[2] < w && k[2] > e) : (k[2] < w || k[2] > e))) continue;
        data.push({ coordinates: [k[2], k[1]], intensity: 1, time: new Date(k[0]).toISOString() });
        if (data.length >= 20000) break;
      }
      mx.data++; mx.strikes = mxLx.strikes.length; mx.lxShown = data.length;
      return Promise.resolve(jsonResponse(null, { lightning: { data: data } }));
    }

    // ---- current weather: FR24's own stations where it answers; else every METAR in the world (aviationweather.gov's
    // ten-minute file), the stations in view - one per few kilometres of screen at each zoom - with a symbol drawn here
    var mxMetars = null;
    function mxCsv(line) { var out = [], cur = '', q = false; for (var i = 0; i < line.length; i++) { var ch = line[i]; if (q) { if (ch === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; } else if (ch === '"') q = true; else if (ch === ',') { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out; }
    function mxGunzip(buf) { return new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).text(); }
    function mxMetarList() {
      if (mxMetars && Date.now() - mxMetars.at < 600000) return mxMetars.p;
      var p = mxBytesOr('/wx/metars', 'https://aviationweather.gov/data/cache/metars.cache.csv.gz', true).then(mxGunzip).then(function (t) {
        var rows = t.split('\n'), out = [];
        for (var i = 1; i < rows.length; i++) {
          if (!rows[i]) continue; var c = mxCsv(rows[i]), lat = parseFloat(c[3]), lon = parseFloat(c[4]); if (!c[1] || !isFinite(lat) || !isFinite(lon)) continue;
          var sky = []; for (var k = 22; k <= 28; k += 2) if (c[k]) sky.push([c[k], +c[k + 1] || 0]);
          out.push({ id: c[1], raw: c[0], t: Date.parse(c[2]) || 0, lat: lat, lon: lon, temp: c[5] === '' ? null : +c[5], wdir: c[7], wspd: +c[8] || 0, gust: +c[9] || 0, vis: c[10], wx: c[21] || '', sky: sky, cat: c[30] || '' });
        }
        return out;
      });
      mxMetars = { at: Date.now(), p: p }; p.catch(function () { mxMetars = null; });
      return p;
    }
    function mxDaylight(lat, lon, t) {
      var d = new Date(t), r = Math.PI / 180, doy = (Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) - Date.UTC(d.getUTCFullYear(), 0, 0)) / 864e5;
      var decl = 23.44 * Math.sin(2 * Math.PI / 365 * (doy - 81)), ha = (d.getUTCHours() + d.getUTCMinutes() / 60) * 15 + lon - 180;
      return Math.asin(Math.sin(lat * r) * Math.sin(decl * r) + Math.cos(lat * r) * Math.cos(decl * r) * Math.cos(ha * r)) > -0.0145;
    }
    var MX_WX_WORDS = { TS: 'thunderstorm', SH: 'showers', FZ: 'freezing', RA: 'rain', DZ: 'drizzle', SN: 'snow', SG: 'snow grains', PL: 'ice pellets', GR: 'hail', GS: 'small hail', FG: 'fog', BR: 'mist', HZ: 'haze', FU: 'smoke', DU: 'dust', SA: 'sand', VA: 'volcanic ash', SQ: 'squalls', BC: 'patches of', MI: 'shallow', BL: 'blowing', DR: 'drifting', VC: 'nearby' };
    function mxWxText(m) {
      var parts = [];
      (m.wx || '').split(/\s+/).filter(Boolean).forEach(function (w) { var lead = w[0] === '-' ? 'light ' : w[0] === '+' ? 'heavy ' : ''; var body = w.replace(/^[-+]/, ''), words = []; for (var i = 0; i + 1 < body.length; i += 2) { var k = body.slice(i, i + 2); if (MX_WX_WORDS[k]) words.push(MX_WX_WORDS[k]); } if (words.length) parts.push(lead + words.join(' ')); });
      var low = m.sky.filter(function (s) { return /BKN|OVC|VV/.test(s[0]); })[0];
      if (low) parts.push((low[0] === 'OVC' ? 'overcast' : low[0] === 'VV' ? 'sky obscured' : 'broken clouds') + ' at ' + low[1].toLocaleString('en-GB') + ' ft');
      else if (m.sky.some(function (s) { return /FEW|SCT/.test(s[0]); })) parts.push('some clouds');
      else if (!parts.length) parts.push('clear');
      if (m.vis) parts.push('visibility ' + m.vis.replace('+', '') + ' mi');
      var t = parts.join(', '); return t.charAt(0).toUpperCase() + t.slice(1);
    }
    function mxWxKind(m) {
      var w = m.wx || '';
      if (/TS/.test(w)) return 'ts'; if (/SN|SG|PL|GS|GR/.test(w)) return 'snow'; if (/RA|DZ|SH|UP/.test(w)) return 'rain'; if (/FG|BR|HZ|FU|DU|SA/.test(w)) return 'fog';
      var c = m.sky.map(function (s) { return s[0]; }).join(' ');
      return /OVC|BKN|VV/.test(c) ? 'cloud' : /SCT|FEW/.test(c) ? 'part' : 'clear';
    }
    function mxStations(url) {
      var bb = (url.match(/[?&]bbox=([^&]*)/) || [])[1]; bb = bb ? decodeURIComponent(bb).split(',').map(Number) : [];
      var w = bb[0], n = bb[1], e = bb[2], s = bb[3], z = bb[4] || 5, cell = z <= 3 ? 8 : z === 4 ? 4 : z === 5 ? 2 : z === 6 ? 1 : z === 7 ? 0.5 : z === 8 ? 0.25 : z === 9 ? 0.1 : 0;
      return mxMetarList().then(function (list) {
        var seen = {}, out = [], now = Date.now();
        list.forEach(function (m) {
          if (now - m.t > 3 * 3600e3) return;
          if (isFinite(n) && (m.lat > n || m.lat < s)) return;
          if (isFinite(w) && (w <= e ? (m.lon < w || m.lon > e) : (m.lon < w && m.lon > e))) return;
          if (cell) { var key = Math.floor(m.lat / cell) + ':' + Math.floor(m.lon / cell); if (seen[key]) return; seen[key] = 1; }
          out.push({ id: m.id, name: m.id, lat: String(m.lat), lon: String(m.lon), temperature_value: m.temp == null ? '' : String(m.temp), weather_code: 'tl' + mxWxKind(m) + (mxOp('current') < 100 ? mxOp('current') : ''), daylight: mxDaylight(m.lat, m.lon, now), weather_text: mxWxText(m), raw_text: m.raw });
        });
        mx.data++;
        return out.slice(0, 1500);
      });
    }
    // (1.3) the airports whose weather the monitor gave here (no METAR of their own: FR24's panel had none) as stations of
    // the current-weather layer - in view, none within 12 km of a station already drawn
    var AP_WX_KIND = { clear: 'clear', cloudy: 'part', overcast: 'cloud', fog: 'fog', drizzle: 'rain', rain: 'rain', snow: 'snow', thunderstorm: 'ts' };
    function mxApWxAdd(r, url) {
      var ids = Object.keys(apWx).filter(function (k) { var w = apWxOf(k); return w && w.src === 'model' && fin(w.lat) && fin(w.lon); });
      if (!ids.length || !r || !r.ok) return r;
      var bb = (url.match(/[?&]bbox=([^&]*)/) || [])[1]; bb = bb ? decodeURIComponent(bb).split(',').map(Number) : [];
      var w0 = bb[0], n = bb[1], e = bb[2], s0 = bb[3];
      return r.clone().json().then(function (list) {
        if (!Array.isArray(list)) return r;
        var near = function (w) { return list.some(function (x) { var la = parseFloat(x.lat), lo = parseFloat(x.lon); return fin(la) && fin(lo) && Math.abs(la - w.lat) < 0.11 && Math.abs(lo - w.lon) * Math.cos(w.lat * Math.PI / 180) < 0.11; }); };
        var add = [], now = Date.now();
        ids.forEach(function (k) {
          var w = apWxOf(k);
          if (isFinite(n) && (w.lat > n || w.lat < s0)) return;
          if (isFinite(w0) && (w0 <= e ? (w.lon < w0 || w.lon > e) : (w.lon < w0 && w.lon > e))) return;
          if (near(w)) return;
          var code = w.icao || w.code || String(k), temp = fin(w.tempC) ? String(Math.round(w.tempC)) : '';
          add.push({ id: code, name: w.name || code, lat: String(w.lat), lon: String(w.lon), temperature_value: temp, weather_code: 'tl' + (AP_WX_KIND[w.cond] || 'part') + (mxOp('current') < 100 ? mxOp('current') : ''), daylight: mxDaylight(w.lat, w.lon, now),
            weather_text: (AP_WX_WORD[w.cond] || 'Unknown') + (fin(w.wkts) ? ', wind ' + (w.wkts === 0 ? 'calm' : (fin(w.wdir) ? w.wdir + '° ' : 'variable ') + w.wkts + ' kt') : '') + ' - live weather at the airport (no METAR sent from it)', raw_text: w.metar || '' });
        });
        if (!add.length) return r;
        mx.data++;
        return jsonResponse(r, list.concat(add));
      }, function () { return r; });
    }
    // (the symbols: FR24 asks for /assets/images/weather/velocity/<code><d|n>.png - for the codes given here, drawn here)
    function mxWxIcon(url) {
      var m = url.match(/\/assets\/images\/weather\/velocity\/tl([a-z]+?)(\d*)([dn])\.png/); if (!m) return null;
      var kind = m[1], day = m[3] === 'd', cv = mxCanvas(50, 50), g = cv.getContext('2d');
      g.globalAlpha = m[2] === '' ? 1 : Math.max(0.05, Math.min(1, +m[2] / 100));
      var sun = function (x, y, r) { g.fillStyle = '#ffc61a'; g.strokeStyle = '#ffc61a'; g.lineWidth = 2.5; g.beginPath(); g.arc(x, y, r, 0, 2 * Math.PI); g.fill(); for (var i = 0; i < 8; i++) { var a = i * Math.PI / 4; g.beginPath(); g.moveTo(x + Math.cos(a) * (r + 3), y + Math.sin(a) * (r + 3)); g.lineTo(x + Math.cos(a) * (r + 7), y + Math.sin(a) * (r + 7)); g.stroke(); } };
      var moon = function (x, y, r) { g.fillStyle = '#d9dde8'; g.beginPath(); g.arc(x, y, r, 0, 2 * Math.PI); g.fill(); g.globalCompositeOperation = 'destination-out'; g.beginPath(); g.arc(x + r * 0.55, y - r * 0.35, r * 0.9, 0, 2 * Math.PI); g.fill(); g.globalCompositeOperation = 'source-over'; };
      var cloud = function (x, y, s, col) { g.fillStyle = col || '#eef1f6'; g.strokeStyle = '#8d97a8'; g.lineWidth = 1.5; g.beginPath(); g.arc(x - 9 * s, y + 2 * s, 7 * s, Math.PI * 0.5, Math.PI * 1.5); g.arc(x - 2 * s, y - 5 * s, 9 * s, Math.PI, Math.PI * 1.85); g.arc(x + 9 * s, y + 1 * s, 8 * s, Math.PI * 1.35, Math.PI * 0.5); g.closePath(); g.fill(); g.stroke(); };
      var drops = function (col) { g.strokeStyle = col; g.lineWidth = 2.5; g.lineCap = 'round'; [[16, 36], [25, 39], [34, 36]].forEach(function (p) { g.beginPath(); g.moveTo(p[0], p[1]); g.lineTo(p[0] - 2, p[1] + 6); g.stroke(); }); };
      if (kind === 'clear') { if (day) sun(25, 25, 9); else moon(25, 25, 12); }
      else if (kind === 'part') { if (day) sun(18, 18, 7); else moon(18, 18, 9); cloud(28, 30, 0.85); }
      else if (kind === 'cloud') cloud(25, 26, 1.05);
      else if (kind === 'rain') { cloud(25, 22, 1); drops('#3b82f6'); }
      else if (kind === 'snow') { cloud(25, 22, 1); g.fillStyle = '#9fb7d9'; [[16, 39], [25, 42], [34, 39]].forEach(function (p) { g.beginPath(); g.arc(p[0], p[1], 2.6, 0, 2 * Math.PI); g.fill(); }); }
      else if (kind === 'ts') { cloud(25, 20, 1, '#c9ced9'); g.fillStyle = '#ffb000'; g.beginPath(); g.moveTo(26, 28); g.lineTo(19, 40); g.lineTo(25, 40); g.lineTo(21, 49); g.lineTo(33, 35); g.lineTo(27, 35); g.lineTo(31, 28); g.closePath(); g.fill(); }
      else if (kind === 'fog') { g.strokeStyle = '#9aa3b2'; g.lineWidth = 3; g.lineCap = 'round'; [16, 24, 32].forEach(function (yy, i) { g.beginPath(); g.moveTo(10 + i * 2, yy); g.lineTo(40 - i * 2, yy); g.stroke(); }); }
      else return null;
      return mxResp(cv);
    }

    // ---- AIRMETs and SIGMETs: FR24's own where it answers; else aviationweather.gov's - the US's AIRMETs, SIGMETs and
    // convective SIGMETs, and every country's international SIGMETs - in FR24's own form, its popup filled from them
    var MX_SEV = { 1: 'LT-MOD', 2: 'MOD', 3: 'MOD-SEV', 4: 'SEV', 5: 'SEV' };
    function mxUtc(t) { if (!t) return ''; var d = new Date(typeof t === 'number' && t < 1e12 ? t * 1000 : t); return isNaN(d) ? '' : d.toISOString().slice(0, 16).replace('T', ' ') + ' UTC'; }
    function mxGeom(coords, kind) {
      var c = (coords || []).filter(function (p) { return p && isFinite(p.lat) && isFinite(p.lon); }).map(function (p) { return [+p.lon, +p.lat]; });
      if (!c.length) return null;
      if (kind === 'POINT' || c.length === 1) return { type: 'Point', coordinates: c[0] };
      if (kind === 'LINE' || c.length === 2) return { type: 'LineString', coordinates: c };
      var f = c[0], l = c[c.length - 1]; if (f[0] !== l[0] || f[1] !== l[1]) c.push(f);
      return { type: 'Polygon', coordinates: [c] };
    }
    function mxAirsigList() {
      var one = function (k) { return mxMon('/wx/' + k, false).then(function (t) { return JSON.parse(t); }).catch(function () { return mxJson('https://aviationweather.gov/api/data/' + k + '?format=json', 600000); }).catch(function () { return []; }); };
      return Promise.all([one('airsigmet'), one('isigmet')]).then(function (r) {
        var out = [];
        (Array.isArray(r[0]) ? r[0] : []).forEach(function (a, i) {
          var g = mxGeom(a.coords); if (!g) return;
          var hz = String(a.hazard || 'UNKNOWN').toUpperCase(); hz = hz === 'ASH' ? 'VA' : hz === 'MTN OBSCN' || hz === 'IFR' || hz === 'CONVECTIVE' || hz === 'TURB' || hz === 'ICE' || hz === 'LLWS' ? hz : hz;
          out.push({ id: 'us' + i + '_' + (a.seriesId || ''), airmet_type: String(a.airSigmetType || 'SIGMET').toUpperCase() === 'OUTLOOK' ? 'SIGMET' : String(a.airSigmetType || 'SIGMET').toUpperCase(), altitude_min_units: a.altitudeLow1 != null ? 'ft' : '', altitude_min_value: a.altitudeLow1 != null ? String(a.altitudeLow1) : '', altitude_max_units: a.altitudeHi1 != null ? 'ft' : '', altitude_max_value: a.altitudeHi1 != null ? String(a.altitudeHi1) : '', hazard_qualifier: '', hazard_severity: MX_SEV[a.severity] || 'NONE', hazard_type: hz, issuer_icao: a.icaoId || 'KKCI', meta_from: mxUtc(a.creationTime || a.receiptTime), movement_direction_units: a.movementDir != null ? 'deg' : '', movement_direction_value: a.movementDir != null ? String(a.movementDir) : '', movement_speed_units: a.movementSpd != null ? 'kt' : '', movement_speed_value: a.movementSpd != null ? String(a.movementSpd) : '', raw_text: a.rawAirSigmet || '', region_id: a.icaoId || '', region_name: 'United States', valid_begin: mxUtc(a.validTimeFrom), valid_end: mxUtc(a.validTimeTo), geometry: JSON.stringify(g) });
        });
        (Array.isArray(r[1]) ? r[1] : []).forEach(function (a, i) {
          var g = mxGeom(a.coords, a.geom); if (!g) return;
          var hz = String(a.hazard || 'UNKNOWN').toUpperCase(), ql = String(a.qualifier || '').toUpperCase().split(/[\s-]+/)[0];
          var q = { OBSC: 1, EMBD: 1, FRQ: 1, SQL: 1, ISOL: 1, SEV: 1 }[ql] ? ql : '';
          var type = /^TS|^TSGR/.test(hz) && /OBSC|EMBD|FRQ|SQL/.test(q) ? q + ' ' + hz : q === 'SEV' && /^(TURB|ICE|MTW)$/.test(hz) ? 'SEV ' + hz : hz;
          out.push({ id: 'in' + i + '_' + (a.firId || '') + (a.seriesId || ''), airmet_type: 'SIGMET', altitude_min_units: a.base != null ? 'ft' : '', altitude_min_value: a.base != null ? String(a.base) : '', altitude_max_units: a.top != null ? 'ft' : '', altitude_max_value: a.top != null ? String(a.top) : '', hazard_qualifier: q, hazard_severity: q === 'SEV' ? 'SEV' : 'NONE', hazard_type: type, issuer_icao: a.icaoId || '', meta_from: mxUtc(a.receiptTime), movement_direction_units: a.dir ? 'deg' : '', movement_direction_value: a.dir ? String(a.dir) : '', movement_speed_units: a.spd ? 'kt' : '', movement_speed_value: a.spd ? String(a.spd) : '', raw_text: a.rawSigmet || '', region_id: a.firId || '', region_name: a.firName || a.firId || '', valid_begin: mxUtc(a.validTimeFrom), valid_end: mxUtc(a.validTimeTo), geometry: JSON.stringify(g) });
        });
        mx.data++;
        return out;
      });
    }

    // ---- oceanic tracks: FR24's own where it answers; else the North Atlantic tracks from the day's NAT messages (the
    // monitor's copy, else the FAA's own list) - each track's points in latitude/longitude (its named entry and exit
    // points left out)
    function mxNatParse(text, into) {
      var t = String(text || '').replace(/<[^>]+>/g, '\n').replace(/&nbsp;/g, ' '), out = into || {}, valid = (t.match(/([A-Z]{3}\s+\d{2}\/\d{4}Z)\s+TO\s+([A-Z]{3}\s+\d{2}\/\d{4}Z)/) || []);
      var lines = t.split('\n').map(function (l) { return l.trim(); }), cur = null;
      lines.forEach(function (l) {
        var m = l.match(/^([A-Z])\s+([A-Z0-9/]+(?:\s+[A-Z0-9/]+)*)$/);
        if (m && /\d{2}(?:\d{2})?\/\d{2,3}/.test(m[2])) {
          var pts = {}, n = 0;
          m[2].split(/\s+/).forEach(function (w) { var c = w.match(/^(\d{2})(\d{2})?\/(\d{2,3})(\d{2})?$/); if (c) pts[n++] = { lat: +c[1] + (+c[2] || 0) / 60, lon: -(+c[3] + (+c[4] || 0) / 60), name: w }; });
          if (n >= 2) { cur = out[m[1]] = { n: m[1], d: 'WEST', p: pts, from: valid[1] || '', until: valid[2] || '' }; return; }
        }
        if (cur && /^EAST LVLS/.test(l) && !/NIL/.test(l)) cur.d = 'EAST';
      });
      return out;
    }
    // (the FAA's list: a message per part, each part with its own validity - the parts of one message read together)
    function mxNatList(list) {
      var out = {}, by = {};
      (Array.isArray(list) ? list : []).forEach(function (m) { if (!m || typeof m.condition_message !== 'string') return; var k = (m.location_code || '') + '|' + (m.start_datetime || ''); (by[k] = by[k] || []).push([+m.part_no || 0, m.condition_message]); });
      Object.keys(by).forEach(function (k) { mxNatParse(by[k].sort(function (a, b) { return a[0] - b[0]; }).map(function (p) { return p[1]; }).join('\n'), out); });
      return out;
    }
    function mxTrackOk(j) { return !!j && typeof j === 'object' && Object.keys(j).some(function (k) { var t = j[k]; return t && t.p && typeof t.p === 'object' && Object.keys(t.p).length >= 2; }); }
    function mxTracks() {
      return mxMon('/wx/nat', false).then(function (t) { var o = JSON.parse(t); if (!mxTrackOk(o)) throw new Error('no tracks'); return o; })
        .catch(function () { return mxGet('https://nms.aim.faa.gov/datanat/nat.json', false).then(function (t) { var o = mxNatList(JSON.parse(t)); if (!mxTrackOk(o)) throw new Error('no tracks'); return o; }); })
        .then(function (o) { mx.data++; return o; });
    }
    // (1.3) the Pacific's organised tracks (PACOTS) beside them - the monitor's, from the day's Track Definition Messages of
    // Oakland, Fukuoka and Anchorage (wxmap.cjs pacParse) - in FR24's own answer or in the one made here; none: the NAT's
    // as they were
    var mxPac = { at: 0, o: null };
    // (1.3.7) the tracks still in force, of a set as the monitor or the parser below gives them
    function mxPacLive(o) {
      var now = Date.now(), out = {};
      Object.keys(o || {}).forEach(function (k) { var x = o[k]; if (/^PAC-/.test(k) && x && x.p && Object.keys(x.p).length >= 2 && !(x.until && Date.parse(x.until) < now)) out[k] = x; });
      return out;
    }
    function mxPacots() {
      if (mxPac.o && Date.now() - mxPac.at < 10 * 60000 && Object.keys(mxPac.o).length) return Promise.resolve(mxPac.o);
      return mxMon('/wx/pacots', false).then(function (t) { var out = mxPacLive(JSON.parse(t)); if (!Object.keys(out).length) throw new Error('none'); return out; })
        // (1.3.7: the monitor with none - the FAA's NOTAM Search refuses servers in data centres: the monitor's never had
        // them - the FAA's own messages asked from this browser through the userscript, kept half an hour)
        .catch(function () { return mxPacFaa(); })
        .then(function (out) { if (Object.keys(out).length) mxPac = { at: Date.now(), o: out }; return out; }, function () { return mxPac.o || {}; });
    }
    // (1.3.7) The day's Track Definition Messages (TDM) of Oakland, Fukuoka and Anchorage, read as the monitor reads them
    // (monitor/wxmap.cjs pacParse): its track (letters westbound, numbers eastbound), its times (YYMMDDHHMM from / until),
    // the positions of its route (40N150W, 4130N15000W) - the named fixes at its ends left out, as the NAT's are
    function mxPacPoint(w) {
      var c = String(w).match(/^(\d{2})(\d{2})?([NS])(\d{3})(\d{2})?([EW])$/); if (!c) return null;
      var lat = (+c[1] + (+c[2] || 0) / 60) * (c[3] === 'S' ? -1 : 1), lon = (+c[4] + (+c[5] || 0) / 60) * (c[6] === 'W' ? -1 : 1);
      return lat <= 90 && Math.abs(lon) <= 180 ? { lat: lat, lon: lon, name: w } : null;
    }
    function mxPacTime(s) { var m = String(s).match(/^(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/); return m ? Date.UTC(2000 + +m[1], +m[2] - 1, +m[3], +m[4], +m[5]) : NaN; }
    function mxPacParse(text, out, nowMs) {
      out = out || {}; nowMs = nowMs || Date.now();
      var t = String(text || '').replace(/<[^>]+>/g, '\n').replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&').replace(/\r/g, '');
      var re = /TDM\s+TRK\s+([A-Z0-9]{1,2})\s+(\d{12})?([\s\S]*?)(?=TDM\s+TRK\s|$)/g, m;
      while ((m = re.exec(t))) {
        var id = m[1], body = m[3], times = body.match(/(\d{10})\s+(\d{10})/), from = times ? mxPacTime(times[1]) : NaN, until = times ? mxPacTime(times[2]) : NaN;
        if (isFinite(until) && until < nowMs) continue;
        var route = body.replace(/^[\s\S]*?\d{10}\s+\d{10}/, '').split(/\b(?:RTS|RMK)\//)[0], pts = {}, n = 0;
        route.split(/[\s)]+/).forEach(function (w) { var p = mxPacPoint(w); if (p) pts[n++] = p; });
        if (n < 2) continue;
        for (var k = 1; k < n; k++) { while (pts[k].lon - pts[k - 1].lon > 180) pts[k].lon -= 360; while (pts[k].lon - pts[k - 1].lon < -180) pts[k].lon += 360; }
        var key = 'PAC-' + id, prev = out[key];
        if (prev && prev.at >= (from || 0)) continue;
        out[key] = { n: id, d: /^\d+$/.test(id) ? 'EAST' : 'WEST', p: pts, from: isFinite(from) ? new Date(from).toISOString() : '', until: isFinite(until) ? new Date(until).toISOString() : '', at: from || 0, pac: 1 };
      }
      return out;
    }
    // (FAA PilotWeb's page of the Pacific tracks - the FAA's own link to them - else NOTAM Search's messages of the three
    // oceanic centres; asked at most every 10 minutes when neither answers)
    var mxPacAsked = 0;
    function mxPacFaa() {
      try { var kept = JSON.parse(lsGet('tl.pac') || 'null'); if (kept && Date.now() - kept.at < 30 * 60000) { var ko = mxPacLive(kept.o); if (Object.keys(ko).length) return Promise.resolve(ko); } } catch (e) { /* none kept */ }
      if (Date.now() - mxPacAsked < 10 * 60000) return Promise.resolve({});
      mxPacAsked = Date.now();
      var keep = function (o) { o = mxPacLive(o); if (Object.keys(o).length) lsSet('tl.pac', JSON.stringify({ at: Date.now(), o: o })); return o; };
      return mxGet(MX_PILOTWEB_PAC, false, 40000).then(function (t) { var o = mxPacParse(t); if (!Object.keys(o).length) throw new Error('no tracks'); return keep(o); })
        .catch(function () {
          var out = {}, locs = ['KZAK', 'RJJJ', 'PAZA'];
          // (each centre's messages a page of 30 at a time, as many as it has - 600 at most)
          var one = function (i, off) {
            if (i >= locs.length) return Promise.resolve(out);
            return mxGet('notams:' + locs[i] + ':' + off, false, 40000).then(function (t) {
              var j = JSON.parse(t), total = Number(j && j.totalNotamCount) || 0;
              (j && Array.isArray(j.notamList) ? j.notamList : []).forEach(function (x) { var s = String((x && (x.icaoMessage || x.traditionalMessage)) || ''); if (/TDM\s+TRK/.test(s)) mxPacParse(s, out); });
              return off + 30 < Math.min(total, 600) ? one(i, off + 30) : one(i + 1, 0);
            }, function () { return one(i + 1, 0); });
          };
          return one(0, 0).then(keep);
        });
    }
    var MX_PILOTWEB_PAC = 'https://pilotweb.nas.faa.gov/PilotWeb/noticesAction.do?queryType=PACIFICTRACKS&formatType=ICAO';
    function mxTracksPac(r) {
      if (!r || !r.ok) return r;
      return Promise.all([r.clone().json().catch(function () { return null; }), mxPacots()]).then(function (x) {
        var j = x[0], pac = x[1]; if (!j || typeof j !== 'object' || Array.isArray(j) || !Object.keys(pac).length) return r;
        var out = Object.assign({}, j); Object.keys(pac).forEach(function (k) { if (!(k in out)) out[k] = pac[k]; });
        return jsonResponse(r, out);
      }, function () { return r; });
    }

    // ---- (1.2.0) transparency for the layers FR24 gives no opacity slider of its own: winds, high-level significant weather,
    // the current weather's symbols (drawn here: faded as they are drawn, the layer shown again at once), ATC boundaries
    // and the aeronautical charts (FR24's own pictures: faded where they are shown). A slider like FR24's own under each,
    // kept in this browser.
    var MX_OP_KEY = 'tl.mx.opacity', mxOps = (function () { try { var o = JSON.parse(localStorage.getItem(MX_OP_KEY) || '{}'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } })();
    function mxOp(k) { var v = Number(mxOps[k]); return isFinite(v) && v >= 5 && v <= 100 ? Math.round(v) : 100; }
    function mxFade(cv, op) { if (op >= 100) return cv; var o = mxCanvas(cv.width, cv.height), g = o.getContext('2d'); g.globalAlpha = op / 100; g.drawImage(cv, 0, 0); return o; }
    function mxOpCss() {
      var st = document.getElementById('tl-mx-opacity'); if (!st) { st = document.createElement('style'); st.id = 'tl-mx-opacity'; (document.head || document.documentElement).appendChild(st); }
      st.textContent = 'img[src*="tiles.flightradar24.com/atc_boundaries"]{opacity:' + mxOp('atc') / 100 + '!important}' +
        'img[src*="tiles.flightradar24.com/navdata_"],img[src*="tiles.flightradar24.com/navaid/"]{opacity:' + mxOp('charts') / 100 + '!important}' +
        '.tl-mx-op{margin-top:.75rem;font-size:.875rem;color:#2c2c2c}.tl-mx-op .tl-mx-oh{display:flex;justify-content:space-between;margin-bottom:.35rem}.tl-mx-op .tl-mx-oh b{font-weight:600}' +
        '.tl-mx-op input{width:100%;accent-color:#fbbf24;cursor:pointer;margin:0}';
    }
    // (the drawn layers shown again with the new value: switched off and on in FR24's own settings - no tile is fetched again)
    var MX_OP_LAYERS = { sigwx: ['sigwx'], current: ['current'] }, mxOpT = 0;
    // Winds: FR24 shows its own wind layer at a fixed 7% (barbs) or 22% (gradient) opacity - right for DTN's pictures, too
    // faint for anything else - so its tiles are left empty and the same winds drawn as a layer of this script's own on the
    // Google map, following FR24's own switch and altitude slider, at the opacity chosen here.
    var mxWindSlot = -1, mxWindSig = '';
    function mxWindType(barbs, kft, op) {
      return { tileSize: new window.google.maps.Size(256, 256), maxZoom: 22, minZoom: 0, name: 'tl-winds',
        getTile: function (c0, zoom, doc) {
          var c = doc.createElement('canvas'), n = Math.pow(2, zoom), x = ((c0.x % n) + n) % n; c.width = c.height = 256; c.style.width = c.style.height = '256px';
          if (c0.y >= 0 && c0.y < n) mxWinds(zoom, x, c0.y, kft, Date.now(), barbs).then(function (cv) { var g = c.getContext('2d'); g.globalAlpha = op / 100; g.drawImage(cv, 0, 0); }, mxFail);
          return c;
        },
        releaseTile: function () { /* nothing kept */ } };
    }
    function mxWindSync() {
      try {
        var p = mxPinia(), st = p && p._s.get('settings'), w = st && st.weather, cfg = st && st.weatherConfig, wr = mxWrapper(), map = wr && wr.getMap();
        if (!w || !map || !window.google || !window.google.maps) return;
        var mode = w.windBarbs ? 'b' : w.windGradient ? 'g' : '', kft = Math.max(1, Number(cfg && cfg.windAltitude) || 1), op = mxOp('wind');
        var sig = mode ? [mode, kft, op, Math.floor(Date.now() / 3600e3)].join('|') : '';
        if (sig === mxWindSig) return; mxWindSig = sig;
        var ov = map.overlayMapTypes;
        if (mxWindSlot < 0 || mxWindSlot >= ov.getLength()) { if (!mode) return; ov.push(null); mxWindSlot = ov.getLength() - 1; }
        ov.setAt(mxWindSlot, mode ? mxWindType(mode === 'b', kft, op) : null);
      } catch (e) { mxFail(e); }
    }
    if (mx.on) setInterval(mxWindSync, 1000);
    function mxRedraw(k) {
      var keys = MX_OP_LAYERS[k]; if (!keys) return;
      oClearTimeout(mxOpT);
      mxOpT = oSetTimeout(function () {
        try {
          var p = mxPinia(), st = p && p._s.get('settings'), w = st && st.weather; if (!w) return;
          keys.forEach(function (n) { if (w[n]) { st.set('weather', n, false); oSetTimeout(function () { st.set('weather', n, true); }, 80); } });
        } catch (e) { mxFail(e); }
      }, 450);
    }
    var MX_OP_SPOTS = [['wind', '[data-testid="weather-windSpeed"]'], ['sigwx', '[data-testid="weather-sigwx"]'], ['current', '[data-testid="weather-current"]'],
      ['atc', '[data-testid="settings__map__atc-boundaries__none"]'], ['charts', '[data-testid="settings__map__nav-data__none"]']];
    function mxOpSliders() {
      MX_OP_SPOTS.forEach(function (sp) {
        var el = document.querySelector(sp[1]); if (!el) return;
        var box = el.matches('[data-testid^="weather-"]') ? el : (el.closest('.border-b-2') || (el.parentElement && el.parentElement.parentElement) || el.parentElement);
        if (!box || box.querySelector('.tl-mx-op')) return;
        var d = document.createElement('div'); d.className = 'tl-mx-op'; d.setAttribute('data-testid', 'tl-mx-opacity__' + sp[0]);
        d.innerHTML = '<div class="tl-mx-oh"><b>Opacity</b><span></span></div><input type="range" min="5" max="100" step="5">';
        var inp = d.querySelector('input'), lab = d.querySelector('span');
        inp.value = String(mxOp(sp[0])); lab.textContent = inp.value + '%';
        inp.addEventListener('input', function () { mxOps[sp[0]] = +inp.value; lab.textContent = inp.value + '%'; try { localStorage.setItem(MX_OP_KEY, JSON.stringify(mxOps)); } catch (e) { /* full */ } mxOpCss(); });
        inp.addEventListener('change', function () { mxRedraw(sp[0]); });
        box.appendChild(d);
      });
    }
    if (mx.on) {
      mxOpCss();
      // (looked at once in 300 ms at most, however busy the page - not at every change: the map changes all the time)
      var mxOpDue = false, mxOpMo = new MutationObserver(function () { if (mxOpDue) return; mxOpDue = true; oSetTimeout(function () { mxOpDue = false; if (document.querySelector('[data-testid="weather-current"],[data-testid="settings__map__atc-boundaries__none"]')) mxOpSliders(); }, 300); });
      (function watch() { if (document.body) mxOpMo.observe(document.body, { childList: true, subtree: true }); else oSetTimeout(watch, 50); })();
    }

    // ---- FR24's weather "authorization": its products all available, the tile server named as this script; a new
    // "date" each hour (FR24 asks for its tiles again), the forecast times FR24's sliders offer
    var MX_TYPES = ['volcanic-eruption', 'basic-weater', 'C09-0x0316-0', 'gfs-preciprate-inph-surface', 'C09-0x0374-0', 'north-american-radar', 'C50-0x030F-0', 'gfs-halfdeg-windvector-1kft-msl', 'gfs-halfdeg-windspeed-kts-1kft-msl', 'lightning', 'airmets-and-sigmets', 'sigwx-high', 'wafs-hires-icing-fl060', 'wafs-hires-turbulence-fl100'];
    function mxIso(t) { return new Date(t).toISOString().slice(0, 19) + 'Z'; }
    function mxAuth() {
      var now = Date.now(), hour = Math.floor(now / 3600e3) * 3600e3, meta = mxIso(hour);
      return mxWafsRun().catch(function () { return Math.floor((now - 6 * 3600e3) / 21600e3) * 21600e3; }).then(function (run) {
        var md = {}, every = function (from, step, n) { var a = []; for (var i = 0; i < n; i++) a.push(mxIso(from + i * step)); return a; };
        MX_TYPES.forEach(function (k) { md[k] = { metaDate: meta, validTimes: [meta], refreshRate: 600 }; });
        md['gfs-halfdeg-windvector-1kft-msl'].validTimes = md['gfs-halfdeg-windspeed-kts-1kft-msl'].validTimes = every(hour, 3 * 3600e3, 9);
        var w0 = Math.max(run + 6 * 3600e3, Math.floor(now / 10800e3) * 10800e3), wt = [];
        for (var t = w0; t <= run + 36 * 3600e3; t += 10800e3) wt.push(mxIso(t));
        md['wafs-hires-icing-fl060'].validTimes = md['wafs-hires-turbulence-fl100'].validTimes = wt.length ? wt : [meta];
        md['sigwx-high'].validTimes = wt.filter(function (x, i) { return i % 2 === 0; }).slice(0, 5);
        md.lightning.refreshRate = 60;
        mx.data++;
        return { data: { endpoints: ['tl-wx.invalid'], key: 'tl', signature: 'tl=1', metadates: md } };
      });
    }
    // (FR24's own answer first, for what FR24 may serve any account; its refusal, an error or an empty answer: built here)
    function mxOwnOr(input, init, ok, build) {
      return oFetch.call(window, input, init).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.clone().json().then(function (j) { if (ok(j)) return r; throw new Error('empty'); });
      }).catch(function () { return build().then(function (o) { return jsonResponse(null, o); }); });
    }
    // ---- (1.2.1) Bookmarks without a limit: FR24 gives a free account one ("map.widgets.bookmarks.max": 1 in its page's
    // features) - raised there, so its widget takes as many as wanted; and where FR24's server keeps no more, the rest are
    // kept in this browser, in FR24's own form, and listed with FR24's own as one list
    // (1.2.4: FR24's own types are "aircraft", "flights", "airports", "locations" - 1.2.1 knew only the first by its own name, so
    // a flight, airport or place past the limit came back as FR24's error, "Unable to add bookmark")
    var MX_BM_KEY = 'tl.mx.bookmarks', MX_BM_LISTS = { aircraft: 'aircraft', flight: 'flights', flights: 'flights', airport: 'airports', airports: 'airports', location: 'locations', locations: 'locations' };
    var MX_BM_ALL = ['aircraft', 'flights', 'airports', 'locations'];
    // (1.2.3) FR24's widget asks its user store - feature("map.widgets.bookmarks.max") - and keeps the answer. The store
    // holds its own copy of the features (and a signed-in account's are fetched again after sign-in, never in the page's
    // props), so the limit is raised in the stores themselves, through their reactive state: FR24's widget then reads 1000
    var MX_BM_MAX = 'map.widgets.bookmarks.max';
    var mxBmLow = function (f) { return !!f && typeof f === 'object' && MX_BM_MAX in f && !(f[MX_BM_MAX] >= 1000); };
    function mxBmMax() {
      try {
        var el = document.getElementById('app'), app = el && el.__vue_app__, pg = app && app.config && app.config.globalProperties && app.config.globalProperties.$page, pr = pg && pg.props;
        [pr && pr.features, pr && pr.dispatcher && pr.dispatcher.features].forEach(function (f) { if (mxBmLow(f)) f[MX_BM_MAX] = 1000; });
        var p = mxPinia(); if (!p) return;
        var ds = p._s.get('dispatcher'), d = ds && ds.dispatcher;
        if (d && mxBmLow(d.features)) d.features[MX_BM_MAX] = 1000;
        if (d && d.userData && mxBmLow(d.userData.features)) d.userData.features[MX_BM_MAX] = 1000;
        var us = p._s.get('user');
        // (its reading of the limit answered 1000 itself - so a fresh copy of the features, set by FR24 at any moment, is
        // never read as one even for the moment before it is raised here)
        if (us && typeof us.feature === 'function' && !us.feature.__tl) {
          var own = us.feature, mine = function (k) { var v = own.apply(this, arguments); return k === MX_BM_MAX && typeof v === 'number' && v < 1000 ? 1000 : v; };
          mine.__tl = true; us.feature = mine;
        }
        if (us && mxBmLow(us.features)) { var nf = Object.assign({}, us.features); nf[MX_BM_MAX] = 1000; us.features = nf; }
        mx.bmMax = us && us.features ? us.features[MX_BM_MAX] : null;
      } catch (e) { /* not drawn yet */ }
    }
    if (mx.on) { setInterval(mxBmMax, 1500); [300, 800, 1500].forEach(function (t) { oSetTimeout(mxBmMax, t); }); }
    // ---- (1.2.3) "Last clicked flights": FR24 notes a flight opened only for a premium account, and keeps the list on its
    // server (/restapi/v1/widgets/last-clicked-flights), which keeps none for a free one. Kept here instead: each flight
    // opened on the live map, newest first, ten at most, in the form FR24's server gives them - and FR24's widget asks
    // this list for them
    var MX_LC_KEY = 'tl.mx.lastclicked', MX_LC_MAX = 10, mxLcSeen = null;
    function mxLcList() { try { var a = JSON.parse(localStorage.getItem(MX_LC_KEY) || '[]'); return Array.isArray(a) ? a.filter(function (x) { return x && x.id != null; }) : []; } catch (e) { return []; } }
    function mxLcSave(a) { try { localStorage.setItem(MX_LC_KEY, JSON.stringify(a.slice(0, MX_LC_MAX))); } catch (e) { /* full */ } }
    // (1.2.9) A flight's id as FR24's widget has it - its hex, as FR24 writes ids (Number(id).toString(16), at least six
    // figures): its click opens the flight by that string (showInfoPanel lower-cases it). Kept here as the number; given
    // to FR24 as the string - the number made its click throw before it did anything, every flight in the air "dead"
    var lcNum = function (v) { return typeof v === 'number' ? v : /^[0-9a-f]{1,12}$/i.test(String(v == null ? '' : v)) ? parseInt(String(v), 16) : NaN; };
    var lcHex = function (v) { var n = typeof v === 'number' ? v : lcNum(v); return n > 0 ? n.toString(16).padStart(6, '0').toLowerCase() : String(v == null ? '' : v); };
    function mxLcOut(list) { return list.slice(0, MX_LC_MAX).map(function (x) { var o = Object.assign({}, x); o.id = lcHex(x.id); return o; }); }
    function mxLcAirport(a) {
      if (!a || typeof a !== 'object') return { code: { iata: null, icao: null }, city: null, name: null };
      var c = a.code && typeof a.code === 'object' ? a.code : {}, pos = a.position || {}, reg = pos.region || {};
      return { code: { iata: c.iata || a.iata || null, icao: c.icao || a.icao || null }, city: a.city || reg.city || null, name: a.name || null };
    }
    // (the flight open in FR24's panel, as an entry of the list)
    function mxLcItem(ac) {
      var s = ac && ac.selected, fi = s && s.flightInfo; if (!fi || fi.flightId == null) return null;
      var ai = s.aircraftInfo || {}, sc = s.scheduleInfo || {}, id = Number(fi.flightId); if (!(id > 0)) return null;
      // (1.3.12: its aircraft's address too - FR24's icaoAddress, a number - for the tag in the widget's row)
      var hexA = typeof ai.icaoAddress === 'number' && ai.icaoAddress > 0 && ai.icaoAddress < 0x1000000 ? ai.icaoAddress.toString(16).padStart(6, '0') : null;
      return { id: id, hex: hexA, callsign: fi.callsign || null, flight: sc.flightNumber || null, type: ai.type || null, registration: ai.reg || null,airport: { origin: mxLcAirport(ac.selectedFlightOriginAirport), destination: mxLcAirport(ac.selectedFlightDestinationAirport) } };
    }
    // (1.2.6: never worse than it was - a blocked flight's name, aircraft and airports, once known, are kept: FR24's panel
    // shows "N/A" for a moment as it opens one, and nothing of it once it has landed. What this script knows of the flight
    // - its name, its route - put in where FR24 had nothing)
    var mxLcBlank = function (v) { return v == null || v === '' || v === 'N/A'; };
    function mxLcAp(x) { var a = x && typeof x === 'object' ? x : {}, c = a.code && typeof a.code === 'object' ? a.code : {}; return { code: { iata: mxLcBlank(c.iata) ? null : c.iata, icao: mxLcBlank(c.icao) ? null : c.icao }, city: mxLcBlank(a.city) ? null : a.city, name: mxLcBlank(a.name) ? null : a.name }; }
    function mxLcMerge(old, it) {
      if (!old || Number(old.id) !== Number(it.id)) return it;
      ['callsign', 'flight', 'type', 'registration', 'hex'].forEach(function (k) { if (mxLcBlank(it[k]) && !mxLcBlank(old[k])) it[k] = old[k]; });
      var oa = old.airport || {}, na = it.airport || (it.airport = {});
      ['origin', 'destination'].forEach(function (k) { var o = mxLcAp(oa[k]), n = mxLcAp(na[k]); na[k] = n.code.iata || n.code.icao ? n : o.code.iata || o.code.icao ? o : n; });
      return it;
    }
    function mxLcFill(it) {
      if (!it || it.id == null) return it;
      var id = Number(it.id), rec = resolved.get(id) || naRecs.get(id), rt = routeNow(id) || null;
      it.airport = it.airport || {}; it.airport.origin = mxLcAp(it.airport.origin); it.airport.destination = mxLcAp(it.airport.destination);
      if (rec) {
        var cs = csOf(rec);
        if (mxLcBlank(it.callsign) && cs) it.callsign = cs;
        if (mxLcBlank(it.registration) && rec.reg) it.registration = rec.reg;
        if (mxLcBlank(it.type) && rec.type) it.type = rec.type;
        if (mxLcBlank(it.hex) && rec.hex) it.hex = String(rec.hex).toLowerCase();
      }
      if (rt) [['origin', 'origin'], ['destination', 'dest']].forEach(function (p) {
        var a = it.airport[p[0]], code = rt[p[1] + 'Iata'], city = rt[p[1] + 'City'];
        if (!a.code.iata && !a.code.icao && code) { a.code = { iata: String(code), icao: null }; if (city) a.city = city; }
        else if (!a.city && city && (a.code.iata === code || a.code.icao === code)) a.city = city;
      });
      return it;
    }
    function mxLcShow(list) { try { var p = mxPinia(), lc = p && p._s.get('lastClickedFlights'); if (lc && typeof lc.setList === 'function') lc.setList(mxLcOut(list)); } catch (e) { /* not drawn */ } }
    function mxLcTick() {
      try {
        var pb = pinStore('playback'); if (pb && pb.active) return;
        var it = mxLcItem(pinStore('aircraft')); if (!it) { mxLcSeen = null; return; }
        var list = mxLcList(), at = list.findIndex(function (x) { return Number(x.id) === it.id; });
        it = mxLcFill(mxLcMerge(at >= 0 ? list[at] : null, it));
        var key = JSON.stringify(it);
        if (mxLcSeen === key) return;
        var fresh = mxLcSeen == null || mxLcSeen.indexOf('{"id":' + it.id + ',') !== 0;
        mxLcSeen = key;
        if (at === 0 && JSON.stringify(list[0]) === key) return;
        // (a flight opened anew goes to the top; the open one's details, as they come, replace its own entry where it is)
        if (fresh || at < 0) { if (at >= 0) list.splice(at, 1); list.unshift(it); } else list[at] = it;
        mxLcSave(list); mxLcShow(list);
      } catch (e) { /* no panel */ }
    }
    if (mx.on) setInterval(mxLcTick, 1000);
    // (1.2.6) An entry clicked: FR24 takes the map back to it while it is in the air (its own "live" mark on it); one that
    // has landed opens its aircraft's log page - as FR24 opens a page from the widget, in a new tab - a blocked flight's
    // too, by the registration kept with it (FR24 would open nothing: it has no flight number, no registration of it)
    // (FR24's own address of a flight in the air: /<callsign>/<its id in hex>)
    function mxLcLiveUrl(x, id) { var cs = String((x && x.callsign) || '').replace(/[^A-Za-z0-9]/g, ''); return '/' + (cs ? cs + '/' : '') + Number(id).toString(16); }
    function onLcClick(ev) {
      if (!mx.on || (ev.type === 'click' && ev.button) || (ev.type === 'auxclick' && ev.button !== 1)) return;
      var t = ev.target && ev.target.nodeType === 1 ? ev.target : ev.target && ev.target.parentElement; if (!t || !t.closest) return;
      var item = t.closest('.cursor-pointer'); if (!item || !item.querySelector('[data-testid="last-clicked__callsign"]')) return;
      var box = item.parentElement, items = box ? [].filter.call(box.children, function (c) { return c.querySelector && c.querySelector('[data-testid="last-clicked__callsign"]'); }) : [], i = items.indexOf(item);
      var shown = null; try { var p = mxPinia(), lc = p && p._s.get('lastClickedFlights'); shown = lc && Array.isArray(lc.list) ? lc.list : null; } catch (e) { shown = null; }
      var x = (shown || mxLcList())[i]; if (!x) return;
      // (still in the air: FR24's own click - the flight selected on the map, the page kept - now that its widget has the
      // id in FR24's own form; a new tab: FR24's own address of the flight)
      if (item.querySelector('[data-testid="last-clicked__live"]')) {
        if (ev.type === 'auxclick' || ev.ctrlKey || ev.metaKey || ev.shiftKey) { var lid = lcNum(x.id); if (lid > 0) { ev.preventDefault(); ev.stopImmediatePropagation(); window.open(mxLcLiveUrl(x, lid), '_blank', 'noopener'); } }
        return;
      }
      var xid = lcNum(x.id), kept = mxLcList().filter(function (k) { return lcNum(k.id) === xid; })[0] || {};
      var reg = [x.registration, kept.registration].filter(function (v) { return !mxLcBlank(v); })[0];
      if (!reg) { var rec = resolved.get(xid); reg = rec && rec.reg; }
      if (!reg) return;
      ev.preventDefault(); ev.stopImmediatePropagation();
      window.open('/data/aircraft/' + encodeURIComponent(String(reg).toLowerCase()), '_blank', 'noopener');
    }
    if (mx.on) { document.addEventListener('click', onLcClick, true); document.addEventListener('auxclick', onLcClick, true); }
    // (FR24's widget asking its server for the list - or setting it: the order given, or none)
    function mxLastClicked(input, init) {
      var method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase(), list = mxLcList();
      // (each with what is known of it now - kept so: the name of a blocked flight stays with it)
      { var was = JSON.stringify(list); list = list.map(function (x) { return mxLcFill(x); }); if (JSON.stringify(list) !== was) mxLcSave(list); }
      if (method === 'PUT') {
        var body = mxBmBody(input, init), ids = body && Array.isArray(body.last_clicked_flights) ? body.last_clicked_flights.map(function (v) { return lcNum(v && typeof v === 'object' ? v.id : v); }) : null;
        if (ids) {
          var by = {}; list.forEach(function (x) { by[lcNum(x.id)] = x; });
          list = ids.map(function (i) { return by[i] || null; }).filter(Boolean);
          mxLcSave(list);
        }
      }
      return Promise.resolve(jsonResponse(null, { last_clicked_flights: { items: mxLcOut(list) } }));
    }
    function mxBmKept() { try { var o = JSON.parse(localStorage.getItem(MX_BM_KEY) || '{}'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
    function mxBmSave(o) { try { localStorage.setItem(MX_BM_KEY, JSON.stringify(o)); } catch (e) { /* full */ } }
    // (an item's key as FR24's widget has it: registration, flight number, IATA code - a place's id, which FR24 removes it by)
    var mxBmId = function (list, it) { return String(list === 'aircraft' ? it.registration : list === 'flights' ? it.flight_number : list === 'airports' ? (it.code && (it.code.iata || it.code.icao)) : (it.id != null ? it.id : it.name || it.identifier) || '').toUpperCase(); };
    function mxBmItem(b) {
      var id = String(b.identifier || '').toUpperCase(), t = MX_BM_LISTS[String(b.type || '').toLowerCase()];
      if (t === 'aircraft') return { registration: id, type: null, callsign: null, flight_id: null, flight_number: null, airport: null, __tl: 1 };
      if (t === 'flights') return { flight_number: id, flight_id: null, registration: null, type: null, airport: null, eta: null, __tl: 1 };
      if (t === 'airports') return { code: { iata: id, icao: '' }, name: id, timezone: { abbr: '' }, weather: null, __tl: 1 };
      if (t === 'locations') {
        // (a place: FR24 sends its name, position and zoom, and gives it an id of its own - one made here from where it is)
        var lc = b.location && typeof b.location === 'object' ? b.location : {}, la = Number(lc.lat), lo = Number(lc.lon);
        if (!isFinite(la) || !isFinite(lo)) return null;
        return { id: 'tl-' + Math.round(la * 1000) + '_' + Math.round(lo * 1000), name: String(lc.name || id || '').slice(0, 80), lat: la, lon: lo, zoom: Number(lc.zoom) || 0, __tl: 1 };
      }
      return null;
    }
    // (FR24's list with the ones kept here added, each once)
    function mxBmMerge(j) {
      var kept = mxBmKept(), out = j && typeof j === 'object' ? j : { data: null }, d = out.data && typeof out.data === 'object' ? out.data : (out.data = { flights: [], aircraft: [], locations: [], airports: [] });
      MX_BM_ALL.forEach(function (list) {
        if (!Array.isArray(d[list])) d[list] = [];
        var have = {}; d[list].forEach(function (it) { have[mxBmId(list, it)] = true; });
        (kept[list] || []).forEach(function (it) { if (!have[mxBmId(list, it)]) { d[list].push(it); have[mxBmId(list, it)] = true; } });
      });
      return out;
    }
    function mxBmBody(input, init) { try { var b = init && init.body; return typeof b === 'string' ? JSON.parse(b) : b && typeof b === 'object' && !(b instanceof Blob) && !(b instanceof FormData) ? b : {}; } catch (e) { return {}; } }
    function mxBmList() { return oFetch.call(window, 'https://www.flightradar24.com/webapi/v1/bookmarks', { credentials: 'include', headers: mxBmHdr }).then(function (r) { return r.ok ? r.json() : { data: null }; }, function () { return { data: null }; }); }
    var mxBmHdr = {};
    // (1.3.6) one of theirs bookmarked: its weather - FR24's server has none for it, and its list said "Weather is currently
    // not available" - the monitor's, live at the airport, in FR24's form; FR24's own airports as FR24 gives them
    var BM_WX_WORD = { clear: 'Clear', cloudy: 'Cloudy', overcast: 'Cloudy', fog: 'Fog', drizzle: 'Rain', rain: 'Rain', snow: 'Snow', thunderstorm: 'Thunderstorm' };
    function apWxFr24(w) {
      var t = fin(w.tempC) ? Math.round(w.tempC) : null, k = fin(w.wkts) ? Math.round(w.wkts) : null;
      return { sky: { condition: { text: BM_WX_WORD[w.cond] || null } }, temp: { celsius: t, fahrenheit: t == null ? null : Math.round(t * 9 / 5 + 32) },
        wind: { speed: { kts: k || 0, text: k == null ? null : k === 0 ? 'Calm' : k + ' kt' }, direction: { degree: fin(w.wdir) ? Math.round(w.wdir) : -1 } } };
    }
    // (the whole list of theirs here - ms at most)
    function oaReady(ms) {
      if (oaRows) return Promise.resolve(true);
      return new Promise(function (res) { var done = false; oaWait.push(function () { if (!done) { done = true; res(true); } }); oSetTimeout(function () { if (!done) { done = true; res(false); } }, ms); });
    }
    function mxBmOaWx(out) {
      var list = out && out.data && Array.isArray(out.data.airports) ? out.data.airports.filter(function (it) { return it && it.code && !it.weather; }) : [];
      if (!list.length) return out;
      return oaReady(3000).then(function () {
        return Promise.all(list.map(function (it) {
          var r = oaByCode.get(String(it.code.iata || '').toLowerCase()); if (!r || oaDupe(r)) return null;
          return apWxWait(r[0], 3000).then(function (w) { if (w) it.weather = apWxFr24(w); });
        })).then(function () { return out; });
      });
    }
    // (their code line in the list as in their window: "GB-1368", "EGOW" - FR24's widget writes "<iata> / <icao>" of FR24's
    // table, which has their code in both)
    function bmCodesTick() {
      if (!oaByCode.size) return;
      var els = document.querySelectorAll('[data-testid="bookmarks__item-airport__iata_icao"]');
      for (var i = 0; i < els.length; i++) {
        var t = textIn(els[i]), m = t && /^\s*([^\s\/]+)\s*\/\s*([^\s\/]*)\s*$/.exec(t.data); if (!m) continue;
        var r = oaByCode.get(m[1].toLowerCase()); if (!r || oaDupe(r)) continue;
        var want = oaCodeLine(r); if (t.data !== want) t.data = want;
      }
    }
    if (!/^\/data\//i.test(location.pathname)) setInterval(function () { try { bmCodesTick(); } catch (e) { stats.errors++; stats.lastError = String(e); } }, 250);
    function mxBookmarks(input, init) {
      var method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
      try { var h = new Headers((init && init.headers) || (input && input.headers) || {}); mxBmHdr = {}; h.forEach(function (v, k) { if (/^(authorization|accept|x-[a-z-]+)$/i.test(k)) mxBmHdr[k] = v; }); } catch (e) { /* none */ }
      var body = mxBmBody(input, init), list = MX_BM_LISTS[String(body.type || '').toLowerCase()], id = String(body.identifier || '').toUpperCase();
      if (method === 'DELETE' && list) {
        var kept = mxBmKept(), mine = (kept[list] || []).some(function (it) { return mxBmId(list, it) === id; });
        if (mine) { kept[list] = kept[list].filter(function (it) { return mxBmId(list, it) !== id; }); mxBmSave(kept); return mxBmList().then(function (j) { return Promise.resolve(mxBmOaWx(mxBmMerge(j))).then(function (o) { return jsonResponse(null, o); }); }); }
      }
      return oFetch.call(window, input, init).then(function (r) {
        if (method === 'POST' && list && !r.ok) {
          // (FR24's server keeps no more for this account: kept here)
          var it = mxBmItem(body); if (!it) return r;
          var nid = mxBmId(list, it), kp = mxBmKept(); kp[list] = (kp[list] || []).filter(function (x) { return mxBmId(list, x) !== nid; }).concat([it]); mxBmSave(kp);
          return mxBmList().then(function (j) { return Promise.resolve(mxBmOaWx(mxBmMerge(j))).then(function (o) { return jsonResponse(null, o); }); });
        }
        if (!r.ok) return r;
        return r.clone().json().then(function (j) { return Promise.resolve(mxBmOaWx(mxBmMerge(j))).then(function (o) { return jsonResponse(r, o); }); }, function () { return r; });
      });
    }
    // ---- (1.2.4) FR24's airport flight history: the runway of each landing and take-off - FR24 shows it a Business account
    // only (its padlock). Worked out from each flight's own track near the airport (the userscript reads FR24's track of
    // it, the monitor names the runway and keeps it for every browser by the flight's id); put in FR24's own answer, the
    // padlock off, for those found within 2.5 s - FR24's answer as it was for the rest
    var mxRwy = new Map(), mxRwyWait = new Map(), mxRwySeq = 0;
    var mxFidHex = function (v) { return typeof v === 'number' && v > 0 ? v.toString(16) : /^[0-9a-f]{1,12}$/i.test(String(v || '')) ? String(v).toLowerCase() : ''; };
    function mxHistItems(o, out, depth) {
      if (!o || typeof o !== 'object' || depth > 5 || out.length > 500) return;
      if (Array.isArray(o)) { for (var i = 0; i < o.length; i++) mxHistItems(o[i], out, depth + 1); return; }
      if ('flightId' in o && 'type' in o && 'time' in o) { out.push(o); return; }
      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k) && o[k] && typeof o[k] === 'object') mxHistItems(o[k], out, depth + 1);
    }
    function mxRwyAsk(ap, items, ms, iata) {
      var need = items.filter(function (x) { return !mxRwy.has(x.fid + ':' + (x.landing ? 1 : 0)); });
      if (!need.length) return Promise.resolve();
      return new Promise(function (res) {
        var rid = 'rw' + (++mxRwySeq), t = oSetTimeout(function () { mxRwyWait.delete(rid); res(); }, ms);
        var end = function () { oClearTimeout(t); mxRwyWait.delete(rid); res(); };
        // (1.2.6: done as soon as every one asked for is in - the monitor's answer - not only once the rest are worked out)
        end.keys = need.map(function (x) { return x.fid + ':' + (x.landing ? 1 : 0); });
        mxRwyWait.set(rid, end);
        post('rwyWant', { rid: rid, ap: ap, iata: iata || '', items: need });
      });
    }
    function onRwyGot(d) {
      (d && Array.isArray(d.list) ? d.list : []).forEach(function (x) { if (x && /^[0-9a-f]{1,12}:[01]$/.test(x.k || '') && x.rwy) mxRwy.set(x.k, String(x.rwy).slice(0, 8)); });
      if (mxRwy.size > 5000) mxRwy.delete(mxRwy.keys().next().value);
      var f = d && mxRwyWait.get(d.rid); if (f && (d.done || (f.keys && f.keys.every(function (k) { return mxRwy.has(k); })))) f();
      cardRwyFill();
    }
    // (1.2.7) An airport's runways all at once, as the monitor logged them from FR24's tracks the moment each flight took off
    // or came down the final approach (monitor/rwylog.cjs): by FR24's id of the flight, and a blocked flight's by its
    // address and time (its ADS-B track's). Asked for as a board opens - the board waits a moment for them - and kept a
    // minute; a card asks for the other end's airport the same way.
    // (1.4.0) An airport's "On ground" as the monitor has it (the userscript's ogRows): asked for with FR24's own list, kept a
    // minute - every aircraft there from its landing until it is seen in the air again, FR24's airports and OurAirports'
    var mxOg = new Map(), mxOgWait = new Map(), mxOgSeq = 0;
    function ogAsk(apId, ms) {
      apId = Number(apId) || 0; if (!(apId > 0)) return Promise.resolve(null);
      var c = mxOg.get(apId);
      if (!c || Date.now() - c.at > 60000) {
        var rid = 'og' + (++mxOgSeq); c = { at: Date.now() };
        c.p = new Promise(function (res) {
          mxOgWait.set(rid, function (d) { mxOgWait.delete(rid); res(d && Array.isArray(d.list) ? d.list : null); });
          oSetTimeout(function () { if (mxOgWait.has(rid)) { mxOgWait.delete(rid); c.at = 0; res(null); } }, 9000);
        });
        mxOg.set(apId, c); if (mxOg.size > 50) mxOg.delete(mxOg.keys().next().value);
        post('ogWant', { rid: rid, ap: apId });
      }
      return ms ? withTimeout(c.p, ms, null) : c.p;
    }
    function onOgGot(d) { var f = d && mxOgWait.get(d.rid); if (f) f(d); }
    // (each aircraft FR24's own list has not got - by its flight, registration or address - as a row of FR24's own form;
    // the list latest landed first, as FR24's is)
    var regNorm = function (r) { return String(r || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); };
    function ogAdd(data, list, apId) {
      if (!Array.isArray(data) || !Array.isArray(list) || !list.length) return 0;
      var have = {}, n = 0;
      data.forEach(function (e) {
        if (!e) return; var f = e.flight || {}, ac = e.aircraft || {}, rec = f.id ? recOf(parseInt(f.id, 16)) : null;
        if (f.id) have['f' + String(f.id).toLowerCase()] = true; if (ac.registration) have['r' + regNorm(ac.registration)] = true;
        var hx = e.__tlHex || (rec && rec.hex); if (hx) have['h' + String(hx).toLowerCase()] = true;
      });
      list.forEach(function (x) {
        if (!x || (!x.reg && !x.hex && !x.cs)) return;
        if ((x.fid && have['f' + x.fid]) || (x.reg && have['r' + regNorm(x.reg)]) || (x.hex && have['h' + x.hex])) return;
        var num = x.fid ? parseInt(x.fid, 16) % 4000000000 : x.hex ? parseInt(x.hex, 16) : 0; if (!num) return;
        var t = Number(x.t) || 0, cat = null; try { cat = categoryOf({ type: x.ty, desc: x.name }); } catch (e) { cat = null; }
        data.push({ id: 40000000000 + num, flight: { id: x.fid || null, number: null, callsign: x.cs || regNorm(x.reg) || null }, landedTime: t || null, airlineId: x.alId || null, runway: null,
          aircraft: { category: cat, name: x.name || x.ty || '', registeredOwners: '', registration: x.reg || '', type: x.ty || '' }, originId: x.ap || null,
          activeDay: t ? new Date(t * 1000).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10), __tlAdded: true, __tlOg: true, __tlHex: x.hex || '', __tlBadge: x.badge || '' });
        if (x.fid) have['f' + x.fid] = true; if (x.reg) have['r' + regNorm(x.reg)] = true; if (x.hex) have['h' + x.hex] = true;
        n++;
      });
      if (n) mx.ogRows = (mx.ogRows || 0) + n;
      return n;
    }
    var mxRwyAp = new Map(), mxRwyHex = new Map(), mxRwyApSeq = 0;   // apId -> { at, p }; apId -> [[hex, 0|1, runway, time]]
    function mxRwyAirport(apId, ms) {
      apId = Number(apId) || 0; if (!(apId > 0) || !mx.on) return Promise.resolve(false);
      var c = mxRwyAp.get(apId);
      if (!c || (c.done && Date.now() - c.at > 30000)) {
        var rid = 'ra' + (++mxRwyApSeq);
        c = { at: Date.now(), done: false, rid: rid }; c.p = new Promise(function (res) { c.res = res; });
        mxRwyAp.set(apId, c); if (mxRwyAp.size > 200) mxRwyAp.delete(mxRwyAp.keys().next().value);
        oSetTimeout(function () { if (!c.done) { c.done = true; c.at = Date.now() - 20000; c.res(false); } }, 10000);   // (no answer: asked again 10 s on)
        post('rwyAp', { rid: rid, ap: apId });
      }
      return ms ? withTimeout(c.p, ms, false) : c.p;
    }
    function onRwyApGot(d) {
      var apId = Number(d && d.ap) || 0, c = mxRwyAp.get(apId); if (!apId) return;
      Object.keys((d && d.f) || {}).forEach(function (k) { if (/^[0-9a-f]{1,12}:[01]$/.test(k) && typeof d.f[k] === 'string' && d.f[k]) mxRwy.set(k, d.f[k].slice(0, 8)); });
      while (mxRwy.size > 20000) mxRwy.delete(mxRwy.keys().next().value);
      if (Array.isArray(d.h)) mxRwyHex.set(apId, d.h); if (mxRwyHex.size > 200) mxRwyHex.delete(mxRwyHex.keys().next().value);
      // (1.2.8: the runway in use in the same answer - the panel's tiles, the boards' rows and the cards from one request)
      if (d && d.use && Array.isArray(d.use.ends)) rwyUseTake(apId, d.use, true);
      else if (d && d.ok) { var cu = mxRwyUse.get(apId) || {}; if ((!cu.d || cu.d.kept) && Date.now() - (cu.askedOld || 0) > 60000) rwyUseAsk(apId); }   // (a monitor before 1.2.8: asked on its own)
      cardRwyFill();
      if (c && c.rid === d.rid && !c.done) {
        // (in after the board was drawn without them: FR24's own re-read of it draws them)
        if (Date.now() - c.at > 1500 && curBoard && curBoard.apId === apId) refreshBoardSoon();
        c.done = true; c.at = Date.now(); c.res(!!d.ok);
      }
      // (1.2.11: written into the open panel the moment it is in - not at its next look, up to 0.4 s on)
      var ap0 = document.querySelector('[data-testid="airport-panel"]');
      if (ap0 && rwyUseApId() === apId && ap0.querySelector('[data-testid="airport-panel__weather__wind"]')) { try { rwyUsePanel(ap0, apId); } catch (e) { stats.errors++; stats.lastError = String(e); } }
    }
    // (a blocked flight's runway at an airport by its address: the take-off or landing nearest the time given, within half an hour)
    // (1.4.0: no time known of it - a card of this script's with no take-off or landing time: its latest there within six
    // hours, the take-off or landing the board shows)
    function mxRwyByHex(apId, hex, end, t) {
      var l = mxRwyHex.get(Number(apId) || 0), h = String(hex || '').toLowerCase(); if (!l || !/^[0-9a-f]{6}$/.test(h)) return '';
      var best = null, nowS = Date.now() / 1000;
      if (t > 1e9) l.forEach(function (x) { if (x[0] === h && x[1] === end && Math.abs(x[3] - t) <= 1800 && (!best || Math.abs(x[3] - t) < Math.abs(best[3] - t))) best = x; });
      else l.forEach(function (x) { if (x[0] === h && x[1] === end && nowS - x[3] <= 6 * 3600 && x[3] <= nowS + 300 && (!best || x[3] > best[3])) best = x; });
      return best ? best[2] : '';
    }
    // ---- (1.2.7) The runway in use at an airport - its departures', its arrivals' - shown beside FR24's own weather (the map's
    // airport panel, its data page): from the wind FR24 shows, the weather, and the take-offs and landings of the last day
    // as the monitor logged them from FR24's tracks (/rwyuse).
    //   CONFIRMED: traffic now - the last hour and a half - on a runway the wind agrees with (a tailwind of 5 kt at most, or
    //              a calm), two movements or more that way, or one in the last half hour
    //   PREDICTED: anything less - the wind alone (the end with the most headwind; between parallels or ends alike, the one
    //              the last day used most; in fog, mist or snow the longest), or traffic the wind has since turned against
    // (1.2.8) Asked for with the airport's runways all at once (mxRwyAirport: one request, made the moment its panel or
    // board opens, every minute while open) - and, until it is in, the last answer this browser had of the airport, kept
    // (its runways and last three hours' movements, in this page's storage): the runway in use shown at once - PREDICTED by
    // the wind FR24 shows, CONFIRMED by traffic only while that traffic is recent
    var mxRwyUse = new Map(), mxRwyUseSeq = 0, RWYUSE_KEY = 'tl.ladd.rwyuse.v1';   // apId -> { at, d, asked }
    function rwyUseKept() { try { var o = JSON.parse(localStorage.getItem(RWYUSE_KEY) || 'null'); return o && typeof o === 'object' && !Array.isArray(o) ? o : {}; } catch (e) { return {}; } }
    function rwyUseTake(apId, u, keep) {
      var c = mxRwyUse.get(apId) || {};
      c.d = { ends: (u.ends || []).slice(), runways: (u.runways || []).slice(), mv: (u.mv || []).slice().sort(function (a, b) { return a[2] - b[2]; }), at: Number(u.at) || Math.floor(Date.now() / 1000) }; c.at = Date.now();
      mxRwyUse.set(apId, c); if (mxRwyUse.size > 100) mxRwyUse.delete(mxRwyUse.keys().next().value);
      if (!keep || !c.d.ends.length) return;
      try {
        var o = rwyUseKept(), cut = Math.floor(Date.now() / 1000) - 3 * 3600;
        o[apId] = { e: c.d.ends, r: c.d.runways, m: c.d.mv.filter(function (m) { return m[2] >= cut; }).slice(-200), t: c.d.at };
        var ks = Object.keys(o); if (ks.length > 80) ks.sort(function (a, b) { return (o[a].t || 0) - (o[b].t || 0); }).slice(0, ks.length - 80).forEach(function (k) { delete o[k]; });
        localStorage.setItem(RWYUSE_KEY, JSON.stringify(o));
      } catch (e) { /* storage full or refused: kept for this page only */ }
    }
    function rwyUseAsk(apId) { var c = mxRwyUse.get(apId) || {}; c.rid = 'ru' + (++mxRwyUseSeq); c.askedOld = Date.now(); mxRwyUse.set(apId, c); post('rwyUse', { rid: c.rid, ap: apId }); }
    function rwyUseWant(apId) {
      apId = Number(apId) || 0; if (!(apId > 0)) return null;
      var c = mxRwyUse.get(apId) || {};
      if (!c.d && !c.kept) { c.kept = true; var k = rwyUseKept()[apId]; if (k && Array.isArray(k.e) && k.e.length) c.d = { ends: k.e, runways: k.r || [], mv: (k.m || []).slice().sort(function (a, b) { return a[2] - b[2]; }), at: Number(k.t) || 0, kept: true }; mxRwyUse.set(apId, c); }
      if (!c.asked || Date.now() - c.asked > 30000) { c.asked = Date.now(); mxRwyUse.set(apId, c); mxRwyAirport(apId); }   // (1.2.10: every 30 s, as the monitor's low scan)
      return c.d || null;
    }
    function onRwyUseGot(d) {
      var apId = Number(d && d.ap) || 0, c = mxRwyUse.get(apId); if (!c || c.rid !== d.rid || !d.ok) return;
      rwyUseTake(apId, d, true);
    }
    // (1.2.8) A card drawn before its runways were in: each one written into it as it comes - FR24's own cell, "N/A" till then
    function cardRwyFill() {
      var cards = document.querySelectorAll('[id^="airport_schedule_"], [data-testid^="airport-panel__schedules__flight__"]'), n = 0;
      for (var i = 0; i < cards.length; i++) {
        var cd = cardInfo.get(rowIdOf(cards[i])), fid = cd && mxFidHex(cd.fid); if (!cd || (!fid && !cd.hex)) continue;
        var dls = cards[i].querySelectorAll('dl');
        for (var j = 0; j < dls.length; j++) {
          var dt = dls[j].querySelector('dt'), dd = dls[j].querySelector('dd'), lab = textOf(dt).toLowerCase(); if (!dd) continue;
          var end = /^departure runway$/.test(lab) ? 0 : /^arrival runway$/.test(lab) ? 1 : -1; if (end < 0) continue;
          // (1.4.0: a blocked flight's - a row of this script's - by its address: its ADS-B track's runway as the monitor
          // logged it, at the board's airport for its own end)
          var endAp = end ? (cd.dst || (cd.kind !== 'departures' ? cd.apId : 0)) : (cd.o || (cd.kind === 'departures' ? cd.apId : 0));
          var v = (fid && mxRwy.get(fid + ':' + end)) || (cd.hex && mxRwyByHex(endAp, cd.hex, end, end ? cd.ata : cd.atd)), cur = textOf(dd); if (!v || (cur && cur !== 'N/A' && cur !== '–')) continue;
          dd.textContent = ''; var el = document.createElement('div'); el.className = 'text-md font-semibold text-gray-1300'; el.setAttribute('data-testid', 'airport-flight-details__' + (end ? 'arrival' : 'departure') + '-runway'); el.textContent = v; dd.appendChild(el); n++;
        }
      }
      if (n) mx.cardRwyLate = (mx.cardRwyLate || 0) + n;
      return n;
    }
    var rwyAng = function (a, b) { var d = Math.abs(((a - b) % 360 + 360) % 360); return d > 180 ? 360 - d : d; };
    // u: /rwyuse's answer; wind: { deg, kts } (null: not known); cond: FR24's word for the weather; nowS: now
    // -> { dep: { rwys, tag 'conf' | 'pred', why }, arr: ... } or null (no runway known)
    function rwyInUse(u, wind, cond, nowS) {
      var ends = ((u && u.ends) || []).filter(function (e) { return e && e[0] && isFinite(e[1]); }); if (!ends.length) return null;
      var hdg = {}, len = {}; ends.forEach(function (e) { hdg[e[0]] = Number(e[1]); });
      ((u && u.runways) || []).forEach(function (r) { if (!r || r[3]) return; [r[0], r[1]].forEach(function (n) { if (n) len[n] = Math.max(len[n] || 0, Number(r[2]) || 0); }); });
      var ws = wind && isFinite(wind.kts) ? Number(wind.kts) : null, wd = wind && isFinite(wind.deg) ? Number(wind.deg) : null;
      var calm = ws == null || wd == null || ws < 4, head = function (n) { return calm ? 0 : ws * Math.cos((wd - hdg[n]) * Math.PI / 180); };
      var lowVis = /fog|mist|haze|snow|freezing|thunder|heavy/i.test(String(cond || ''));
      var same = function (a, b) { return rwyAng(hdg[a], hdg[b]) <= 20; };
      var windWord = calm ? 'calm or light wind' : Math.round(wd) + '° ' + Math.round(ws) + ' kt';
      // (1.2.12) A minor runway - shorter than 1,500 m and than 60% of the airport's longest, or of no known length beside
      // one of 1,000 m or more: Beauvais's 04/22, 1.1 km beside 12/30's 2.4 km, was shown its "departures runway". Its
      // movements count only when no main runway has any (either way, take-offs or landings) in the same window, and it is
      // never a guess by the wind. (Both, not the share alone: JFK's 22L, 2.6 km, is 58% of its 13R/31L - and a main runway.)
      var longestLen = 0; Object.keys(len).forEach(function (n) { longestLen = Math.max(longestLen, len[n] || 0); });
      var minor = function (n) { var l = len[n] || 0; return longestLen > 0 && (l ? l < 0.6 * longestLen && l < 4921 : longestLen >= 3281); };
      var allMv = ((u && u.mv) || []).filter(function (m) { return m && hdg[m[0]] != null && m[2] <= nowS + 300 && nowS - m[2] <= 86400; });
      var mainIn = function (secs) { return allMv.some(function (m) { return nowS - m[2] <= secs && !minor(m[0]); }); };
      var mainRecent = mainIn(5400), mainDay = mainIn(86400);
      var mainEnds = ends.map(function (e) { return e[0]; }).filter(function (n) { return !minor(n); });
      if (!mainEnds.length) mainEnds = ends.map(function (e) { return e[0]; });
      function one(kind) {
        var word = kind ? 'landings' : 'take-offs';
        var mv = allMv.filter(function (m) { return m[1] === kind && !(mainDay && minor(m[0])); });
        var recent = mv.filter(function (m) { return nowS - m[2] <= 5400 && !(mainRecent && minor(m[0])); }), day = {}; mv.forEach(function (m) { day[m[0]] = (day[m[0]] || 0) + 1; });
        var byCount = function (o) { return Object.keys(o).sort(function (a, b) { return o[b] - o[a] || (len[b] || 0) - (len[a] || 0); }); };
        // (1.2.12: a second runway only with a share of its own - two movements at least and a quarter of the first's: JFK's
        // one take-off logged on 22L beside 57 on 22R read "22R / 22L")
        var two = function (o) { var b = byCount(o); return b.filter(function (n, i) { return i === 0 || (i === 1 && o[n] >= 2 && o[n] >= o[b[0]] * 0.25); }); };
        var turned = '';
        // (1.2.10) The other kind's latest movement, and this kind's runways the way it went: the ones this kind used that
        // way in the last day (the most used, and a second used nearly as much), else the far ends of its own runways now,
        // else the other kind's own runway
        var oth = allMv.filter(function (m) { return m[1] === 1 - kind && nowS - m[2] <= 5400 && !(mainRecent && minor(m[0])); }), oLast = oth[oth.length - 1];
        var oWord = kind ? 'take-offs' : 'landings', oAge = oLast ? Math.round((nowS - oLast[2]) / 60) : 0;
        var farEnd = function (n) { var r = ((u && u.runways) || []).filter(function (x) { return x && !x[3] && (x[0] === n || x[1] === n); })[0]; return r ? (r[0] === n ? r[1] : r[0]) : ''; };
        var thatWay = function (own) {
          var sub = {}; Object.keys(day).forEach(function (n) { if (rwyAng(hdg[n], hdg[oLast[0]]) <= 20) sub[n] = day[n]; });
          var b = byCount(sub); if (b.length) return b.filter(function (n, i) { return i === 0 || (i === 1 && sub[n] >= 2 && sub[n] >= sub[b[0]] * 0.3); });
          var f = (own || []).map(farEnd).filter(function (n) { return n && hdg[n] != null; }); return f.length ? f : [oLast[0]];
        };
        if (recent.length) {
          var lastR = recent[recent.length - 1][0], cnt = {}, nDir = 0;
          recent.forEach(function (m) { if (same(m[0], lastR)) { cnt[m[0]] = (cnt[m[0]] || 0) + 1; nDir++; } });
          var ageMin = Math.round((nowS - recent[recent.length - 1][2]) / 60), hw = head(lastR);
          // (1.2.10: the airport turned round - the other kind's latest, newer than this kind's, the other way along the
          // runways: this kind follows, predicted until one of its own goes that way. Manchester went from 05 to 23 at
          // 19:37: take-offs on 23R, and its panel still had landings "05R, confirmed" from the last one, at 19:19)
          if (oLast && oLast[2] > recent[recent.length - 1][2] && rwyAng(hdg[oLast[0]], hdg[lastR]) >= 150) {
            return { rwys: thatWay(two(cnt)), tag: 'pred', why: oWord + ' have turned round onto ' + oLast[0] + ' (' + oAge + ' min ago); ' + word + ' follow - the last ' + word.replace(/s$/, '') + ', ' + ageMin + ' min ago, was the other way, on ' + lastR + '; wind ' + windWord };
          }
          // (1.2.11: the traffic over the wind. JFK landing on 22L and taking off from 22R minutes before, with a 5 kt
          // tailwind (340 degrees 8 kt), was shown "31L, predicted" by the wind: 1.2.7 to 1.2.10 let the traffic count only
          // up to 5 kt of tailwind. Now up to 10 kt, as airports do run; beyond what they accept, more than 10 kt behind
          // it, only traffic of the last 10 minutes - older than that, the airport has likely turned round)
          if (calm || hw >= -10 || ageMin <= 10) {
            var sure = ageMin <= 30 || (nDir >= 2 && (calm || hw >= -5));
            return { rwys: two(cnt), tag: sure ? 'conf' : 'pred', why: nDir + ' ' + (nDir === 1 ? word.replace(/s$/, '') : word) + ' that way in the last 90 minutes (the last ' + ageMin + ' min ago); wind ' + windWord + (calm ? '' : ', ' + (hw >= 0 ? Math.round(hw) + ' kt headwind' : Math.round(-hw) + ' kt tailwind')) };
          }
          turned = '; the wind has turned against the ' + lastR + ' the traffic used';
        }
        // (1.2.10: none of its own in the last 90 minutes, the other kind's there: its way - traffic before the wind)
        if (!recent.length && oLast) return { rwys: thatWay(null), tag: 'pred', why: 'no ' + word + ' in the last 90 minutes; ' + oWord + ' are on ' + oLast[0] + ' (' + oAge + ' min ago); wind ' + windWord };
        if (!calm) {
          var cand = mainEnds.filter(function (n) { return head(n) >= -5; });
          if (!cand.length) cand = mainEnds.slice();
          cand.sort(function (a, b) { var ha = head(a), hb = head(b); if (Math.abs(ha - hb) > 2) return hb - ha; if (lowVis && (len[b] || 0) !== (len[a] || 0)) return (len[b] || 0) - (len[a] || 0); return (day[b] || 0) - (day[a] || 0) || (len[b] || 0) - (len[a] || 0); });
          return { rwys: [cand[0]], tag: 'pred', why: 'by the wind, ' + windWord + ' (' + Math.round(head(cand[0])) + ' kt headwind)' + (lowVis ? ' and the weather' : '') + (mv.length ? '' : '; no ' + word + ' in the last 24 hours') + turned };
        }
        if (mv.length) { var used = byCount(day); return { rwys: [used[0]], tag: 'pred', why: 'calm or light wind: the runway the last 24 hours\' ' + word + ' used most' + turned }; }
        var longest = mainEnds.slice().sort(function (a, b) { return (len[b] || 0) - (len[a] || 0); })[0], opp = mainEnds.filter(function (n) { return n !== longest && rwyAng(hdg[n], hdg[longest] + 180) <= 20 && len[n] === len[longest]; })[0];
        return { rwys: [opp ? longest + '/' + opp : longest], tag: 'pred', why: 'calm or light wind, and no ' + word + ' in the last 24 hours: the longest runway' };
      }
      return { dep: one(0), arr: one(1), calm: calm };
    }
    // (FR24's wind as its panel writes it: "50° 5 kts"; "Calm")
    function windOfText(t) { t = String(t || ''); var d = /(\d{1,3})\s*°/.exec(t), k = /(\d{1,3})\s*(?:kts?|kt)\b/i.exec(t) || /°\s*(\d{1,3})\b/.exec(t); return d && k ? { deg: +d[1], kts: +k[1] } : /calm/i.test(t) ? { deg: 0, kts: 0 } : null; }
    function rwyUseHtml(r, tile, wait) {
      var cell = function (label, x, kind) {
        if (wait) return tile(label, '<span class="tl-rwyuse-val" style="font-size:1.25rem;line-height:1.6rem">&nbsp;</span>', 'Being worked out', kind);
        // (the tag as the destination's: blue "Predicted", green "Confirmed" - styled here, for pages without the script's sheet)
        var val = x && x.rwys && x.rwys.length ? x.rwys.join(' / ') : 'N/A', tag = x ? '<span class="tl-tag tl-tag-' + (x.tag === 'conf' ? 'conf' : 'pred') + '" style="display:inline-block;margin:0;padding:0 5px;border-radius:3px;font:700 10px/15px \'Open Sans\',Roboto,Arial,sans-serif;letter-spacing:.3px;text-transform:uppercase;white-space:nowrap;color:#fff;background:' + (x.tag === 'conf' ? '#2e8540">Confirmed' : '#327db6">Predicted') + '</span>' : '';
        return tile(label, '<span class="tl-rwyuse-val" style="font-size:1.25rem;line-height:1.6rem">' + rwyEsc(val) + '</span>' + tag, x ? x.why : 'Not known yet', kind);
      };
      // (1.2.8: two runways in use - parallels, one each way - "runways")
      var lab = function (w, x) { return w + (x && x.rwys && x.rwys.length > 1 ? ' runways' : ' runway'); };
      return cell(lab('Departures', r && r.dep), r && r.dep, 'departures') + cell(lab('Arrivals', r && r.arr), r && r.arr, 'arrivals');
    }
    var rwyEsc = function (s0) { return String(s0 == null ? '' : s0).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
    // (1.2.11) the panel's airport by its address (as panelTick reads it); the tiles put in where FR24's weather is drawn and
    // they are not yet - once per batch of FR24's changes to the panel
    function rwyUseApId() { var code = panelCode(), d = code ? (panelData[code] || panelFromKept(code)) : null; return (d && d.apId) || Number((location.pathname.match(/^\/airport\/(\d+)\//) || [])[1]) || 0; }
    function rwyUseInline(panel) {
      if (!panel || !panel.isConnected || !panel.querySelector('[data-testid="airport-panel__weather__wind"]')) return;
      var box = panel.querySelector('.tl-rwyuse'), pid = rwyUseApId(); if (!pid) return;
      // (1.3: and the monitor's weather where FR24 has none - again should FR24 have drawn its own weather anew)
      var wxb = panel.querySelector('.tl-wx'), wxRedo = wxb ? !(wxb.previousElementSibling && wxb.previousElementSibling.hasAttribute('data-tl-wxhid')) : !!apWxOf(pid) && apWxNone(panel);
      if (!box || box.__tlAp !== pid || wxRedo) rwyUsePanel(panel, pid);
    }
    // ---- (1.3) An airport's weather where FR24 has none - no METAR from it (Barrow/Walney: "N/A" under Conditions,
    // Temperature and Wind): the monitor's (apwx.cjs) - the live weather at the airport itself and a METAR made from it -
    // in FR24's own tiles and its "More weather & METAR", on its data page, on the current-weather layer, and into the
    // runway in use
    var apWx = {};      // airport id -> { at, wx, asked }
    function apWxOf(apId) { var x = apWx[apId]; return x && x.wx && Date.now() - x.at < 30 * 60000 ? x.wx : null; }
    function apWxWant(apId) {
      apId = Number(apId) || 0; if (!(apId > 0)) return;
      var x = apWx[apId] || (apWx[apId] = { at: 0, wx: null, asked: 0 });
      if ((x.wx && Date.now() - x.at < 10 * 60000) || Date.now() - x.asked < 60000) return;
      x.asked = Date.now(); post('needApWx', { ap: apId });
    }
    // (1.3.1) the airport's weather from the monitor, waited for: ms at most; null - none (an airport FR24 has weather for
    // never asks)
    var apWxWaiting = {};
    function apWxWait(apId, ms) {
      var w = apWxOf(apId); if (w) return Promise.resolve(w);
      return new Promise(function (res) {
        var l = apWxWaiting[apId] || (apWxWaiting[apId] = []), done = false, f = function (v) { if (!done) { done = true; res(v || null); } };
        l.push(f); oSetTimeout(function () { f(apWxOf(apId)); }, ms);
        // (asked again now, whenever it was asked last - unless it is on its way already: 1.3.12 asks for an airfield's weather
        // the moment the airfield is, and FR24's own ask for it a moment later waits for that answer, not a second one)
        var x = apWx[apId]; if (x && Date.now() - x.asked > 20000) x.asked = 0;
        apWxWant(apId);
      });
    }
    // (1.3.12: FR24's /weather answer: { data: {} } - or its fields empty - where the airport sends no METAR)
    function apWxEmpty(j) { var d = j && typeof j === 'object' ? j.data : null; return !d || typeof d !== 'object' || Array.isArray(d) || (d.condition == null && d.temperature == null); }
    function apWxFill(p, apId) {
      return p.then(function (res) {
        if (!res || !res.ok) return res;
        return res.clone().json().then(function (j) {
          if (!apWxEmpty(j)) return res;
          return apWxWait(apId, 8000).then(function (w) {
            if (!w) return res;
            var o = j && typeof j === 'object' && !Array.isArray(j) ? j : {};
            o.data = Object.assign({}, o.data && typeof o.data === 'object' && !Array.isArray(o.data) ? o.data : {}, oaWeather(w));
            stats.apWxFilled = (stats.apWxFilled || 0) + 1;
            return jsonResponse(res, o);
          });
        }, function () { return res; });
      });
    }
    function onApWxGot(d) {
      var id = Number(d.ap) || 0; if (!(id > 0)) return;
      var x = apWx[id] || (apWx[id] = { asked: Date.now() }), w = d.wx;
      if (w && !w.none && typeof w.cond === 'string' && (fin(w.tempC) || fin(w.wkts))) { x.wx = w; x.at = Date.now(); }
      var wl = apWxWaiting[id]; if (wl) { delete apWxWaiting[id]; wl.forEach(function (f) { try { f(apWxOf(id)); } catch (e) { /* ignore */ } }); }
      var ap0 = document.querySelector('[data-testid="airport-panel"]');
      if (ap0 && rwyUseApId() === id && ap0.querySelector('[data-testid="airport-panel__weather__wind"]')) { try { rwyUsePanel(ap0, id); } catch (e) { stats.errors++; stats.lastError = String(e); } }
    }
    // (the wind as the runway in use reads it: variable - no direction - is no wind to choose a runway by)
    var apWxWind = function (w) { return w && fin(w.wkts) ? (fin(w.wdir) ? { deg: w.wdir, kts: w.wkts } : { deg: 0, kts: 0 }) : null; };
    var AP_WX_WORD = { clear: 'Clear', cloudy: 'Cloudy', overcast: 'Overcast', fog: 'Fog', drizzle: 'Drizzle', rain: 'Rain', snow: 'Snow', thunderstorm: 'Thunderstorm' };
    // (FR24's units as its settings say - Celsius or Fahrenheit, knots, km/h, mph or m/s)
    function apWxUnits() { try { var p = mxPinia(), st = p && p._s.get('settings'), u = st && st.units; return { t: u && u.temperature === 'f' ? 'f' : 'c', w: u && /^(kmh|mph|ms)$/.test(u.windSpeed) ? u.windSpeed : 'kt' }; } catch (e) { return { t: 'c', w: 'kt' }; } }
    var apWxTemp = function (c, un) { return fin(c) ? (un.t === 'f' ? Math.round(c * 9 / 5 + 32) + ' °F' : Math.round(c) + ' °C') : 'N/A'; };
    var apWxSpeed = function (k, un) { return un.w === 'kmh' ? [Math.round(k * 1.852), 'km/h'] : un.w === 'mph' ? [Math.round(k * 1.15078), 'mph'] : un.w === 'ms' ? [Math.round(k * 0.514444), 'm/s'] : [Math.round(k), 'kts']; };
    // (a small picture for each word - FR24 draws one over its own)
    var AP_WX_ICON = {
      clear: '<circle cx="12" cy="12" r="4.5"/><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" fill="none"/>',
      cloudy: '<circle cx="8" cy="8" r="3.2"/><path d="M8 1.5v1.6M2.5 8H1M3.6 3.6l1.1 1.1M12.4 3.6l-1.1 1.1" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" fill="none"/><path d="M7.5 20.5h11a4 4 0 0 0 .5-8 5.5 5.5 0 0 0-10.4-1.4A4.3 4.3 0 0 0 7.5 20.5z"/>',
      overcast: '<path d="M6.5 19.5h12a4.5 4.5 0 0 0 .6-9 6.5 6.5 0 0 0-12.4-1.6A5.3 5.3 0 0 0 6.5 19.5z"/>',
      fog: '<path d="M3 7h18M2 11.5h20M3 16h18M5 20.5h14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" fill="none"/>',
      drizzle: '<path d="M6.5 14.5h12a4.2 4.2 0 0 0 .5-8.4 6 6 0 0 0-11.5-1.5A5 5 0 0 0 6.5 14.5z"/><path d="M8 18v1.5M12 18v1.5M16 18v1.5M10 21.5v1M14 21.5v1" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" fill="none"/>',
      rain: '<path d="M6.5 14.5h12a4.2 4.2 0 0 0 .5-8.4 6 6 0 0 0-11.5-1.5A5 5 0 0 0 6.5 14.5z"/><path d="M8 17l-1.2 3.5M12.5 17l-1.2 3.5M17 17l-1.2 3.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" fill="none"/>',
      snow: '<path d="M6.5 14.5h12a4.2 4.2 0 0 0 .5-8.4 6 6 0 0 0-11.5-1.5A5 5 0 0 0 6.5 14.5z"/><circle cx="8" cy="18.5" r="1.2"/><circle cx="12.5" cy="20.5" r="1.2"/><circle cx="17" cy="18.5" r="1.2"/>',
      thunderstorm: '<path d="M6.5 13.5h12a4.2 4.2 0 0 0 .5-8.4 6 6 0 0 0-11.5-1.5A5 5 0 0 0 6.5 13.5z"/><path d="M12.5 13.5l-3 5h3l-1.5 4.5 4.5-6.5h-3l2-3z"/>'
    };
    // (FR24's three say nothing: no weather of its own for the airport)
    function apWxNone(panel) {
      var ids = ['conditions', 'temperature', 'wind'];
      for (var i = 0; i < ids.length; i++) { var dd = panel.querySelector('[data-testid="airport-panel__weather__' + ids[i] + '"] dd'); if (!dd || !/^(n\/a|-|—|)$/i.test(textOf(dd))) return false; }
      return true;
    }
    var apWxAgo = function (t) { var m = Math.max(0, Math.round((Date.now() / 1000 - t) / 60)); return m < 60 ? m + ' m ago' : Math.floor(m / 60) + ' h ' + (m % 60) + ' m ago'; };
    function apWxHtml(w) {
      var un = apWxUnits(), sp = fin(w.wkts) ? apWxSpeed(w.wkts, un) : null, word = AP_WX_WORD[w.cond] || 'Unknown';
      var tip = rwyEsc('No METAR is sent from this airport: its live weather (the weather model at the airport, Open-Meteo), ' + apWxAgo(w.t) + ' (LADD unblocker)');
      var tile = function (id, label, dd) { return '<div class="rounded border border-gray-500 px-1.5 pb-1 pt-1.5 bg-gray-200" data-tl-wx="' + id + '" title="' + tip + '"><div class="flex size-full items-center space-x-3"><div class="flex size-full flex-col"><dt class="text-xs font-semibold uppercase text-gray-900"><span class="inline-flex w-fit"><span>' + label + '</span></span></dt><dd class="h-full text-md font-semibold text-gray-1300">' + dd + '</dd></div></div></div>'; };
      var more = function (label, dd, wide) { return '<div class="rounded border border-gray-500 bg-gray-100 px-1.5 pb-1 pt-1.5' + (wide ? ' col-span-3' : '') + '"><div class="flex size-full items-center space-x-3"><div class="flex size-full flex-col"><dt class="text-xs font-semibold uppercase text-gray-900"><span class="inline-flex w-fit"><span>' + label + '</span></span></dt><dd class="h-full text-md font-semibold text-gray-1300">' + dd + '</dd></div></div></div>'; };
      var cond = '<div class="flex flex-col items-center"><svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="fill-current my-0.5 size-8 text-gray-1300">' + (AP_WX_ICON[w.cond] || AP_WX_ICON.cloudy) + '</svg><div class="whitespace-nowrap text-sm font-semibold">' + word + '</div></div>';
      var wind = !sp ? 'N/A' : sp[0] === 0 ? '<span class="flex h-full items-center justify-center text-3xl font-normal">Calm</span>'
        : '<div class="flex flex-col items-center">' + (fin(w.wdir) ? '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 28" class="fill-current size-8 text-gray-1300 my-0.5" style="transform: rotate(' + ((w.wdir + 180) % 360) + 'deg);"><path d="M20.917 10.043 10.566 0 .224 10.014a.72.72 0 0 0-.015 1.031.72.72 0 0 0 1.031.015l8.617-8.339v24.548a.731.731 0 0 0 1.463 0V2.765L19.9 11.1a.73.73 0 0 0 .512.2.728.728 0 0 0 .5-1.258"></path></svg>' : '') +
          '<div class="space-x-1 text-sm font-semibold"><span class="text-sm">' + (fin(w.wdir) ? w.wdir + '°' : 'Variable') + '</span><span>' + sp[0] + (fin(w.gust) ? 'G' + apWxSpeed(w.gust, un)[0] : '') + '</span><span class="text-xs">' + sp[1] + '</span></div></div>';
      // (the report made from it on the monitor, as a METAR is written - AUTO, RMK MODEL: no station's own)
      var last = more('<div class="flex justify-between"><span>Latest metar</span><span class="text-sm font-normal normal-case text-gray-1300">' + apWxAgo(w.t) + '</span></div>', ' ' + rwyEsc(w.metar || '') + ' <p class="pt-2 text-md font-normal text-gray-900">No METAR is sent from this airport: this one is made from its live weather (the weather model at the airport, Open-Meteo) - not an official report.</p>', true);
      return '<dl class="grid grid-cols-3 gap-1 text-center">' + tile('conditions', 'Conditions', cond) + tile('temperature', 'Temperature', '<span class="flex h-full items-center justify-center text-3xl font-normal">' + apWxTemp(w.tempC, un) + '</span>') + tile('wind', 'Wind', wind) + '</dl>' +
        '<details class="space-y-1 rounded-lg border border-gray-400 p-1 align-top text-gray-1300 bg-white"><summary class="group flex cursor-pointer list-none items-center gap-x-2 px-1 py-0.5 font-semibold pl-8 text-blue-500 normal-case text-md">More weather &amp; METAR</summary><section class="relative overflow-hidden rounded-lg"><dl class="mt-1 grid grid-cols-3 gap-1">' +
        more('Air pressure', fin(w.hpa) ? w.hpa.toLocaleString('en-GB') + ' hPa' : 'N/A') + more('Dew point', apWxTemp(w.dewC, un)) + more('Humidity', fin(w.rh) ? w.rh + '%' : 'N/A') + last + '</dl></section></details>';
    }
    // (FR24's own weather and its "More weather" put away while it has none; back - ours gone - the moment it has)
    var apWxHide = function (el) { if (el && !el.hasAttribute('data-tl-wxhid')) { el.setAttribute('data-tl-wxhid', ''); el.style.setProperty('display', 'none', 'important'); } };
    var apWxShow = function (el) { if (el && el.hasAttribute('data-tl-wxhid')) { el.removeAttribute('data-tl-wxhid'); el.style.removeProperty('display'); } };
    function apWxPanel(panel, apId, dl) {
      var box = dl.parentElement.querySelector(':scope > .tl-wx'), fr24More = null;
      for (var sib = dl.nextElementSibling; sib; sib = sib.nextElementSibling) if (sib.tagName === 'DETAILS' && /more weather/i.test(textOf(sib.querySelector('summary')))) { fr24More = sib; break; }
      var w = apWxNone(panel) ? (apWxWant(apId), apWxOf(apId)) : null;
      if (!w) { if (box) box.remove(); apWxShow(dl); apWxShow(fr24More); return null; }
      var html = apWxHtml(w);
      if (!box) { box = document.createElement('div'); box.className = 'space-y-1 tl-wx'; dl.insertAdjacentElement('afterend', box); }
      if (box.__tl !== html) { var open = !!(box.querySelector('details') || {}).open; box.innerHTML = html; box.__tl = html; if (open) box.querySelector('details').open = true; }
      box.__tlAp = apId; apWxHide(dl); apWxHide(fr24More);
      return w;
    }
    // the map's airport panel: under its Conditions / Temperature / Wind
    function rwyUsePanel(panel, apId) {
      var w = panel.querySelector('[data-testid="airport-panel__weather__wind"]'), dl = w && w.closest('dl'); if (!dl || !dl.parentElement) return;
      // (1.3: FR24 with no weather for it: the monitor's in its place, and its wind and weather for the runway in use)
      var aw = apWxPanel(panel, apId, dl), anchor = aw ? dl.parentElement.querySelector(':scope > .tl-wx') || dl : dl;
      var u = rwyUseWant(apId), cond = aw ? AP_WX_WORD[aw.cond] || '' : textOf(panel.querySelector('[data-testid="airport-panel__weather__conditions"] dd'));
      var r = u ? rwyInUse(u, aw ? apWxWind(aw) : windOfText(textOf(w.querySelector('dd'))), cond, Math.floor(Date.now() / 1000)) : null;
      var tile = function (label, inner, why, kind) { return '<div class="rounded border border-gray-500 px-1.5 pb-1 pt-1.5 bg-gray-200" data-testid="airport-panel__weather__runway-' + kind + '" title="' + rwyEsc(why + ' (LADD unblocker)') + '"><div class="flex size-full items-center space-x-3"><div class="flex size-full flex-col"><dt class="text-xs font-semibold uppercase text-gray-900"><span class="inline-flex w-fit"><span>' + rwyEsc(label) + '</span></span></dt><dd class="h-full text-md font-semibold text-gray-1300"><div class="flex flex-col items-center gap-0.5">' + inner + '</div></dd></div></div></div>'; };
      // (1.2.11: the airport's answer still on its way - nothing kept of it in this browser: the tiles there, empty, not
      // "N/A" for a moment)
      var c0 = mxRwyAp.get(apId), wait = !r && !!c0 && !c0.done;
      var html = rwyUseHtml(r, tile, wait), box = dl.parentElement.querySelector(':scope > .tl-rwyuse');
      if (!box) { box = document.createElement('dl'); box.className = 'grid grid-cols-2 gap-1 text-center tl-rwyuse'; anchor.insertAdjacentElement('afterend', box); }
      else if (anchor !== dl && box.previousElementSibling !== anchor) anchor.insertAdjacentElement('afterend', box);   // (under the weather put in)
      box.__tlAp = apId;
      if (box.__tl !== html) { box.innerHTML = html; box.__tl = html; }
    }
    // (1.3) an airport's data page with no weather from FR24 (none, or nothing in it): the monitor's, in FR24's own form -
    // its weather card drawn by FR24 itself - and FR24's again the moment it has its own
    function apWxData(p, apId) {
      var fw = p.weather;
      if (fw && !fw.__tl && (fin(fw.temperatureC) || fin(fw.windSpeedKts) || (fw.condition && fw.condition !== 'unknown'))) return;
      apWxWant(apId);
      var w = apWxOf(apId); if (!w) return;
      var kts = fin(w.wkts) ? Math.round(w.wkts) : null, nw = { timestamp: w.t, condition: w.cond, temperatureC: fin(w.tempC) ? Math.round(w.tempC) : null, windDirection: fin(w.wdir) ? w.wdir : 0, windSpeedKts: fin(w.wdir) ? kts : (kts === null ? null : 0) };
      var sig = JSON.stringify(nw); if (fw && fw.__tl === sig) return;
      nw.__tl = sig; p.weather = nw;
    }
    // an airport's data page (/data/airports/<code>): a card of its own under FR24's weather card, in its markup
    function rwyUseData(p, apId) {
      var spans = document.querySelectorAll('dl dt span'), wSpan = null;
      for (var i = 0; i < spans.length; i++) if (/^wind$/i.test(textOf(spans[i])) && !spans[i].closest('.tl-rwyuse')) { wSpan = spans[i]; break; }
      var dl = wSpan && wSpan.closest('dl'), card = dl && dl.parentElement; if (!card || !card.parentElement) return;
      var wx = p.weather || {}, u = rwyUseWant(apId);
      var r = u ? rwyInUse(u, isFinite(wx.windDirection) && isFinite(wx.windSpeedKts) ? { deg: wx.windDirection, kts: wx.windSpeedKts } : null, wx.condition || '', Math.floor(Date.now() / 1000)) : null;
      var item = dl.children[0], dtSpan = wSpan, val = item && item.querySelector('dd span span span');
      var tile = function (label, inner, why) { return '<div class="' + rwyEsc(item ? item.className : '') + '" title="' + rwyEsc(why + ' (LADD unblocker)') + '"><dt class="flex max-w-full flex-wrap items-center gap-s justify-center text-center"><span class="' + rwyEsc(dtSpan.className) + '">' + rwyEsc(label) + '</span></dt><dd class="flex max-w-full flex-wrap items-center justify-center gap-1 md:gap-1.5"><span class="flex flex-col items-center gap-1 ' + rwyEsc(val ? val.className : '') + '">' + inner + '</span></dd></div>'; };
      var html = rwyUseHtml(r, tile), box = card.parentElement.querySelector(':scope > .tl-rwyuse');
      if (!box) { box = document.createElement('div'); box.className = card.className + ' tl-rwyuse'; box.innerHTML = '<dl class="grid md:flex grid-cols-2"></dl>'; card.insertAdjacentElement('afterend', box); }
      var bdl = box.querySelector('dl'); if (bdl.__tl !== html) { bdl.innerHTML = html; bdl.__tl = html; }
    }
    // (1.2.6) A board's flight card - FR24's own, or one of this script's rows: its departure and arrival runways, FR24's
    // padlock over both below Business. Each from the flight's own track, as the boards' rows have theirs - the take-off's
    // at the field it left, the landing's where it landed - waited for 2.5 s at most; the padlock never kept: "N/A" where
    // none is known (yet). madeUp: the card's flight id is one made up here, which no track is kept under.
    function cardRwy(resp, apId, kind, madeUp, hex) {
      if (!resp || !resp.ok || !mx.on) return resp;
      return resp.clone().json().then(function (j) {
        var d = j && j.data; if (!d || typeof d !== 'object' || !d.flight) return resp;
        var fid = madeUp ? '' : mxFidHex(d.flight.id), dep = kind === 'departures', sc = d.schedule || {};
        // (a blocked flight followed here: its address, for the runways its ADS-B track gave)
        if (!hex && /^[0-9a-f]{1,8}$/.test(fid)) { var rr = recOf(parseInt(fid, 16)); if (rr && rr.hex) hex = rr.hex; }
        hex = /^[0-9a-f]{6}$/i.test(String(hex || '')) ? String(hex).toLowerCase() : '';
        // (flown only: the take-off once it has taken off, the landing once it has landed - each at its own airport)
        var oAp = Number(dep ? apId : d.originId) || 0, aAp = Number(dep ? d.destinationId : apId) || 0, atd = Number(sc.atd) || 0, ata = Number(sc.ata) || 0;
        var known = function (end) { return (fid && mxRwy.get(fid + ':' + end)) || (hex && mxRwyByHex(end ? aAp : oAp, hex, end, end ? ata : atd)) || ''; };
        var put = function () {
          var rw = d.runways && typeof d.runways === 'object' ? d.runways : {}, ch = !(d.runways && typeof d.runways === 'object');
          ['departure', 'arrival'].forEach(function (k) {
            var e = rw[k] && typeof rw[k] === 'object' ? rw[k] : {}, own = e.name != null && e.name !== '' && !e.upsell ? String(e.name) : '';
            var v = own || known(k === 'arrival' ? 1 : 0) || null;
            if (e.name !== v || e.upsell !== false) { rw[k] = Object.assign({}, e, { name: v, upsell: false }); ch = true; }
          });
          d.runways = rw; if (ch) mx.cardRwy = (mx.cardRwy || 0) + 1;
          return ch ? jsonResponse(resp, j) : resp;
        };
        // (each end's airport's runways as logged - kept from the board, else asked for now; then, for one still not known,
        // the flight's own track worked out)
        // (2.7 s at most in all: the airports' 1.2, the flight's own 1.5)
        var aps = []; if (oAp && atd) aps.push(mxRwyAirport(oAp)); if (aAp && ata && aAp !== oAp) aps.push(mxRwyAirport(aAp));
        return withTimeout(Promise.all(aps), 1200, null).then(function () {
          var asks = [];
          if (fid && oAp && atd && !known(0)) asks.push(mxRwyAsk(oAp, [{ fid: fid, landing: false, t: atd }], 1500));
          if (fid && aAp && ata && !known(1)) asks.push(mxRwyAsk(aAp, [{ fid: fid, landing: true, t: ata }], 1500));
          return asks.length ? Promise.all(asks) : null;
        }).then(put, put);
      }, function () { return resp; });
    }
    function mxAirportHistory(input, init, url) {
      var apId = +((url.match(/\/airport-history\/(\d+)/) || [])[1] || 0);
      return oFetch.call(window, input, init).then(function (r) {
        if (!r.ok || !apId) return r;
        return r.clone().json().then(function (j) {
          var items = []; mxHistItems(j, items, 0);
          var want = items.filter(function (it) { return (it.runway == null || it.runway === '') && mxFidHex(it.flightId) && (it.type === 'landed' || it.type === 'takeoff'); });
          if (!want.length) return r;
          var ask = want.map(function (it) { return { fid: mxFidHex(it.flightId), landing: it.type === 'landed', t: Number(it.time) || 0 }; });
          return mxRwyAsk(apId, ask, 2500).then(function () {
            var n = 0;
            want.forEach(function (it) {
              var v = mxRwy.get(mxFidHex(it.flightId) + ':' + (it.type === 'landed' ? 1 : 0)); if (!v) return;
              it.runway = v; var av = Array.isArray(it.available) ? it.available : []; if (av.indexOf('runway') < 0) it.available = av.concat(['runway']); n++;
            });
            if (!n) return r;
            mx.rwy = (mx.rwy || 0) + n;
            return jsonResponse(r, j);
          });
        }, function () { return r; });
      });
    }
    // ---- (1.2.4) A flight's page (/data/flights/<flight>): the runways of its "Live flight" card, FR24's padlock over both
    // for anything below Business - from the flight's own track (as the airport's flight history's): put in FR24's page
    // data, the padlock off, once the take-off's is known (the landing's is shown when it has landed and is known)
    var mxLiveRw = { at: 0, fid: '' };
    function mxLiveRunways(p) {
      var lf = p.liveFlight, fid = lf && mxFidHex(lf.flightId); if (!fid || lf.unscheduled === true) return;
      var o = lf.origin, de = lf.destination, lk = function (e) { return !!(e && e.locked && e.locked.runway === true); };
      if (!lk(o) && !lk(de) && !lf.__tl) return;
      var k0 = fid + ':0', k1 = fid + ':1', r0 = mxRwy.get(k0), r1 = mxRwy.get(k1), landed = !!(de && de.actual);
      var ask = function (e, landing, key) {
        if (!e || !e.iata || mxRwy.has(key)) return;
        mxRwyAsk(0, [{ fid: fid, landing: landing, t: Number(landing ? e.actual : (e.actual || e.scheduled)) || 0 }], 8000, String(e.iata)).then(mxDataTick);
      };
      // (asked once a minute at most for each flight)
      if ((!r0 || (landed && !r1)) && (mxLiveRw.fid !== fid || Date.now() - mxLiveRw.at > 60000)) { mxLiveRw = { at: Date.now(), fid: fid }; ask(o, false, k0); if (landed) ask(de, true, k1); }
      if (!r0 && !r1) return;
      var sig = (r0 || '') + '|' + (r1 || ''); if (lf.__tl === sig) return;
      var put = function (e, v) { if (!e) return e; return Object.assign({}, e, v ? { runway: v } : {}, { locked: Object.assign({}, e.locked, { runway: false }) }); };
      p.liveFlight = Object.assign({}, lf, { origin: put(o, r0), destination: put(de, landed ? r1 : null), __tl: sig });
      mx.liveRwy = (mx.liveRwy || 0) + 1;
    }
    // ---- (1.2.4) FR24's airport boards - its arrivals, departures and on-ground pages, the airport page's boards and the
    // map's airport panel: each flown row's runway (FR24's padlock below Business), as the flight history's - from the
    // flight's own track, worked out on the monitor. Those known put in the row at once, the padlock off; the rest asked
    // for (30 at a time for a board, the latest first, each once in 10 minutes) and put in as they come
    var mxBrAsked = new Map(), mxBrAt = {};
    // (a board row's aircraft address, where this script knows it: a row of its own - kept, or a flight it follows - or
    // FR24's own row of a flight it follows; an airport data page's row of its own)
    function mxRowHex(r) {
      if (!r) return '';
      if (/^[0-9a-f]{6}$/.test(r.__tlHex || '')) return r.__tlHex;
      var id = Number(r.id) || 0, a = id >= 20000000000 || r.__tlArch ? archById.get(id) : null; if (a && a.r && /^[0-9a-f]{6}$/i.test(a.r.hex || '')) return String(a.r.hex).toLowerCase();
      var rec = id >= 9000000000 && id < 20000000000 ? recOf(id - 9000000000) : null;
      if (!rec) { var f = r.flight && r.flight.id != null ? String(r.flight.id) : r.flightId != null ? String(r.flightId) : ''; if (/^[0-9a-f]{1,8}$/i.test(f)) rec = recOf(parseInt(f, 16)); }
      return rec && /^[0-9a-f]{6}$/i.test(rec.hex || '') ? String(rec.hex).toLowerCase() : '';
    }
    function mxBoardRwy(rows, kind, apId) {
      if (!Array.isArray(rows) || !apId) return 0;
      // (1.4.0: the airport's runways - its blocked flights' by address among them - asked for with the board, whichever board)
      mxRwyAirport(apId);
      var now = Date.now() / 1000, land = kind !== 'departures', n = 0, ask = [];
      rows.forEach(function (r) {
        if (!r || typeof r !== 'object') return;
        var lk = !!(r.locked && r.locked.runway === true); if (!lk && r.runway != null && r.runway !== '') return;
        // (1.2.6: never FR24's padlock. 1.2.9: the rows themselves show no runway - only each flight's card does, in its
        // dropdown; the runways are asked for here still, so the card has its own the moment it opens)
        if (lk) { r.locked = Object.assign({}, r.locked, { runway: false }); r.runway = null; n++; }
        var raw = r.flightId != null ? r.flightId : r.flight && r.flight.id, fid = mxFidHex(raw);
        var st = String((r.status && (r.status.name || r.status.type || r.status.label)) || '').toLowerCase(), t = Number(r.landedTime || r.estimatedTime || r.scheduledTime) || 0;
        var flown = kind === 'on-ground' || kind === 'onGround' || kind === 'on-grounds' || /landed|departed|arrived/.test(st) || (!st && t > 0 && t < now - 300);
        if (!flown || /cancel|divert/.test(st)) return;
        // (1.2.7: a blocked flight's - a row of this script's, FR24's own of one followed here - by its address and time, its
        // ADS-B track's runway as the monitor logged it)
        var hx = mxRowHex(r), vh = hx ? mxRwyByHex(apId, hx, land ? 1 : 0, t) : '';
        // (1.4.0: kept under the row's own id too, which its card is drawn by - it showed none)
        if (vh) { if (fid && /^[0-9a-z]{1,12}$/.test(fid)) mxRwy.set(fid + ':' + (land ? 1 : 0), vh); return; }
        // (a row of this script's own with an id made up here: no track of it anywhere by that id)
        if (!fid || !/^[0-9a-f]{1,12}$/.test(fid) || (r.__tlArch && /^c[0-9a-f]{0,7}$/.test(fid))) return;
        var key = fid + ':' + (land ? 1 : 0), v = mxRwy.get(key);
        if (v) return;
        if (Date.now() - (mxBrAsked.get(key) || 0) > 600000) ask.push({ fid: fid, landing: land, t: t, key: key });
      });
      var bk = apId + ':' + kind;
      if (ask.length && Date.now() - (mxBrAt[bk] || 0) > 3000) {
        mxBrAt[bk] = Date.now();
        ask.sort(function (a, b) { return Math.abs(now - a.t) - Math.abs(now - b.t); });
        ask = ask.slice(0, 30); ask.forEach(function (x) { mxBrAsked.set(x.key, Date.now()); });
        if (mxBrAsked.size > 5000) mxBrAsked.delete(mxBrAsked.keys().next().value);
        mxRwyAsk(apId, ask.map(function (x) { return { fid: x.fid, landing: x.landing, t: x.t }; }), 20000);
      }
      if (n) mx.boardRwy = (mx.boardRwy || 0) + n;
      return n;
    }
    // (FR24's flight and aircraft history pages: a flight's KML and CSV in their download menu - FR24's own menu, unlocked;
    // the files made here, mxTrackFile)
    function mxDataTick() {
      try {
        var el = document.getElementById('app'), va = el && el.__vue_app__, pg = va && va.config && va.config.globalProperties && va.config.globalProperties.$page;
        if (!pg || !pg.props || !mx.on) return;
        var c = pg.component, p = pg.props;
        if ((c === 'Data/FlightHistory' || c === 'Data/AircraftRegistration') && p.canDownload === false) { p.canDownload = true; mx.dl = (mx.dl || 0) + 1; }
        if (c === 'Data/FlightHistory' && p.liveFlight) mxLiveRunways(p);
        var apI = p.airport && Number(p.airport.id);
        // (1.2.7: the airport's runways as logged, asked for once a minute; FR24's rows with no other airport filled)
        if ((c === 'Data/AirportBoard' || c === 'Data/Airport') && apI) mxRwyAirport(apI);
        if (c === 'Data/AirportBoard' && apI) { mxBoardRwy(p.flights, p.board, apI); if (p.board !== 'on-ground') mxDataEnds(p.flights, p.board, apI); }
        if (c === 'Data/Airport' && apI && p.boards) ['departures', 'arrivals', 'onGround'].forEach(function (k) { if (p.boards[k]) { mxBoardRwy(p.boards[k].flights, k, apI); if (k !== 'onGround') mxDataEnds(p.boards[k].flights, k, apI); } });
        if (c === 'Data/Airport' && apI) { apWxData(p, apI); rwyUseData(p, apI); }
        if (mxPbVeil && c === 'Data/NewFlightPlayback') mxPbVeilOff();
        var pm = location.pathname.match(/^\/data\/playback\/([0-9a-f]{1,16})\/?$/i);
        // (a flight known only here: its aircraft's page, where it plays in place; FR24's own page of a flight it locks or
        // shows empty: given the track)
        if (pm) { if (MX_PB_SYN.test(pm[1].toLowerCase())) mxPbAway(pm[1].toLowerCase()); else mxPbTake(pg, pm[1].toLowerCase()); }
        else if (mxPbWanted) mxPbTake(pg, mxPbWanted, true);
        // (allowed while one of these pages is shown - or about to be: the page it was asked from still showing, 15 s at most)
        // (1.4.0: and on FR24's own player page of one of its own flights: the figures of each moment from its public ADS-B
        // track, as on FR24's map's playback - patchFlightMsg; its vertical speed from FR24's own altitudes. Padlocked there
        // before: EIN6KR's GPS altitude, airspeeds and vertical speed)
        mxPbFlags(c === 'Data/NewFlightPlayback' || (c === mxPbFrom && Date.now() - mxPbAt < 15000));
        if (c === 'Data/NewFlightPlayback') { try { mxPbTag(p); } catch (e) { mxFail(e); } try { mxPbEnrich(pg); } catch (e) { mxFail(e); } try { mxPbRunways(pg); } catch (e) { mxFail(e); } if (mxPhoneApp()) { try { mxPbBackLabel(); } catch (e) { mxFail(e); } } }
      } catch (e) { mxFail(e); }
    }
    if (mx.on) setInterval(mxDataTick, 700);
    // ---- (1.2.4) FR24's own playback page (/data/playback/<id>, its component Data/NewFlightPlayback) for the flights FR24
    // plays back to nobody - a blocked (LADD) flight, a flight older than FR24's week of playback, a flight of a log rebuilt
    // here: the page FR24 builds from its own records, built here from the flight's track as kept (the monitor's FR24
    // positions of it, the public ADS-B record of its day - the userscript's pbFlight) and handed to FR24's own router, so
    // FR24's player plays it: its map, slider, figures, speed and altitude graph, tracklog, and its KML and CSV beside the
    // play button. A flight of FR24's own keeps its id; one known only here is "ff" + address + take-off (hex)
    var MX_PB_SYN = /^ff[0-9a-f]{14}$/, MX_PB_FLAGS = ['map.info.flight.vertical-speed', 'map.info.flight.squawk', 'map.info.flight.ems.alt.gps', 'map.info.flight.ems.tas', 'map.info.flight.ems.ias'], mxPlans = null, mxPbAdded = {}, mxPbAt = 0, mxPbFrom = '';
    var mxPbSynId = function (hex, t) { return 'ff' + String(hex).toLowerCase() + ('00000000' + Math.max(0, Math.round(t || 0)).toString(16)).slice(-8); };
    function mxGp() { try { var el = document.getElementById('app'), va = el && el.__vue_app__; return va && va.config && va.config.globalProperties && va.config.globalProperties.$inertia ? va.config.globalProperties : null; } catch (e) { return null; } }
    // (an airport as FR24's player's header has it: its code and city, where it is)
    function mxPbEp(a) { return a && a.code ? { code: a.code, city: a.city || a.name || '', lat: fin(a.lat) ? a.lat : null, long: fin(a.lon) ? a.lon : null } : { code: 'N/A', city: 'Not available', lat: null, long: null }; }
    // (1.4.1) the line over the callsign: the airline - FR24's logo of it by its id - or the operator / owner, by name alone
    function mxPbAirline(name, alId) { return { name: name || null, logoUrl: name && Number(alId) > 0 ? logoOf(Number(alId)) : null, logoDimensions: null }; }
    var MX_PRIVATE = /^\s*private(?:\s+owner)?\s*$/i;
    // FR24's page props of a flight from its track - the shapes FR24's page makes of its own records (its HistoricTrail
    // radar records: the trail's altitude and speed, the route's position and track, the tracklog's every one of them)
    function mxPbProps(d) {
      var P = [];
      (d.pts || []).forEach(function (p) {
        if (!p || !fin(p.t) || !fin(p.lat) || !fin(p.lon)) return;
        var alt = p.gnd ? 0 : fin(p.alt) ? Math.max(0, Math.round(p.alt)) : null, gs = fin(p.gs) ? Math.round(p.gs) : null;
        if (alt === null || gs === null) return;
        // (the squawk as FR24's records have it: the code's digits read as hex - its page shows the number in hex)
        var q = { timestamp: Math.round(p.t), barometricAltitude: alt, groundSpeed: gs, lat: p.lat, long: p.lon, track: fin(p.trk) ? Math.round(p.trk) : null, squawk: /^[0-7]{4}$/.test(p.sq || '') ? parseInt(p.sq, 16) : null, verticalSpeed: fin(p.vr) ? Math.round(p.vr) : null, estimated: false };
        if (P.length && P[P.length - 1].timestamp >= q.timestamp) return;
        P.push(q);
      });
      var t0 = P.length ? P[0].timestamp : 0, t1 = P.length ? P[P.length - 1].timestamp : 0;
      var dep = fin(d.dep) && d.dep > 0 ? d.dep : t0, arr = fin(d.arr) && d.arr > 0 ? d.arr : null;
      var mins = Math.round(((arr || t1) - dep) / 60), dur = mins > 0 ? (mins >= 60 ? Math.floor(mins / 60) + 'h ' + (mins % 60) + 'm' : mins + 'm') : null;
      var ep = mxPbEp;
      // (1.4.0: its runway at each end, as the monitor logged it - never FR24's padlock)
      var endp = function (a, rwy) { return { name: a && (a.name || a.city || a.code) || 'Not available', timezone: (a && a.tz) || 'UTC', terminal: null, gate: null, runway: rwy || null, runwayLocked: false }; };
      var cell = function (label) { return { label: label, value: 'N/A' }; };
      var facts = [['flight_number', d.flightNumber], ['callsign', d.cs], ['aircraft', d.model], ['type_code', d.type], ['registration', d.reg], ['serial_number', d.msn]].filter(function (f) { return !!f[1]; }).map(function (f) { return { key: f[0], value: f[1] }; });
      return {
        // (1.4.1: who it flew for - its airline, with FR24's logo of it, else the aircraft's operator or owner - over its
        // callsign, and its flight number beside it, as FR24's own flights have them)
        flightNumber: d.flightNumber || null, callsign: d.cs || null, airline: mxPbAirline(d.operator, d.alId),
        origin: ep(d.origin), destination: ep(d.destination), divertedFrom: null, duration: dur, progress: 1, progressLabel: '',
        metrics: [[cell('Time'), cell('Date')], [cell('Barometric altitude'), cell('GPS altitude')], [cell('Ground speed'), cell('True airspeed')], [cell('Vertical speed'), cell('Indicated airspeed')], [cell('Track'), cell('Squawk')]],
        liveFlightId: null, aircraft: { name: d.model || d.type || 'N/A', registration: d.reg || null }, playbackLock: null,
        photos: (d.photos || []).filter(function (x) { return x && x.url; }).map(function (x) { return { url: x.url, link: x.link || null, copyright: x.copyright || null }; }),
        trail: P.map(function (q) { var o = { timestamp: q.timestamp, barometricAltitude: q.barometricAltitude, groundSpeed: q.groundSpeed }; if (q.verticalSpeed != null) o.verticalSpeed = q.verticalSpeed; return o; }),
        tracklog: P.filter(function (q) { return q.track != null; }),
        trailRoute: P.map(function (q) { return { timestamp: q.timestamp, lat: q.lat, long: q.long, track: q.track, altitude: q.barometricAltitude, estimated: false }; }),
        trailSource: 'tl', download: { flightId: String(d.id), history: dep }, about: null, canonicalUrl: 'https://www.flightradar24.com/data/playback/' + d.id,
        flightTimes: { origin: endp(d.origin, d.rwyOff), destination: endp(d.destination, d.rwyOn), scheduledDeparture: null, actualDeparture: dep || null, scheduledArrival: null, actualArrival: arr },
        facts: facts, relatedFlights: [], content: []
      };
    }
    // (vertical speed, squawk, GPS altitude, true and indicated airspeed, which FR24's page padlocks for a free account,
    // given by the track here: allowed in FR24's plan table while one of these pages is shown - and only then: FR24's live
    // panel shows its own, which it does not send)
    function mxPbFlags(on) {
      if (!mxPlans) return;
      MX_PB_FLAGS.forEach(function (k) {
        var a = mxPlans[k]; if (!Array.isArray(a) || MX_OPTS.indexOf(k) >= 0) return;
        if (on) { ['basic', 'Basic', 'BASIC', 'guest', 'Guest', 'GUEST'].forEach(function (p) { if (a.indexOf(p) < 0) { a.push(p); (mxPbAdded[k] = mxPbAdded[k] || []).push(p); } }); }
        else { (mxPbAdded[k] || []).forEach(function (p) { var i = a.indexOf(p); if (i >= 0) a.splice(i, 1); }); mxPbAdded[k] = []; }
      });
    }
    var mxPbWait = new Map(), mxPbSeq = 0, mxPbAwayGot = null;
    // (1.4.0) FR24's player of a blocked flight - one of this script's: its tag (LADD, PIA, MIL) beside its callsign in the
    // player's header, as the map's panel and the logs show it
    var mxPbBadges = new Map(), mxPbTagEl = null, mxPbRwyAsked = {};
    // (1.4.0) FR24's player of one of its own flights: its flight times card's runways - padlocked below Business - as the
    // monitor logged them from FR24's own tracks (asked for by the flight's id and each end's airport, as the boards' are);
    // never the padlock: "-" while none is known
    // (a time of FR24's page data as seconds: seconds, milliseconds or a date written out)
    function mxSec(v) { var n = Number(v); if (!(n > 0) && typeof v === 'string' && v) { var d = Date.parse(v); n = isFinite(d) ? d / 1000 : 0; } n = n || 0; return Math.round(n > 1e12 ? n / 1000 : n); }
    function mxPbRunways(pg) {
      var p = pg.props, ft = p && p.flightTimes; if (!ft || typeof ft !== 'object') return;
      var pm = location.pathname.match(/^\/data\/playback\/([0-9a-f]{1,16})\/?$/i), fid = pm && !MX_PB_SYN.test(pm[1].toLowerCase()) ? pm[1].toLowerCase() : '';
      var sec = mxSec;
      [['origin', 0, p.origin, sec(ft.actualDeparture)], ['destination', 1, p.destination, sec(ft.actualArrival)]].forEach(function (x) {
        var e = ft[x[0]]; if (!e || typeof e !== 'object') return;
        if (e.runwayLocked === true) { e.runwayLocked = false; mx.pbRwyOpen = (mx.pbRwyOpen || 0) + 1; }
        if (!fid || (e.runway != null && e.runway !== '')) return;
        var v = mxRwy.get(fid + ':' + x[1]); if (v) { e.runway = v; mx.pbRwy = (mx.pbRwy || 0) + 1; return; }
        var code = x[2] && typeof x[2].code === 'string' ? x[2].code.toUpperCase() : '', k = fid + ':' + x[1];
        // (1.4.1: with FR24's own track of the flight by that end, as its page has it - the runway fitted from it when the
        // monitor has none logged: CDG and Edinburgh, which it does not watch, had none)
        // (asked at once - the monitor's log by the flight's id; its track not on the page yet - FR24 may send it a moment
        // after - asked once more with it when the first ask brought none)
        if (!/^[A-Z0-9]{3}$/.test(code) || !(x[3] > 1e9)) return;
        var asked = mxPbRwyAsked[k], ends = asked === 2 || (asked && asked !== 1) ? [] : mxPbEndPts(p, !!x[1], x[3]);
        if (!asked || (asked === 1 && ends.length >= 3)) {
          var withPts = ends.length >= 3; mxPbRwyAsked[k] = 'busy';
          mxRwyAsk(0, [{ fid: fid, landing: !!x[1], t: x[3], pts: withPts ? ends : [] }], 15000, code).then(function () { mxPbRwyAsked[k] = withPts ? 2 : 1; mxDataTick(); });
        }
      });
    }
    // ---- (1.4.1) FR24's player in the app: its back button - FR24's link to its "Search for flights to play" page,
    // named "Playback" - is "Flights", and goes back to the flights it was played from: the log page before it (an
    // aircraft's, a flight number's), else the aircraft's log page
    function mxPbIsBack(a) { var u = null; try { u = new URL(a.getAttribute('href') || '', location.href); } catch (e) { return false; } return u.origin === location.origin && /^\/data\/playback\/?$/i.test(u.pathname); }
    function mxPbBackTo() {
      var gp = mxGp(), p = gp && gp.$page && gp.$page.props || {}, ac = p.aircraft || {};
      var reg = !mxNA(ac.registration) ? String(ac.registration) : mxFact(p, 'registration'), fn = !mxNA(p.flightNumber) ? String(p.flightNumber) : '';
      return reg ? '/data/aircraft/' + encodeURIComponent(reg.toLowerCase()) : fn ? '/data/flights/' + encodeURIComponent(fn.toLowerCase()) : '/';
    }
    function mxPbBack() {
      var ref = null; try { ref = document.referrer ? new URL(document.referrer) : null; } catch (e) { ref = null; }
      mx.pbBack = (mx.pbBack || 0) + 1;
      if (ref && ref.origin === location.origin && /^\/data\/(?:aircraft|flights)\/[^/]+\/?$/i.test(ref.pathname) && history.length > 1) { history.back(); return; }
      mxNav(mxPbBackTo());
    }
    function mxPbBackLabel() {
      var as = document.querySelectorAll('#app a[href]');
      for (var i = 0; i < as.length; i++) {
        var a = as[i]; if (!mxPbIsBack(a)) continue;
        // (its words only - its arrow kept)
        var w = document.createTreeWalker(a, NodeFilter.SHOW_TEXT), n;
        while ((n = w.nextNode())) if (/\bPlayback\b/.test(n.nodeValue) && n.nodeValue.trim() === 'Playback') n.nodeValue = n.nodeValue.replace('Playback', 'Flights');
        if (a.getAttribute('aria-label') === 'Playback') a.setAttribute('aria-label', 'Flights');
      }
    }
    if (mx.on && mxPhoneApp()) document.addEventListener('click', function (ev) {
      if (ev.defaultPrevented || ev.button || ev.ctrlKey || ev.metaKey || ev.shiftKey) return;
      var gp = mxGp(); if (!gp || !gp.$page || gp.$page.component !== 'Data/NewFlightPlayback') return;
      var t = ev.target && ev.target.nodeType === 1 ? ev.target : ev.target && ev.target.parentElement, a = t && t.closest ? t.closest('a[href]') : null;
      if (!a || !mxPbIsBack(a)) return;
      ev.preventDefault(); ev.stopImmediatePropagation(); mxPbBack();
    }, true);
    // ---- (1.4.1) FR24's own player of one of its own flights: what FR24 leaves out - "Private owner" over the callsign
    // where the registers name the aircraft's operator or owner (G-WAPA), "N/A" at an end it has no airport for (a
    // helicopter's pad), its flight number - asked of the userscript once a flight (pbInfo), written into FR24's own page
    // data as it comes, and again whenever FR24 draws the page anew
    var mxPbInfo = new Map(), mxPbInfoAsked = {}, mxPbInfoSeq = 0;
    function mxPbWants(p) {
      var priv = !p.airline || mxNA(p.airline.name) || MX_PRIVATE.test(String(p.airline.name));
      return { owner: priv, from: !p.origin || mxNA(p.origin.code), to: !p.destination || mxNA(p.destination.code), fn: mxNA(p.flightNumber) && !mxNA(p.callsign) };
    }
    function mxPbEnrich(pg) {
      var p = pg && pg.props; if (!p || p.trailSource === 'tl') return;
      var pm = location.pathname.match(/^\/data\/playback\/([0-9a-f]{1,12})\/?$/i), fid = pm ? pm[1].toLowerCase() : ''; if (!fid) return;
      // (one FR24 locks or shows empty - made ours whole, mxPbTake: not this)
      if (mxPbTried[fid]) return;
      var w = mxPbWants(p); if (!w.owner && !w.from && !w.to && !w.fn) return;
      var got = mxPbInfo.get(fid); if (got) { mxPbInfoPut(p, got, w); return; }
      if (mxPbInfoAsked[fid]) return; mxPbInfoAsked[fid] = Date.now();
      var ft = p.flightTimes || {}, sec = mxSec;
      var tr = Array.isArray(p.trailRoute) ? p.trailRoute : [], tl = Array.isArray(p.trail) ? p.trail : [];
      var end = function (r, i) { if (!r || !fin(r.lat) || !fin(r.long)) return null; var g = tl[i] && tl[i].timestamp === r.timestamp ? tl[i] : null; return { t: r.timestamp, lat: r.lat, lon: r.long, alt: fin(r.altitude) ? r.altitude : g && fin(g.barometricAltitude) ? g.barometricAltitude : null, gs: g && fin(g.groundSpeed) ? g.groundSpeed : null }; };
      var ac = p.aircraft || {}, reg = !mxNA(ac.registration) ? String(ac.registration) : mxFact(p, 'registration');
      post('pbInfo', { rid: 'pi' + (++mxPbInfoSeq), fid: fid, reg: reg || '', cs: !mxNA(p.callsign) ? String(p.callsign) : '', dep: sec(ft.actualDeparture) || sec(ft.scheduledDeparture), arr: sec(ft.actualArrival),
        ends: tr.length ? [end(tr[0], 0), end(tr[tr.length - 1], tr.length - 1)] : [], wantOwner: w.owner, wantFrom: w.from, wantTo: w.to, wantFn: w.fn });
    }
    function onPbInfoGot(d) {
      if (!d || !d.ok || !/^[0-9a-f]{1,12}$/.test(d.fid || '')) return;
      mxPbInfo.set(d.fid, d); if (mxPbInfo.size > 50) mxPbInfo.delete(mxPbInfo.keys().next().value);
      mxDataTick();
    }
    // (into FR24's page data - its reactive props: FR24's page draws them anew at once)
    function mxPbInfoPut(p, d, w) {
      var n = 0;
      if (w.owner && d.operator) { p.airline = Object.assign({}, p.airline || {}, { name: d.operator, logoUrl: (p.airline && p.airline.logoUrl) || mxPbAirline(d.operator, d.alId).logoUrl, logoDimensions: (p.airline && p.airline.logoDimensions) || null }); n++; }
      var ft = p.flightTimes;
      var endName = function (k, a) { var e = ft && typeof ft === 'object' ? ft[k] : null; if (e && typeof e === 'object' && (mxNA(e.name) || e.name === 'Not available')) ft[k] = Object.assign({}, e, { name: a.name || a.city || a.code, timezone: e.timezone || a.tz || 'UTC' }); };
      if (w.from && d.origin && d.origin.code) { p.origin = Object.assign({}, p.origin || {}, mxPbEp(d.origin)); endName('origin', d.origin); n++; }
      if (w.to && d.destination && d.destination.code) { p.destination = Object.assign({}, p.destination || {}, mxPbEp(d.destination)); endName('destination', d.destination); n++; }
      if (w.fn && d.flightNumber) { p.flightNumber = d.flightNumber; n++; }
      if (n) mx.pbInfo = (mx.pbInfo || 0) + n;
    }
    // (FR24's own track of the flight on its player page - its route's positions with the trail's heights and speeds - by
    // the take-off's or the landing's time: half an hour of it, 400 points at most)
    function mxPbEndPts(p, landing, t) {
      var tr = Array.isArray(p && p.trailRoute) ? p.trailRoute : [], tl = Array.isArray(p && p.trail) ? p.trail : [], gs = {};
      tl.forEach(function (q) { if (q && fin(q.timestamp)) gs[q.timestamp] = q; });
      var out = [];
      for (var i = 0; i < tr.length; i++) {
        var r = tr[i]; if (!r || !fin(r.timestamp) || !fin(r.lat) || !fin(r.long)) continue;
        if (landing ? !(r.timestamp >= t - 1800 && r.timestamp <= t + 900) : !(r.timestamp >= t - 900 && r.timestamp <= t + 1800)) continue;
        var g = gs[r.timestamp] || {}, alt = fin(r.altitude) ? r.altitude : fin(g.barometricAltitude) ? g.barometricAltitude : null;
        out.push({ t: r.timestamp, lat: r.lat, lon: r.long, alt: alt, gs: fin(g.groundSpeed) ? g.groundSpeed : null, trk: fin(r.track) ? r.track : null });
      }
      return landing ? out.slice(-400) : out.slice(0, 400);
    }
    function mxPbTag(p) {
      var id = String((p.download && p.download.flightId) || '').toLowerCase(), b = p.trailSource === 'tl' ? mxPbBadges.get(id) || '' : '';
      var old = document.querySelectorAll('.tl-pb-tag');
      if (!b) { for (var o = 0; o < old.length; o++) old[o].remove(); mxPbTagEl = null; return; }
      if (mxPbTagEl && mxPbTagEl.isConnected && mxPbTagEl.nextElementSibling && mxPbTagEl.nextElementSibling.classList.contains('tl-pb-tag') && mxPbTagEl.nextElementSibling.textContent === b) return;
      for (var q = 0; q < old.length; q++) old[q].remove();
      var name = String(p.callsign || p.flightNumber || '').trim(), app = document.getElementById('app'); if (!name || !app) return;
      // (the callsign's own element: its words alone, shown, the largest of them - the header's, not a line of the page's text)
      var best = null, bestSize = 0, els = app.querySelectorAll('h1, h2, h3, p, span, div');
      for (var i = 0; i < els.length; i++) {
        var el = els[i]; if (el.children.length || (el.textContent || '').trim() !== name || el.closest('canvas, svg, [data-testid*="map"]')) continue;
        var r = el.getBoundingClientRect(); if (!(r.width > 0 && r.height > 0)) continue;
        var fz = parseFloat(getComputedStyle(el).fontSize) || 0; if (fz > bestSize) { bestSize = fz; best = el; }
      }
      if (!best) return;
      var t = document.createElement('span'); t.className = 'tl-pb-tag tl-ladd-chip'; t.textContent = b; t.title = 'Blocked on FR24 - identified from public ADS-B by the LADD unblocker';
      t.style.cssText = 'display:inline-flex;align-items:center;align-self:center;margin-left:10px;padding:1px 6px;border-radius:3px;background:#e3b021;color:#1b1b1b;font:700 ' + Math.max(11, Math.min(14, Math.round(bestSize * 0.4))) + 'px/1.5 Roboto,Arial,sans-serif;letter-spacing:.3px;vertical-align:middle;white-space:nowrap';
      best.insertAdjacentElement('afterend', t); mxPbTagEl = best; mx.pbTags = (mx.pbTags || 0) + 1;
    }
    function mxPbAsk(req, ms) {
      return new Promise(function (res) {
        var rid = 'pp' + (++mxPbSeq), t = oSetTimeout(function () { mxPbWait.delete(rid); res(null); }, ms || 30000);
        mxPbWait.set(rid, function (d) { oClearTimeout(t); mxPbWait.delete(rid); res(d && d.ok && Array.isArray(d.pts) && d.pts.length > 1 ? d : null); });
        post('pbPage', Object.assign({ rid: rid }, req));
      });
    }
    function onPbPageGot(d) { var f = d && mxPbWait.get(d.rid); if (f) f(d); }
    var mxNA = function (v) { return v == null || v === '' || v === 'N/A' || (Array.isArray(v) && !v.length); };
    // The page shown: FR24's own router given it - a new page (push), or this one's again (replace). FR24's own page of the
    // flight (a locked one, an empty one) keeps its words - its flight number, airline, airports and times - and takes the
    // track; for one FR24 has nothing of, the page is all of the track's
    function mxPbShow(d, replace, base) {
      var gp = mxGp(), router = gp && gp.$inertia, cur = gp && gp.$page; if (!router || !cur || !cur.props) return false;
      var ours = mxPbProps(d), props = {};
      ours.liveFlightId = mxPbStandIn(d);
      ['errors', 'name', 'host', 'locale', 'dispatcher', 'features', 'meta'].forEach(function (k) { if (k in cur.props) props[k] = cur.props[k]; });
      props.route = base && cur.props.route ? cur.props.route : { name: 'web.data.playback', params: { id: String(d.id) }, query: [] };
      if (base) {
        Object.keys(base).forEach(function (k) { if (!(k in props)) props[k] = base[k]; });
        ['trail', 'tracklog', 'trailRoute', 'trailSource', 'metrics', 'download', 'playbackLock', 'liveFlightId'].forEach(function (k) { props[k] = ours[k]; });
        ['flightNumber', 'callsign', 'duration', 'facts', 'photos', 'canonicalUrl'].forEach(function (k) { if (mxNA(props[k])) props[k] = ours[k]; });
        ['origin', 'destination'].forEach(function (k) { if (!props[k] || mxNA(props[k].code)) props[k] = ours[k]; });
        // (1.4.1: and FR24's "Private owner" where the registers name the aircraft's operator or owner)
        if (!props.airline || mxNA(props.airline.name) || (MX_PRIVATE.test(String(props.airline.name)) && ours.airline.name)) props.airline = Object.assign({}, props.airline || {}, { name: ours.airline.name, logoUrl: (props.airline && props.airline.logoUrl) || ours.airline.logoUrl });
        var ac = Object.assign({}, props.aircraft || {}); delete ac.lockedFeature;
        if (mxNA(ac.name)) ac.name = ours.aircraft.name; if (mxNA(ac.registration)) ac.registration = ours.aircraft.registration; props.aircraft = ac;
        var ft = Object.assign({}, props.flightTimes || {}); ['origin', 'destination'].forEach(function (k) { if (!ft[k] || mxNA(ft[k].name)) ft[k] = ours.flightTimes[k]; });
        if (!ft.actualDeparture) ft.actualDeparture = ours.flightTimes.actualDeparture; if (!ft.actualArrival) ft.actualArrival = ours.flightTimes.actualArrival; props.flightTimes = ft;
        ['about', 'relatedFlights', 'content'].forEach(function (k) { if (!(k in props)) props[k] = ours[k]; });
      } else Object.keys(ours).forEach(function (k) { props[k] = ours[k]; });
      mxPbFlags(true); mxPbAt = Date.now(); mxPbFrom = cur.component;
      if (d.badge) { mxPbBadges.set(String(d.id), String(d.badge)); if (mxPbBadges.size > 50) mxPbBadges.delete(mxPbBadges.keys().next().value); }
      var visit = { url: '/data/playback/' + d.id, component: 'Data/NewFlightPlayback', props: props, preserveScroll: false, preserveState: false };
      try { if (replace) router.replace(visit); else router.push(visit); } catch (e) { mxFail(e); return false; }
      mx.pbPages = (mx.pbPages || 0) + 1;
      return true;
    }
    // A blocked flight's Playback clicked (FR24's own button - boards, search, the panel, its recent flights): FR24's player
    // with its track - in a new tab when asked for one. Nothing known of the flight: FR24's own Playback after all
    // (as FR24 plays one of its own flights from anywhere: the aircraft's page, the flight's id in its address - FR24's page
    // script plays it in place, in its own player)
    var mxNav = function (u, replace) { if (replace) location.replace(u); else location.assign(u); };
    var mxPbLogUrl = function (reg, id) { return '/data/aircraft/' + encodeURIComponent(String(reg).toLowerCase()) + '#' + id; };
    // (1.3.12) in the phone app (android/app, ios/): a flight played in FR24's own player page - its map, its slider, made
    // for a phone - never on its aircraft's log page, whose player is FR24's old one for a computer
    // (1.4.1: the app whatever its width - a tablet's too. Not the page's width: as a page starts, before FR24's viewport
    // tag is read, Android's WebView lays it out 980 px wide, so a log page opened with a flight - FR24's own Playback,
    // window.open - was never seen as a phone's and played in the old player)
    function mxPhoneApp() { try { return typeof TL_APP === 'object' && !!TL_APP; } catch (e) { return false; } }
    // (its address there: FR24's own id's page; one known only here, FR24's flights page given it - mxPbAway)
    var mxPbPhoneUrl = function (id) { return MX_PB_SYN.test(String(id)) ? '/data/flights?tl-pb=' + id : '/data/playback/' + id; };
    // (1.4.0) ... and wherever it is asked for: FR24's own Playback - its search's, the aircraft's panel's, its boards',
    // live flights' too - opens the aircraft's or flight number's log page with the flight in its address, where FR24's
    // page plays it in its old player for a computer. In the phone app that page goes on to FR24's own player page of the
    // flight before anything of it is drawn (its place in the history taken), and a link to one, tapped, goes there at once
    var mxPbLogId = function (path, hash) { var h = String(hash || '').replace(/^#/, '').toLowerCase(); return /^\/data\/(?:aircraft|flights)\/[^/]+\/?$/i.test(path) && (/^[0-9a-f]{6,12}$/.test(h) || MX_PB_SYN.test(h)) ? h : ''; };
    // (a link's or window's address, FR24's site's: the flight it plays on a log page, if that is what it is)
    var mxPbLinkId = function (href) {
      var u = null; try { u = new URL(String(href), location.href); } catch (e) { return ''; }
      return (u.origin === location.origin || /^https:\/\/(?:[a-z0-9-]+\.)*flightradar24\.com$/i.test(u.origin)) ? mxPbLogId(u.pathname, u.hash) : '';
    };
    if (mx.on && mxPhoneApp()) {
      (function () {
        var id0 = mxPbLogId(location.pathname, location.hash); if (id0) { mx.pbToPlayer = (mx.pbToPlayer || 0) + 1; mxNav(mxPbPhoneUrl(id0), true); }
        window.addEventListener('hashchange', function () { var id = mxPbLogId(location.pathname, location.hash); if (id && mxPhoneApp()) { mx.pbToPlayer = (mx.pbToPlayer || 0) + 1; mxNav(mxPbPhoneUrl(id), true); } });
        document.addEventListener('click', function (ev) {
          if (ev.defaultPrevented || ev.button || ev.ctrlKey || ev.metaKey || ev.shiftKey || !mxPhoneApp()) return;
          var t = ev.target && ev.target.nodeType === 1 ? ev.target : ev.target && ev.target.parentElement, a = t && t.closest ? t.closest('a[href]') : null; if (!a) return;
          var id = mxPbLinkId(a.getAttribute('href')); if (!id) return;
          ev.preventDefault(); ev.stopImmediatePropagation(); mx.pbToPlayer = (mx.pbToPlayer || 0) + 1; mxNav(mxPbPhoneUrl(id));
        }, true);
        // (1.4.1) FR24's map plays a flight - its panel's Playback, the Playback of each of its recent flights, its search's -
        // by opening the aircraft's log page with the flight in its address in a new window (window.open): in the app,
        // FR24's own player page of it in this one, at once - no window, no log page first (the iPhone app opens none)
        try {
          var oWinOpen = window.open;
          if (typeof oWinOpen === 'function') {
            window.open = function (url) {
              var id = url != null && url !== '' ? mxPbLinkId(url) : '';
              if (id && mxPhoneApp()) { mx.pbToPlayer = (mx.pbToPlayer || 0) + 1; mx.pbOpens = (mx.pbOpens || 0) + 1; mxNav(mxPbPhoneUrl(id)); return null; }
              return oWinOpen.apply(this === undefined ? window : this, arguments);
            };
          }
        } catch (e) { /* the page's own */ }
      })();
    }
    // (1.3: the flight's log page and its player in a tab of their own, however it was clicked - the map, its panel and
    // board left as they were. A browser that will not open one - a pop-up blocker: in this tab after all)
    var mxTab = function (u) { var wn = null; try { wn = window.open(u, '_blank'); } catch (e) { wn = null; } if (wn) { try { wn.opener = null; } catch (e) { /* ignore */ } } else mxNav(u); };
    function mxPbOpen(w, t, newTab) {
      var id = isHex(w.hex) && w.dep > 0 ? mxPbSynId(w.hex, w.dep) : w.id > 0 ? Number(w.id).toString(16) : isHex(w.hex) ? mxPbSynId(w.hex, 0) : '';
      var go = function (u) { mxTab(u); };
      // (1.3.12: in the phone app, FR24's own player page, in this page)
      if (id && mxPhoneApp()) { mxNav(mxPbPhoneUrl(id)); return; }
      if (w.reg && id && !mxPhoneApp()) { go(mxPbLogUrl(w.reg, id)); return; }
      var root = document.documentElement; root.style.cursor = 'progress';
      mxPbAsk({ id: id, hex: w.hex || '', reg: w.reg || '', cs: w.cs || '', dep: w.dep || 0, at: w.at || 0, apId: w.apId || 0, kind: w.kind || '' }).then(function (d) {
        root.style.cursor = '';
        if (d && d.reg && !mxPhoneApp()) { go(mxPbLogUrl(d.reg, d.hex && d.dep ? mxPbSynId(d.hex, d.dep) : d.id)); return; }
        if (!newTab && d && mxPbShow(d, false, null)) return;
        // (1.2.6: no registration known, here or to FR24 - FR24's own Playback would open its list of aircraft types,
        // /data/aircraft/#<id>: FR24's player page of the flight instead - its own id's page, or, for one known only here,
        // FR24's flights page given the flight to play. Nothing known of the flight at all: FR24's own Playback after all)
        var fid = d && d.id ? String(d.id).toLowerCase() : id;
        if (fid && MX_PB_SYN.test(fid)) { if (d) go('/data/flights?tl-pb=' + fid); return; }
        if (fid && /^[0-9a-f]{1,8}$/.test(fid)) { go('/data/playback/' + fid); return; }
        pbFallback(t, newTab);
      });
    }
    // ---- (1.2.4) FR24's aircraft page (/data/aircraft/<reg>) and flight-number page play a flight in place: the row's Play
    // asks FR24 for the flight (/common/v1/flight-playback.json) and FR24's page script draws it in the page's own player -
    // map, slider, figures, graph. A flight known only here ("ff" + address + take-off), or one FR24 answers with no track
    // (a blocked flight, one older than its week): answered here from the flight's track as kept, in FR24's own form
    var mxLpPhotos = new Map();
    function mxLegacyPbJson(d) {
      var tr = [];
      (d.pts || []).forEach(function (p) {
        if (!p || !fin(p.t) || !fin(p.lat) || !fin(p.lon)) return;
        var ft = p.gnd ? 0 : fin(p.alt) ? Math.max(0, Math.round(p.alt)) : null; if (ft === null) return;
        var kt = fin(p.gs) ? Math.max(0, Math.round(p.gs)) : 0, vr = fin(p.vr) ? Math.round(p.vr) : 0;
        var ems = fin(p.ag) || fin(p.ias) || fin(p.tas) ? { altGPS: fin(p.ag) ? Math.round(p.ag) : null, ias: fin(p.ias) ? Math.round(p.ias) : null, tas: fin(p.tas) ? Math.round(p.tas) : null } : null;
        var o = { latitude: p.lat, longitude: p.lon, altitude: { feet: ft, meters: Math.round(ft * 0.3048) }, speed: { kmh: Math.round(kt * 1.852), kts: kt, mph: Math.round(kt * 1.15078) },
          verticalSpeed: { fpm: vr, ms: Math.round(vr * 0.0508) / 10 }, heading: fin(p.trk) ? Math.round(p.trk) : 0, squawk: /^[0-7]{4}$/.test(p.sq || '') ? p.sq : null, timestamp: Math.round(p.t), ems: ems };
        if (tr.length && tr[tr.length - 1].timestamp >= o.timestamp) return;
        tr.push(o);
      });
      var ap = function (a) { return a && a.code ? { name: a.name || a.city || a.code, code: { iata: a.code, icao: a.code }, position: { latitude: fin(a.lat) ? a.lat : null, longitude: fin(a.lon) ? a.lon : null, altitude: 0, country: { name: '', code: '' }, region: { city: a.city || a.name || a.code } }, timezone: { name: a.tz || 'UTC', offset: 0, abbr: '', abbrName: '', isDst: false }, visible: true, website: null } : null; };
      var dep = Number(d.dep) || null, arr = Number(d.arr) || null;
      var flight = {
        identification: { id: String(d.id), row: null, number: { default: d.flightNumber || null, alternative: null }, callsign: d.cs || null, codeshare: null },
        status: { live: false, text: arr ? 'Landed' : 'Unknown', icon: null, estimated: null, ambiguous: false },
        aircraft: { model: { code: d.type || '', text: d.model || d.type || '' }, countryId: null, registration: d.reg || null, identification: { modes: String(d.hex || '').toUpperCase() || null, registration: d.reg || null, serialNo: d.msn || null }, availability: { serialNo: true, age: false } },
        owner: null, airline: d.operator ? { name: d.operator, code: null, short: d.operator } : null,
        airport: { origin: ap(d.origin), destination: ap(d.destination), real: null },
        median: { time: null, delay: null, timestamp: null },
        time: { scheduled: { departure: null, arrival: null }, real: { departure: dep, arrival: arr }, estimated: { departure: null, arrival: null }, other: { eta: null, duration: arr && dep && arr > dep ? arr - dep : null } },
        track: tr, aircraftImages: [], availability: []
      };
      return { result: { request: { callback: null, device: null, flightId: String(d.id), format: 'json', pk: null, timestamp: dep, token: null }, response: { timestamp: Math.floor(Date.now() / 1000), altitudeFilter: false, data: { flight: flight } } },
        _api: { copyright: 'Copyright (c) 2014-2026 Flightradar24 AB. All rights reserved.', legalNotice: '', version: '1.0' } };
    }
    function mxLegacyPb(url, input, init) {
      var q = {}; try { new URL(url, location.href).searchParams.forEach(function (v, k) { q[k] = v; }); } catch (e) { /* none */ }
      var id = String(q.flightId || '').toLowerCase(), ts = Number(q.timestamp) || 0; if (!/^[0-9a-f]{1,16}$/.test(id)) return null;
      var ours = function () {
        return mxPbAsk({ id: id, dep: MX_PB_SYN.test(id) ? 0 : ts }, 30000).then(function (d) {
          if (!d) return null;
          if (d.hex && d.photos && d.photos.length) mxLpPhotos.set(String(d.hex).toUpperCase(), d.photos);
          mx.lpPlays = (mx.lpPlays || 0) + 1;
          return jsonResponse(null, mxLegacyPbJson(d));
        });
      };
      if (MX_PB_SYN.test(id)) return ours().then(function (r) { return r || jsonResponse(null, { result: { request: {}, response: { data: { flight: null } } } }); });
      // (FR24's own flight: FR24's answer when it has the track; else the track as kept)
      return oFetch.call(window, input, init).then(function (r) {
        return r.clone().json().then(function (j) {
          var f = j && j.result && j.result.response && j.result.response.data && j.result.response.data.flight;
          if (f && Array.isArray(f.track) && f.track.length) return r;
          return ours().then(function (o) { return o || r; });
        }, function () { return ours().then(function (o) { return o || r; }); });
      }, function (e) { return ours().then(function (o) { if (o) return o; throw e; }); });
    }
    // (its pictures beside the player: FR24's, else those of the aircraft the flight was answered with)
    // (1.2.6: FR24's player takes a "sideview" before any photo - for an aircraft it has no photo of, the side view of its
    // type, often one FR24 has no file of (GL5T.jpg, 404) - and then shows no picture at all. Its answer is kept only when
    // it has a real photo; else the aircraft's pictures as shown everywhere else - the flight's own, or those asked of the
    // userscript, JetPhotos first - and FR24's answer when there are none)
    var mxLpReg = function () { var m = location.pathname.match(/^\/data\/aircraft\/([^\/?#]+)/i); try { return m ? decodeURIComponent(m[1]).toUpperCase() : ''; } catch (e) { return ''; } };
    function mxLegacyImages(url, input, init) {
      var hx = String((/[?&]aircraft=([0-9a-f]{6})/i.exec(url) || [])[1] || '').toUpperCase(); if (!hx) return null;
      var e = function (s) { return String(s || '').replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
      var good = function (u) { return /^https:\/\//i.test(String(u || '')); };
      var ours = function () {
        var ph = mxLpPhotos.get(hx); if (ph && ph.length) return Promise.resolve(ph.filter(function (x) { return x && good(x.url); }));
        return photosWithin({ hex: hx, reg: mxLpReg() }, 8000).then(function (p) {
          return (p || []).map(function (x) { return x ? { url: x.large || x.medium || x.thumb || '', link: x.link || '', copyright: x.credit || '' } : null; }).filter(function (x) { return x && good(x.url); });
        }, function () { return []; });
      };
      var mine = function (r) {
        return ours().then(function (ph) {
          if (!ph.length) return r || jsonResponse(null, null);
          var p = ph[0], src = /jetphotos/i.test(p.link || p.url) ? 'Jetphotos' : /planespotters/i.test(p.link || p.url) ? 'Planespotters' : '';
          mx.lpImages = (mx.lpImages || 0) + 1;
          return jsonResponse(null, { medium: ph.map(function (x) { return { src: x.url, link: x.link || x.url, copyright: e(x.copyright || ''), source: src }; }) });
        });
      };
      return oFetch.call(window, input, init).then(function (r) {
        return r.clone().json().then(function (j) {
          if (!(j && Array.isArray(j.medium) && j.medium.length && j.medium[0] && j.medium[0].src)) return mine(r);
          // (a real photo with a side view as well: the photo - the side view would be shown first)
          if (!('sideview' in j)) return r;
          var j2 = Object.assign({}, j); delete j2.sideview; return jsonResponse(r, j2);
        }, function () { return mine(r); });
      }, function () { return mine(null); });
    }
    // A playback page opened by its address (a new tab, a reload, FR24's own link): one of these flights, or FR24's own page
    // of a flight it locks (older than its week), shows nothing of (a blocked flight's) or has no page for - the flight
    // asked for once, and the page given its track when there is one; FR24's own page as it is otherwise
    var mxPbTried = {};
    // A playback page FR24 has no page of - a flight known only here, or one FR24's server answers without its app - opened
    // by its address: FR24's flights page opened in its place (FR24's app, and so its router), marked, and the playback
    // given to the router there; its address the playback's again
    var mxPbParam = function () { var m = /[?&]tl-pb=([0-9a-f]{1,16})(?:&|$)/i.exec(location.search); return m ? m[1].toLowerCase() : ''; };
    // (the flight's aircraft page, where FR24 plays it in place; asked of the userscript, which aircraft it was)
    // (1.4.0) FR24's flights page given a flight to play: its search form not shown while the flight is made ready - FR24's
    // page covered, as its own pages load, until its player is in (or nothing came of it: the page as it is)
    var mxPbVeil = null;
    function mxPbVeilOn() {
      if (mxPbVeil) return;
      var dark = false; try { dark = !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches); } catch (e) { dark = false; }
      var v = document.createElement('div'); v.id = 'tl-pb-veil'; v.setAttribute('role', 'status'); v.setAttribute('aria-live', 'polite');
      v.style.cssText = 'position:fixed;inset:0;z-index:2147483000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;background:' + (dark ? '#141414' : '#f2f2f2') + ';color:' + (dark ? '#e6e6e6' : '#333') + ';font:500 15px/1.4 Inter,Roboto,Arial,sans-serif';
      v.innerHTML = '<div style="width:40px;height:40px;border-radius:50%;border:4px solid ' + (dark ? '#3a3a3a' : '#ddd') + ';border-top-color:#f8c023;animation:tlPbSpin .8s linear infinite"></div><div>Loading playback\u2026</div><style>@keyframes tlPbSpin{to{transform:rotate(360deg)}}</style>';
      mxPbVeil = v; (document.body || document.documentElement).appendChild(v);
      if (!document.body) document.addEventListener('DOMContentLoaded', function () { if (mxPbVeil && mxPbVeil.parentNode !== document.body && document.body) document.body.appendChild(mxPbVeil); }, { once: true });
      oSetTimeout(mxPbVeilOff, 35000);
    }
    function mxPbVeilOff() { if (mxPbVeil) { try { mxPbVeil.remove(); } catch (e) { /* gone */ } mxPbVeil = null; } }
    var mxPbAway = function (id) {
      if (mx.pbAway === id) return; mx.pbAway = id;
      if (mxPbParam() === id && /^\/data\/flights\/?$/i.test(location.pathname)) mxPbVeilOn();
      mxPbAsk({ id: id }, 30000).then(function (d) {
        // (nothing of it: FR24's page as it is - shown again)
        if (!d) mxPbVeilOff();
        if (d && d.reg && !mxPhoneApp()) { mxNav(mxPbLogUrl(d.reg, d.hex && d.dep && MX_PB_SYN.test(id) ? mxPbSynId(d.hex, d.dep) : id), true); return; }
        if (!d) return;
        // (1.2.6: an aircraft of no registration anywhere - no log page to play it on: FR24's own player page, given the
        // flight by FR24's router - here when this page is FR24's app, else on FR24's flights page, where it is)
        var gp = mxGp(); if (gp && gp.$inertia && gp.$page && mxPbShow(d, true, null)) return;
        // (1.4.0: FR24's app not started yet - the flight as made ready kept for it, not asked for again: twice the wait)
        mxPbAwayGot = { id: id, d: d, at: Date.now() };
        if (!mxPbParam()) mxNav('/data/flights?tl-pb=' + id, true); else mxPbWanted = id;
      });
    };
    // (an address of the version before: its flight's aircraft page, where it plays)
    var mxPbWanted = '';
    if (mx.on && mxPbParam()) mxPbAway(mxPbParam());
    if (mx.on) (function () {
      var m = location.pathname.match(/^\/data\/playback\/([0-9a-f]{1,16})\/?$/i); if (!m) return;
      var id = m[1].toLowerCase();
      if (MX_PB_SYN.test(id)) { mxPbAway(id); return; }
      // (FR24's own id: its page as FR24's server gives it - left to FR24 when it is FR24's app, else the flights page)
      var check = function () { if (!document.querySelector('#app[data-page]') && /^\/data\/playback\//i.test(location.pathname)) mxPbAway(id); };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { oSetTimeout(check, 1500); }); else oSetTimeout(check, 1500);
    })();
    var mxFact = function (p, key) { var f = p && Array.isArray(p.facts) ? p.facts.filter(function (x) { return x && x.key === key; })[0] : null; return f && !mxNA(f.value) ? String(f.value) : ''; };
    function mxPbTake(pg, id, viaFlights) {
      var p = pg.props || {}; if (p.trailSource === 'tl' || mxPbTried[id]) return;
      var own = pg.component === 'Data/NewFlightPlayback', none = own && !(Array.isArray(p.trailRoute) && p.trailRoute.length) && !(Array.isArray(p.trail) && p.trail.length);
      // (FR24's page of a blocked flight: no callsign, flight number or registration of it - the identity it hides given)
      var noName = own && mxNA(p.callsign) && mxNA(p.flightNumber) && (!p.aircraft || mxNA(p.aircraft.registration)) && !mxFact(p, 'registration');
      if (!(viaFlights || MX_PB_SYN.test(id) || !own || p.playbackLock != null || p.trailSource === 'mock' || none || noName)) return;
      mxPbTried[id] = 1; if (viaFlights) mxPbWanted = '';
      var at = pg.component + '|' + pg.url, ft = (own && p.flightTimes) || {}, n = function (v) { return Number(v) > 1e9 ? Number(v) : 0; };
      var kept = viaFlights && mxPbAwayGot && mxPbAwayGot.id === id && Date.now() - mxPbAwayGot.at < 120000 ? mxPbAwayGot.d : null;
      (kept ? Promise.resolve(kept) : mxPbAsk({ id: id, reg: (own && ((p.aircraft && !mxNA(p.aircraft.registration) && p.aircraft.registration) || mxFact(p, 'registration'))) || '', cs: (own && !mxNA(p.callsign) && p.callsign) || '', flightNumber: (own && !mxNA(p.flightNumber) && p.flightNumber) || '',
        dep: n(ft.actualDeparture) || n(ft.scheduledDeparture), arr: n(ft.actualArrival) })).then(function (d) {
        if (!d) return;
        // (still on FR24's page it was asked for: not when the user has moved on meanwhile - FR24's own page, not the address
        // bar, which a page may write over as it starts)
        var gp = mxGp(), cur = gp && gp.$page; if (!cur || cur.component + '|' + cur.url !== at) return;
        mxPbShow(d, true, cur.component === 'Data/NewFlightPlayback' && cur.props && cur.props.trailSource !== 'tl' ? cur.props : null);
      });
    }
    // A flight's KML or CSV, as FR24's download asks for it (/download/?flight=<id>&file=kml|csv&history=<its departure>):
    // made in the userscript from FR24's own track of the flight, else the monitor's; FR24's "not available" otherwise
    var mxTfWait = new Map(), mxTfSeq = 0;
    function mxTrackFile(url) {
      var q = {}; try { new URL(url, location.href).searchParams.forEach(function (v, k) { q[k] = v; }); } catch (e) { /* none */ }
      // (FR24's id of a flight as hex - 8 characters - or, written out in decimal, 9 digits or more)
      var raw = String(q.flight || '').toLowerCase(), fid = MX_PB_SYN.test(raw) ? raw : /^\d{9,}$/.test(raw) ? Number(raw).toString(16) : mxFidHex(raw), file = q.file === 'kml' ? 'kml' : 'csv';
      var none = function () { return new Response('', { status: 404, headers: { 'content-type': 'text/plain' } }); };
      if (!fid) return Promise.resolve(none());
      return new Promise(function (res) {
        var rid = 'tf' + (++mxTfSeq), t = oSetTimeout(function () { mxTfWait.delete(rid); res(none()); }, 45000);
        mxTfWait.set(rid, function (d) { oClearTimeout(t); mxTfWait.delete(rid); mx.files = (mx.files || 0) + (d && d.ok ? 1 : 0); res(d && d.ok && d.text ? new Response(d.text, { status: 200, headers: { 'content-type': d.type || 'text/plain' } }) : none()); });
        post('trackFile', { rid: rid, fid: fid, file: file, ts: Number(q.history) || 0 });
      });
    }
    function onTrackFileGot(d) { var f = d && mxTfWait.get(d.rid); if (f) f(d); }
    // every request of FR24's these options answer: their answer, or null (FR24's own request goes on)
    function mxFetch(url, input, init) {
      if (!mx.on) return null;
      if (/\/webapi\/v1\/bookmarks(?:$|\?(?!.*sort))/.test(url) && !/\/bookmarks\/sort/.test(url)) return mxBookmarks(input, init);
      if (/\/restapi\/v1\/widgets\/last-clicked-flights(?:$|[?#])/.test(url)) return mxLastClicked(input, init);
      if (/\/airport-history\/\d+(?:\/recent)?(?:[?#]|$)/.test(url)) return mxAirportHistory(input, init, url);
      if (/\/common\/v1\/flight-playback\.json\?/.test(url)) { var lp = mxLegacyPb(url, input, init); if (lp) return lp; }
      if (/^(?:https?:\/\/[^/]*flightradar24\.com)?\/aircraft\/images\/?\?(?:.*&)?aircraft=[0-9a-f]{6}/i.test(url)) { var li = mxLegacyImages(url, input, init); if (li) return li; }
      if (/^(?:https?:\/\/[^/]*flightradar24\.com)?\/download\/check-quota\?/.test(url)) return Promise.resolve(jsonResponse(null, { quotaLeft: 60, quota: 60, expires: Date.now() + 86400e3 }));
      if (/^(?:https?:\/\/[^/]*flightradar24\.com)?\/download\/?\?(?:.*&)?file=(?:kml|csv)(?:&|$)/.test(url)) return mxTrackFile(url);
      if (/\/\/tl-wx\.invalid\//.test(url)) return mxTile(url);
      if (/\/api\/v1\/weather\/auth\b/.test(url)) return mxAuth().then(function (o) { return jsonResponse(null, o); }, function (e) { mxFail(e); return jsonResponse(null, { data: null }); });
      if (/adn\.velocityweather\.com\/v1\/[^/]+\/reports\/lightning\/region\.json/.test(url)) return mxLightning(url);
      if (/\/assets\/images\/weather\/velocity\/tl[a-z]+\d*[dn]\.png/.test(url)) return mxWxIcon(url);
      // (1.3: and the airports with no METAR of their own whose weather the monitor gave - Barrow/Walney's - among them)
      if (/\/weather\/stations\?bbox=/.test(url)) return mxOwnOr(input, init, function (j) { return Array.isArray(j) && j.length > 0; }, function () { return mxStations(url); }).then(function (r) { return mxApWxAdd(r, url); });
      if (/\/weather\/airsigmetsbbox\?/.test(url)) return mxOwnOr(input, init, function (j) { return Array.isArray(j) && j.length > 0; }, mxAirsigList);
      if (/\/json\/tracks(?:[?#]|$)/.test(url)) return mxOwnOr(input, init, mxTrackOk, mxTracks).then(mxTracksPac);
      return null;
    }

    window.fetch = function (input, init) {
      if (!optOn('on')) return oFetch.apply(window, arguments);   // (1.3: switched off - FR24's own, untouched)
      var url = urlOf(input), m;
      noteReq('fetch', (init && init.method) || (input && input.method), url);
      // (1.3.5: a page of one of the aircraft directory's added families or types, should FR24's router ask with fetch: as
      // with its XHR - FR24's page it is made from asked for, once the monitor's page of it is here, and made theirs)
      if (/\/data\/aircraft\//i.test(url)) {
        var aih = init && init.headers, ainer = aih && (aih['X-Inertia'] || aih['x-inertia'] || (typeof aih.get === 'function' && aih.get('X-Inertia'))), afq = ainer ? acPageReq(url) : null;
        if (afq) { var aself = this; return acAskPage(afq).then(function (d) { return oFetch.call(aself, afq.refUrl, init).then(function (res) { if (!res.ok) return res; return res.clone().json().then(function (j) { return j && j.component && j.props ? jsonResponse(res, acPageOf(j, afq, d)) : res; }, function () { return res; }); }); }); }
      }
      // (1.3.1: a move to an airport's statistics page within FR24, should its router ask with fetch: unlocked as the first load is)
      if (STATS_PAGE_RE.test(url)) {
        var ih = init && init.headers, inertia = ih && (ih['X-Inertia'] || ih['x-inertia'] || (typeof ih.get === 'function' && ih.get('X-Inertia')));
        if (inertia) return oFetch.apply(this, arguments).then(function (res) { if (!res.ok) return res; return res.clone().json().then(function (j) { return statsUnlock(j) ? jsonResponse(res, j) : res; }, function () { return res; }); });
      }
      // the userscript's own lookups (boards for filed plans, registration searches): passed through untouched
      try {
        var hd = init && init.headers;
        if (hd && (hd['X-TL-Internal'] || (typeof hd.get === 'function' && hd.get('X-TL-Internal')))) {
          var h2 = {}; if (typeof hd.forEach === 'function') hd.forEach(function (v, k) { if (!/^x-tl-internal$/i.test(k)) h2[k] = v; }); else for (var hk in hd) if (hk !== 'X-TL-Internal') h2[hk] = hd[hk];
          return oFetch.call(this, input, Object.assign({}, init, { headers: h2 }));
        }
      } catch (e) { /* fall through */ }
      try {
        // (1.2.0) FR24's locked map options: their weather authorization, tiles, stations, AIRMETs/SIGMETs, lightning, tracks
        var mxr = mxFetch(url, input, init); if (mxr) return mxr;
        // board detail card of a kept row (an earlier or later page): from what was kept
        if ((m = url.match(/\/api\/v\d+\/airports\/(\d+)\/(arrivals|departures)\/(\d+)(?:$|[?#])/)) && Number(m[3]) >= 20000000000 && archById.has(Number(m[3]))) { stats.details++; var arK = archById.get(Number(m[3])), arA = Number(m[1]), arD = m[2]; return archDetail(arK, arA, arD).then(function (r) { return cardRwy(r, arA, arD, !!arK.own, arK.r && arK.r.hex); }); }
        // board detail card of a row this script added: answered locally, instantly (FR24 would say 404)
        if ((m = url.match(/\/api\/v\d+\/airports\/(\d+)\/(arrivals|departures)\/(\d+)(?:$|[?#])/)) && Number(m[3]) >= 9000000000) {
          var sid = Number(m[3]) - 9000000000, rec0 = recOf(sid), route0 = routeNow(sid) || {};
          if (rec0) { stats.details++; var sAp = Number(m[1]), sKind = m[2]; return photosWithin(rec0, 2800).then(function (ph) { return cardRwy(jsonResponse(null, boardDetailFor(sid, rec0, route0, sKind, sAp, ph)), sAp, sKind, false, rec0.hex); }); }
        }
        // (1.4.0: a row of the monitor's on-ground list - FR24 has no such row: no pictures of FR24's, at once)
        if ((m = url.match(/\/api\/v\d+\/airports\/(\d+)\/on-grounds\/(\d+)\/aircraft-images/)) && Number(m[2]) >= 40000000000) return Promise.resolve(jsonResponse(null, { data: { images: [] } }));
        if ((m = url.match(/\/api\/v\d+\/airports\/(\d+)\/on-grounds\/(\d+)\/aircraft-images/)) && Number(m[2]) >= 9000000000) {
          var gid = Number(m[2]) - 9000000000, grec = resolved.get(gid);
          if (grec) return photosWithin(grec, 2800).then(function (ph) { return jsonResponse(null, { data: { images: ph.slice(0, 3).map(boardImage) } }); });
        }
        if (LIST_RE.test(url)) return listFetch(this, arguments, url);
        // (1.1.5) a page of a board other than its first, its whole list kept here: answered from it, at once
        if (optOn('boards') && (m = url.match(/\/api\/v\d+\/airports\/(\d+)\/(departures|arrivals)\?/))) { var kpg = keptPage(Number(m[1]), m[2], url); if (kpg) return Promise.resolve(jsonResponse(null, kpg)); }
        // (a landing place the userscript learned is no airport of FR24's: its boards, opened from its marker, answered
        // here - empty - instead of FR24's "not found")
        if ((m = url.match(/\/api\/v\d+\/airports\/(\d+)\/(?:departures|arrivals|on-grounds)\b/)) && Number(m[1]) > 9000000 && Number(m[1]) < 10000000) return Promise.resolve(jsonResponse(null, { data: [], meta: { currentPage: 1, previousPage: null, nextPage: null, hasMorePreviousData: false, hasMoreNextData: false } }));
      } catch (e) { stats.errors++; stats.lastError = String(e); }
      // (1.3: an OurAirports airport's board - FR24 has none: an empty one of FR24's form, filled below as FR24's own are -
      // the flights kept for it, those followed here)
      // (1.3.4: FR24's searches - with the OurAirports airports)
      if (/\/api\/v\d+\/airports\/search\?/.test(url)) { var sap = searchFetch(this, arguments, url, 'airports'); if (sap) return sap; }
      // (1.3.2: by either of its addresses - api.flightradar24.com/common/v1 and, newer, www.flightradar24.com/common/v2)
      if (/\/common\/v\d+\/airport\.json\?/.test(url) && oaByCode.size) { var oaJ = oaAirportJson(url); if (oaJ) return Promise.resolve(jsonResponse(null, oaJ)); }
      // (1.3.1) An OurAirports airport's window on the map: FR24 asks its airport API for it by id - its details, pictures,
      // weather and delays - and for an airport it does not have, its server says "not found" and the window shuts
      // before it opens. Answered here in FR24's own form: the details from the list; no pictures; the weather the
      // monitor makes for it (apwx.cjs - waited for, a few seconds at most; FR24 shows "N/A" when there is none); no delays
      // (1.3.8: any version of the API, any part, by id or code - oaApiTarget)
      var oaT = oaApiTarget(url);
      if (oaT) {
        // (1.3.11: FR24's own request, for the FR24 airport the OurAirports one's pages are made from - a part not yet seen)
        var oaSelf = this, oaArgs = arguments, oaRef = function (refId) {
          var ru = apRefUrl(url, refId); if (!ru) return Promise.reject(new Error('no address'));
          var a0 = oaArgs[0], RQ = window.Request;
          return oFetch.apply(oaSelf, RQ && a0 instanceof RQ ? [new RQ(ru, a0)] : [ru, oaArgs[1]]);
        };
        var oaAns = oaApi(oaT.id, oaT.part, oaRef); if (oaAns) return oaAns.then(function (j) { return jsonResponse(null, j); });
      }
      var oaB = url.match(/\/api\/v\d+\/airports\/(\d+)\/(?:departures|arrivals|on-grounds)\b/), oaBoard = !!oaB && Number(oaB[1]) >= 1e7;
      var p = oaBoard ? Promise.resolve(jsonResponse(null, { data: [], meta: { currentPage: Number((url.match(/[?&]page=(-?\d+)/) || [])[1]) || 1, previousPage: null, nextPage: null, hasMorePreviousData: false, hasMoreNextData: false } })) : oFetch.apply(this, arguments);
      try {
        // (1.3.8) FR24's own answer for one of its airports: its shape kept (apShapeNote); and FR24's "not found" for any
        // request about an OurAirports airport - an address of its not answered here: counted, named by the health check
        var apOwn = !oaBoard && url.match(OA_API_RE);
        if (apOwn && /^\d+$/.test(apOwn[1]) && Number(apOwn[1]) < 9000000 && !/^\/(?:departures|arrivals|on-grounds)\b/i.test(apOwn[2] || '')) { var apPart = (apOwn[2] || '').toLowerCase(); p.then(function (res) { if (res.ok) res.clone().json().then(function (j) { apShapeNote(apPart, j); }, function () {}); }, function () {}); }
        // (1.3.12) FR24's weather for one of its own airports that sends no METAR - an answer with no conditions and no
        // temperature in it: the monitor's (the weather model at the airport, its METAR made from it) put into FR24's
        // answer, waited for 8 s at most - FR24 draws it itself, in its panel's tiles and, on a phone, in the panel's
        // header before the panel is pulled up. An answer with weather of its own is left as it is
        if (apOwn && /^\d+$/.test(apOwn[1]) && Number(apOwn[1]) < 9000000 && /^\/weather\/?$/i.test(apOwn[2] || '')) return apWxFill(p, Number(apOwn[1]));
        var oaN = oaById && oaById.size && /flightradar24\.com\//.test(url) ? url.match(/\/(\d{8,9})(?=[/?#]|$)/) : null;
        if (oaN && oaById.has(Number(oaN[1]))) { var oaPath = url.replace(/^https?:\/\/[^/]+/, '').replace(/[?#].*$/, '').replace(/\/\d{8,9}(?=\/|$)/g, '/:id'); p.then(function (res) { if (res.status === 404) { stats.oaMiss = (stats.oaMiss || 0) + 1; stats.oaMissPath = oaPath; } }, function () {}); }
        // FR24's own airport answer (its map panel's): its runways kept for the panel's table and the airport pages
        if (/\/common\/v\d+\/airport\.json\?/.test(url) && /runways/.test(url)) { p.then(function (res) { if (res.ok) res.clone().json().then(noteAirportJson, function () {}); }, function () {}); return p; }
        // FR24's picture list of an aircraft on the ground (board card): its airport-data pictures taken out
        if (/\/aircraft-images(?:$|[?#])/.test(url)) {
          return p.then(function (res) {
            if (!res.ok) return res;
            return res.clone().json().then(function (j) {
              var imgs = j && j.data && j.data.images; if (!Array.isArray(imgs) || !imgs.some(adJson)) return res;
              j.data.images = imgs.filter(function (im) { return !adJson(im); }); return jsonResponse(res, j);
            }, function () { return res; });
          });
        }
        // (the same list asked for with fetch rather than XHR: its frames patched the same way, binary or base64 text)
        if (/fr24\.feed\.api\.v1\.Feed\/TopFlights(?:$|\?)/.test(url)) {
          stats.topSeen = (stats.topSeen || 0) + 1;
          return p.then(function (res) {
            if (!res.ok) return res;
            var ct = res.headers.get('content-type') || '', text = /grpc-web-text/i.test(ct);
            return (text ? res.clone().text() : res.clone().arrayBuffer()).then(function (body) {
              var out;
              if (text) { var arr = []; b64DecodeInto(body.slice(0, body.length - body.length % 4), arr); out = b64Encode(new Uint8Array(patchFrames(Uint8Array.from(arr).buffer, patchTopFlights))); }
              else out = patchFrames(body, patchTopFlights);
              var h = new Headers(res.headers); h.delete('content-length'); h.delete('content-encoding');
              return new Response(out, { status: res.status, statusText: res.statusText, headers: h });
            }, function () { return res; });
          });
        }
        if (/\/most-tracked(?:$|[?#/])/.test(url)) {
          return p.then(function (res) {
            if (!res.ok) return res;
            return res.clone().json().then(function (j) { return fillFlightList(j) ? jsonResponse(res, j) : res; }, function () { return res; });
          });
        }
        if (optOn('search') && /\/v1\/search\/web\/find\?/.test(url)) {
          var qm = url.match(/[?&]query=([^&]*)/); var q = qm ? decodeURIComponent(qm[1].replace(/\+/g, ' ')).trim().toUpperCase() : '';
          if (q.length < 2) return p;
          var mine = askSearch(q);     // (asked of the userscript at once, answered while FR24's own search runs)
          return p.then(function (res) {
            // (a route FR24 has nothing for - or no answer at all: the flights worked out here on it, on their own)
            if (!res.ok) return /^[A-Z0-9]{3,4}\s*[-–—>/]\s*[A-Z0-9]{3,4}$/.test(q) ? mine.then(function (ans) { var rr = routeRows(ans && ans.live), sc = rr.length ? ((ans && ans.rows) || []).filter(function (r) { return r && r.type === 'schedule'; }) : []; if (!rr.length) return res; stats.searchHits += rr.length + sc.length; return jsonResponse(null, { results: rr.concat(sc), stats: { total: { all: rr.length + sc.length, live: rr.length, schedule: sc.length }, count: { live: rr.length, schedule: sc.length } } }); }) : res;
            return Promise.all([res.clone().json(), mine]).then(function (both) {
              // (1.2.1: the live flights FR24 lists with no route - every page, not the map's alone, where none of them is
              // in view: "N/A - N/A" on a data page - their routes from the monitor's own calculation first, a moment at most)
              var lj = both[0], need = lj && Array.isArray(lj.results) ? lj.results.filter(function (r) { return r && r.type === 'live' && r.id && r.detail && !r.detail.schd_to && !routeNow(parseInt(r.id, 16)); }).map(function (r) { return parseInt(r.id, 16); }).filter(function (x) { return x > 0; }).slice(0, 12) : [];
              return askRoutes(need).then(function () { return both; });
            }).then(function (both) {
              var j = both[0], ans = both[1] || {}, extra = ans.rows || [];
              if (!j || !Array.isArray(j.results)) return res;
              var enriched = 0; j.results.forEach(function (r) { if (enrichAircraftRow(r)) enriched++; if (logoFix(r)) enriched++; if (liveDestFix(r)) enriched++; });
              // (aircraft found by registration: blocked on FR24 or not - its register lookup lists no flights for a blocked
              // one - for the yellow tag in the list: M-CDJC, M-PORT)
              if (q.length >= 4) j.results.filter(function (r) { return r && r.type === 'aircraft' && r.id && !recByReg(r.id); }).slice(0, 3).forEach(function (r) {
                var hx = String((r.detail && r.detail.hex) || '').toLowerCase();
                regInfo(r.id).then(function (x) { if (x && x.blocked) pbBlkNote('A', x.reg, x.hex || hx); if (x) post('searchRows', { rows: [{ reg: x.reg, hex: x.hex || hx, type: x.ty, blocked: !!x.blocked }] }); });
              });
              var add = liveEntries(q).concat(routeRows(ans.live));
              // one row per aircraft: none added for a flight - or a registration - FR24's own results already list live
              var have = {}, haveReg = {}, seen = {}; j.results.forEach(function (r) { if (!r) return; seen[r.type + ':' + String(r.id).toUpperCase()] = true; if (r.type === 'live') { have[r.id] = true; if (r.detail && r.detail.reg) haveReg[String(r.detail.reg).toUpperCase()] = true; } });
              var once = {}; add = add.filter(function (a) { if (once[a.id]) return false; once[a.id] = true; return !have[a.id] && !(a.detail.reg && haveReg[String(a.detail.reg).toUpperCase()]); });
              // the blocked aircraft and the callsigns they flew under that the userscript keeps logs of - FR24 lists neither:
              // as its aircraft (to the log page) and flight numbers (to the flight-number page)
              // (1.2.1: an aircraft row by its registration however written - "SP-CEO", "spceo" - and only once)
              var rk = function (r) { return r.type + ':' + String(r.id).toUpperCase().replace(/[^A-Z0-9]/g, ''); };
              j.results.forEach(function (r) { if (r && r.id) seen[rk(r)] = true; });
              var more = extra.filter(function (r) { if (!r || !r.id || seen[r.type + ':' + String(r.id).toUpperCase()] || seen[rk(r)]) return false; seen[rk(r)] = true; return true; });
              more.forEach(function (r) { r.detail = r.detail || {}; if (!logoFix(r) && r.detail.operator_id && !r.detail.logo) r.detail.logo = logoOf(r.detail.operator_id); });
              // the expanded card (FlightDetails) shows photos: fetch them now, while the list is being read
              // (ahead of any background work; the top result first)
              add.concat(j.results.filter(function (r) { return r && r.type === 'live'; })).slice(0, 8).reverse().forEach(function (a) { var r = resolved.get(parseInt(a.id, 16)); if (r) warmPhotos(r, true); });
              if (!add.length && !more.length) { if (!enriched) return res; stats.searchHits += enriched; return jsonResponse(res, j); }
              j.results = add.concat(j.results, more);
              try { add.concat(more).forEach(function (r) { var t = r.type; j.stats.count[t] = (j.stats.count[t] || 0) + 1; j.stats.total[t] = (j.stats.total[t] || 0) + 1; j.stats.total.all = (j.stats.total.all || 0) + 1; }); } catch (e) { /* ignore */ }
              stats.searchHits += add.length + more.length;
              return jsonResponse(res, j);
            }, function () { return res; });
          });
        }
        // detail card of a real FR24 row for a blocked flight: fill what FR24 left empty
        if ((m = url.match(/\/api\/v\d+\/airports\/(\d+)\/(arrivals|departures)\/(\d+)(?:$|[?#])/))) {
          // (an FR24 row of an earlier day, kept: its card from what was kept when FR24 no longer gives it)
          var arKept = archById.get(Number(m[3])), arAp = Number(m[1]), arKind = m[2], arRow = Number(m[3]), usedArch = false;
          return p.then(function (res) {
            if (!res.ok) { if (!arKept) return res; usedArch = true; return archDetail(arKept, arAp, arKind); }
            return res.clone().json().then(function (j) {
              var d = j && j.data; if (!d || !d.flight) return res;
              noteCard(arRow, arAp, arKind, d);
              var id = d.flight.id ? parseInt(d.flight.id, 16) : 0, rec = id ? resolved.get(id) : null;
              // (FR24's card with no aircraft - "N/A" all through, G-PTRK's - or one of a flight this script knows more of)
              if (!rec && (natInfo.has(arRow) || !(d.aircraft && d.aircraft.registration && d.aircraft.type) || !d.airline || /private owner/i.test(d.airline))) return fillNativeCard(d, arRow, arKind).then(function () { stats.details++; return jsonResponse(res, j); }, function () { return res; });
              if (!d.flight.id) return res;
              if (!rec) {
                // an ordinary flight's card: only its airport-data pictures are replaced
                if (!Array.isArray(d.images) || !d.images.some(adJson)) return res;
                d.images = d.images.filter(function (im) { return !adJson(im); });
                var ah = String((d.aircraft && (d.aircraft.hex || d.aircraft.icao24 || d.aircraft.modeS)) || '').toLowerCase(), areg = d.aircraft && d.aircraft.registration || '';
                if (d.images.length || !/^[0-9a-f]{6}$/.test(ah)) return jsonResponse(res, j);
                return photosWithin({ hex: ah, reg: areg }, 2800).then(function (ph) { d.images = goodPhotos(ph).slice(0, 3).map(boardImage); return jsonResponse(res, j); });
              }
              var label = csOf(rec);
              if (!d.flight.callsign && label) d.flight.callsign = label;
              d.aircraft = d.aircraft || {};
              if (!d.aircraft.registration && rec.reg) d.aircraft.registration = rec.reg;
              if (!d.aircraft.type && rec.type) d.aircraft.type = rec.type;
              if (!d.aircraft.name && (rec.desc || rec.type)) d.aircraft.name = rec.desc || rec.type;
              if ((!d.airline || /private owner/i.test(d.airline)) && (rec.operatorName || rec.owner)) d.airline = rec.operatorName || rec.owner;
              if (!d.airlineId && rec.operatorId) d.airlineId = rec.operatorId;
              var route = routes.get(id);
              if (route && d.schedule) { if (!d.schedule.atd && route.atd) d.schedule.atd = route.atd; if (!d.schedule.ata && route.ata) d.schedule.ata = route.ata; if (!d.schedule.eta && route.eta) d.schedule.eta = route.eta; }
              var ci = cardInfo.get(arRow); if (ci && d.schedule) { if (!ci.atd) ci.atd = Number(d.schedule.atd) || 0; if (!ci.ata) ci.ata = Number(d.schedule.ata) || 0; }
              stats.details++;
              if (Array.isArray(d.images)) d.images = d.images.filter(function (im) { return !adJson(im); });
              if (Array.isArray(d.images) && d.images.length) return jsonResponse(res, j);
              return photosWithin(rec, 2800).then(function (ph) { d.images = goodPhotos(ph).slice(0, 3).map(boardImage); return jsonResponse(res, j); });
            }, function () { return res; });
          }).then(function (out) { return cardRwy(out, arAp, arKind, usedArch && !!arKept.own, (arKept && arKept.r && arKept.r.hex) || (natInfo.get(arRow) || {}).hex || ''); });
        }
        if (optOn('boards') && (m = url.match(/\/api\/v\d+\/airports\/(\d+)\/(departures|arrivals|on-grounds)\b/))) {
          var apId = Number(m[1]), kind = m[2];
          var pageM = url.match(/[?&]page=(-?\d+)/), page = pageM ? Number(pageM[1]) : 1;
          var whole = kind !== 'on-grounds' && page === 1;
          // (the airport's kept flights, and FR24's own earlier page, asked for alongside FR24's own answer)
          var archP = kind === 'on-grounds' ? null : needBoardArch(apId), earlier = null;
          var earlierP = whole && apId < 1e7 ? oFetch.call(window, /[?&]page=/.test(url) ? url.replace(/([?&])page=-?\d+/, '$1page=-1') : url + (url.indexOf('?') >= 0 ? '&' : '?') + 'page=-1', init).then(function (r) { return r.ok ? r.json() : null; }).then(function (x) { earlier = x; }, function () { /* FR24's day without it */ }) : null;
          // (1.2.7: and the airport's runways, as logged - 1.5 s at most: the board drawn with them in)
          var rwyApP = mx.on ? mxRwyAirport(apId, 1500) : null;
          // (1.4.0: the on-ground list: the monitor's of the airport too - 2 s at most)
          var ogList = null, ogP = kind === 'on-grounds' && page === 1 ? ogAsk(apId, 2000).then(function (l) { ogList = l; }) : null;
          return Promise.all([p, archP, earlierP, rwyApP, ogP]).then(function (x) { return x[0]; }).then(function (res) {
            if (!res.ok) return res;
            return res.clone().json().then(function (j) {
              if (!j || !Array.isArray(j.data)) return res;
              var merged = false;
              if (whole && earlier && Array.isArray(earlier.data)) { var have = {}; j.data.forEach(function (e) { if (e && e.id) have[e.id] = true; }); earlier.data.forEach(function (e) { if (e && !have[e.id]) { j.data.push(e); merged = true; } }); }
              var hits = 0, today = new Date().toISOString().slice(0, 10), seenIds = [], fullList = null;
              j.data.forEach(function (e) {
                if (!e || !e.flight || !e.flight.id) return;
                var id = parseInt(e.flight.id, 16), rec = resolved.get(id);
                // (an N/A flight of FR24's own that this script follows: where it is going / came from, as reasoned)
                if (!rec) { var nr = naRecs.get(id); if (nr && kind !== 'on-grounds') { var rt = routeNow(id) || {}; nativeFill(e, { ap: (kind === 'departures' ? rt.destId : rt.originId) || 0, reg: nr.reg, hex: nr.hex, ty: nr.type, dsc: nr.desc, al: nr.operatorName || nr.owner, alId: nr.operatorId || 0, fc: nr.fcat }, kind, rt); } return; }
                var label = csOf(rec);
                if (!e.flight.callsign && label) { e.flight.callsign = label; hits++; }
                if (!e.airlineId && rec.operatorId) e.airlineId = rec.operatorId;
                if ((!e.airline || /private owner/i.test(e.airline)) && (rec.operatorName || rec.owner)) e.airline = rec.operatorName || rec.owner;
                if (!e.aircraftType && rec.type) e.aircraftType = rec.type;
                if (e.aircraft && typeof e.aircraft === 'object') { if (!e.aircraft.registration && rec.reg) e.aircraft.registration = rec.reg; if (!e.aircraft.name && (rec.desc || rec.type)) e.aircraft.name = rec.desc || rec.type; if (!e.aircraft.registeredOwners && (rec.operatorName || rec.owner)) e.aircraft.registeredOwners = rec.operatorName || rec.owner; }
                // (1.2.6: and where it came from or is going, as reasoned - FR24's own row of it said "N/A")
                if (kind !== 'on-grounds' && !e.airportId) { var rt1 = routeNow(id) || {}, o1 = kind === 'departures' ? rt1.destId : rt1.originId; if (o1) { nativeFill(e, { ap: o1 }, kind, rt1); hits++; } }
                seenIds.push(id);
              });
              // Every identified flight whose reasoned route touches this airport is listed as traffic, even when the
              // destination is only the most likely one (FR24's own "estimated / ambiguous" styling marks those). A row
              // goes on the board page whose time span holds it - page 1 (from now on) also takes the flights that landed
              // in the last hours - so paging back and forth never duplicates or misorders a row.
              var board = noteBoard(apId, kind);
              if (page === 1) {
                var present = {}; j.data.forEach(function (e) { if (e && e.flight && e.flight.id) present[e.flight.id] = true; });
                // one row per aircraft in flight, under the flight id FR24 has for it now: an aircraft can also be known
                // under an older id (from before a coverage gap, or its last flight) - "Show on map" on that one finds no
                // live flight (C-GTLA into Halifax)
                var newest = {};
                var noteId = function (rec, id) { var hx = rec && rec.hex; if (!hx) return; var lp = lastPos.get(id), t = lp ? lp.at : 0, b = newest[hx]; if (!b || t > b.t) newest[hx] = { id: id, t: t }; };
                resolved.forEach(noteId); naRecs.forEach(function (rec, id) { if (!resolved.has(id)) noteId(rec, id); });
                // (FR24's own row of the same aircraft - by its callsign, or the airframe the userscript matched it to - within an
                // hour and a half: that one stands, none of ours beside it)
                var nativeWho = []; j.data.forEach(function (e) { if (!e || e.__tlAdded || !e.flight) return; var nid = e.flight.id ? parseInt(e.flight.id, 16) : 0, nr = nid ? recOf(nid) : null; nativeWho.push({ cs: String(e.flight.callsign || '').toUpperCase(), hex: nr && nr.hex ? String(nr.hex).toLowerCase() : '', t: e.estimatedTime || e.scheduledTime || 0 }); });
                var addRow = function (rec, id) {
                  var route = routeNow(id); if (!route || present[id.toString(16)] || !boardSig(id, apId, kind)) return;
                  var lbl0 = String(csOf(rec) || '').toUpperCase(), hx0 = String(rec.hex || '').toLowerCase(), t0r = (kind === 'departures' ? (route.atd || route.std) : (route.ata || route.eta || route.sta)) || 0;
                  if (nativeWho.some(function (n) { return ((n.hex && n.hex === hx0) || (n.cs && n.cs === lbl0)) && (!t0r || !n.t || Math.abs(n.t - t0r) < 5400); })) return;
                  if (!route.landed && rec.hex && newest[rec.hex] && newest[rec.hex].id !== id) return;
                  var label = csOf(rec);
                  if (kind === 'on-grounds') {
                    j.data.push({ id: 9000000000 + id, flight: { id: id.toString(16), number: null, callsign: label }, landedTime: route.ata || null, airlineId: rec.operatorId || null, runway: null,
                      aircraft: { category: categoryOf(rec), name: rec.desc || rec.type || '', registeredOwners: rec.operatorName || rec.owner || '', registration: rec.reg || '', type: rec.type || '' }, originId: route.originId || null, activeDay: today, __tlAdded: true });
                    hits++; seenIds.push(id); return;
                  }
                  var row = boardRowFor(id, rec, route, kind, apId);
                  if (!row.scheduledTime) return;
                  j.data.push(row); hits++; seenIds.push(id);
                };
                resolved.forEach(addRow); naRecs.forEach(function (rec, id) { if (!resolved.has(id)) addRow(rec, id); });
                // (1.4.0: the monitor's aircraft on the ground there that FR24's list has not got)
                if (kind === 'on-grounds' && ogList) { try { hits += ogAdd(j.data, ogList, apId); } catch (e) { stats.errors++; stats.lastError = String(e); } }
                // (the on-ground list latest landed first, as FR24 orders it - the boards earliest first)
                if (hits) j.data.sort(kind === 'on-grounds' ? function (a, b) { return (b.landedTime || 0) - (a.landedTime || 0); } : function (a, b) { return (a.scheduledTime || a.landedTime || 0) - (b.scheduledTime || b.landedTime || 0); });
              }
              j.data.forEach(function (e) { if (e && e.flight && e.flight.id && !e.__tlAdded) board.native[parseInt(e.flight.id, 16)] = true; });
              if (page === 1) { resolved.forEach(function (rec, id) { board.sig[id] = boardSig(id, apId, kind); }); naRecs.forEach(function (rec, id) { board.sig[id] = boardSig(id, apId, kind); }); }
              boardServedAt = Date.now();
              // warm the photo cache for every identified row, so an expanded card has its pictures immediately
              seenIds.forEach(function (id) { var r = recOf(id); if (r && r.hex) warmPhotos(r, false); });
              if (seenIds.length) post('boardSeen', { airportId: apId, kind: kind, ids: seenIds });
              // FR24's own rows kept for when they drop off its free day; the kept flights of this page added, and the
              // pages before and after FR24's day opened up
              var metaWas = JSON.stringify(j.meta || null);
              if (kind !== 'on-grounds') {
                var natRows = j.data.filter(function (e) { return e && e.flight && e.flight.id && !e.__tlAdded; });
                if (natRows.length && (page === 1 || page === -1)) post('boardRows', { apId: apId, kind: kind, rows: natRows });
                if (whole) {
                  try { hits += addArch(j, apId, kind); } catch (e) { stats.errors++; stats.lastError = String(e); }
                  j.data.sort(function (x, y) { return (x.scheduledTime || x.landedTime || 0) - (y.scheduledTime || y.landedTime || 0); });
                  var kb = keepBoard(apId, kind, j.data, !pageM), pg1 = pageOf(kb, 1); kb.date = j.meta && j.meta.date || kb.date || null; fullList = j.data;
                  j.data = pg1.data; j.meta = Object.assign({}, j.meta, pg1.meta);
                  var nowS1 = Date.now() / 1000 - 900, first = j.data.filter(function (e) { return e && (e.scheduledTime || 0) >= nowS1; })[0] || j.data[j.data.length - 1];
                  placeBoard(first, apId + '/' + kind, fullList, !pageM);
                }
              }
              if (kind !== 'on-grounds') { try { hits += naEndsFill(fullList || j.data, kind, apId); } catch (e) { stats.errors++; stats.lastError = String(e); } }
              if (kind !== 'on-grounds') noteBoardRows(fullList || j.data, apId, kind);
              // (each flown row's runway, the map panel's badge beside its aircraft type - 1.2.4)
              if (mx.on) { try { hits += mxBoardRwy(j.data, kind, apId); } catch (e) { mxFail(e); } }
              if (!hits && !merged && JSON.stringify(j.meta || null) === metaWas) return res;
              stats.boardHits += hits;
              return jsonResponse(res, j);
            }, function () { return res; });
          });
        }
        if (REGLIST_RE.test(url) && /[?&]fetchBy=reg\b/.test(url)) {
          var qr = (url.match(/[?&]query=([^&#]*)/) || [])[1]; var reg = qr ? decodeURIComponent(qr.replace(/\+/g, ' ')).trim().toUpperCase() : '';
          if (!reg) return p;
          stats.listAsked = (stats.listAsked || 0) + 1;
          return p.then(function (res) {
            return res.clone().json().then(function (j) { return j; }, function () { return null; }).then(function (j) {
              var resp = listRespOf(j);
              // (1.3.7: an answer of FR24's, read, in a shape not known here - its new address may one day answer in a
              // shape of its own: left as FR24 gave it, so no aircraft's list is ever made worse here. Its shape is in
              // stats.lastList)
              if (!resp && res.ok && listUnknown(j)) {
                stats.lastList = { reg: reg, at: Date.now(), via: 'fetch', url: listUrlOf(url), status: res.status, fr24: -1, ours: null, shape: shapeOf(j, 0), left: true };
                return res;
              }
              // (FR24's own rows of flights that never took off have no flight id, and its dropdown keeps a row open by
              // that id: every such row opened and closed together, stuck open - ZZ504's two "Estimated dep" SCARB54s.
              // Each gets one of its own)
              var noId = resp && Array.isArray(resp.data) ? resp.data.filter(function (x) { return x && x.identification && !x.identification.id; }) : [];
              if (noId.length > 1) noId.forEach(function (x, i) { x.identification.id = 'f' + ((Number(x.identification.row) || i + 1) % 0xfffffff).toString(16); });
              var fr24n = resp ? (Array.isArray(resp.data) ? resp.data.length : 0) : -1;   // (-1: no list in FR24's answer at all)
              stats.lastList = { reg: reg, at: Date.now(), via: 'fetch', url: listUrlOf(url), status: res.status, fr24: fr24n, ours: null, shape: resp ? null : shapeOf(j, 0) };
              if (resp && Array.isArray(resp.data) && resp.data.length > 1) return noId.length > 1 ? jsonResponse(res, j) : res;
              // (FR24 listing nothing - a blocked aircraft, a military or N/A one it shows without a past: FAMUS62, 06-6165 -
              // the log kept here, for any aircraft; one it knows nothing of is answered at once. Whatever FR24 answered -
              // its usual shape with no flights, none at all, an error: N1876T's list said "No flights available" with its
              // flights in the log)
              return needHistory(reg).then(function (h) {
                stats.lastList.ours = h && h.data ? h.data.length : 0;
                if (!h || !h.data || h.data.length < 2) return res;
                var out = resp ? j : listShell(reg, url);
                fillList(resp || out.result.response, h, url);
                return jsonResponse(res.ok ? res : null, out);
              });
            });
          });
        }
      } catch (e) { stats.errors++; stats.lastError = String(e); }
      return p;
    };
    // (1.3.4) FR24's search box: the OurAirports airports added once all the above has made FR24's answer - its aircraft,
    // its routes, its logos - so both are in it
    (function () {
      var hooked = window.fetch;
      window.fetch = function (input, init) {
        var url = urlOf(input);
        if (optOn('on') && /\/v1\/search\/web\/find\?/.test(url)) {
          var u = null; try { u = new URL(url, location.href); } catch (e) { u = null; }
          var q = u ? (u.searchParams.get('query') || '') : '', type = u ? (u.searchParams.get('type') || '') : '';
          if (q.trim().length >= 2 && (!type || type === 'airport')) {
            var oaP = oaSearch(q, 500);
            return Promise.resolve(hooked.apply(this, arguments)).then(function (res) {
              return oaP.then(function (rows) {
                if (!rows.length || !res || !res.ok) return res;
                return res.clone().json().then(function (j) { var o = searchMerge(j, rows, q); if (o) stats.oaSearch = (stats.oaSearch || 0) + 1; return o ? jsonResponse(res, o) : res; }, function () { return res; });
              });
            });
          }
        }
        return hooked.apply(this, arguments);
      };
    })();

    // ---- bridge ---------------------------------------------------------------------------------------------
    function acceptEntries(entries) {
      if (!entries) return;
      for (var i = 0; i < entries.length; i++) {
        var r = entries[i]; if (!r || r.id == null || fr24Named.has(Number(r.id))) continue;
        var hexNum = r.hex ? parseInt(String(r.hex), 16) : 0;
        var prev = resolved.get(Number(r.id));
        var photos = Array.isArray(r.photos) && r.photos.length ? r.photos : (prev && prev.photos) || [];
        resolved.set(Number(r.id), { cs: r.cs || '', reg: r.reg || '', hex: r.hex || '', type: r.type || '', desc: r.desc || '', cat: r.cat || '', mil: !!r.mil, hexNum: hexNum > 0 ? hexNum : 0, msn: r.msn || '', owner: r.owner || '', operatorId: r.operatorId > 0 ? Number(r.operatorId) : 0, operatorIcao: r.operatorIcao || '', operatorName: r.operatorName || '', age: r.age > 0 ? Math.round(r.age) : 0, ageText: r.ageText || '', countryId: r.countryId > 0 ? Number(r.countryId) : 0, squawk: r.squawk > 0 ? Number(r.squawk) : 0, photos: photos });
        if (followSt && Number(r.id) === followSt.id) pushFollowSoon();
        if (r.hex && Array.isArray(r.photos) && r.photos.length) preloadPhotos(r.photos, !!(followSt && Number(r.id) === followSt.id));
        if (r.hex && Array.isArray(r.photos) && r.photos.length) { var pc = photoCache.get(String(r.hex).toUpperCase()); photoCache.set(String(r.hex).toUpperCase(), { photos: photos, at: Date.now(), err: '', final: !!r.photoFinal || !!(pc && pc.final && pc.photos === photos) }); }
        if (r.pos && typeof r.pos.lat === 'number') { var lp = lastPos.get(Number(r.id)); if (!lp || (r.pos.at || 0) >= lp.at) lastPos.set(Number(r.id), { lat: r.pos.lat, lon: r.pos.lon, alt: r.pos.alt, gnd: !!r.pos.gnd, at: r.pos.at || Date.now() }); }
      }
    }
    // ---- FR24's adverts --------------------------------------------------------------------------------------
    // Switched off where FR24 itself decides to show them, so the page lays itself out as it does for a subscriber:
    //  - the right-hand sidebar (video advert, 300x250 slot, upgrade promos) is drawn while the 'sidebar' store's
    //    isSidebarVisible is true; pinned to false, the map, header, search and notifications use the full width
    //  - the free-trial pop-up ('freeTrialPromo' store) never becomes eligible
    //  - the JetPhotos promo slide after the photos is the JetphotosCarousel's hidePromo prop, made its default
    // The advert slots inside panels and on the data pages are hidden by the userscript's stylesheet. Nothing is kept
    // from loading: FR24 detects ad blockers by loading adsbygoogle.js, so no "ad blocker" wall appears.
    var adFree = (function () {
      var OFF = { __v_isRef: true, get value() { return false; }, set value(v) { /* stays off */ } };   // a ref Vue unwraps
      var done = new WeakSet(), st = { sidebar: 0, trial: 0, promo: 0, session: 0 };
      function store(s) {
        if (!s || done.has(s)) return;
        try {
          if (s.$id === 'sidebar') { if (!optOn('noAds')) return; s.isSidebarVisible = OFF; done.add(s); st.sidebar++; }
          // FR24's 30-minute "Your session has timed out" (free accounts: its 'session' store, map.timeout.mins) - set
          // back the moment its timer sets it, before the overlay is drawn
          else if (s.$id === 'session') {
            var keep = function () { try { if (s.sessionSuspended) { s.$patch({ sessionSuspended: false }); st.session++; } } catch (e) { /* ignore */ } };
            s.$subscribe(keep, { flush: 'sync', detached: true }); keep(); done.add(s);
          }
          else if (s.$id === 'freeTrialPromo') { if (!optOn('noAds')) return; s.hasEligibilityToShowModal = false; s.showFreeTrialModal = OFF; done.add(s); st.trial++; }
        } catch (e) { /* ignore */ }
      }
      function app(a) {
        var p = a && a.config && a.config.globalProperties && a.config.globalProperties.$pinia;
        if (!p || !p._s || done.has(p)) return;
        done.add(p);
        p._s.forEach(store);
        try { p.use(function (c) { store(c.store); }); } catch (e) { /* ignore */ }   // stores made later
      }
      // Vue writes container.__vue_app__ right after the first render and before that render's follow-up tick, which
      // is when the sidebar (inside a client-only wrapper) would first be drawn
      try {
        if (!Object.getOwnPropertyDescriptor(Element.prototype, '__vue_app__')) {
          Object.defineProperty(Element.prototype, '__vue_app__', { configurable: true, get: function () { return undefined; }, set: function (v) { Object.defineProperty(this, '__vue_app__', { value: v, writable: true, configurable: true, enumerable: true }); try { app(v); } catch (e) { /* ignore */ } } });
        }
      } catch (e) { /* ignore */ }
      function scanApps() { document.querySelectorAll('[data-v-app]').forEach(function (el) { if (el.__vue_app__) app(el.__vue_app__); }); }
      // the carousel's props are resolved against options Vue normalises once per component and shares, so its first
      // instance turns the promo off for every later one too
      function promoOff(img) {
        if (!optOn('noAds')) return;
        var host = img.closest('[data-v-app]'), root = host && host._vnode; if (!root) return;
        var stack = [root], n = 0, v, c, i;
        while (stack.length && n++ < 200000) {
          v = stack.pop(); if (!v || typeof v !== 'object') continue;
          c = v.component;
          if (c) {
            if (c.type && c.type.__name === 'JetphotosCarousel') {
              try { var o = c.propsOptions && c.propsOptions[0] && c.propsOptions[0].hidePromo; if (o && o.default !== true) { o.default = true; st.promo++; } } catch (e) { /* ignore */ }
              try { if (c.props && c.props.hidePromo !== true) c.props.hidePromo = true; } catch (e) { /* ignore */ }
            }
            if (c.subTree) stack.push(c.subTree);
            continue;
          }
          if (v.suspense) { if (v.suspense.activeBranch) stack.push(v.suspense.activeBranch); continue; }
          if (Array.isArray(v.children)) for (i = 0; i < v.children.length; i++) stack.push(v.children[i]);
        }
      }
      var PROMO = '[data-testid$="__image__promo"]';
      try {
        new MutationObserver(function (recs) {
          for (var i = 0; i < recs.length; i++) {
            var add = recs[i].addedNodes;
            for (var j = 0; j < add.length; j++) {
              var el = add[j], img = el.nodeType === 1 ? (el.matches(PROMO) ? el : el.querySelector(PROMO)) : null;
              if (img) { scanApps(); promoOff(img); return; }
            }
          }
        }).observe(document.documentElement, { childList: true, subtree: true });
      } catch (e) { /* ignore */ }
      scanApps();
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scanApps, { once: true });
      return st;
    })();
    stats.adFree = adFree;
    // (1.3.1) FR24's adverts are asked for a slot at a time: each panel that has a slot calls its advert library
    // (window.tude - Aditude's, loaded with the page) with refreshAdsViaDivMappings([slot]), and the library then runs an
    // auction among its bidders, loads the advert into the slot and does so again on its timer. The slots are hidden
    // (the stylesheet) - the auctions, the adverts' own scripts and their requests ran all the same, behind every panel
    // opened. With "no adverts" on, that one call does nothing: no advert is asked for. FR24 itself allows for the
    // library not being there (its own check) and for a call that fills nothing. The 3D view's rewarded advert
    // (initRewardedAd - how a free account gets a 3D session) is left as it is; so is the library itself, and the
    // advert script FR24 loads to see whether adverts are blocked.
    (function () {
      var cur, noop = function () {};
      function guard(t) {
        if (!t || (typeof t !== 'object' && typeof t !== 'function')) return;
        try {
          var d = Object.getOwnPropertyDescriptor(t, 'refreshAdsViaDivMappings'); if (d && d.get && d.get.__tl) return;
          if (d && !d.configurable) return;
          var f = d ? d.value : undefined, has = !!d;
          var get = function () { if (optOn('noAds')) { stats.adsHeld = (stats.adsHeld || 0) + 1; return noop; } return has ? f : Object.getPrototypeOf(t) ? Object.getPrototypeOf(t).refreshAdsViaDivMappings : undefined; };
          get.__tl = true;
          Object.defineProperty(t, 'refreshAdsViaDivMappings', { configurable: true, enumerable: true, get: get, set: function (v) { f = v; has = true; } });
        } catch (e) { /* left as it is */ }
      }
      try {
        var d0 = Object.getOwnPropertyDescriptor(window, 'tude');
        if (!d0 || d0.configurable) {
          cur = window.tude; guard(cur);
          Object.defineProperty(window, 'tude', { configurable: true, enumerable: true, get: function () { return cur; }, set: function (v) { cur = v; guard(v); } });
        }
      } catch (e) { /* left as it is */ }
    })();
    // No picture in JetPhotos' credit-bar size anywhere on the page, whichever way it got there (FR24 takes some of its
    // picture URLs verbatim): the "cb" size has "© name - JetPhotos" burnt into a band along its bottom. The same picture
    // without "cb" is the clean one.
    (function () {
      var CB = /\/\/cdn\.jetphotos\.com\/\d+cb\//i;
      var CBG = /(\/\/cdn\.jetphotos\.com\/\d+)cb\//gi;
      function fix(img) {
        var s = img.getAttribute('src'), ss = img.getAttribute('srcset');
        if (s && CB.test(s)) { img.setAttribute('src', noBar(s)); stats.cbFixed = (stats.cbFixed || 0) + 1; }
        if (ss && CB.test(ss)) img.setAttribute('srcset', ss.replace(CBG, '$1/'));
      }
      function scan(el) { if (el.tagName === 'IMG') fix(el); else if (el.getElementsByTagName) { var l = el.getElementsByTagName('img'); for (var i = 0; i < l.length; i++) fix(l[i]); } }
      try {
        new MutationObserver(function (recs) {
          for (var i = 0; i < recs.length; i++) {
            var r = recs[i];
            if (r.type === 'attributes') { if (r.target.tagName === 'IMG') fix(r.target); continue; }
            for (var j = 0; j < r.addedNodes.length; j++) if (r.addedNodes[j].nodeType === 1) scan(r.addedNodes[j]);
          }
        }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'srcset'] });
      } catch (e) { /* ignore */ }
    })();
    // ---- "Playback" of a flight FR24 blocks: its ADS-B track on airplanes.live ---------------------------------------------
    // A blocked flight's own Playback - on an airport board's card (today's rows and the days kept from before), in its
    // panel (the action row and the More menu), on a search result, on a row of a rebuilt log - finds nothing on FR24,
    // which has no record of the flight and shows the flight's log page instead. Here it opens the flight's track on
    // airplanes.live, in a new tab: from three minutes before it took off to a few minutes after it landed (or until now).
    // Every other Playback - FR24's own flights, and the bottom bar's, which opens FR24's own playback window - is FR24's
    // alone: nothing outside a flight's card, panel, search result or log row is ever taken.
    var PB_BAR = ['Settings', 'Weather', 'Filters', 'Widgets', 'Playback'];
    var pbText = function (el) { return String((el && el.textContent) || '').replace(/\s+/g, ' ').trim(); };
    var pbWord = function (s) { return /^playback\b/i.test(String(s || '').trim()); };
    var regKey = function (s) { return String(s || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); };
    var isHex = function (h) { return /^[0-9a-f]{6}$/i.test(String(h || '')); };
    // (FR24's bottom bar: its row of options - Settings, Weather, Filters, Widgets, Playback - with LADD Unblock's button)
    function inBar(el) {
      for (var a = el, d = 0; a && a.nodeType === 1 && a !== document.body && d < 7; a = a.parentElement, d++) {
        if (a.classList.contains('tl-ub-btn') || /^map-bar/i.test(a.getAttribute('data-testid') || '')) return true;
        var kids = a.children, n = 0; if (kids.length < 4 || kids.length > 14) continue;
        for (var i = 0; i < kids.length; i++) if (kids[i].classList.contains('tl-ub-btn') || PB_BAR.indexOf(pbText(kids[i])) >= 0) n++;
        if (n >= 4) return true;
      }
      return false;
    }
    // (the Playback action clicked: its words - "Playback", "Playback - N600EB" - its label or its test id; the outermost
    // element that is only that)
    function pbAct(t) {
      for (var a = t, d = 0; a && a.nodeType === 1 && a !== document.body && d < 6; a = a.parentElement, d++) {
        var tx = pbText(a);
        if (/playback/i.test(a.getAttribute('data-testid') || '') || (pbWord(tx) && tx.length <= 40) || (!tx && (pbWord(a.getAttribute('aria-label')) || pbWord(a.getAttribute('title'))))) {
          var top = a; while (top.parentElement && top.parentElement !== document.body && pbText(top.parentElement) === tx && !/playback/i.test(top.getAttribute('data-testid') || '')) top = top.parentElement;
          return top;
        }
        if (tx.length > 60) return null;
      }
      return null;
    }
    // (a blocked aircraft's flight of this session, by its registration: [id, rec], the one heard last)
    function knownByReg(reg) { reg = regKey(reg); var hit = null; if (!reg) return null; resolved.forEach(function (r, k) { if (r && r.reg && regKey(r.reg) === reg && (!hit || (lastPos.get(k) || {}).at > (lastPos.get(hit[0]) || {}).at)) hit = [k, r]; }); return hit; }
    // (the blocked aircraft and callsigns the userscript named in a search - its own rows - and FR24's own aircraft rows
    // its register lookup says are blocked: a search result of one not flying now is known for one)
    var pbBlk = new Map();
    function pbBlkNote(kind, key, hex) { key = regKey(key); if (!key) return; pbBlk.set(kind + ':' + key, isHex(hex) ? String(hex).toLowerCase() : (pbBlk.get(kind + ':' + key) || '')); if (pbBlk.size > 3000) pbBlk.delete(pbBlk.keys().next().value); }
    // (FR24's board rows and the cards opened from them, by row id: their times, their two ends, their flight)
    var boardRowsSeen = new Map(), cardInfo = new Map();
    // (1.2.6) FR24's own rows - of any flight - with no other airport ("N/A"): that end from the flight's own track, found
    // by the userscript (06-boards onNeedEnds) once per flight and put in at once every time after; FR24's re-read of the
    // board shows those found meanwhile. An arrival's origin once it is under way; a departure's destination once down.
    var naEnds = new Map(), naEndsAsked = new Map(), naEndsAp = new Map();   // "fid:0|1" -> airport id (0: none found); airport id -> its name, codes (data pages)
    // (an airport data page's rows - FR24's own, "N/A" where the flight came from or went: that end as found, in the form
    // its rows give it; asked for as on the map's boards)
    function mxDataEnds(rows, kind, apId) {
      if (!Array.isArray(rows) || kind === 'onGround' || kind === 'on-ground') return 0;
      var n = 0, ask = [], nowS = Date.now() / 1000, end = kind === 'departures' ? 1 : 0;
      rows.forEach(function (r) {
        if (!r || r.__tl || (r.endpoint && (r.endpoint.iata || r.endpoint.icao || r.endpoint.name))) return;
        var fid = mxFidHex(r.flightId); if (!/^[0-9a-f]{5,8}$/.test(fid)) return;
        var st = String((r.status && r.status.name) || '').toLowerCase(), t = Number(r.estimatedTime || r.scheduledTime) || 0;
        if (!t || /cancel|scheduled/.test(st)) return;
        var k = fid + ':' + end, v = naEnds.get(k), a = v > 0 ? naEndsAp.get(v) : null;
        if (a) { r.endpoint = { name: a.name || '', city: a.city || '', iata: a.iata || null, icao: a.icao || null, countryId: a.countryId || 0, countryName: a.countryName || '' }; n++; return; }
        if (end === 0 ? !/landed|estimated|delayed|diverted/.test(st) : !(/departed|landed/.test(st) && t < nowS - 1200)) return;
        if (v === 0 || Date.now() - (naEndsAsked.get(k) || 0) < 10 * 60000) return;
        ask.push({ fid: fid, end: end, t: t, k: k });
      });
      if (ask.length) {
        ask = ask.slice(0, 15); ask.forEach(function (x) { naEndsAsked.set(x.k, Date.now()); });
        post('needEnds', { apId: apId, list: ask.map(function (x) { return { fid: x.fid, end: x.end, t: x.t }; }) });
      }
      return n;
    }
    function naEndsFill(rows, kind, apId) {
      if (kind === 'on-grounds' || !Array.isArray(rows)) return 0;
      var n = 0, ask = [], nowS = Date.now() / 1000, end = kind === 'departures' ? 1 : 0;
      rows.forEach(function (e) {
        if (!e || e.airportId || !e.flight || !e.flight.id) return;
        // (a row of this script's own - one it follows, one kept with an id made up here - has its ends from elsewhere)
        if (e.__tlAdded && !e.__tlArch) return; var ar = e.__tlArch ? archById.get(e.id) : null; if (ar && ar.own) return;
        var fid = mxFidHex(e.flight.id); if (!/^[0-9a-f]{5,8}$/.test(fid)) return;
        var st = String((e.status && e.status.name) || '').toLowerCase(), t = Number(e.estimatedTime || e.scheduledTime) || 0;
        if (/cancel|scheduled/.test(st) || !t) return;
        var k = fid + ':' + end, v = naEnds.get(k);
        if (v > 0) { e.airportId = v; n++; return; }
        // (under way: an arrival's take-off long enough ago for it to have one; a departure's landing - 20 minutes and more)
        if (end === 0 ? !/landed|estimated|delayed|diverted/.test(st) : !(/departed|landed/.test(st) && t < nowS - 1200)) return;
        if (v === 0 || Date.now() - (naEndsAsked.get(k) || 0) < 10 * 60000) return;
        ask.push({ fid: fid, end: end, t: t, k: k });
      });
      if (ask.length) {
        ask.sort(function (a, b) { return Math.abs(nowS - a.t) - Math.abs(nowS - b.t); }); ask = ask.slice(0, 15);
        ask.forEach(function (x) { naEndsAsked.set(x.k, Date.now()); }); if (naEndsAsked.size > 5000) naEndsAsked.delete(naEndsAsked.keys().next().value);
        post('needEnds', { apId: apId, list: ask.map(function (x) { return { fid: x.fid, end: x.end, t: x.t }; }) });
      }
      return n;
    }
    function onEndsGot(d) {
      var found = 0;
      // (none found: kept as none only when that is final - the flight's track has that end; else asked again in 10 minutes)
      (d && Array.isArray(d.list) ? d.list : []).forEach(function (x) { if (x && /^[0-9a-f]{5,8}:[01]$/.test(x.k || '')) { var ap = Number(x.ap) > 0 ? Number(x.ap) : 0; if (ap || x.fin) naEnds.set(x.k, ap); if (ap && x.a && typeof x.a === 'object') naEndsAp.set(ap, x.a); if (ap) found++; } });
      while (naEnds.size > 5000) naEnds.delete(naEnds.keys().next().value);
      if (found) { mx.naEnds = (mx.naEnds || 0) + found; refreshBoardSoon(); }
    }
    function noteBoardRows(rows, apId, kind) {
      (rows || []).forEach(function (e) { if (e && e.id) boardRowsSeen.set(Number(e.id), { fid: e.flight && e.flight.id ? String(e.flight.id) : '', t: Number(e.estimatedTime) || Number(e.scheduledTime) || 0, st: e.status && e.status.name || '', ap: Number(e.airportId) || 0, apId: apId, kind: kind }); });
      while (boardRowsSeen.size > 6000) boardRowsSeen.delete(boardRowsSeen.keys().next().value);
    }
    function noteCard(row, apId, kind, d) {
      if (!row || !d) return; var s = d.schedule || {};
      var cHex = ''; try { cHex = mxRowHex({ id: Number(row), flight: d.flight }); } catch (e) { cHex = ''; }
      cardInfo.set(Number(row), { fid: d.flight && d.flight.id ? String(d.flight.id) : '', reg: (d.aircraft && d.aircraft.registration) || '', atd: Number(s.atd) || 0, ata: Number(s.ata) || 0, o: Number(d.originId) || 0, dst: Number(d.destinationId) || 0, apId: apId, kind: kind, hex: cHex });
      if (cardInfo.size > 600) cardInfo.delete(cardInfo.keys().next().value);
    }
    var fidNum = function (s) { s = String(s || ''); return /^[0-9a-f]{5,8}$/i.test(s) ? parseInt(s, 16) : 0; };
    // (the flight open in the panel: the one FR24's playback has selected, else the live one followed)
    function pbIdOf(s) { if (typeof s === 'number') return s; s = String(s == null ? '' : s); if (!s) return 0; if (/^\d+$/.test(s) && resolved.has(Number(s))) return Number(s); return /^[0-9a-f]{1,8}$/i.test(s) ? parseInt(s, 16) : 0; }
    // (and the panel clicked in shows that flight: its header's callsign or registration, where it has one - not a blocked
    // flight followed earlier, with this panel some other aircraft's)
    function panelIs(el, id) {
      var box = el.closest('[data-testid="aircraft-panel"]') || document, h = box.querySelector('[data-testid="aircraft-panel__header__callsign"]');
      var k = function (s) { return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }, txt = h ? k(h.textContent) : '';
      if (!txt || txt === 'NA') return true;
      var rec = resolved.get(id) || {}, cs = k(csOf(rec)), reg = k(rec.reg);
      return (!!cs && txt.indexOf(cs) >= 0) || (!!reg && txt.indexOf(reg) >= 0) || (!!rec.cs && txt.indexOf(k(rec.cs)) >= 0);
    }
    function panelFlightId() { if (pbOn()) { var st = pinStore('playback'), n = st ? pbIdOf(st.selectedFlightId) : 0; if (n) return n; } return curFollowId; }
    // What is known here of a flight followed this session: its take-off and the field it left (or where it was first
    // heard), and where it is now
    function liveWant(id) {
      var rec = resolved.get(id) || {}, r = (pbOn() && pbRoutes.get(id)) || routeNow(id) || {};
      var dep = Number(r.atd) || Number(r.departedAt) || Number(r.t0) || 0, nowS = Math.floor(Date.now() / 1000);
      // (a flight that has landed: to its landing; else until now - and with no take-off known, three hours back)
      return { id: id, hex: rec.hex || r.hex || '', reg: rec.reg || '', cs: csOf(rec), dep: dep || nowS - 3 * 3600, end: r.landed && Number(r.ata) > 0 ? Number(r.ata) : nowS, depAp: Number(r.originId) || 0 };
    }
    // (a row of the panel's recent flights: our entry of it - a flight of a rebuilt log - or null for one of FR24's own)
    function logEntry(li) {
      var box = li.closest('[data-testid^="aircraft-panel"]') || document;
      var more = box.querySelector('[data-testid="aircraft-panel__recent-flights__more-flights-button"]') || document.querySelector('[data-testid="aircraft-panel__recent-flights__more-flights-button"]');
      var m = more && (more.getAttribute('href') || '').match(/\/data\/aircraft\/([^\/#?]+)/i); if (!m || !li.parentElement) return null;
      var h = hist.get(decodeURIComponent(m[1]).toUpperCase()); if (!h || !Array.isArray(h.data)) return null;
      var e = h.data[[].indexOf.call(li.parentElement.children, li) + 1];
      return e && (e.__tlPb || e.__tlTrace) ? e : null;
    }
    function rowIdOf(card) { var m = String(card.id || card.getAttribute('data-testid') || '').match(/(\d+)$/); return m ? Number(m[1]) : 0; }
    function regOfCard(card) {
      var el = card.querySelector('[data-testid="airport-flight-details__registration"]'); if (el && regKey(el.textContent)) return pbText(el).toUpperCase();
      var regs = []; [].forEach.call(card.querySelectorAll('a[href*="/data/aircraft/"]'), function (a) { var m = (a.getAttribute('href') || '').match(/\/data\/aircraft\/([^\/#?]+)/i); if (m && regs.indexOf(decodeURIComponent(m[1]).toUpperCase()) < 0) regs.push(decodeURIComponent(m[1]).toUpperCase()); });
      return regs.length === 1 ? regs[0] : '';
    }
    // A board row: one this script put there (a blocked flight it follows, 9,000,000,000 + its id; a flight it kept from
    // its own logs), FR24's own row of a blocked flight (followed here, or kept as a blocked aircraft's), or one of an
    // aircraft named blocked here. Its take-off - the card's, the row's own on a departures board, its other end's on an
    // arrivals one - and the field it left; and the row's own time at this airport, should the take-off not be known.
    function boardWant(card) {
      var row = rowIdOf(card); if (!row) return null;
      if (row >= 9000000000 && row < 20000000000) { var sid = row - 9000000000; return resolved.has(sid) ? liveWant(sid) : null; }
      var br = boardRowsSeen.get(row) || {}, cd = cardInfo.get(row) || {}, ar = archById.get(row) || null, r = (ar && ar.r) || {}, ni = natInfo.get(row) || null;
      // (the flight id made up here for a row of this script's own - in its card and board answers too - is not FR24's)
      var fsAll = String(cd.fid || br.fid || r.fid || (ar && ar.fid) || ''), fs0 = fsAll; if (ar && ar.own && fs0.toLowerCase() === String(ar.fid).toLowerCase()) fs0 = '';
      var fid = fidNum(fs0);
      if (fid && resolved.has(fid)) return liveWant(fid);
      // (1.2.6: a flight id of this script's own - "ff", the aircraft's address, its take-off - is always ours, whatever
      // the aircraft: FR24's own Playback opens the aircraft's page by the card's registration, and with none its list of
      // aircraft types, /data/aircraft/#ff... 1.2.8: read before a row of this script's own has its id set aside - G-RVNX,
      // an ordinary Piper on Liverpool's board from the monitor's log, went to FR24's list of aircraft types)
      var syn = MX_PB_SYN.test(fsAll.toLowerCase()) ? fsAll.toLowerCase() : '', synDep = syn ? parseInt(syn.slice(8), 16) || 0 : 0;
      var reg = String(r.reg || cd.reg || (ni && ni.reg) || regOfCard(card) || '').toUpperCase(), kr = knownByReg(reg);
      // (a row of this script's own: FR24 has no playback of it, whatever the aircraft)
      var ours = !!(syn || (ar && ar.own) || r.blk || (ni && ni.blk) || (ar && row >= 20000000000 && !r.fid) || kr || (reg && pbBlk.has('A:' + regKey(reg))));
      if (!ours) return null;
      var kind = (ar && ar.kind) || br.kind || cd.kind || '', apId = (ar && ar.apId) || br.apId || cd.apId || 0, dep = kind === 'departures';
      var other = Number(r.ap) || br.ap || (dep ? cd.dst : cd.o) || 0, tRow = Number(r.t) || br.t || 0, t2 = Number(r.t2) || 0;
      if (!t2 && ar && r.ap && boardArch.has(Number(r.ap))) { var o = boardArch.get(Number(r.ap)), mm = (dep ? o.arr : o.dep).filter(function (x) { return x && x.k === r.k; })[0]; if (mm) t2 = Number(mm.t) || 0; }
      var depT = synDep || cd.atd || (dep ? tRow : t2), depAp = dep ? apId : other;
      return { id: fid, hex: (isHex(r.hex) && r.hex) || (ni && isHex(ni.hex) && ni.hex) || (kr && kr[1].hex) || pbBlk.get('A:' + regKey(reg)) || (syn && syn.slice(2, 8)) || '', reg: reg, cs: r.cs || '', kind: kind, apId: apId,
        dep: depT, end: dep ? (t2 > depT ? t2 : 0) : (cd.ata || tRow), depAp: depAp, at: dep ? 0 : (cd.ata || tRow), atAp: apId };
    }
    // A search result: a blocked flight followed here (live), or a blocked aircraft or a callsign of one - the userscript
    // finds its flight (06-playback)
    function searchWant(row) {
      var key = row.querySelector('[data-search-result]'), m = /^([a-z]+):(.+)$/i.exec(key ? String(key.getAttribute('data-search-result') || '') : ''); if (!m) return null;
      var type = m[1].toLowerCase(), v = m[2];
      if (type === 'live') { var lid = parseInt(v, 16); return lid && resolved.has(lid) ? liveWant(lid) : null; }
      if (type === 'aircraft') { var k = knownByReg(v); if (k) return liveWant(k[0]); return pbBlk.has('A:' + regKey(v)) ? { reg: v.toUpperCase(), hex: pbBlk.get('A:' + regKey(v)) } : null; }
      var cs = regKey(v), hit = 0; resolved.forEach(function (rec, id) { if (csOf(rec) === cs && (!hit || (lastPos.get(id) || {}).at > (lastPos.get(hit) || {}).at)) hit = id; });
      if (hit) return liveWant(hit);
      return pbBlk.has('C:' + cs) ? { cs: cs, hex: pbBlk.get('C:' + cs) } : null;
    }
    // The Playback clicked, when it is a blocked flight's: { w: what is known of the flight } - or null, FR24's own
    function pbFind(t) {
      if (!t.closest('[id^="airport_schedule_"], [data-testid^="airport-panel__schedules__flight__"], [data-testid="search__result-row"], [data-testid^="aircraft-panel"], [data-testid^="aircraft__"], [data-testid*="recent-flights"], li')) return null;
      var top = pbAct(t); if (!top || inBar(top)) return null;
      var w = null, li = top.closest('li');
      if (li && (li.querySelector('[data-testid^="aircraft-panel__recent-flights"]') || li.closest('[data-testid*="recent-flights"]'))) {
        var e = logEntry(li); if (!e) return null;
        var tr = e.time && e.time.real || {}, nowL = Math.floor(Date.now() / 1000);
        w = { hex: String((e.aircraft && e.aircraft.hex) || '').toLowerCase(), reg: (e.aircraft && e.aircraft.registration) || '', dep: Number((e.__tlPb || {}).t) || Number(tr.departure) || 0,
          end: Number(tr.arrival) || (e.status && e.status.live ? nowL : 0) };
      } else {
        var card = top.closest('[id^="airport_schedule_"], [data-testid^="airport-panel__schedules__flight__"]'), sr = card ? null : top.closest('[data-testid="search__result-row"]');
        if (card) w = boardWant(card);
        else if (sr) w = searchWant(sr);
        else if (top.closest('[data-testid^="aircraft-panel"], [data-testid^="aircraft__"]')) { var pid = panelFlightId(); w = pid && resolved.has(pid) && panelIs(top, pid) ? liveWant(pid) : null; }
      }
      return w ? { w: w, el: top } : null;
    }
    // (nothing known of the aircraft: FR24's own Playback after all - the click given back to it)
    var pbBypass = null;
    function pbFallback(t, newTab) {
      if (newTab) { var a = t.closest('a[href]'); if (a) window.open(a.href, '_blank', 'noopener'); return; }
      pbBypass = t; try { t.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); } catch (e) { /* ignore */ } finally { pbBypass = null; }
    }
    function onPbClick(ev) {
      if (pbBypass || (ev.type === 'auxclick' && ev.button !== 1) || (ev.type === 'click' && ev.button)) return;
      var t = ev.target && ev.target.nodeType === 1 ? ev.target : ev.target && ev.target.parentElement; if (!t || !t.closest) return;
      var hit = null; try { hit = pbFind(t); } catch (e) { stats.errors++; stats.lastError = String(e); }
      if (!hit) return;
      ev.preventDefault(); ev.stopImmediatePropagation();
      var w = hit.w, newTab = ev.type === 'auxclick' || ev.ctrlKey || ev.metaKey || ev.shiftKey;
      // (1.2.4: FR24's own player with the flight's track - 06-pbpage; no longer airplanes.live's)
      stats.pbOpened = (stats.pbOpened || 0) + 1;
      mxPbOpen(w, t, newTab);
    }
    document.addEventListener('click', onPbClick, true);
    document.addEventListener('auxclick', onPbClick, true);
    window.addEventListener('message', function (ev) {
      if (ev.source !== window || !ev.data || typeof ev.data !== 'object') return;
      var d = ev.data;
      if (d.__tweeksLadd === 'resolve') acceptEntries(d.entries);
      else if (d.__tweeksLadd === 'revoke') { for (var i = 0; i < (d.ids || []).length; i++) { resolved.delete(Number(d.ids[i])); routes.delete(Number(d.ids[i])); telem.delete(Number(d.ids[i])); } }
      else if (d.__tweeksLadd === 'route') { if (d.id != null) { if (d.route) routes.set(Number(d.id), d.route); else routes.delete(Number(d.id)); if (followSt && Number(d.id) === followSt.id) pushFollowSoon(); if (boardAffected([d.id])) refreshBoardSoon(); } }
      else if (d.__tweeksLadd === 'routesGot') onRoutesGot(d);
      else if (d.__tweeksLadd === 'topGot') onTopGot(d);
      else if (d.__tweeksLadd === 'lastSq') onLastSq(d);
      else if (d.__tweeksLadd === 'rwyGot') onRwyGot(d);
      else if (d.__tweeksLadd === 'endsGot') onEndsGot(d);
      else if (d.__tweeksLadd === 'rwyApGot') onRwyApGot(d);
      else if (d.__tweeksLadd === 'ogGot') onOgGot(d);
      else if (d.__tweeksLadd === 'rwyUseGot') onRwyUseGot(d);
      else if (d.__tweeksLadd === 'apWxGot') onApWxGot(d);
      else if (d.__tweeksLadd === 'trackFileGot') onTrackFileGot(d);
      else if (d.__tweeksLadd === 'pbPageGot') onPbPageGot(d);
      else if (d.__tweeksLadd === 'pbInfoGot') onPbInfoGot(d);
      else if (d.__tweeksLadd === 'ctyTable') onCtyTable(d);
      else if (d.__tweeksLadd === 'routes') { (d.list || []).forEach(function (x) { if (x && x.id != null) { if (x.route) routes.set(Number(x.id), x.route); else routes.delete(Number(x.id)); if (followSt && Number(x.id) === followSt.id) pushFollowSoon(); } }); if (boardAffected((d.list || []).map(function (x) { return x && x.id; }))) refreshBoardSoon(); }
      // (where flights FR24 is not drawing here were last: the monitor's - the boards of every airport list them)
      else if (d.__tweeksLadd === 'positions') {
        var chp = [];
        (d.list || []).forEach(function (x) { if (x && x.id != null && x.pos && fin(x.pos.lat)) { var k = Number(x.id), lp0 = lastPos.get(k); if (!lp0 || lp0.at < x.pos.at) { lastPos.set(k, x.pos); chp.push(k); } } });
        if (chp.length && boardAffected(chp)) refreshBoardSoon();
      }
      else if (d.__tweeksLadd === 'naBoard') {
        var ch = [];
        (d.list || []).forEach(function (x) { if (x && x.id != null && x.rec && x.route) { var k = Number(x.id); naRecs.set(k, x.rec); naRoutes.set(k, x.route); if (x.pos && (!lastPos.has(k) || lastPos.get(k).at < x.pos.at)) lastPos.set(k, x.pos); ch.push(x.id); } });
        (d.drop || []).forEach(function (id) { naRecs.delete(Number(id)); naRoutes.delete(Number(id)); ch.push(id); });
        if (ch.length && boardAffected(ch)) refreshBoardSoon();
      }
      // (new public telemetry of the flight open in the panel: drawn now, not at FR24's next frame)
      else if (d.__tweeksLadd === 'telem') { if (d.id != null && d.t) { var tt = Object.assign({ at: Date.now() }, d.t); telem.set(Number(d.id), tt); noteTelem(Number(d.id), tt); if (followSt && Number(d.id) === followSt.id) pushFollowSoon(); } }
      else if (d.__tweeksLadd === 'pubTel') acceptPubTel(d.rows);
      else if (d.__tweeksLadd === 'airRows') acceptAir(d.rows);
      else if (d.__tweeksLadd === 'sites') acceptSites(d.list);
      else if (d.__tweeksLadd === 'oaRows') acceptOa(d);
      else if (d.__tweeksLadd === 'oaIs') acceptOaOne(d);
      else if (d.__tweeksLadd === 'oaFrom') acceptOaFrom(d);
      else if (d.__tweeksLadd === 'oaFound') acceptOaFound(d);
      else if (d.__tweeksLadd === 'oaDirGot') acceptOaDir(d);
      else if (d.__tweeksLadd === 'acDirGot') acceptAcDir(d);
      else if (d.__tweeksLadd === 'acPageGot') acceptAcPage(d);
      else if (d.__tweeksLadd === 'acFrom') acceptAcFrom(d);
      else if (d.__tweeksLadd === 'pbRoute') { if (d.id != null) { var prId = Number(d.id); if (!d.none) { if (d.route) pbRoutes.set(prId, d.route); else pbRoutes.delete(prId); if (pbRoutes.size > 3000) pbRoutes.delete(pbRoutes.keys().next().value); } pbRouteDone.add(prId); if (pbRouteDone.size > 3000) pbRouteDone.delete(pbRouteDone.values().next().value); pbRelease(); } }
      else if (d.__tweeksLadd === 'pbTrace') { if (d.id != null && Array.isArray(d.pts)) { pbTrace = { id: Number(d.id), hex: d.hex || '', pts: d.pts }; pbRelease(); } }
      else if (d.__tweeksLadd === 'routesAdd') { if (d.apId) { routesAdd.set(Number(d.apId), d.list || []); keepApData(Number(d.apId)); routesTick(); } }
      else if (d.__tweeksLadd === 'airportPanel') acceptAirportPanel(d);
      else if (d.__tweeksLadd === 'searchAdd') onSearchAdd(d);
      else if (d.__tweeksLadd === 'airportData') { if (d.apId) { var ad = apDataOf(Number(d.apId)); if (d.runways) ad.runways = d.runways; if (Array.isArray(d.closest)) ad.closest = d.closest; if (Array.isArray(d.oa)) d.oa.forEach(function (o) { acceptOaOne(o, true); }); if (d.board) ad.board = d.board; if (d.stats && typeof d.stats === 'object') ad.stats = Object.assign({ at: Date.now() }, d.stats); keepApData(Number(d.apId)); routesTick(); } }
      else if (d.__tweeksLadd === 'hist') {
        var reg = String(d.reg || '').toUpperCase(); if (!reg) return;
        if (d.data) hist.set(reg, { data: d.data, at: Date.now(), partial: !!d.partial });
        // a first answer that is still loading and has nothing to list yet (FR24 hides the first entry, the flight on
        // screen) is not handed over: FR24 draws the list once, so it waits for the full log instead
        if (d.partial && !(d.data && d.data.length > 1)) return;
        var w = histWait.get(reg) || []; histWait.delete(reg); w.forEach(function (fn) { try { fn(hist.get(reg) || null); } catch (e) { /* ignore */ } });
      }
      else if (d.__tweeksLadd === 'boardArch') acceptBoardArch(d);
      else if (d.__tweeksLadd === 'mxGot') mxGotMsg(d);
      else if (d.__tweeksLadd === 'needTrail') bgFollowTrail(Number(d.id) || 0);
      else if (d.__tweeksLadd === 'pubIds') { (d.rows || []).forEach(function (r) { if (r && r[0]) pubIds.set(String(r[0]).toUpperCase(), { o: r[1] || '', a: Number(r[2]) || 0, m: r[3] || '', c: Number(r[4]) || 0 }); }); if (pubIds.size > 30000) { var drop = pubIds.size - 25000; pubIds.forEach(function (v, k) { if (drop-- > 0) pubIds.delete(k); }); } }
      else if (d.__tweeksLadd === 'photoReq') { if (d.hex) fetchPhotos(d.hex, d.reg, !!d.pri); }
      // (OpenStreetMap's Overpass answers a browser's own request; the userscript asks it through here)
      else if (d.__tweeksLadd === 'osmReq') { if (d.key && /^https:\/\/overpass-api\.de\/api\/interpreter\?data=/.test(String(d.url || ''))) oFetch.call(window, d.url).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) { post('osmRes', { key: d.key, j: j }); }, function () { post('osmRes', { key: d.key, j: null }); }); }
      else if (d.__tweeksLadd === 'photosDone') acceptPhotosDone(d);
      // (what the two networks' trace files answered this browser lately - __tweeksLaddBridge.stats.net in the console)
      else if (d.__tweeksLadd === 'netDiag') { if (d.net && typeof d.net === 'object') stats.net = d.net; }
      else if (d.__tweeksLadd === 'scan') runScan(d.regions || [], d.opts || {});
      // (the health check's figures - the extension's script runs in its own world and cannot read this one's objects)
      else if (d.__tweeksLadd === 'stats?') post('stats', { stats: stats });
      else if (d.__tweeksLadd === 'opts') { if (d.opts && typeof d.opts === 'object') opts = d.opts; }
      else if (d.__tweeksLadd === 'hello') post('ready', { oaWant: oaWant, stats: stats, feedReady: !!feedHeaders, hdr: feedHdrPublic(), v: BRIDGE_V });
    });
    // ---- (1.3.10) FR24's Android app ---------------------------------------------------------------------------------
    // The module (android/) runs this script in a page of its own inside FR24's app, and hands FR24's gRPC messages here as
    // the app's own code reads and writes them - each the bare message, where the website's come framed: the same patching
    // as the website's, on the same messages. req(method, bytes): a request on its way out; resp(method, bytes): an answer
    // before FR24's code reads it. Each gives the bytes back changed or as they came; never throws.
    if (window.TL_MOBILE) window.__tlApp = (function () {
      var follows = new Map(), lastReq = {};
      var framed = function (b) { return concat([frameHeader(0, b.length), b]); };
      var unframed = function (u) { if (!u || u.length < 5 || u[0] !== 0) return null; var len = ((u[1] << 24) | (u[2] << 16) | (u[3] << 8) | u[4]) >>> 0; return 5 + len <= u.length ? u.subarray(5, 5 + len) : null; };
      // (a flight's answer names its flight: ExtendedFlightInfo's field 1 - FollowFlight's 5, FlightDetails' 4)
      var efiId = function (b, F) { try { var f = find(parse(b), F.efi); return f && f.wt === 2 ? numOf(parse(f.val), 1) : 0; } catch (e) { return 0; } };
      function req(method, b) {
        try {
          var fb = framed(b), out = fb;
          if (method === 'LiveFeed') { out = patchLiveFeedRequest(fb); stats.mobileReq = (stats.mobileReq || 0) + 1; }
          else if (method === 'FollowFlight' || method === 'FlightDetails') {
            var id = followIdFromBody(fb); lastReq[method] = { id: id };
            if (method === 'FollowFlight') { stats.follow++; curFollowId = id; post('follow', { id: id }); follows.set(id, { id: id }); if (follows.size > 24) follows.delete(follows.keys().next().value); }
            else stats.flightDetails++;
            out = stripRestriction(fb);
          } else if (method === 'Playback') { lastReq.Playback = { ts: tsOf(fb) }; out = patchPlaybackRequest(fb); }
          if (out === fb) return b;
          return unframed(bodyBytes(out)) || b;
        } catch (e) { stats.errors++; stats.lastError = String(e); return b; }
      }
      function resp(method, b) {
        try {
          if (method === 'LiveFeed') return patchLiveFeed(b, false);
          if (method === 'TopFlights') return patchTopFlights(b);
          if (method === 'Playback') return patchPlayback(b, (lastReq.Playback || {}).ts || 0);
          if (method === 'FollowFlight' || method === 'FlightDetails') {
            var F = method === 'FollowFlight' ? FOLLOW : DETAILS, id = efiId(b, F) || (lastReq[method] || {}).id || 0, st;
            if (F.follow) { st = follows.get(id); if (!st) { st = { id: id }; follows.set(id, st); } } else st = { id: id };
            return patchFlightMsg(b, st, F);
          }
        } catch (e) { stats.errors++; stats.lastError = String(e); }
        return b;
      }
      return { req: req, resp: resp, stats: function () { return stats; }, v: 1 };
    })();
    window[NS] = { resolved: resolved, routes: routes, naRecs: naRecs, naRoutes: naRoutes, telem: telem, hist: hist, lastPos: lastPos, photoCache: photoCache, psCache: psCache, stats: stats, fetchPhotos: fetchPhotos, hello: function () { post('ready', { oaWant: oaWant, stats: stats, feedReady: !!feedHeaders, v: BRIDGE_V }); }, v: BRIDGE_V };
    if (window.__tlTestHook) try { window.__tlTestHook({ iconNote: iconNote, iconFor: iconFor, mxPbFlightMsg: mxPbFlightMsg, mxPbTag: mxPbTag, mxPbRunways: mxPbRunways, mxPbBadges: mxPbBadges, noteCard: noteCard, mxPbVeilOn: mxPbVeilOn, mxPbVeilOff: mxPbVeilOff, mxPbLogId: mxPbLogId, mxPbLinkId: mxPbLinkId, mxPbEnrich: mxPbEnrich, mxPbInfo: mxPbInfo, mxPbBackLabel: mxPbBackLabel, mxPbBackTo: mxPbBackTo, mxSec: mxSec, mxPbEndPts: mxPbEndPts, csOf: csOf, patchTopFlights: patchTopFlights, onTopGot: onTopGot, topNames: topNames, fillFlightList: fillFlightList, routeRows: routeRows, liveDestFix: liveDestFix, hist: hist, preloaded: function () { return preloaded; }, parse: parse, photoFits: photoFits, makerOf: makerOf, patchFollow: patchFollow, patchFlightMsg: patchFlightMsg, pushFollow: pushFollow, followSt: function () { return followSt; }, setFollowSt: function (s) { followSt = s; }, shownPhotos: shownPhotos, photoCache: photoCache, FOLLOW: FOLLOW, DETAILS: DETAILS, fLen: fLen, fStr: fStr, fVar: fVar, patchFlight: patchFlight, patchLiveFeed: patchLiveFeed, fr24Named: fr24Named, psState: function () { return { q: psQ.length, busy: psBusy, last: psLast, blockedFor: Math.max(0, psBlockedUntil - Date.now()), pri: Array.from(psPri), jobs: photoJobs.size, head: psQ.slice(0, 3).map(function (j) { return j.hex; }) }; }, acceptPubTel: acceptPubTel, pubTelFor: pubTelFor, fillNativeCard: fillNativeCard, regsOfCallsign: regsOfCallsign, categoryOf: categoryOf, placeShort: placeShort, nativeFill: nativeFill, natInfo: natInfo, addArch: addArch, acceptBoardArch: acceptBoardArch, telem: telem, b64Encode: b64Encode, b64DecodeInto: b64DecodeInto, frameHeader: frameHeader, concat: concat, varintInt32: varintInt32, PLAYBACK: PLAYBACK, patchPlayback: patchPlayback, patchPlaybackRequest: patchPlaybackRequest, pbRoutes: pbRoutes, pbTelAt: pbTelAt, setPbTrace: function (t) { pbTrace = t; }, patchList: patchList, acceptSites: acceptSites, listSig: listSig, mergeRoutes: mergeRoutes, applyRoutes: applyRoutes, routesAdd: routesAdd, applyAirport: applyAirport, applyBoardPage: applyBoardPage, applyStats: applyStats, mergeFlights: mergeFlights, apData: apData, telAt: telAt, noteTelem: noteTelem, pbTraceOf: function () { return pbTrace; }, logoOf: logoOf, archDetail: archDetail, tsOf: tsOf, noteAirportJson: noteAirportJson, rwyOf: rwyOf, rwyPanel: rwyPanel, panelTick: panelTick, panelData: panelData, promoSlots: promoSlots, acceptAirportPanel: acceptAirportPanel, unlockRunways: unlockRunways, mvRows: mvRows, mvKept: mvKept, dayOf: dayOf, pbPanelTick: pbPanelTick, logoFix: logoFix, liveEntries: liveEntries, pbPos: pbPos, unlockFeed: unlockFeed, derivedVs: derivedVs, altHist: altHist, acceptAir: acceptAir, airCache: airCache, flushAir: flushAir, airWant: function () { return airWant; }, lastPos: lastPos, resolved: resolved, stats: stats, pbFind: pbFind, inBar: inBar, pbBlk: pbBlk, cardInfo: cardInfo, boardRowsSeen: boardRowsSeen, archById: archById, placeBoard: placeBoard, stopBoardHold: stopBoardHold, needBoardArch: needBoardArch, mx: mx, mxPatchCore: mxPatchCore, mxAuth: mxAuth, mxNatList: mxNatList, mxTrackOk: mxTrackOk, stripRestriction: stripRestriction, mxBmMerge: mxBmMerge, mxBmItem: mxBmItem, mxMonTile: mxMonTile, mxMonOr: mxMonOr, mxPinVer: mxPinVer, mxAirportHistory: mxAirportHistory, mxHistItems: mxHistItems, mxTrackFile: mxTrackFile, mxDataTick: mxDataTick, mxPbProps: mxPbProps, mxPbShow: mxPbShow, mxPbStandIn: mxPbStandIn, mxPbReadAt: mxPbReadAt, mxPbStand: mxPbStand, mxBoardRwy: mxBoardRwy, reqIdOf: reqIdOf, mxPbOpen: mxPbOpen, mxPbTake: mxPbTake, setNav: function (f) { mxNav = f; }, mxPbAway: mxPbAway, mxLegacyPbJson: mxLegacyPbJson, mxLegacyPb: mxLegacyPb, mxPbFlags: mxPbFlags, mxPbSynId: mxPbSynId, mxPbParam: mxPbParam, setPbWanted: function (v) { mxPbWanted = v; }, mxPlans: function () { return mxPlans; }, mxLiveRunways: mxLiveRunways, mxRwy: mxRwy, mxSetApply: mxSetApply, mxSetNote: mxSetNote, mxSetKept: mxSetKept, mxLastClicked: mxLastClicked, mxLcList: mxLcList, onLcClick: onLcClick, mxLcFill: mxLcFill, cardRwy: cardRwy, naEndsFill: naEndsFill, onEndsGot: onEndsGot, naEnds: naEnds, boardWant: boardWant, mxLegacyImages: mxLegacyImages, rwyInUse: rwyInUse, windOfText: windOfText, mxRwyAirport: mxRwyAirport, mxRwyByHex: mxRwyByHex, mxRowHex: mxRowHex, mxDataEnds: mxDataEnds, rwyUsePanel: rwyUsePanel, apWxPanel: apWxPanel, apWxData: apWxData, apWxOf: apWxOf, mxApWxAdd: mxApWxAdd, vsNoLock: vsNoLock, statsUsage: statsUsage, statsMoves: statsMoves, apDataOf: apDataOf, acceptOa: acceptOa, oaAirportJson: oaAirportJson, oaMap: oaMap, oaRefs: fr24Refs, setOaBase: function (b) { oaBase = b; oaShown = 'x'; }, oaStoreRow: oaStoreRow, setViewBox: function (b) { viewBox = b; }, oaView: oaView, sunTimes: sunTimes, tzText: tzText, panelCodeFields: panelCodeFields, oaLinkPressed: oaLinkPressed, oaRefHref: oaRefHref, acceptOaOne: acceptOaOne, oaLost: function () { return oaLost; }, acceptOaFrom: acceptOaFrom, oaCodeLine: oaCodeLine, noteFr24Codes: noteFr24Codes, oaDupe: oaDupe, dirTick: dirTick, acceptOaDir: acceptOaDir, searchMerge: searchMerge, apSearchMerge: apSearchMerge, oaMatchRows: oaMatchRows, oaOneGet: oaOneGet, oaFillTables: oaFillTables, refOf: refOf, fieldShortName: fieldShortName, closestMerge: closestMerge, heliText: heliText, oaFast: function () { return oaFast; }, setOaNav: function (f) { oaNav = f; }, oaWantNow: function () { return oaWant; }, oaApi: oaApi, oaPageReq: oaPageReq, oaPageOf: oaPageOf, acMerge: acMerge, acStrip: acStrip, acMergeAdd: acMergeAdd, acSig: acSig, acDirFastPage: acDirFastPage, dirFastPage: dirFastPage, dirApply: dirApply, dirKeyOf: dirKeyOf, veilOn: veilOn, veilOff: veilOff, mxBmOaWx: mxBmOaWx, apWxFr24: apWxFr24, bmCodesTick: bmCodesTick, oaIataMode: oaIataMode, acPageReq: acPageReq, acPageOf: acPageOf, acPaginator: acPaginator, acTick: acTick, acceptAcDir: acceptAcDir, acceptAcPage: acceptAcPage, acAskPage: acAskPage, acLinkPressed: acLinkPressed, acceptAcFrom: acceptAcFrom, setAcNav: function (f) { acNav = f; }, acAddGet: acAddGet, acRefGet: acRefGet, statsUnlock: statsUnlock, onApWxGot: onApWxGot, mxStat: function () { return mx; }, mxTracksPac: mxTracksPac, mxPacParse: mxPacParse, mxPacots: mxPacots, acLegDir: acLegDir, acLegPage: acLegPage, acLegTick: acLegTick, acMaker: acMaker, acMakers: acMakers, patchListFor: patchList, listRowsFor: listRowsFor, listApCompact: listApCompact, listUnknown: listUnknown, setPac: function (o) { mxPac = { at: Date.now(), o: o }; }, rwyUseData: rwyUseData, rwyUseWant: rwyUseWant, cardRwyFill: cardRwyFill, rwyUseKept: rwyUseKept, mxLcTick: mxLcTick, mxBmMax: mxBmMax, mxNatParse: mxNatParse, mxAirsigList: mxAirsigList, mxStations: mxStations, mxLightning: mxLightning, mxLx: mxLx, mxFetch: mxFetch, mxWxText: mxWxText, mxWxKind: mxWxKind, mxCsv: mxCsv, patchLiveFeedRequest: patchLiveFeedRequest, mxCats: mxCats, mxOp: mxOp, mxLevels: mxLevels, mxNearest: mxNearest, MX_ICE: MX_ICE, MX_TURB: MX_TURB, mxWafsUrl: mxWafsUrl, routes: routes, setCurFollow: function (id) { curFollowId = id; } }); } catch (e) { /* ignore */ }
    post('ready', { oaWant: oaWant, stats: stats, feedReady: false, v: BRIDGE_V });
  }

  pageInterceptor();
})();
